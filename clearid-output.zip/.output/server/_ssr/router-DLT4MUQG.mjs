import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { i as captureTokenFromUrl } from "./argus-client-fTtea6N-.mjs";
import { t as hydrateSettings } from "./supabase-settings-DI2-qLO-.mjs";
import { A as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ensureTechnicalSession, t as Route$20 } from "./foto._token-BdRRslOk.mjs";
import { t as Route$21 } from "./identities._id-DlwPfeR9.mjs";
import { t as Route$22 } from "./identities.new-CV8bAi58.mjs";
import { t as Route$23 } from "./regras-CeYhJ67H.mjs";
import { t as Route$24 } from "./terceirizados._id-D2ukSORI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DLT4MUQG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-g8kBPNYU.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
if (typeof window !== "undefined") captureTokenFromUrl();
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$19 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Argus ClearID — Console R&M" },
			{
				name: "description",
				content: "Console de integração R&M com o Genetec ClearID."
			},
			{
				name: "author",
				content: "R&M"
			},
			{
				property: "og:title",
				content: "Argus ClearID — Console R&M"
			},
			{
				property: "og:description",
				content: "Console de integração R&M com o Genetec ClearID."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$19.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		hydrateSettings();
		const { data: sub } = supabase.auth.onAuthStateChange((event) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			if (event === "SIGNED_IN") hydrateSettings();
			router.invalidate();
			if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
		});
		return () => sub.subscription.unsubscribe();
	}, [router, queryClient]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			richColors: true,
			position: "top-right"
		})]
	});
}
var $$splitComponentImporter$18 = () => import("./routes-DTEZEvkE.mjs");
var Route$18 = createFileRoute("/")({
	beforeLoad: () => {
		throw redirect({ to: "/identities" });
	},
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./route-B_db1DLn.mjs");
var Route$17 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		await ensureTechnicalSession();
	},
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./apelidos-DGJl0RLx.mjs");
var Route$16 = createFileRoute("/_authenticated/apelidos")({
	head: () => ({ meta: [{ title: "Apelidos dos campos — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./branding-B-Lh2fEa.mjs");
var Route$15 = createFileRoute("/_authenticated/branding")({
	head: () => ({ meta: [{ title: "Identidade Visual — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./campanhas-foto-NLQCNIlZ.mjs");
var Route$14 = createFileRoute("/_authenticated/campanhas-foto")({
	head: () => ({ meta: [{ title: "Campanhas de Foto — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./campos-do-site-BU-vkg_w.mjs");
var Route$13 = createFileRoute("/_authenticated/campos-do-site")({
	head: () => ({ meta: [{ title: "Campos do site — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./campos-personalizados-Cu5Alhbl.mjs");
var Route$12 = createFileRoute("/_authenticated/campos-personalizados")({
	head: () => ({ meta: [{ title: "Campos personalizados — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
/** Minúsculas sem acento, para a busca casar "apolice" com "Apólice". */
/** Criação/edição de um campo de Anexo (local — só do sistema). */
/**
* Configura o ANEXO COMPROBATÓRIO de um campo (complemento): permitir, exigir e
* o tipo de arquivo aceito. Grava os flags na definição (por custom_field_name),
* funcionando para campos do Argus (mirrados) e locais.
*/
/** Criação/edição de seção. O nome e o storage são imutáveis na edição. */
/** Criação/edição de campo personalizado. Nome e tipo são imutáveis na edição. */
var $$splitComponentImporter$11 = () => import("./configuracoes-cliente-J_Pm1hhl.mjs");
var Route$11 = createFileRoute("/_authenticated/configuracoes-cliente")({
	head: () => ({ meta: [{ title: "Configurações do cliente — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./diagnostics-BPXs0yWM.mjs");
var Route$10 = createFileRoute("/_authenticated/diagnostics")({
	head: () => ({ meta: [{ title: "Diagnóstico — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./empresas-BJ4IF1Xm.mjs");
var Route$9 = createFileRoute("/_authenticated/empresas")({
	head: () => ({ meta: [{ title: "Empresas — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./identities-DHY2h_8H.mjs");
var Route$8 = createFileRoute("/_authenticated/identities")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./importar-3hNiy-kg.mjs");
var Route$7 = createFileRoute("/_authenticated/importar")({
	head: () => ({ meta: [{ title: "Importar — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./layout-formulario-DIGkRBHv.mjs");
var Route$6 = createFileRoute("/_authenticated/layout-formulario")({
	head: () => ({ meta: [{ title: "Layout do formulário — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./settings-Dcj21wLA.mjs");
var Route$5 = createFileRoute("/_authenticated/settings")({
	head: () => ({ meta: [{ title: "Configurações — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./tipos-trabalhador-K5ZwS04U.mjs");
var Route$4 = createFileRoute("/_authenticated/tipos-trabalhador")({
	head: () => ({ meta: [{ title: "Tipos de trabalhador — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./identities.index-CK6LRgRD.mjs");
var Route$3 = createFileRoute("/_authenticated/identities/")({
	head: () => ({ meta: [{ title: "Pessoas — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./terceirizados.index-CqAu4H9b.mjs");
var Route$2 = createFileRoute("/_authenticated/terceirizados/")({
	head: () => ({ meta: [{ title: "Terceirizados — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./visitas.index-BkaISwbT.mjs");
var Route$1 = createFileRoute("/_authenticated/visitas/")({
	head: () => ({ meta: [{ title: "Visitas — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
/** Expected → CheckedIn → CheckedOut */
/** Uma visita, com seus visitantes e as ações de portaria. */
var $$splitComponentImporter = () => import("./visitas.nova-Ca1rT11u.mjs");
var Route = createFileRoute("/_authenticated/visitas/nova")({
	head: () => ({ meta: [{ title: "Nova visita — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
/** datetime-local (hora local) → ISO UTC exigido pela API. */
/** Date → valor de <input type="datetime-local"> (hora local). */
/** Duração padrão da visita: o término é 12h após o início. */
/** Busca identidades e devolve a escolhida (para requester/host). */
var IndexRoute = Route$18.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$19
});
var AuthenticatedRouteRoute = Route$17.update({
	id: "/_authenticated",
	getParentRoute: () => Route$19
});
var AuthenticatedApelidosRoute = Route$16.update({
	id: "/apelidos",
	path: "/apelidos",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBrandingRoute = Route$15.update({
	id: "/branding",
	path: "/branding",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCampanhasFotoRoute = Route$14.update({
	id: "/campanhas-foto",
	path: "/campanhas-foto",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCamposDoSiteRoute = Route$13.update({
	id: "/campos-do-site",
	path: "/campos-do-site",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCamposPersonalizadosRoute = Route$12.update({
	id: "/campos-personalizados",
	path: "/campos-personalizados",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedConfiguracoesClienteRoute = Route$11.update({
	id: "/configuracoes-cliente",
	path: "/configuracoes-cliente",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDiagnosticsRoute = Route$10.update({
	id: "/diagnostics",
	path: "/diagnostics",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedEmpresasRoute = Route$9.update({
	id: "/empresas",
	path: "/empresas",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedIdentitiesRoute = Route$8.update({
	id: "/identities",
	path: "/identities",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedImportarRoute = Route$7.update({
	id: "/importar",
	path: "/importar",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLayoutFormularioRoute = Route$6.update({
	id: "/layout-formulario",
	path: "/layout-formulario",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRegrasRoute = Route$23.update({
	id: "/regras",
	path: "/regras",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSettingsRoute = Route$5.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTiposTrabalhadorRoute = Route$4.update({
	id: "/tipos-trabalhador",
	path: "/tipos-trabalhador",
	getParentRoute: () => AuthenticatedRouteRoute
});
var FotoTokenRoute = Route$20.update({
	id: "/foto/$token",
	path: "/foto/$token",
	getParentRoute: () => Route$19
});
var AuthenticatedIdentitiesIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedIdentitiesRoute
});
var AuthenticatedIdentitiesIdRoute = Route$21.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AuthenticatedIdentitiesRoute
});
var AuthenticatedIdentitiesNewRoute = Route$22.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => AuthenticatedIdentitiesRoute
});
var AuthenticatedTerceirizadosIndexRoute = Route$2.update({
	id: "/terceirizados/",
	path: "/terceirizados/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTerceirizadosIdRoute = Route$24.update({
	id: "/terceirizados/$id",
	path: "/terceirizados/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVisitasIndexRoute = Route$1.update({
	id: "/visitas/",
	path: "/visitas/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVisitasNovaRoute = Route.update({
	id: "/visitas/nova",
	path: "/visitas/nova",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedIdentitiesRouteChildren = {
	AuthenticatedIdentitiesIdRoute,
	AuthenticatedIdentitiesNewRoute,
	AuthenticatedIdentitiesIndexRoute
};
var AuthenticatedRouteRouteChildren = {
	AuthenticatedApelidosRoute,
	AuthenticatedBrandingRoute,
	AuthenticatedCampanhasFotoRoute,
	AuthenticatedCamposDoSiteRoute,
	AuthenticatedCamposPersonalizadosRoute,
	AuthenticatedConfiguracoesClienteRoute,
	AuthenticatedDiagnosticsRoute,
	AuthenticatedEmpresasRoute,
	AuthenticatedIdentitiesRoute: AuthenticatedIdentitiesRoute._addFileChildren(AuthenticatedIdentitiesRouteChildren),
	AuthenticatedImportarRoute,
	AuthenticatedLayoutFormularioRoute,
	AuthenticatedRegrasRoute,
	AuthenticatedSettingsRoute,
	AuthenticatedTiposTrabalhadorRoute,
	AuthenticatedTerceirizadosIdRoute,
	AuthenticatedVisitasNovaRoute,
	AuthenticatedTerceirizadosIndexRoute,
	AuthenticatedVisitasIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	FotoTokenRoute
};
var routeTree = Route$19._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
