import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { ht as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as argusApi, t as ArgusApiError, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { i as saveIdentityCustomFields } from "./supabase-mirror--nGFXAER.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as createIdentityAtomic } from "./identity-atomic-DXMsrL_T.mjs";
import { t as saveIdentityAttachments } from "./attachments-PsPmKuGo.mjs";
import { t as IdentityForm } from "./IdentityForm-DlM5ERWD.mjs";
import { t as Route } from "./identities.new-CV8bAi58.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identities.new-Cpt02fox.js
var import_jsx_runtime = require_jsx_runtime();
function NewIdentity() {
	const { t, lang } = useT();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { type: workerTypeId } = Route.useSearch();
	const activeProfile = useActiveProfile();
	const wt = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("id, name, name_i18n").eq("is_active", true).eq("profile", activeProfile);
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	}).data?.find((w) => w.id === workerTypeId);
	const heading = workerTypeId && wt ? t("identityNew.newOf", { type: pickLang(wt.name_i18n, lang) || wt.name }) : t("identityNew.title");
	const mut = useMutation({
		mutationFn: async (vars) => {
			const dupes = await argusApi.findIdentitiesByEmail(vars.data.email);
			if (dupes.length) {
				const d = dupes[0];
				throw new ArgusApiError({
					status: 409,
					message: t("identityNew.duplicateEmail", {
						email: vars.data.email,
						name: `${d.firstName} ${d.lastName}`,
						status: d.status
					})
				});
			}
			return createIdentityAtomic(vars.data, {
				companyId: vars.companyId,
				workerTypeId: vars.workerTypeId
			});
		},
		onSuccess: async (data, vars) => {
			const ok = [t("identityNew.step.main")];
			const fail = [];
			const cf = Object.entries(vars.data.customFields ?? {}).filter(([, v]) => (v ?? "").trim()).map(([customFieldName, customFieldValue]) => ({
				customFieldName,
				customFieldValue
			}));
			if (cf.length) try {
				await argusApi.patchIdentityCustomFields(data.identityId, cf);
				ok.push(t("identityNew.step.customFields"));
			} catch (e) {
				fail.push(t("identityNew.fail.customFields", { error: e.message }));
			}
			if (vars.photo) try {
				await argusApi.uploadIdentityPicture(data.identityId, vars.photo);
				ok.push(t("identityNew.step.photo"));
			} catch (e) {
				fail.push(t("identityNew.fail.photo", { error: e.message }));
			}
			try {
				const rule = await argusApi.ensureDefaultRule(data.identityId);
				if (rule.assigned) ok.push(t("identityNew.step.defaultRule", { rule: rule.ruleName ?? t("identityNew.defaultRuleFallback") }));
			} catch (e) {
				fail.push(t("identityNew.fail.defaultRule", { error: e.message }));
			}
			try {
				await argusApi.synchronizeIdentities([data.identityId], vars.data.siteId);
				ok.push(t("identityNew.step.sync"));
			} catch (e) {
				fail.push(t("identityNew.fail.sync", { error: e.message }));
			}
			if (fail.length) toast.warning(t("identityNew.createdWithIssues", { ok: ok.join(", ") }), {
				description: t("identityNew.failedList", { fail: fail.join("; ") }),
				duration: 12e3
			});
			else toast.success(t("identityNew.createdSuccess", { ok: ok.join(", ") }));
			await saveIdentityCustomFields(data.identityId, vars.siteFieldValues);
			if (vars.attachments.length) {
				const { failed } = await saveIdentityAttachments(data.identityId, vars.attachments);
				if (failed.length) toast.warning(t("attachment.uploadPartial", { n: failed.length }));
			}
			qc.invalidateQueries({ queryKey: ["identities"] });
			navigate({
				to: "/identities/$id",
				params: { id: data.identityId }
			});
		},
		onError: (e) => {
			const err = e;
			const description = [err.status === 400 ? t("identityNew.error.duplicateHint") : void 0, err.traceId ? `TraceId: ${err.traceId}` : void 0].filter(Boolean).join(" · ");
			toast.error(err.message, { description: description || void 0 });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/identities",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 h-4 w-4" }),
						" ",
						t("identityNew.back")
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-semibold tracking-tight text-foreground",
				children: heading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("identityNew.subtitle")
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityForm, {
			mode: "create",
			submitting: mut.isPending,
			initialWorkerTypeId: workerTypeId,
			lockWorkerType: Boolean(workerTypeId),
			onSubmit: (data, siteFieldValues, companyId, wtId, photo, attachments) => mut.mutate({
				data,
				siteFieldValues,
				companyId,
				workerTypeId: wtId,
				photo,
				attachments
			}),
			onCancel: () => navigate({ to: "/identities" })
		}, workerTypeId ?? "novo")]
	});
}
//#endregion
export { NewIdentity as component };
