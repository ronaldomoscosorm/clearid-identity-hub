import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { T as Pencil, l as Trash2, pt as BriefcaseBusiness, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tipos-trabalhador-K5ZwS04U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_FORM = {
	namePt: "",
	nameEn: "",
	nameEs: "",
	code: "",
	argus: "Colaborador",
	displayIndex: "",
	isActive: true
};
function langFromJson(v) {
	const o = v && typeof v === "object" ? v : {};
	return {
		pt: String(o["pt-BR"] ?? ""),
		en: String(o["en-US"] ?? ""),
		es: String(o["es-ES"] ?? "")
	};
}
function toForm(w) {
	const n = langFromJson(w.name_i18n);
	return {
		namePt: n.pt || w.name || "",
		nameEn: n.en,
		nameEs: n.es,
		code: w.code ?? "",
		argus: w.argus_worker_type_code ?? "Colaborador",
		displayIndex: w.display_index != null ? String(w.display_index) : "",
		isActive: w.is_active
	};
}
function WorkerTypesPage() {
	const { t, lang } = useT();
	const qc = useQueryClient();
	const activeProfile = useActiveProfile();
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(EMPTY_FORM);
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const query = useQuery({
		queryKey: ["worker-types-admin", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			}).order("name", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const upsert = useMutation({
		mutationFn: async (values) => {
			const namePt = values.namePt.trim();
			const nameI18n = {
				"pt-BR": namePt,
				default: namePt
			};
			if (values.nameEn.trim()) nameI18n["en-US"] = values.nameEn.trim();
			if (values.nameEs.trim()) nameI18n["es-ES"] = values.nameEs.trim();
			const payload = {
				name: namePt,
				name_i18n: nameI18n,
				code: values.code.trim(),
				argus_worker_type_code: values.argus,
				display_index: values.displayIndex.trim() ? Number(values.displayIndex) : null,
				is_active: values.isActive
			};
			if (editing) {
				const { error } = await supabase.from("worker_types").update(payload).eq("id", editing.id);
				if (error) throw new Error(error.message);
			} else {
				const { error } = await supabase.from("worker_types").insert({
					...payload,
					profile: activeProfile
				});
				if (error) throw new Error(error.message);
			}
		},
		onSuccess: () => {
			toast.success(editing ? t("workerTypes.toast.updated") : t("workerTypes.toast.created"));
			qc.invalidateQueries({ queryKey: ["worker-types-admin"] });
			qc.invalidateQueries({ queryKey: ["worker-types"] });
			setDialogOpen(false);
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("worker_types").delete().eq("id", id);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("workerTypes.toast.deleted"));
			qc.invalidateQueries({ queryKey: ["worker-types-admin"] });
			qc.invalidateQueries({ queryKey: ["worker-types"] });
			setToDelete(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const openCreate = () => {
		setEditing(null);
		setForm(EMPTY_FORM);
		setDialogOpen(true);
	};
	const openEdit = (w) => {
		setEditing(w);
		setForm(toForm(w));
		setDialogOpen(true);
	};
	const submit = () => {
		if (!form.namePt.trim()) {
			toast.error(t("workerTypes.validation.nameRequired"));
			return;
		}
		if (!form.code.trim()) {
			toast.error(t("workerTypes.validation.codeRequired"));
			return;
		}
		if (!form.argus) {
			toast.error(t("workerTypes.validation.argusRequired"));
			return;
		}
		upsert.mutate(form);
	};
	const items = query.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight text-foreground",
						children: t("workerTypes.title")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full border px-2 py-0.5 text-xs font-medium text-muted-foreground",
						children: [
							t("shell.profile"),
							": ",
							activeProfile
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("workerTypes.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => query.refetch(),
						disabled: query.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${query.isFetching ? "animate-spin" : ""}` }), t("workerTypes.refreshButton")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: openCreate,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("workerTypes.newButton")
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: query.data ? items.length === 1 ? t("workerTypes.count.one", { count: items.length }) : t("workerTypes.count.other", { count: items.length }) : t("workerTypes.title")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })
				]
			}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: query.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("workerTypes.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("workerTypes.col.code") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("workerTypes.col.argus") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[80px] text-center",
					children: t("workerTypes.col.order")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.status") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[100px] text-right",
					children: t("common.actions")
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: pickLang(w.name_i18n, lang) || w.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: w.code
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: w.argus_worker_type_code ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-center text-muted-foreground",
					children: w.display_index ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: w.is_active ? "default" : "secondary",
					children: w.is_active ? t("workerTypes.status.active") : t("workerTypes.status.inactive")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => openEdit(w),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "text-destructive hover:text-destructive",
							onClick: () => setToDelete(w),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})]
					})
				})
			] }, w.id)) })] }) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: setDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[85vh] overflow-y-auto sm:max-w-[520px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BriefcaseBusiness, { className: "h-5 w-5" }), editing ? t("workerTypes.dialog.editTitle") : t("workerTypes.newButton")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: editing ? t("workerTypes.dialog.editDescription") : t("workerTypes.dialog.createDescription") })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "namePt",
										children: t("workerTypes.form.name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "namePt",
										value: form.namePt,
										onChange: (e) => setForm((f) => ({
											...f,
											namePt: e.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "nameEn",
											children: t("workerTypes.form.nameEn")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "nameEn",
											value: form.nameEn,
											onChange: (e) => setForm((f) => ({
												...f,
												nameEn: e.target.value
											}))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "nameEs",
											children: t("workerTypes.form.nameEs")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "nameEs",
											value: form.nameEs,
											onChange: (e) => setForm((f) => ({
												...f,
												nameEs: e.target.value
											}))
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "code",
												children: t("workerTypes.form.code")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "code",
												value: form.code,
												onChange: (e) => setForm((f) => ({
													...f,
													code: e.target.value
												})),
												placeholder: "EMP"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: t("workerTypes.form.codeHint")
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "order",
											children: t("workerTypes.form.order")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "order",
											type: "number",
											value: form.displayIndex,
											onChange: (e) => setForm((f) => ({
												...f,
												displayIndex: e.target.value
											}))
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "argus",
											children: t("workerTypes.form.argus")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: form.argus,
											onValueChange: (v) => setForm((f) => ({
												...f,
												argus: v
											})),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												id: "argus",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Colaborador",
												children: t("workerTypes.argus.colaborador")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Terceiros",
												children: t("workerTypes.argus.terceiros")
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: t("workerTypes.form.argusHint")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										id: "active",
										checked: form.isActive,
										onCheckedChange: (c) => setForm((f) => ({
											...f,
											isActive: Boolean(c)
										}))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "active",
										className: "cursor-pointer",
										children: t("workerTypes.form.active")
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDialogOpen(false),
							children: t("common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: submit,
							disabled: upsert.isPending,
							children: upsert.isPending ? t("common.saving") : t("common.save")
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(toDelete),
				onOpenChange: (o) => !o && setToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("workerTypes.delete.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					t("workerTypes.delete.confirmBefore"),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: toDelete ? pickLang(toDelete.name_i18n, lang) || toDelete.name : ""
					}),
					t("workerTypes.delete.confirmAfter")
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					onClick: () => toDelete && remove.mutate(toDelete.id),
					disabled: remove.isPending,
					children: remove.isPending ? t("workerTypes.delete.deleting") : t("common.delete")
				})] })] })
			})
		]
	});
}
//#endregion
export { WorkerTypesPage as component };
