import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { a as objectType, i as numberType, o as stringType, r as nullType, s as unionType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/argus-client-fTtea6N-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var CFG_KEY = "argus.config";
var DEFAULT = {
	baseUrl: "https://argusclearidapi.rmtecho.com.br".replace(/\/+$/, "") ?? "https://argusclearidapi.rmtecho.com.br",
	apiKey: ""
};
function isBrowser$1() {
	return typeof window !== "undefined";
}
function getConfig() {
	if (!isBrowser$1()) return DEFAULT;
	try {
		const raw = localStorage.getItem(CFG_KEY);
		if (!raw) return DEFAULT;
		const parsed = JSON.parse(raw);
		return {
			...DEFAULT,
			...parsed
		};
	} catch {
		return DEFAULT;
	}
}
function saveConfig(cfg) {
	if (!isBrowser$1()) return;
	localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
	notify$1();
}
var listeners$1 = /* @__PURE__ */ new Set();
function notify$1() {
	for (const l of listeners$1) l();
}
function subscribe(cb) {
	listeners$1.add(cb);
	const onStorage = (e) => {
		if (e.key === CFG_KEY) cb();
	};
	if (isBrowser$1()) window.addEventListener("storage", onStorage);
	return () => {
		listeners$1.delete(cb);
		if (isBrowser$1()) window.removeEventListener("storage", onStorage);
	};
}
function useArgusConfig() {
	const data = (0, import_react.useSyncExternalStore)(subscribe, () => JSON.stringify(getConfig()), () => JSON.stringify(DEFAULT));
	return JSON.parse(data);
}
/**
* Site ativo — par `cliente:site` (ex.: `corteva:LA-BR-Alphaville`).
* Persistido em sessionStorage: sobrevive a reloads da aba, mas some quando fecha.
*
* Usado pelo argus-client em cada request via header `X-Argus-Site`, e pelo
* dropdown do topbar para trocar entre sites que o usuário tem grant.
*/
var KEY = "argus.activeSite";
var listeners = /* @__PURE__ */ new Set();
function notify() {
	for (const cb of listeners) cb();
}
function isBrowser() {
	return typeof window !== "undefined";
}
/** Retorna o site ativo (`cliente:site`) ou `null` se nenhum foi escolhido. */
function getActiveSite() {
	if (!isBrowser()) return null;
	try {
		return window.sessionStorage.getItem(KEY);
	} catch {
		return null;
	}
}
/** Define o site ativo. `null` limpa. */
function setActiveSite(value) {
	if (!isBrowser()) return;
	try {
		if (value) window.sessionStorage.setItem(KEY, value);
		else window.sessionStorage.removeItem(KEY);
		notify();
	} catch {}
}
/**
* Ao logar, se o usuário não tem site ativo, seleciona o primeiro da lista permitida
* automaticamente. Chame no root layout após ter `sites` do useCurrentUser.
*/
function useEnsureActiveSite(sitesAllowed) {
	(0, import_react.useEffect)(() => {
		if (!sitesAllowed || sitesAllowed.length === 0) return;
		const current = getActiveSite();
		if (current && sitesAllowed.includes(current)) return;
		setActiveSite(sitesAllowed[0]);
	}, [sitesAllowed]);
}
var STORAGE_KEY = "argus.ssoToken";
/** Retorna o JWT armazenado ou null. */
function getSsoToken() {
	if (typeof window === "undefined") return null;
	try {
		const t = window.localStorage.getItem(STORAGE_KEY);
		return t && t.length > 0 ? t : null;
	} catch {
		return null;
	}
}
/** Persiste o JWT. */
function setSsoToken(token) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(STORAGE_KEY, token);
	} catch {}
}
/**
* Se a URL tem `#token=<jwt>` (redirecionado do Portal Argus), extrai,
* persiste e limpa o fragment. Retorna true se algo foi capturado.
* Chamar 1x no bootstrap da app, ANTES das primeiras requests.
*/
function captureTokenFromUrl() {
	if (typeof window === "undefined") return false;
	const hash = window.location.hash;
	if (!hash || !hash.includes("token=")) return false;
	const token = new URLSearchParams(hash.startsWith("#") ? hash.slice(1) : hash).get("token");
	if (!token) return false;
	setSsoToken(token);
	const cleanUrl = window.location.pathname + window.location.search;
	window.history.replaceState(null, "", cleanUrl);
	return true;
}
function lsGet(key) {
	if (typeof window === "undefined") return null;
	try {
		return window.localStorage.getItem(key);
	} catch {
		return null;
	}
}
function lsSet(key, val) {
	if (typeof window === "undefined") return;
	try {
		if (val) window.localStorage.setItem(key, val);
		else window.localStorage.removeItem(key);
	} catch {}
}
function ssGet(key) {
	if (typeof window === "undefined") return null;
	try {
		return window.sessionStorage.getItem(key);
	} catch {
		return null;
	}
}
function ssSet(key, val) {
	if (typeof window === "undefined") return;
	try {
		window.sessionStorage.setItem(key, val);
	} catch {}
}
function ssRemove(key) {
	if (typeof window === "undefined") return;
	try {
		window.sessionStorage.removeItem(key);
	} catch {}
}
var SITE_KEY = "argus.defaultSiteId";
var SITE_SESSION_KEY = "argus.sessionSiteId";
var siteListeners = /* @__PURE__ */ new Set();
function notifySite() {
	for (const cb of siteListeners) cb();
}
/** Site padrão configurado em Configurações (persistente). */
function getConfiguredSiteId() {
	return lsGet(SITE_KEY);
}
/** Grava o site padrão (Configurações) e remove o override da sessão. */
function setConfiguredSiteId(id) {
	lsSet(SITE_KEY, id);
	ssRemove(SITE_SESSION_KEY);
	notifySite();
}
/**
* Define o site da SESSÃO (seletor do topbar). Não altera o padrão de
* Configurações. `null` = "sem site" explícito (força escolher), gravado como
* string vazia para sobrepor o padrão.
*/
function setSessionSiteId(id) {
	ssSet(SITE_SESSION_KEY, id ?? "");
	notifySite();
}
/** Site em efeito: override da sessão (se houver) senão o padrão configurado. */
function getDefaultSiteId() {
	const override = ssGet(SITE_SESSION_KEY);
	if (override !== null) return override || null;
	return getConfiguredSiteId();
}
function subscribeSite(cb) {
	siteListeners.add(cb);
	const onStorage = (e) => {
		if (e.key === SITE_KEY) cb();
	};
	if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
	return () => {
		siteListeners.delete(cb);
		if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
	};
}
/** React hook: site em efeito (sessão ?? padrão). */
function useDefaultSiteId() {
	return (0, import_react.useSyncExternalStore)(subscribeSite, () => getDefaultSiteId(), () => null);
}
var cachedAccountId = null;
var accountIdListeners = /* @__PURE__ */ new Set();
function getAccountId() {
	if (cachedAccountId) return cachedAccountId;
	if (typeof window !== "undefined") try {
		const stored = window.localStorage.getItem("argus.accountId");
		if (stored) cachedAccountId = stored;
	} catch {}
	return cachedAccountId;
}
function setAccountId(id) {
	cachedAccountId = id || null;
	if (typeof window !== "undefined") try {
		if (id) window.localStorage.setItem("argus.accountId", id);
		else window.localStorage.removeItem("argus.accountId");
	} catch {}
	for (const cb of accountIdListeners) cb(cachedAccountId);
}
var cachedSystemObjectId = null;
var SYSTEM_KEY = "argus.systemObjectId";
var systemListeners = /* @__PURE__ */ new Set();
function getSystemObjectId() {
	if (cachedSystemObjectId) return cachedSystemObjectId;
	if (typeof window !== "undefined") try {
		const stored = window.localStorage.getItem(SYSTEM_KEY);
		if (stored) cachedSystemObjectId = stored;
	} catch {}
	return cachedSystemObjectId;
}
function setSystemObjectId(id) {
	cachedSystemObjectId = id || null;
	if (typeof window !== "undefined") try {
		if (id) window.localStorage.setItem(SYSTEM_KEY, id);
		else window.localStorage.removeItem(SYSTEM_KEY);
	} catch {}
	for (const cb of systemListeners) cb();
}
function subscribeSystem(cb) {
	systemListeners.add(cb);
	const onStorage = (e) => {
		if (e.key === SYSTEM_KEY) {
			cachedSystemObjectId = e.newValue || null;
			cb();
		}
	};
	if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
	return () => {
		systemListeners.delete(cb);
		if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
	};
}
function useSystemObjectId() {
	return (0, import_react.useSyncExternalStore)(subscribeSystem, () => getSystemObjectId(), () => null);
}
/** Lista de perfis disponíveis. TODO: tornar dinâmica (endpoint/config). */
var CLEARID_PROFILES = [
	{
		code: "RM",
		label: "RM"
	},
	{
		code: "Corteva",
		label: "Corteva"
	},
	{
		code: "Vylor",
		label: "Vylor"
	}
];
var DEFAULT_PROFILE = "RM";
var PROFILE_KEY = "argus.profile";
var PROFILE_SESSION_KEY = "argus.sessionProfile";
var profileListeners = /* @__PURE__ */ new Set();
function notifyProfile() {
	for (const cb of profileListeners) cb();
}
/** Perfil padrão configurado em Configurações. */
function getDefaultProfile() {
	return lsGet(PROFILE_KEY) || DEFAULT_PROFILE;
}
/** Grava o perfil padrão (Configurações) e remove o override da sessão. */
function setDefaultProfile(code) {
	lsSet(PROFILE_KEY, code);
	ssRemove(PROFILE_SESSION_KEY);
	notifyProfile();
}
/** Define o perfil da SESSÃO (topbar). Não altera o padrão de Configurações. */
function setSessionProfile(code) {
	if (code) ssSet(PROFILE_SESSION_KEY, code);
	else ssRemove(PROFILE_SESSION_KEY);
	notifyProfile();
}
/** Perfil em efeito: override da sessão (se houver) senão o padrão configurado. */
function getActiveProfile() {
	return ssGet(PROFILE_SESSION_KEY) || getDefaultProfile();
}
function subscribeProfile(cb) {
	profileListeners.add(cb);
	const onStorage = (e) => {
		if (e.key === PROFILE_KEY) cb();
	};
	if (typeof window !== "undefined") window.addEventListener("storage", onStorage);
	return () => {
		profileListeners.delete(cb);
		if (typeof window !== "undefined") window.removeEventListener("storage", onStorage);
	};
}
/** React hook: perfil em efeito (sessão ?? padrão). */
function useActiveProfile() {
	return (0, import_react.useSyncExternalStore)(subscribeProfile, getActiveProfile, () => DEFAULT_PROFILE);
}
/** React hook: perfil padrão configurado (para Configurações). */
function useDefaultProfile() {
	return (0, import_react.useSyncExternalStore)(subscribeProfile, getDefaultProfile, () => DEFAULT_PROFILE);
}
var ArgusApiError = class extends Error {
	status;
	traceId;
	raw;
	constructor(e) {
		super(e.message);
		this.status = e.status;
		this.traceId = e.traceId;
		this.raw = e.raw;
	}
};
async function argusFetch(path, init = {}, opts = {}) {
	const cfg = getConfig();
	if (!cfg.baseUrl) throw new ArgusApiError({
		status: 0,
		message: "Base URL não configurada"
	});
	let url = cfg.baseUrl.replace(/\/+$/, "") + path;
	const siteIdForQuery = opts.siteId ?? (opts.environment ? null : getDefaultSiteId());
	if (!opts.allSites && siteIdForQuery && !/[?&]siteId=/.test(url)) url += (url.includes("?") ? "&" : "?") + "siteId=" + encodeURIComponent(siteIdForQuery);
	const headers = new Headers(init.headers);
	if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
	if (cfg.apiKey) headers.set("Authorization", `Bearer ${cfg.apiKey}`);
	else {
		const ssoToken = getSsoToken();
		if (ssoToken && !headers.has("Authorization")) headers.set("Authorization", `Bearer ${ssoToken}`);
	}
	const activeSite = getActiveSite();
	if (activeSite && !headers.has("X-Argus-Site")) headers.set("X-Argus-Site", activeSite);
	if (!headers.has("X-ClearId-Environment")) headers.set("X-ClearId-Environment", opts.environment ?? getActiveProfile());
	const systemObjectId = getSystemObjectId();
	if (systemObjectId && !headers.has("X-System-Object-Id")) headers.set("X-System-Object-Id", systemObjectId);
	if (systemObjectId && !/[?&]systemObjectId=/.test(url)) url += (url.includes("?") ? "&" : "?") + "systemObjectId=" + encodeURIComponent(systemObjectId);
	if (!opts.allSites && siteIdForQuery && !headers.has("X-Site-Id")) headers.set("X-Site-Id", siteIdForQuery);
	let response;
	try {
		if ((init.method ?? "GET").toUpperCase() === "DELETE" && /\/api\/identities(\/|$|\?)/i.test(path)) throw new ArgusApiError({
			status: 0,
			message: "Operação bloqueada: DELETE em /api/identities não é permitido. Use updateIdentity com status='Inactive'."
		});
		response = await fetch(url, {
			credentials: "include",
			...init,
			headers
		});
	} catch (e) {
		throw new ArgusApiError({
			status: 0,
			message: `Falha de rede ao chamar ${url}: ${e.message}`
		});
	}
	const headerTraceId = response.headers.get("x-trace-id") ?? void 0;
	const text = await response.text();
	let body = text;
	if (text) try {
		body = JSON.parse(text);
	} catch {}
	if (!response.ok) {
		const bodyObj = body && typeof body === "object" ? body : null;
		const traceId = headerTraceId ?? (bodyObj && typeof bodyObj.traceId === "string" ? bodyObj.traceId : void 0);
		const msg = (bodyObj && "message" in bodyObj && typeof bodyObj.message === "string" ? bodyObj.message : null) ?? (bodyObj && "error" in bodyObj ? String(bodyObj.error) : null) ?? response.statusText ?? `HTTP ${response.status}`;
		console.warn(`[argus] ${response.status} ${path} — ${msg}${traceId ? ` (traceId ${traceId})` : ""}`);
		throw new ArgusApiError({
			status: response.status,
			message: msg,
			traceId,
			raw: body
		});
	}
	return body;
}
/**
* ClearID v4 exige formatos diferentes para criação e atualização: no PUT,
* externalId/customFields ficam dentro de systemData e eTag é obrigatório.
*/
function assertWorkerTypeCode(code) {
	const v = (code ?? "").trim();
	if (!v) throw new ArgusApiError({
		status: 400,
		message: "workerTypeCode é obrigatório (Tipo do Trabalhador)."
	});
	if (v !== "Terceiros" && v !== "Colaborador") throw new ArgusApiError({
		status: 400,
		message: "workerTypeCode inválido: use 'Terceiros' ou 'Colaborador'."
	});
}
function normalizeCreateIdentityPayload(data) {
	assertWorkerTypeCode(data.workerTypeCode);
	return {
		...data,
		customFields: void 0,
		siteId: data.siteId ?? getDefaultSiteId() ?? void 0,
		workerTypeCode: data.workerTypeCode ?? void 0,
		companyData: {
			...data.companyData ?? {},
			...data.siteId ? { siteId: data.siteId } : {},
			workerTypeCode: data.workerTypeCode ?? null
		},
		status: typeof data.status === "string" ? data.status.toLowerCase() : data.status,
		identityType: typeof data.identityType === "string" ? data.identityType.toLowerCase() : data.identityType
	};
}
/**
* Converte valores do formulário em payload PATCH para
* /api/identities/{id}/custom-fields, respeitando as regras por tipo.
* Campos vazios viram `null` (limpar). Retorna apenas os que mudaram em
* relação aos valores atuais.
*/
function serializeCustomFieldsForPatch(defs, values, current) {
	const currentByName = new Map((current ?? []).map((f) => [f.customFieldName, f.customFieldValue ?? ""]));
	const out = [];
	for (const def of defs) {
		const name = def.customFieldName;
		if (!(name in values)) continue;
		if (def.isReadOnly) continue;
		const typeLc = (def.customFieldType ?? "").toLowerCase();
		const raw = (values[name] ?? "").trim();
		let serialized;
		if (!raw) serialized = null;
		else if (typeLc === "date" || typeLc === "datetime") {
			const iso = /^\d{4}-\d{2}-\d{2}/.test(raw) ? raw.slice(0, 10) : (() => {
				const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(raw);
				return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
			})();
			if (!iso) continue;
			serialized = iso;
		} else if (typeLc === "bool" || typeLc === "boolean") serialized = [
			"true",
			"1",
			"yes",
			"sim"
		].includes(raw.toLowerCase()) ? "true" : "false";
		else if (typeLc === "numeric" || typeLc === "number") serialized = raw.replace(/[^0-9.\-]/g, "") || null;
		else serialized = raw;
		const currentValue = currentByName.get(name);
		if (serialized === (currentValue == null || currentValue === "" ? null : currentValue)) continue;
		out.push({
			customFieldName: name,
			customFieldValue: serialized
		});
	}
	return out;
}
function toClearIdName(value, fallback) {
	const raw = value || fallback;
	return raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
}
function normalizeUpdateIdentityPayload(data) {
	assertWorkerTypeCode(data.workerTypeCode);
	if (!data.eTag) throw new ArgusApiError({
		status: 0,
		message: "Não foi possível atualizar: versão da identidade não carregada. Aguarde a foto atualizar e tente novamente."
	});
	const READONLY_SYSTEM = /* @__PURE__ */ new Set([
		"resourceFilters",
		"horizonId",
		"provisioningAttributes",
		"externalSyncSourceId",
		"externalSyncTimeUtc",
		"externalId",
		"customFields"
	]);
	const systemData = { externalId: getClearIdExternalId(data) };
	for (const [k, v] of Object.entries(data.systemData ?? {})) {
		if (READONLY_SYSTEM.has(k)) continue;
		if (v !== null && v !== void 0) systemData[k] = v;
	}
	const displayName = data.displayName ?? ([data.lastName, data.firstName].filter(Boolean).join(", ") || `${data.firstName} ${data.lastName}`.trim());
	const companyData = {
		...data.companyData ?? {},
		workerTypeCode: data.workerTypeCode ?? null
	};
	if (data.siteId) companyData.siteId = data.siteId;
	return {
		systemData,
		companyData,
		privateData: data.privateData ?? void 0,
		description: data.description ?? null,
		status: typeof data.status === "string" ? data.status.charAt(0).toUpperCase() + data.status.slice(1).toLowerCase() : data.status,
		firstName: data.firstName,
		lastName: data.lastName,
		middleName: data.middleName ?? null,
		displayName,
		countryCode: data.countryCode ?? null,
		culture: data.culture ?? null,
		email: data.email,
		identityType: toClearIdName(data.identityType, "Employee"),
		workerTypeCode: data.workerTypeCode ?? null,
		eTag: data.eTag
	};
}
async function unwrap(p) {
	const r = await p;
	if (r && typeof r === "object" && "data" in r) return r.data;
	return r;
}
var credentialFieldSchema = objectType({
	name: stringType(),
	value: unionType([
		stringType(),
		numberType(),
		nullType()
	]).optional()
});
var credentialFormatSchema = objectType({
	formatId: stringType().optional().nullable(),
	facilityCode: unionType([
		stringType(),
		numberType(),
		nullType()
	]).optional(),
	cardNumber: unionType([
		stringType(),
		numberType(),
		nullType()
	]).optional(),
	fields: arrayType(credentialFieldSchema).optional().nullable()
}).passthrough();
var credentialStatusSchema = objectType({
	state: stringType().optional().nullable(),
	activationDateUtc: stringType().optional().nullable(),
	expirationDateUtc: stringType().optional().nullable(),
	expirationMode: stringType().optional().nullable(),
	expirationDurationInDays: numberType().nullable().optional()
}).passthrough();
var credentialItemSchema = objectType({
	globalId: stringType().optional(),
	credentialId: stringType().optional(),
	identityId: stringType().optional(),
	name: stringType().nullable().optional(),
	description: stringType().nullable().optional(),
	credentialType: stringType().nullable().optional(),
	credentialFormat: credentialFormatSchema.optional().nullable(),
	status: credentialStatusSchema.optional().nullable()
}).passthrough();
var credentialsResponseSchema = unionType([arrayType(credentialItemSchema), objectType({ credentials: arrayType(credentialItemSchema).optional().nullable() }).passthrough()]);
function fieldValue(fields, name) {
	if (!fields) return null;
	const found = fields.find((f) => f.name?.toLowerCase() === name.toLowerCase());
	if (!found || found.value == null) return null;
	return String(found.value);
}
function parseCredentialsResponse(raw) {
	const parsed = credentialsResponseSchema.safeParse(raw);
	if (!parsed.success) throw new Error(`Resposta inválida de credenciais: ${parsed.error.message}`);
	return (Array.isArray(parsed.data) ? parsed.data : parsed.data.credentials ?? []).map((it) => {
		const fmt = it.credentialFormat ?? void 0;
		const st = it.status ?? void 0;
		const facility = fmt?.facilityCode != null && fmt.facilityCode !== "" ? String(fmt.facilityCode) : fieldValue(fmt?.fields, "FacilityCode");
		const card = fmt?.cardNumber != null && fmt.cardNumber !== "" ? String(fmt.cardNumber) : fieldValue(fmt?.fields, "CardNumber");
		return {
			credentialId: it.credentialId ?? it.globalId,
			identityId: it.identityId,
			formatId: fmt?.formatId ?? void 0,
			facilityCode: facility,
			cardNumber: card,
			name: it.name ?? null,
			description: it.description ?? null,
			activationDateUtc: st?.activationDateUtc ?? null,
			expirationDateUtc: st?.expirationDateUtc ?? null,
			expirationMode: st?.expirationMode ?? null,
			expirationDurationInDays: st?.expirationDurationInDays ?? null,
			status: st?.state ?? null
		};
	});
}
var argusApi = {
	listSites: async (environment) => {
		const data = await unwrap(argusFetch(`/api/sites`, void 0, {
			environment,
			allSites: true
		}));
		if (Array.isArray(data)) return data;
		return data?.sites ?? [];
	},
	listSystems: async (environment) => {
		const data = await unwrap(argusFetch(`/api/systems?${new URLSearchParams().toString()}`, void 0, {
			allSites: true,
			environment
		}));
		return (Array.isArray(data) ? data : data?.systems ?? []).map((s) => ({
			systemObjectId: s.systemObjectId ?? s.SystemObjectId ?? s.systemId ?? s.id ?? "",
			name: s.name ?? s.Name ?? s.displayName ?? "",
			description: s.description ?? null,
			accountId: s.accountId,
			...s
		})).filter((s) => s.systemObjectId);
	},
	listTeams: async (params) => {
		const q = new URLSearchParams();
		q.set("includeDeleted", "false");
		q.set("take", String(params?.take ?? 200));
		if (params?.name) q.set("name", params.name);
		const data = await unwrap(argusFetch(`/api/teams?${q.toString()}`, void 0, {
			allSites: params?.allSites,
			siteId: params?.siteId,
			environment: params?.environment
		}));
		if (Array.isArray(data)) return data;
		return data?.teams ?? [];
	},
	listTeamMembers: async (teamId, params) => {
		const q = new URLSearchParams();
		q.set("count", String(params?.count ?? 200));
		if (params?.searchText) q.set("searchText", params.searchText);
		const data = await unwrap(argusFetch(`/api/teams/${encodeURIComponent(teamId)}/members?${q.toString()}`));
		if (Array.isArray(data)) return data;
		return data?.teamMembers ?? [];
	},
	listLocations: async (params) => {
		const q = new URLSearchParams();
		q.set("skip", String(params?.skip ?? 0));
		q.set("take", String(params?.take ?? 200));
		const data = await unwrap(argusFetch(`/api/locations?${q.toString()}`));
		if (Array.isArray(data)) return data;
		return data?.results ?? [];
	},
	listCustomFields: async () => {
		const data = await unwrap(argusFetch(`/api/custom-fields?${new URLSearchParams().toString()}`, void 0, { allSites: true }));
		if (Array.isArray(data)) return data;
		return data?.customFields ?? [];
	},
	/** Cria uma definição de campo personalizado. O nome/tipo são imutáveis depois. */
	createCustomField: (payload) => unwrap(argusFetch(`/api/custom-fields`, {
		method: "POST",
		body: JSON.stringify(payload)
	}, { allSites: true })),
	/** Atualiza uma definição (nome e tipo não são alteráveis pela API). */
	updateCustomField: (customFieldName, payload) => unwrap(argusFetch(`/api/custom-fields/${encodeURIComponent(customFieldName)}`, {
		method: "PUT",
		body: JSON.stringify(payload)
	}, { allSites: true })),
	/** Remove a definição de campo personalizado da conta. */
	deleteCustomField: (customFieldName) => unwrap(argusFetch(`/api/custom-fields/${encodeURIComponent(customFieldName)}`, { method: "DELETE" }, { allSites: true })),
	/** Lista todas as seções de campos personalizados (nome, exibição, campos). */
	listCustomFieldSections: async () => {
		const data = await unwrap(argusFetch(`/api/custom-fields/sections`));
		return (Array.isArray(data) ? data : []).map((s) => ({
			sectionName: String(s.identityCustomFieldsSectionName ?? s.sectionName ?? ""),
			displayName: String(s.displayName ?? s.identityCustomFieldsSectionName ?? s.sectionName ?? ""),
			index: typeof s.index === "number" ? s.index : 0,
			eTag: typeof s.eTag === "string" ? s.eTag : null,
			fields: Array.isArray(s.identityCustomFields) ? s.identityCustomFields.map((f) => ({
				name: String(f.name ?? ""),
				index: typeof f.index === "number" ? f.index : 0
			})) : []
		}));
	},
	/**
	* Cria uma seção de campos personalizados. O nome é imutável depois.
	*
	* Atenção: o `index` precisa ser único entre as seções. Se colidir, o backend
	* responde 400 com a mensagem enganosa "Já existe uma section com o nome X"
	* (fala do nome, mas o conflito é do índice).
	*/
	createCustomFieldSection: (payload) => unwrap(argusFetch(`/api/custom-fields/sections`, {
		method: "POST",
		body: JSON.stringify(payload)
	})),
	/**
	* Atualiza a seção. `identityCustomFields` deve conter os campos atuais — o
	* PUT substitui o agrupamento, então omiti-lo esvaziaria a seção.
	*/
	updateCustomFieldSection: (sectionName, payload) => unwrap(argusFetch(`/api/custom-fields/sections/${encodeURIComponent(sectionName)}`, {
		method: "PUT",
		body: JSON.stringify(payload)
	})),
	/** Remove a seção (o agrupamento). Os campos personalizados não são excluídos. */
	deleteCustomFieldSection: (sectionName) => unwrap(argusFetch(`/api/custom-fields/sections/${encodeURIComponent(sectionName)}`, { method: "DELETE" })),
	getCustomFieldSection: async (sectionName) => {
		try {
			return await unwrap(argusFetch(`/api/custom-fields/sections/${encodeURIComponent(sectionName)}`, void 0, { allSites: true })) ?? null;
		} catch {
			return null;
		}
	},
	/**
	* Grava apenas os campos personalizados alterados. Valores nulos limpam o
	* campo. Nunca envie string vazia para tipos Date/Boolean/Numeric — use
	* null. Este endpoint substitui o PUT completo para salvar documentos.
	*/
	patchIdentityCustomFields: (id, values) => argusFetch(`/api/identities/${encodeURIComponent(id)}/custom-fields`, {
		method: "PATCH",
		body: JSON.stringify({ values })
	}),
	addTeamMembers: (teamId, payload) => argusFetch(`/api/teams/${encodeURIComponent(teamId)}/members`, {
		method: "POST",
		body: JSON.stringify({
			identityIds: payload.identityIds,
			sourceId: payload.sourceId ?? null,
			startDateTimeUtc: payload.startDateTimeUtc ?? null,
			endDateTimeUtc: payload.endDateTimeUtc ?? null,
			reason: payload.reason ?? "Portal Argus"
		})
	}, { siteId: payload.siteId }),
	removeTeamMembers: (teamId, payload) => argusFetch(`/api/teams/${encodeURIComponent(teamId)}/members`, {
		method: "DELETE",
		body: JSON.stringify({
			identityIds: payload.identityIds,
			reason: payload.reason ?? "Portal Argus"
		})
	}, { siteId: payload.siteId }),
	/** Identidades com o e-mail informado (busca exata, em todos os sites). */
	findIdentitiesByEmail: async (email) => {
		const e = (email ?? "").trim();
		if (!e) return [];
		const { items } = await argusApi.listIdentities({
			email: e,
			allSites: true,
			take: 20
		});
		return items.filter((i) => (i.email ?? "").trim().toLowerCase() === e.toLowerCase());
	},
	/** Regras (teams) vinculadas a uma identidade. */
	getIdentityTeams: async (id, opts) => {
		const data = await unwrap(argusFetch(`/api/identities/${encodeURIComponent(id)}/teams`, void 0, { siteId: opts?.siteId }));
		if (Array.isArray(data)) return data;
		return data?.teams ?? [];
	},
	/**
	* Garante que a identidade tenha ao menos uma regra: se não tiver nenhuma e
	* houver uma regra padrão configurada, atribui a padrão.
	*/
	ensureDefaultRule: async (id) => {
		const cfg = getConfig();
		const ruleId = cfg.defaultRuleId;
		if (!ruleId) return { assigned: false };
		if ((await argusApi.getIdentityTeams(id)).length > 0) return { assigned: false };
		await argusApi.addTeamMembers(ruleId, { identityIds: [id] });
		return {
			assigned: true,
			ruleName: cfg.defaultRuleName
		};
	},
	listPhotoCampaigns: async () => {
		const data = await unwrap(argusFetch(`/api/photo-campaigns`, void 0, { allSites: true }));
		if (Array.isArray(data)) return data;
		return data?.campaigns ?? [];
	},
	getPhotoCampaign: (id) => unwrap(argusFetch(`/api/photo-campaigns/${encodeURIComponent(id)}`, void 0, { allSites: true })),
	createPhotoCampaign: (payload) => unwrap(argusFetch(`/api/photo-campaigns`, {
		method: "POST",
		body: JSON.stringify(payload)
	}, { allSites: true })),
	updatePhotoCampaign: (id, payload) => unwrap(argusFetch(`/api/photo-campaigns/${encodeURIComponent(id)}`, {
		method: "PUT",
		body: JSON.stringify(payload)
	}, { allSites: true })),
	deletePhotoCampaign: (id) => unwrap(argusFetch(`/api/photo-campaigns/${encodeURIComponent(id)}`, { method: "DELETE" }, { allSites: true })),
	listIdentities: async (params) => {
		const q = new URLSearchParams();
		q.set("includeDeleted", "false");
		q.set("skip", String(params?.skip ?? 0));
		q.set("take", String(params?.take ?? 50));
		const hasCriterion = Boolean(params?.query || params?.firstName || params?.lastName || params?.email || params?.company || params?.jobTitle || params?.department || params?.status);
		const effectiveQuery = params?.query ?? (params?.allSites && !hasCriterion ? "*" : void 0);
		if (effectiveQuery) q.set("query", effectiveQuery);
		if (params?.firstName) q.set("firstName", params.firstName);
		if (params?.lastName) q.set("lastName", params.lastName);
		if (params?.email) q.set("email", params.email);
		if (params?.company) q.set("company", params.company);
		if (params?.jobTitle) q.set("jobTitle", params.jobTitle);
		if (params?.department) q.set("department", params.department);
		if (params?.status) q.set("status", params.status.toLowerCase());
		if (params?.workerTypeCode) q.set("workerTypeCode", params.workerTypeCode);
		const data = await unwrap(argusFetch(`/api/identities/search?${q.toString()}`, {}, {
			allSites: params?.allSites,
			siteId: params?.siteId
		}));
		return {
			items: data.results ?? [],
			total: data.totalItems ?? data.results?.length ?? 0
		};
	},
	getIdentity: (id) => unwrap(argusFetch(`/api/identities/${encodeURIComponent(id)}`)),
	createIdentity: (data) => unwrap(argusFetch(`/api/identities`, {
		method: "POST",
		body: JSON.stringify(normalizeCreateIdentityPayload(data))
	})),
	updateIdentity: (id, data) => unwrap(argusFetch(`/api/identities/${encodeURIComponent(id)}`, {
		method: "PUT",
		body: JSON.stringify(normalizeUpdateIdentityPayload(data))
	})),
	deactivateIdentity: async (id) => {
		const current = await argusApi.getIdentity(id);
		await argusApi.updateIdentity(id, {
			...clearIdToFormValues(current),
			status: "Inactive",
			identityType: current.identityType ?? "Employee",
			eTag: current.eTag,
			description: current.description ?? void 0,
			countryCode: current.countryCode ?? void 0,
			culture: current.culture ?? void 0,
			middleName: current.middleName ?? void 0,
			displayName: current.displayName ?? void 0,
			privateData: current.privateData ?? void 0,
			companyData: current.companyData ?? void 0,
			systemData: current.systemData ?? void 0
		});
	},
	activateIdentity: (id) => argusFetch(`/api/identities/${encodeURIComponent(id)}/activate`, { method: "POST" }),
	/**
	* Solicita a sincronização das identidades com os sistemas integrados.
	* Deve ser chamado após incluir/alterar uma identity (e seus dados
	* complementares). `siteId` escopa a chamada; por padrão usa o site padrão.
	*/
	synchronizeIdentities: (ids, siteId) => unwrap(argusFetch(`/api/identities/synchronize`, {
		method: "POST",
		body: JSON.stringify({ IdentityIds: ids })
	}, { siteId: siteId ?? void 0 })),
	/**
	* Perfis de visita do site. O perfil define os motivos permitidos
	* (`visitReasons`) — o ClearID rejeita motivos fora dessa lista.
	*/
	listVisitProfiles: async () => {
		const data = await unwrap(argusFetch(`/api/visit-profiles`));
		if (Array.isArray(data)) return data;
		return data?.visitProfiles ?? [];
	},
	/** Busca visitas. `futureOnly` limita às que ainda vão ocorrer. */
	listVisits: async (params) => {
		const q = new URLSearchParams();
		q.set("take", String(params?.take ?? 50));
		if (params?.searchTerm) q.set("searchTerm", params.searchTerm);
		if (params?.status) q.set("status", params.status);
		if (params?.identityId) q.set("identityId", params.identityId);
		if (params?.futureOnly) q.set("futureOnly", "true");
		const data = await unwrap(argusFetch(`/api/visits?${q.toString()}`));
		if (Array.isArray(data)) return data;
		return data?.visitEvents ?? data?.results ?? [];
	},
	getVisit: (visitEventId) => unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}`)),
	createVisit: (payload) => unwrap(argusFetch(`/api/visits`, {
		method: "POST",
		body: JSON.stringify(payload)
	})),
	/** Visitantes da visita — traz o visitorId e o identityId (necessário p/ credencial). */
	listVisitVisitors: async (visitEventId) => {
		const data = await unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}/visitors`));
		if (Array.isArray(data)) return data;
		return data?.visitors ?? [];
	},
	/** Check-in em lote. `timestampUtc` omitido = agora (decidido pelo ClearID). */
	checkInVisitors: (visitEventId, visitorIds) => unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}/checkin`, {
		method: "POST",
		body: JSON.stringify({ visitorCheckIns: visitorIds.map((visitorId) => ({ visitorId })) })
	})),
	/** Check-out em lote. */
	checkOutVisitors: (visitEventId, visitorIds) => unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}/checkout`, {
		method: "POST",
		body: JSON.stringify({ visitorCheckOuts: visitorIds.map((visitorId) => ({ visitorId })) })
	})),
	/** Exclui a visita. */
	deleteVisit: (visitEventId) => unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}`, { method: "DELETE" })),
	/** Decisão sobre a visita: approve | deny | cancel. */
	decideVisit: (visitEventId, decision, comment) => unwrap(argusFetch(`/api/visits/${encodeURIComponent(visitEventId)}/${decision}`, {
		method: "POST",
		body: JSON.stringify({ comment: comment ?? null })
	})),
	listCredentialFormats: async () => {
		const systemObjectId = getSystemObjectId();
		const q = new URLSearchParams();
		if (systemObjectId) q.set("systemObjectId", systemObjectId);
		const data = await unwrap(argusFetch(`/api/credentials/formats?${q.toString()}`, void 0, { allSites: true }));
		if (Array.isArray(data)) return data;
		return data?.credentialFormats ?? data?.formats ?? [];
	},
	listCredentials: async (identityId) => {
		try {
			return parseCredentialsResponse(await unwrap(argusFetch(`/api/identities/${encodeURIComponent(identityId)}/credentials`)));
		} catch (e) {
			if (e instanceof ArgusApiError && e.status === 404) return [];
			throw e;
		}
	},
	createCredential: (payload) => {
		const status = { state: "Active" };
		if (payload.activationDateUtc) status.activationDateUtc = payload.activationDateUtc;
		if (payload.expirationDateUtc) {
			status.expirationDateUtc = payload.expirationDateUtc;
			const start = payload.activationDateUtc ? new Date(payload.activationDateUtc) : /* @__PURE__ */ new Date();
			const end = new Date(payload.expirationDateUtc);
			if (!Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime())) status.expirationDurationInDays = Math.max(0, Math.round((end.getTime() - start.getTime()) / 864e5));
		}
		const body = {
			credentialFormat: {
				formatId: payload.formatId,
				facilityCode: payload.facilityCode ?? null,
				cardNumber: payload.cardNumber
			},
			name: payload.name ?? `Cred ${payload.cardNumber}`,
			identityId: payload.identityId,
			status
		};
		if (payload.description) body.description = payload.description;
		return unwrap(argusFetch(`/api/credentials`, {
			method: "POST",
			body: JSON.stringify(body)
		}));
	},
	deleteCredential: (credentialId) => unwrap(argusFetch(`/api/credentials/${encodeURIComponent(credentialId)}`, { method: "DELETE" })),
	/** Baixa a foto da identidade como Blob. Retorna null em 404. */
	getIdentityPicture: async (id) => {
		const cfg = getConfig();
		if (!cfg.baseUrl) return null;
		let url = cfg.baseUrl.replace(/\/+$/, "") + `/api/identities/${encodeURIComponent(id)}/picture`;
		const headers = new Headers();
		if (cfg.apiKey) headers.set("Authorization", `Bearer ${cfg.apiKey}`);
		headers.set("X-ClearId-Environment", getActiveProfile());
		const _activeSite = getActiveSite();
		if (_activeSite) headers.set("X-Argus-Site", _activeSite);
		const sys = getSystemObjectId();
		if (sys) {
			headers.set("X-System-Object-Id", sys);
			url += (url.includes("?") ? "&" : "?") + "systemObjectId=" + encodeURIComponent(sys);
		}
		const res = await fetch(url, {
			credentials: "include",
			headers
		});
		if (res.status === 404) return null;
		if (!res.ok) throw new ArgusApiError({
			status: res.status,
			message: res.statusText
		});
		return await res.blob();
	},
	/** Envia uma nova foto (JPEG) para a identidade. */
	uploadIdentityPicture: async (id, blob) => {
		const cfg = getConfig();
		if (!cfg.baseUrl) throw new ArgusApiError({
			status: 0,
			message: "Base URL não configurada"
		});
		let url = cfg.baseUrl.replace(/\/+$/, "") + `/api/identities/${encodeURIComponent(id)}/picture`;
		const form = new FormData();
		form.append("picture", blob, "capture.jpg");
		const headers = new Headers();
		if (cfg.apiKey) headers.set("Authorization", `Bearer ${cfg.apiKey}`);
		headers.set("X-ClearId-Environment", getActiveProfile());
		const _activeSite = getActiveSite();
		if (_activeSite) headers.set("X-Argus-Site", _activeSite);
		const sys = getSystemObjectId();
		if (sys) {
			headers.set("X-System-Object-Id", sys);
			url += (url.includes("?") ? "&" : "?") + "systemObjectId=" + encodeURIComponent(sys);
		}
		const res = await fetch(url, {
			method: "POST",
			credentials: "include",
			headers,
			body: form
		});
		if (!res.ok) {
			const text = await res.text().catch(() => "");
			throw new ArgusApiError({
				status: res.status,
				message: text || res.statusText
			});
		}
	},
	/**
	* Importa identities a partir de uma planilha CSV/Excel via
	* POST /api/identities/import (multipart, campo `file`). `dryRun` simula
	* sem gravar. Retorna o log completo por linha.
	*/
	importIdentities: async (file, opts) => {
		const cfg = getConfig();
		if (!cfg.baseUrl) throw new ArgusApiError({
			status: 0,
			message: "Base URL não configurada"
		});
		let url = cfg.baseUrl.replace(/\/+$/, "") + `/api/identities/import`;
		if (opts?.dryRun) url += "?dryRun=true";
		const form = new FormData();
		form.append("file", file, file.name);
		const headers = new Headers();
		if (cfg.apiKey) headers.set("Authorization", `Bearer ${cfg.apiKey}`);
		headers.set("X-ClearId-Environment", getActiveProfile());
		const _activeSite = getActiveSite();
		if (_activeSite) headers.set("X-Argus-Site", _activeSite);
		const sys = getSystemObjectId();
		if (sys) {
			headers.set("X-System-Object-Id", sys);
			url += (url.includes("?") ? "&" : "?") + "systemObjectId=" + encodeURIComponent(sys);
		}
		const res = await fetch(url, {
			method: "POST",
			credentials: "include",
			headers,
			body: form
		});
		const body = await res.json().catch(() => null);
		if (!res.ok) {
			const message = body && typeof body === "object" && body.message || res.statusText;
			throw new ArgusApiError({
				status: res.status,
				message,
				raw: body
			});
		}
		return body && typeof body === "object" && "data" in body ? body.data : body;
	},
	/**
	* Diagnóstico: chama GET /api/diagnostics/test-connection. O backend define
	* o ambiente atual (demo/prod) — o frontend apenas exibe.
	*/
	diagnostics: async () => {
		const cfg = getConfig();
		const start = performance.now();
		try {
			const [conn, env] = await Promise.all([argusFetch(`/api/diagnostics/test-connection`), argusFetch(`/api/diagnostics/environment`).catch(() => null)]);
			const latencyMs = Math.round(performance.now() - start);
			const connBody = conn && typeof conn === "object" && "data" in conn && conn.data && typeof conn.data === "object" ? conn.data : conn;
			const envBody = env && typeof env === "object" && "data" in env && env.data && typeof env.data === "object" ? env.data : env ?? {};
			const environment = envBody.environment ?? connBody.environment ?? "—";
			const clientCode = envBody.accountId ?? envBody.AccountId ?? envBody.clientCode;
			const message = conn?.message ?? connBody.message;
			return {
				environment,
				clientCode,
				baseUrl: cfg.baseUrl,
				backend: {
					reachable: true,
					latencyMs,
					status: 200,
					message
				},
				checkedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
		} catch (e) {
			const err = e;
			return {
				environment: "—",
				baseUrl: cfg.baseUrl,
				backend: {
					reachable: false,
					status: err.status,
					message: err.message
				},
				checkedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
		}
	}
};
function customFieldsToRecord(cf) {
	const out = {};
	for (const f of cf ?? []) if (f.customFieldName) out[f.customFieldName] = f.customFieldValue ?? "";
	return out;
}
function getClearIdExternalId(i) {
	const systemExternalId = i.systemData?.externalId;
	if (typeof systemExternalId === "string" && systemExternalId.trim()) return systemExternalId;
	return i.externalId ?? "";
}
function clearIdToFormValues(i) {
	const company = i.companyData ?? null;
	const siteIdFromCompany = company && typeof company.siteId === "string" ? company.siteId : void 0;
	const workerTypeFromCompany = company && typeof company.workerTypeCode === "string" ? company.workerTypeCode : void 0;
	return {
		identityId: i.identityId,
		externalId: getClearIdExternalId(i),
		firstName: i.firstName ?? "",
		lastName: i.lastName ?? "",
		email: i.email ?? "",
		status: i.status === "Inactive" ? "Inactive" : "Active",
		customFields: customFieldsToRecord(i.systemData?.customFields),
		siteId: siteIdFromCompany ?? i.siteId ?? i.systemData?.siteId ?? void 0,
		workerTypeCode: workerTypeFromCompany ?? i.workerTypeCode ?? void 0,
		middleName: i.middleName ?? void 0,
		displayName: i.displayName ?? void 0,
		description: i.description ?? void 0,
		countryCode: i.countryCode ?? void 0,
		culture: i.culture ?? void 0,
		privateData: i.privateData ?? void 0,
		companyData: i.companyData ?? void 0
	};
}
//#endregion
export { useEnsureActiveSite as C, useDefaultSiteId as S, setSessionSiteId as _, clearIdToFormValues as a, useArgusConfig as b, getConfiguredSiteId as c, serializeCustomFieldsForPatch as d, setAccountId as f, setSessionProfile as g, setDefaultProfile as h, captureTokenFromUrl as i, getSystemObjectId as l, setConfiguredSiteId as m, CLEARID_PROFILES as n, getAccountId as o, setActiveSite as p, argusApi as r, getConfig as s, ArgusApiError as t, saveConfig as u, setSystemObjectId as v, useSystemObjectId as w, useDefaultProfile as x, useActiveProfile as y };
