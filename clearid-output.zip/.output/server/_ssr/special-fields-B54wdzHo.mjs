import { t as supabase } from "./client-pXxOjxhm.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/special-fields-B54wdzHo.js
function parseOptions(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const o of raw) {
		const v = o?.value;
		const l = o?.label;
		if (typeof v === "string" && v) out.push({
			value: v,
			label: typeof l === "string" && l ? l : v
		});
	}
	return out;
}
async function fetchSpecialFields() {
	const { data, error } = await supabase.from("special_custom_fields").select("custom_field_name, label, options");
	if (error) return [];
	return (data ?? []).map((r) => ({
		custom_field_name: r.custom_field_name,
		label: r.label ?? "",
		options: parseOptions(r.options)
	}));
}
function useSpecialFields() {
	const query = useQuery({
		queryKey: ["special-custom-fields"],
		queryFn: fetchSpecialFields,
		staleTime: 300 * 1e3,
		retry: false
	});
	const list = query.data ?? [];
	return {
		list,
		byName: new Map(list.map((s) => [s.custom_field_name, s.options])),
		labelByName: new Map(list.map((s) => [s.custom_field_name, s.label])),
		loaded: query.isSuccess
	};
}
//#endregion
export { useSpecialFields as t };
