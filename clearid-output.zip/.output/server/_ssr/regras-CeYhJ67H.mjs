import { a as objectType, o as stringType } from "../_libs/zod.mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/regras-CeYhJ67H.js
var $$splitComponentImporter = () => import("./regras-BvkfUWt1.mjs");
var searchSchema = objectType({
	teamId: stringType().optional(),
	view: stringType().optional()
});
var Route = createFileRoute("/_authenticated/regras")({
	head: () => ({ meta: [{ title: "Regras — Argus ClearID" }] }),
	validateSearch: (s) => searchSchema.parse(s),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
