import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as STANDARD_IDENTITY_FIELDS, r as useIdentityFieldLabels } from "./identity-labels-B1NFjUho.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { _ as CSS, a as PointerSensor, c as getFirstCollision, d as rectIntersection, g as useSensors, h as useSensor, i as MeasuringStrategy, m as useDroppable, o as closestCorners, r as KeyboardSensor, t as DndContext, u as pointerWithin } from "../_libs/@dnd-kit/core+[...].mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { N as Lock, V as GripVertical, h as Share2, l as Trash2, v as Search, w as Plus, z as Hourglass } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, _ as setSessionSiteId, g as setSessionProfile, r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { t as useSpecialFields } from "./special-fields-B54wdzHo.mjs";
import { a as useFormLayoutConfig, i as saveFormLayoutConfig, n as exportFormLayoutToClients, t as REQUIRED_KEYS } from "./form-layout-BbQ23fKU.mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
import { a as verticalListSortingStrategy, i as useSortable, n as rectSortingStrategy, r as sortableKeyboardCoordinates, t as SortableContext } from "../_libs/dnd-kit__sortable.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/layout-formulario-DIGkRBHv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LABEL_KEY = {
	company_worker_type_code: "identityForm.workerType",
	first_name: "common.name",
	last_name: "identityForm.lastName",
	display_name: "identityForm.displayName",
	email: "common.email",
	company_site_id: "identityForm.site",
	company_id: "identityForm.company"
};
var REQUIRED = new Set(REQUIRED_KEYS);
var ALL_KEYS = STANDARD_IDENTITY_FIELDS.map((f) => f.key);
var AVAILABLE = "available";
var uid = () => typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `id-${Math.round(performance.now() * 1e3)}`;
function layoutToModel(layout, pool) {
	const groups = layout.groups.map((g) => ({
		gid: uid(),
		name: g.name,
		fields: [...g.fields]
	}));
	if (groups.length === 0) groups.push({
		gid: uid(),
		name: "",
		fields: []
	});
	const used = new Set(groups.flatMap((g) => g.fields));
	return {
		available: pool.filter((k) => !used.has(k)),
		groups
	};
}
var modelToGroups = (m) => m.groups.map((g) => ({
	name: g.name.trim(),
	fields: g.fields
}));
function LayoutFormularioPage() {
	const { t, lang } = useT();
	const qc = useQueryClient();
	const { alias } = useIdentityFieldLabels();
	const activeProfile = useActiveProfile();
	const defaultSiteId = useDefaultSiteId();
	const scope = useUserScope();
	const sitesQuery = useQuery({
		queryKey: ["sites", activeProfile],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	const sites = scope.filterSites(sitesQuery.data ?? [], activeProfile).slice().sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "pt-BR"));
	const editSiteId = sites.find((s) => s.siteId === defaultSiteId)?.siteId ?? sites[0]?.siteId ?? "";
	const editSiteName = sites.find((s) => s.siteId === editSiteId)?.name ?? "";
	const changeClient = (code) => {
		if (code === activeProfile) return;
		setSessionProfile(code);
		setSessionSiteId(null);
		qc.clear();
	};
	const { config, loaded } = useFormLayoutConfig(activeProfile, editSiteId || null);
	const customFieldsQuery = useQuery({
		queryKey: ["custom-fields", activeProfile],
		queryFn: () => argusApi.listCustomFields(),
		staleTime: 300 * 1e3
	});
	const allCustomDefs = (customFieldsQuery.data ?? []).filter((f) => !f.isDeleted && f.customFieldName.startsWith("Vylor_"));
	const siteFieldsQuery = useQuery({
		queryKey: ["layout-site-field-names", editSiteId],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_custom_fields").select("definition:custom_field_definitions(custom_field_name, display_name, is_local)").eq("site_id", editSiteId ?? "").eq("entity_type", "identity").eq("is_active", true).returns();
			if (error) throw new Error(error.message);
			return (data ?? []).map((r) => r.definition).filter((d) => Boolean(d));
		},
		enabled: Boolean(editSiteId),
		staleTime: 300 * 1e3
	});
	const siteDefs = siteFieldsQuery.data ?? [];
	const siteFieldNames = siteFieldsQuery.data ? new Set(siteDefs.map((d) => d.custom_field_name)) : void 0;
	const { list: specialList, loaded: specialLoaded } = useSpecialFields();
	const siteCustomDefs = siteFieldNames ? allCustomDefs.filter((d) => siteFieldNames.has(d.customFieldName)) : allCustomDefs;
	const cfLabel = new Map(allCustomDefs.map((d) => ["cf:" + d.customFieldName, d.displayName || d.customFieldName]));
	for (const s of specialList) if (s.label) cfLabel.set("cf:" + s.custom_field_name, s.label);
	const localSiteDefs = siteDefs.filter((d) => d.is_local);
	for (const d of localSiteDefs) cfLabel.set("cf:" + d.custom_field_name, pickLang(d.display_name) || d.custom_field_name);
	const siteKeys = siteCustomDefs.map((d) => "cf:" + d.customFieldName);
	const specialKeys = specialList.map((s) => "cf:" + s.custom_field_name);
	const localKeys = localSiteDefs.map((d) => "cf:" + d.custom_field_name);
	const customKeys = [.../* @__PURE__ */ new Set([
		...siteKeys,
		...specialKeys,
		...localKeys
	])];
	const pool = [...ALL_KEYS, ...customKeys];
	const siteReady = !editSiteId || siteFieldsQuery.isSuccess;
	const ready = loaded && customFieldsQuery.isSuccess && siteReady && specialLoaded;
	const labelOf = (key) => {
		if (key.startsWith("cf:")) return alias(key.slice(3), cfLabel.get(key) ?? key.slice(3));
		return alias(key, t(LABEL_KEY[key] ?? `identityForm.extra.${key}`));
	};
	const [layouts, setLayouts] = (0, import_react.useState)([]);
	const [links, setLinks] = (0, import_react.useState)({});
	const [selId, setSelId] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)({
		available: [],
		groups: []
	});
	const [search, setSearch] = (0, import_react.useState)("");
	const initedKey = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const key = `${activeProfile}::${editSiteId}`;
		if (initedKey.current === key) return;
		initedKey.current = key;
		setLayouts(config.layouts.map((l) => ({
			...l,
			groups: l.groups.map((g) => ({ ...g }))
		})));
		setLinks({ ...config.links });
		const first = config.layouts[0];
		setSelId(first.id);
		setModel(layoutToModel(first, pool));
	}, [
		ready,
		activeProfile,
		editSiteId
	]);
	const workerTypes = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("is_active", true).eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			});
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	}).data ?? [];
	const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }), useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }));
	const selName = layouts.find((l) => l.id === selId)?.name ?? "";
	const commit = (ls) => ls.map((l) => l.id === selId ? {
		...l,
		groups: modelToGroups(model)
	} : l);
	const switchTo = (id) => {
		if (id === selId) return;
		const committed = commit(layouts);
		const target = committed.find((l) => l.id === id);
		setLayouts(committed);
		setSelId(id);
		if (target) setModel(layoutToModel(target, pool));
	};
	const addLayout = () => {
		const committed = commit(layouts);
		const nl = {
			id: uid(),
			name: t("formLayout.newLayoutName"),
			groups: [{
				name: "",
				fields: [...REQUIRED_KEYS]
			}]
		};
		setLayouts([...committed, nl]);
		setSelId(nl.id);
		setModel(layoutToModel(nl, pool));
	};
	const deleteLayout = () => {
		if (layouts.length <= 1) return;
		const remaining = layouts.filter((l) => l.id !== selId);
		setLinks((prev) => {
			const next = { ...prev };
			for (const k of Object.keys(next)) if (next[k] === selId) delete next[k];
			return next;
		});
		const next = remaining[0];
		setLayouts(remaining);
		setSelId(next.id);
		setModel(layoutToModel(next, pool));
	};
	const renameLayout = (name) => setLayouts((prev) => prev.map((l) => l.id === selId ? {
		...l,
		name
	} : l));
	const containerOf = (m, id) => {
		if (id === AVAILABLE || m.available.includes(id)) return AVAILABLE;
		const byId = m.groups.find((g) => g.gid === id);
		if (byId) return byId.gid;
		const byField = m.groups.find((g) => g.fields.includes(id));
		return byField ? byField.gid : null;
	};
	const listOf = (m, c) => c === AVAILABLE ? m.available : m.groups.find((g) => g.gid === c)?.fields ?? [];
	const isContainerId = (id) => id === AVAILABLE || model.groups.some((g) => g.gid === id);
	const collisionDetection = (args) => {
		const pointer = pointerWithin(args);
		const first = getFirstCollision(pointer.length ? pointer : rectIntersection(args), "id");
		if (first == null) return closestCorners(args);
		const overId = String(first);
		if (isContainerId(overId)) {
			const items = listOf(model, overId);
			if (items.length > 0) {
				const refined = closestCorners({
					...args,
					droppableContainers: args.droppableContainers.filter((c) => c.id !== overId && items.includes(String(c.id)))
				});
				if (refined.length) return refined;
			}
		}
		return [{ id: overId }];
	};
	const onDragEnd = (e) => {
		const activeId = String(e.active.id);
		const overId = e.over ? String(e.over.id) : null;
		if (!overId || activeId === overId) return;
		setModel((prev) => {
			const from = containerOf(prev, activeId);
			const to = containerOf(prev, overId);
			if (!from || !to) return prev;
			if (to === AVAILABLE && REQUIRED.has(activeId)) return prev;
			const m = {
				available: [...prev.available],
				groups: prev.groups.map((g) => ({
					...g,
					fields: [...g.fields]
				}))
			};
			const src = listOf(m, from);
			const oldIdx = src.indexOf(activeId);
			if (oldIdx < 0) return prev;
			if (from === to) {
				let newIdx = overId === to ? src.length - 1 : src.indexOf(overId);
				if (newIdx < 0) newIdx = src.length - 1;
				src.splice(oldIdx, 1);
				src.splice(newIdx, 0, activeId);
			} else {
				src.splice(oldIdx, 1);
				listOf(m, to).push(activeId);
			}
			return m;
		});
	};
	const renameGroup = (gid, name) => setModel((m) => ({
		...m,
		groups: m.groups.map((g) => g.gid === gid ? {
			...g,
			name
		} : g)
	}));
	const addGroup = () => setModel((m) => ({
		...m,
		groups: [...m.groups, {
			gid: uid(),
			name: "",
			fields: []
		}]
	}));
	const removeGroup = (gid) => setModel((m) => {
		if (m.groups.length <= 1) return m;
		const g = m.groups.find((x) => x.gid === gid);
		if (!g) return m;
		const rest = m.groups.filter((x) => x.gid !== gid);
		const req = g.fields.filter((k) => REQUIRED.has(k));
		const opt = g.fields.filter((k) => !REQUIRED.has(k));
		rest[0] = {
			...rest[0],
			fields: [...rest[0].fields, ...req]
		};
		return {
			available: [...m.available, ...opt],
			groups: rest
		};
	});
	const setLink = (wtId, layoutId) => setLinks((prev) => {
		const next = { ...prev };
		if (layoutId === "__default__") delete next[wtId];
		else next[wtId] = layoutId;
		return next;
	});
	const save = useMutation({
		mutationFn: async () => {
			const payload = {
				layouts: commit(layouts),
				links
			};
			await saveFormLayoutConfig(activeProfile, payload);
		},
		onSuccess: () => {
			toast.success(t("formLayout.saved"));
			qc.invalidateQueries({ queryKey: ["form-layout"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const [exportOpen, setExportOpen] = (0, import_react.useState)(false);
	const [exportTargets, setExportTargets] = (0, import_react.useState)({});
	const toggleTarget = (id) => setExportTargets((prev) => ({
		...prev,
		[id]: !prev[id]
	}));
	const exportMut = useMutation({
		mutationFn: async () => {
			const targets = Object.keys(exportTargets).filter((code) => exportTargets[code] && code !== activeProfile);
			if (targets.length === 0) throw new Error(t("formLayout.export.none"));
			await exportFormLayoutToClients({
				layouts: commit(layouts),
				links
			}, targets);
			return targets.length;
		},
		onSuccess: (count) => {
			toast.success(t("formLayout.export.done", { count }));
			qc.invalidateQueries({ queryKey: ["form-layout"] });
			setExportOpen(false);
			setExportTargets({});
		},
		onError: (e) => toast.error(e.message)
	});
	const q = search.trim().toLowerCase();
	const availShown = q ? model.available.filter((k) => labelOf(k).toLowerCase().includes(q)) : model.available;
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex cursor-wait items-center justify-center py-24 text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hourglass, { className: "mr-2 h-5 w-5 animate-pulse" }), t("common.loading")]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-6", save.isPending && "cursor-wait"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight text-foreground",
						children: t("formLayout.title")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full border px-2 py-0.5 text-xs font-medium text-muted-foreground",
						children: [
							t("shell.profile"),
							": ",
							activeProfile
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [t("formLayout.subtitle"), editSiteName && ` · ${t("formLayout.fieldsFromSite", { site: editSiteName })}`]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
						open: exportOpen,
						onOpenChange: setExportOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "mr-1 h-4 w-4" }), t("formLayout.export.button")]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
							className: "sm:max-w-[460px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("formLayout.export.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("formLayout.export.hint") })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-h-[50vh] space-y-2 overflow-y-auto py-2",
									children: [scope.visibleProfiles.filter((p) => p.code !== activeProfile).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											checked: Boolean(exportTargets[p.code]),
											onCheckedChange: () => toggleTarget(p.code)
										}), p.label]
									}, p.code)), scope.visibleProfiles.filter((p) => p.code !== activeProfile).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "py-4 text-center text-sm text-muted-foreground",
										children: t("formLayout.export.noOthers")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setExportOpen(false),
									children: t("common.cancel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => exportMut.mutate(),
									disabled: exportMut.isPending,
									children: exportMut.isPending ? t("common.saving") : t("formLayout.export.confirm")
								})] })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => save.mutate(),
						disabled: save.isPending,
						children: [save.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hourglass, { className: "mr-1 h-4 w-4 animate-pulse" }), t("common.save")]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-wrap items-end gap-3 pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: t("shell.profile")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: activeProfile,
							onValueChange: changeClient,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-56",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: scope.visibleProfiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: p.code,
								children: p.label
							}, p.code)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: t("formLayout.selectLayout")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: selId,
							onValueChange: switchTo,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-56",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: layouts.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: l.id,
								children: l.name.trim() || t("formLayout.newLayoutName")
							}, l.id)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 space-y-1.5 min-w-48",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: t("formLayout.layoutName")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: selName,
							onChange: (e) => renameLayout(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: addLayout,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }), t("formLayout.newLayout")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						className: "text-muted-foreground hover:text-destructive",
						disabled: layouts.length <= 1,
						onClick: deleteLayout,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mr-1 h-4 w-4" }), t("formLayout.deleteLayout")]
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("formLayout.links")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: t("formLayout.linksHint")
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "grid gap-3 sm:grid-cols-2",
				children: workerTypes.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-md border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: pickLang(w.name_i18n, lang) || w.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: links[w.id] ?? "__default__",
						onValueChange: (v) => setLink(w.id, v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-48",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "__default__",
							children: t("formLayout.useDefault")
						}), layouts.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: l.id,
							children: l.name.trim() || t("formLayout.newLayoutName")
						}, l.id))] })]
					})]
				}, w.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DndContext, {
				sensors,
				collisionDetection,
				measuring: { droppable: { strategy: MeasuringStrategy.Always } },
				onDragEnd,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 md:grid-cols-[16rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base font-semibold text-foreground",
								children: t("formLayout.available")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("formLayout.availableHint")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: search,
								onChange: (e) => setSearch(e.target.value),
								placeholder: t("common.search"),
								className: "h-9 pl-8"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droppable, {
							id: AVAILABLE,
							items: availShown,
							strategy: "list",
							className: "min-h-24",
							children: availShown.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldItem, {
								id: k,
								label: labelOf(k)
							}, k))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [model.groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
							className: "gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: g.name,
									onChange: (e) => renameGroup(g.gid, e.target.value),
									placeholder: t("formLayout.groupNamePlaceholder"),
									className: "h-8 font-medium"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive",
									disabled: model.groups.length <= 1,
									title: t("formLayout.removeGroup"),
									onClick: () => removeGroup(g.gid),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droppable, {
							id: g.gid,
							items: g.fields,
							strategy: "grid",
							emptyHint: t("formLayout.emptyGroup"),
							children: g.fields.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldItem, {
								id: k,
								label: labelOf(k)
							}, k))
						}) })] }, g.gid)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full",
							onClick: addGroup,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }), t("formLayout.addGroup")]
						})]
					})]
				})
			})
		]
	});
}
function Droppable({ id, items, emptyHint, className, strategy, children }) {
	const { setNodeRef, isOver } = useDroppable({ id });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableContext, {
		items,
		strategy: strategy === "grid" ? rectSortingStrategy : verticalListSortingStrategy,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: setNodeRef,
			className: cn("min-h-16 rounded-md border border-dashed p-2 transition-colors", strategy === "grid" ? "grid grid-cols-1 gap-2 sm:grid-cols-2" : "space-y-2", isOver && "border-primary bg-primary/5", className),
			children: [children, items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("py-4 text-center text-xs text-muted-foreground", strategy === "grid" && "sm:col-span-2"),
				children: emptyHint || " "
			})]
		})
	});
}
function FieldItem({ id, label }) {
	const required = REQUIRED.has(id);
	const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: setNodeRef,
		style: {
			transform: CSS.Transform.toString(transform),
			transition
		},
		className: cn("flex items-center gap-2 rounded-md border bg-card px-2 py-2 text-sm", isDragging && "opacity-50"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "cursor-grab touch-none text-muted-foreground active:cursor-grabbing",
				...attributes,
				...listeners,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "h-4 w-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 truncate",
				children: label
			}),
			required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				title: "Obrigatório",
				className: "text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-3.5 w-3.5" })
			})
		]
	});
}
//#endregion
export { LayoutFormularioPage as component };
