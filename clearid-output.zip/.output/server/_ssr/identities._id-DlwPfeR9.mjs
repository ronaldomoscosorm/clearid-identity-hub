import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identities._id-DlwPfeR9.js
var $$splitComponentImporter = () => import("./identities._id-n56Oi29-.mjs");
var Route = createFileRoute("/_authenticated/identities/$id")({
	head: () => ({ meta: [{ title: "Identity — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
