import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/client-settings-DnLX0jMS.js
var DEFAULT_STORAGE = "both";
function rowToSettings(row) {
	const raw = row.default_custom_field_storage ?? DEFAULT_STORAGE;
	const storage = raw === "clearid" || raw === "supabase" || raw === "both" ? raw : DEFAULT_STORAGE;
	return {
		profile: row.profile,
		defaultCustomFieldStorage: storage
	};
}
/**
* Configurações do cliente (profile ClearID). Uma linha por cliente,
* compartilhada entre todos os usuários daquele cliente. Se a linha
* ainda não existe, retorna um objeto com defaults sem falhar.
*/
function useClientSettings(profile) {
	return useQuery({
		queryKey: ["client-settings", profile],
		enabled: !!profile,
		queryFn: async () => {
			const { data, error } = await supabase.from("client_settings").select("profile,default_custom_field_storage").eq("profile", profile).maybeSingle();
			if (error) throw new Error(error.message);
			if (!data) return {
				profile,
				defaultCustomFieldStorage: DEFAULT_STORAGE
			};
			return rowToSettings(data);
		}
	});
}
/** Salva (upsert) as configurações do cliente ativo. */
function useUpdateClientSettings() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const { error } = await supabase.from("client_settings").upsert({
				profile: input.profile,
				default_custom_field_storage: input.defaultCustomFieldStorage
			}, { onConflict: "profile" });
			if (error) throw new Error(error.message);
		},
		onSuccess: (_r, vars) => {
			qc.invalidateQueries({ queryKey: ["client-settings", vars.profile] });
		}
	});
}
//#endregion
export { useUpdateClientSettings as n, useClientSettings as t };
