import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { M as LogIn, P as LoaderCircle, j as LogOut, l as Trash2, v as Search, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as CredentialsDialog } from "./CredentialsDialog-Dh7PlQvT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visitas.index-BkaISwbT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatDate(iso) {
	if (!iso) return "—";
	try {
		return new Date(iso).toLocaleString("pt-BR");
	} catch {
		return iso;
	}
}
/** Expected → CheckedIn → CheckedOut */
function visitorStateBadge(state, t) {
	const s = (state ?? "").toLowerCase();
	if (s === "checkedin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t("visits.state.checkedIn") });
	if (s === "checkedout") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "secondary",
		children: t("visits.state.checkedOut")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "outline",
		children: t("visits.state.expected")
	});
}
function VisitasPage() {
	const { t } = useT();
	const qc = useQueryClient();
	const [search, setSearch] = (0, import_react.useState)("");
	const [applied, setApplied] = (0, import_react.useState)("");
	const query = useQuery({
		queryKey: ["visits", applied],
		queryFn: () => argusApi.listVisits({
			searchTerm: applied || void 0,
			take: 50
		}),
		retry: false
	});
	const visits = query.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: t("visits.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("visits.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => query.refetch(),
						disabled: query.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${query.isFetching ? "animate-spin" : ""}` }), t("visits.refresh")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/visitas/nova",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
								" ",
								t("visits.newVisit")
							]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex gap-2 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && setApplied(search.trim()),
						placeholder: t("visits.searchPlaceholder"),
						className: "pl-8"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setApplied(search.trim()),
					disabled: query.isFetching,
					children: t("common.search")
				})]
			}) }),
			query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28 w-full" })]
			}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: query.error.message
			}) : visits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: t("visits.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: visits.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisitCard, {
					visit: v,
					onChanged: () => qc.invalidateQueries({ queryKey: ["visits"] })
				}, v.visitEventId))
			})
		]
	});
}
/** Uma visita, com seus visitantes e as ações de portaria. */
function VisitCard({ visit, onChanged }) {
	const { t } = useT();
	const qc = useQueryClient();
	const [sel, setSel] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const del = useMutation({
		mutationFn: () => argusApi.deleteVisit(visit.visitEventId),
		onSuccess: () => {
			toast.success(t("visits.deletedToast"));
			setConfirmDelete(false);
			onChanged();
		},
		onError: (e) => toast.error(e.message, { duration: 1e4 })
	});
	const visitorsQuery = useQuery({
		queryKey: ["visit-visitors", visit.visitEventId],
		queryFn: () => argusApi.listVisitVisitors(visit.visitEventId),
		retry: false
	});
	const visitors = visitorsQuery.data ?? [];
	const reload = async () => {
		setSel(/* @__PURE__ */ new Set());
		await qc.invalidateQueries({ queryKey: ["visit-visitors", visit.visitEventId] });
		onChanged();
	};
	const checkIn = useMutation({
		mutationFn: (ids) => argusApi.checkInVisitors(visit.visitEventId, ids),
		onSuccess: async (_r, ids) => {
			toast.success(t("visits.checkedInToast", { n: ids.length }));
			await reload();
		},
		onError: (e) => toast.error(e.message, { duration: 1e4 })
	});
	const checkOut = useMutation({
		mutationFn: (ids) => argusApi.checkOutVisitors(visit.visitEventId, ids),
		onSuccess: async (_r, ids) => {
			toast.success(t("visits.checkedOutToast", { n: ids.length }));
			await reload();
		},
		onError: (e) => toast.error(e.message, { duration: 1e4 })
	});
	const busy = checkIn.isPending || checkOut.isPending;
	const toggle = (id) => setSel((prev) => {
		const next = new Set(prev);
		if (next.has(id)) next.delete(id);
		else next.add(id);
		return next;
	});
	const stateOf = (v) => (v.visitorState ?? "").toLowerCase();
	const selArr = [...sel];
	const canCheckIn = selArr.some((id) => stateOf(visitors.find((v) => v.visitorId === id)) !== "checkedin");
	const canCheckOut = selArr.some((id) => stateOf(visitors.find((v) => v.visitorId === id)) === "checkedin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex-row items-start justify-between gap-3 space-y-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: visit.visitEventName || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						formatDate(visit.startDateTimeUtc),
						" → ",
						formatDate(visit.endDateTimeUtc)
					]
				}),
				visit.reason && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: visit.reason
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: (visit.status ?? "").toLowerCase() === "approved" ? "default" : "outline",
					children: visit.status || "—"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					title: t("visits.deleteVisit"),
					className: "text-destructive hover:text-destructive",
					onClick: () => setConfirmDelete(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "space-y-3",
			children: visitorsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full" }) : visitors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: t("visits.noVisitors")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-1",
				children: visitors.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded border p-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							checked: sel.has(v.visitorId),
							onCheckedChange: () => toggle(v.visitorId),
							disabled: busy
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [[v.firstName, v.lastName].filter(Boolean).join(" ") || "—", v.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-muted-foreground",
								children: v.email
							})]
						}),
						visitorStateBadge(v.visitorState, t),
						v.identityId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialsDialog, { identityId: v.identityId }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: t("visits.noIdentityForCredential")
						})
					]
				}, v.visitorId))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					disabled: !canCheckIn || busy,
					onClick: () => checkIn.mutate(selArr),
					children: [checkIn.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "mr-1 h-4 w-4" }), t("visits.checkIn")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					disabled: !canCheckOut || busy,
					onClick: () => checkOut.mutate(selArr),
					children: [checkOut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "mr-1 h-4 w-4" }), t("visits.checkOut")]
				})]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: confirmDelete,
			onOpenChange: setConfirmDelete,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("visits.confirmDeleteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("visits.confirmDeleteDesc", { name: visit.visitEventName || "—" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
				disabled: del.isPending,
				children: t("common.cancel")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
				disabled: del.isPending,
				onClick: (e) => {
					e.preventDefault();
					del.mutate();
				},
				children: del.isPending ? t("common.saving") : t("common.delete")
			})] })] })
		})
	] });
}
//#endregion
export { VisitasPage as component };
