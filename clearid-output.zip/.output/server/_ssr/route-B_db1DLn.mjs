import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime, M as Slot, d as DialogClose, f as DialogContent, g as DialogTitle, h as DialogPortal, m as DialogOverlay, p as DialogDescription, u as Dialog } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useT, t as LANGS } from "./i18n-Box3vBJj.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { $ as ClipboardList, D as PanelLeft, F as ListChecks, H as Globe, I as LayoutGrid, O as Palette, P as LoaderCircle, X as Database, Y as DoorOpen, Z as Cog, _ as Settings2, c as TriangleAlert, ct as ChevronDown, f as SlidersHorizontal, ft as Building2, g as Settings, gt as Activity, ht as ArrowLeft, j as LogOut, lt as Check, m as ShieldCheck, n as Wrench, nt as CircleUser, p as Shield, pt as BriefcaseBusiness, r as Users, s as Upload, t as X, u as Tag, ut as Camera, x as RefreshCw, z as Hourglass } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useApplyBranding, s as useBranding } from "./branding-lYWRBKZ3.mjs";
import { C as useEnsureActiveSite, S as useDefaultSiteId, _ as setSessionSiteId, b as useArgusConfig, g as setSessionProfile, p as setActiveSite, r as argusApi, s as getConfig, w as useSystemObjectId, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { n as getTheme, t as applyTheme } from "./theme-CZ6cvH_Z.mjs";
import { t as PoweredBy } from "./PoweredBy-CRi75zGX.mjs";
import { t as mirrorCustomFieldDefs } from "./supabase-mirror--nGFXAER.mjs";
import { n as useCurrentUser } from "./current-user-BxaXazZH.mjs";
import { f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
import { a as DropdownMenuSeparator, i as DropdownMenuLabel, n as DropdownMenuContent, o as DropdownMenuTrigger, r as DropdownMenuItem, t as DropdownMenu } from "./dropdown-menu-CsR71wG4.mjs";
import { t as Root } from "../_libs/radix-ui__react-separator.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/radix-ui__react-tooltip.mjs";
import { n as CollapsibleTrigger$1, r as Root$1, t as CollapsibleContent$1 } from "../_libs/radix-ui__react-collapsible.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-B_db1DLn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* URL absoluta do login do Portal Argus, configurável via env.
* Em prod: https://portal.rmtecho.com.br/login
* Em dev:  http://localhost:5173/login  (ou o que estiver no .env)
*/
function getPortalArgusLoginUrl(returnUrl) {
	const url = new URL("https://portalargus.rmtecho.com.br/login");
	if (returnUrl) url.searchParams.set("returnUrl", returnUrl);
	return url.toString();
}
/**
* Redireciona o navegador para o login do Portal Argus, guardando a URL atual como retorno.
* Chame quando detectar 401/sessão expirada.
*/
function redirectToPortalLogin(currentUrl) {
	if (typeof window === "undefined") return;
	const returnUrl = currentUrl ?? window.location.href;
	window.location.assign(getPortalArgusLoginUrl(returnUrl));
}
/**
* URL de logout do Portal Argus: a rota `/logout` do FRONTEND do portalargus.
* Essa rota encerra a sessão de forma COMPLETA — limpa o token local do Portal
* (localStorage), apaga o cookie SSO `rmtecho_token` (.rmtecho.com.br, some de todos
* os apps) via API, e cai na tela de login. Derivada da URL de login (mesmo origin).
*/
function getPortalArgusLogoutUrl() {
	const url = new URL(getPortalArgusLoginUrl());
	url.pathname = "/logout";
	url.search = "";
	return url.toString();
}
/**
* Encerra a sessão: navega para o logout do Portal (limpa localStorage do portalargus
* + cookie SSO compartilhado) e cai no login — sempre, mesmo se já estava logado.
*/
function redirectToLogout() {
	if (typeof window === "undefined") return;
	try {
		sessionStorage.removeItem("portal_auth_redirected");
		localStorage.removeItem("argus.ssoToken");
	} catch {}
	window.location.assign(getPortalArgusLogoutUrl());
}
function FlagIcon({ lang, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className,
		style: {
			display: "inline-block",
			width: "1.25rem",
			height: "0.833rem",
			borderRadius: "2px",
			overflow: "hidden",
			boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)",
			flexShrink: 0,
			lineHeight: 0
		},
		"aria-hidden": true,
		children: [
			lang === "pt-BR" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brazil, {}),
			lang === "en-US" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Usa, {}),
			lang === "es-ES" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spain, {})
		]
	});
}
function Brazil() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 16",
		width: "100%",
		height: "100%",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "24",
				height: "16",
				fill: "#009C3B"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "12,2 22,8 12,14 2,8",
				fill: "#FFDF00"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "8",
				r: "3.4",
				fill: "#002776"
			})
		]
	});
}
function Usa() {
	const stripe = 16 / 13;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 16",
		width: "100%",
		height: "100%",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			Array.from({ length: 13 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0",
				y: i * stripe,
				width: "24",
				height: stripe,
				fill: i % 2 === 0 ? "#B22234" : "#FFFFFF"
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0",
				y: "0",
				width: "10",
				height: stripe * 7,
				fill: "#3C3B6E"
			}),
			[
				1.6,
				4,
				6.4,
				8.4
			].map((cx, r) => [
				1.4,
				3.4,
				5.4
			].map((cy, c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx,
				cy: cy + r % 2 * 1,
				r: "0.5",
				fill: "#FFFFFF"
			}, `${r}-${c}`)))
		]
	});
}
function Spain() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 16",
		width: "100%",
		height: "100%",
		xmlns: "http://www.w3.org/2000/svg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "24",
			height: "16",
			fill: "#AA151B"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			y: "4",
			width: "24",
			height: "8",
			fill: "#F1BF00"
		})]
	});
}
/**
* Indicador do usuário autenticado no Portal Argus (SSO por cookie).
* Gracioso: não renderiza nada quando o backend não retorna um usuário
* (ex.: dev sem portal, sessão expirada) — não bloqueia nem polui a UI.
* A auth de DADOS (Supabase) continua pela sessão técnica; este badge reflete
* apenas a identidade de usuário vinda do backend Argus.
*/
function CurrentUserBadge() {
	const { data: user } = useCurrentUser();
	if (!user?.username) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-center gap-2 rounded-md border border-[var(--rm-line)] bg-[var(--rm-panel-2)] px-2 py-1.5 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUser, { className: "h-4 w-4 shrink-0 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 leading-tight",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate font-medium text-foreground",
					children: user.username
				}), user.argusProfile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate text-muted-foreground",
					children: user.argusProfile
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => redirectToLogout(),
				title: "Sair",
				"aria-label": "Sair",
				className: "ml-auto shrink-0 rounded p-1 text-muted-foreground hover:bg-[var(--rm-line)] hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" })
			})
		]
	});
}
var PORTAL_BASE = "https://portal.rmtecho.com.br/api";
async function fetchMenus() {
	const cfg = getConfig();
	const res = await fetch(`${cfg.baseUrl.replace(/\/+$/, "")}/api/menus`, {
		credentials: "include",
		headers: { Accept: "application/json" }
	});
	if (!res.ok) throw new Error(`GET /api/menus falhou (${res.status})`);
	return (await res.json()).data ?? [];
}
async function fetchWorkerTypes() {
	try {
		const cfg = getConfig();
		const res = await fetch(`${cfg.baseUrl.replace(/\/+$/, "")}/api/worker-types`, {
			credentials: "include",
			headers: { Accept: "application/json" }
		});
		if (!res.ok) return [];
		return (await res.json()).data ?? [];
	} catch {
		return [];
	}
}
async function fetchOperations(profileId) {
	if (profileId === "0") return [];
	const res = await fetch(`${PORTAL_BASE.replace(/\/+$/, "")}/access-profiles/${encodeURIComponent(profileId)}/menus`, {
		credentials: "include",
		headers: { Accept: "application/json" }
	});
	if (!res.ok) throw new Error(`GET access-profiles/${profileId}/menus falhou (${res.status})`);
	return await res.json();
}
function filterTreeByOperations(tree, opsByKey, bypass) {
	const walk = (nodes) => nodes.map((node) => {
		const children = walk(node.children);
		const op = opsByKey.get(node.key);
		const isSelectable = bypass || op?.select === true;
		const hasVisibleChildren = children.length > 0;
		if (!isSelectable && !hasVisibleChildren) return null;
		return {
			...node,
			children
		};
	}).filter((n) => n !== null).sort((a, b) => a.order - b.order);
	return walk(tree);
}
function injectDynamicChildren(tree, workerTypes) {
	return tree.map((node) => {
		let children = node.children.map((c) => ({ ...c }));
		if (node.dynamicChildren === "workerTypes") {
			const dyn = workerTypes.map((wt) => ({
				key: `${node.key}.${wt.code}`,
				label: wt.label,
				icon: wt.icon ?? null,
				route: wt.route,
				order: wt.order,
				children: [],
				dynamicChildren: null
			}));
			children = [...children, ...dyn].sort((a, b) => a.order - b.order);
		}
		return {
			...node,
			children: injectDynamicChildren(children, workerTypes)
		};
	});
}
function useMenuTree() {
	const { data: user } = useCurrentUser();
	const profileId = user?.accessProfileId ?? null;
	const bypass = profileId === "0" || profileId === null;
	return useQuery({
		queryKey: ["menu-tree", profileId ?? "anonymous"],
		enabled: !!user,
		staleTime: 5 * 6e4,
		queryFn: async () => {
			const [menus, workerTypes, operations] = await Promise.all([
				fetchMenus(),
				fetchWorkerTypes(),
				profileId ? fetchOperations(profileId) : Promise.resolve([])
			]);
			const opsByKey = new Map(operations.map((o) => [o.menuKey, o]));
			return {
				tree: filterTreeByOperations(injectDynamicChildren(menus, workerTypes), opsByKey, bypass),
				operations: opsByKey
			};
		}
	});
}
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
	const [isMobile, setIsMobile] = import_react.useState(void 0);
	import_react.useEffect(() => {
		const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
		const onChange = () => {
			setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		};
		mql.addEventListener("change", onChange);
		setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		return () => mql.removeEventListener("change", onChange);
	}, []);
	return !!isMobile;
}
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]", className),
	...props
}));
Separator.displayName = Root.displayName;
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var SIDEBAR_COOKIE_NAME = "sidebar_state";
var SIDEBAR_COOKIE_MAX_AGE = 3600 * 24 * 7;
var SIDEBAR_WIDTH = "16rem";
var SIDEBAR_WIDTH_MOBILE = "18rem";
var SIDEBAR_WIDTH_ICON = "3rem";
var SIDEBAR_KEYBOARD_SHORTCUT = "b";
var SidebarContext = import_react.createContext(null);
function useSidebar() {
	const context = import_react.useContext(SidebarContext);
	if (!context) throw new Error("useSidebar must be used within a SidebarProvider.");
	return context;
}
var SidebarProvider = import_react.forwardRef(({ defaultOpen = true, open: openProp, onOpenChange: setOpenProp, className, style, children, ...props }, ref) => {
	const isMobile = useIsMobile();
	const [openMobile, setOpenMobile] = import_react.useState(false);
	const [_open, _setOpen] = import_react.useState(defaultOpen);
	const open = openProp ?? _open;
	const setOpen = import_react.useCallback((value) => {
		const openState = typeof value === "function" ? value(open) : value;
		if (setOpenProp) setOpenProp(openState);
		else _setOpen(openState);
		document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
	}, [setOpenProp, open]);
	const toggleSidebar = import_react.useCallback(() => {
		return isMobile ? setOpenMobile((open) => !open) : setOpen((open) => !open);
	}, [
		isMobile,
		setOpen,
		setOpenMobile
	]);
	import_react.useEffect(() => {
		const handleKeyDown = (event) => {
			if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
				event.preventDefault();
				toggleSidebar();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [toggleSidebar]);
	const state = open ? "expanded" : "collapsed";
	const contextValue = import_react.useMemo(() => ({
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	}), [
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContext.Provider, {
		value: contextValue,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
			delayDuration: 0,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					"--sidebar-width": SIDEBAR_WIDTH,
					"--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
					...style
				},
				className: cn("group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar", className),
				ref,
				...props,
				children
			})
		})
	});
});
SidebarProvider.displayName = "SidebarProvider";
var Sidebar = import_react.forwardRef(({ side = "left", variant = "sidebar", collapsible = "offcanvas", className, children, ...props }, ref) => {
	const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
	if (collapsible === "none") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", className),
		ref,
		...props,
		children
	});
	if (isMobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: openMobile,
		onOpenChange: setOpenMobile,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			"data-sidebar": "sidebar",
			"data-mobile": "true",
			className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
			style: { "--sidebar-width": SIDEBAR_WIDTH_MOBILE },
			side,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
				className: "sr-only",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Sidebar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Displays the mobile sidebar." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full w-full flex-col",
				children
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: "group peer hidden text-sidebar-foreground md:block",
		"data-state": state,
		"data-collapsible": state === "collapsed" ? collapsible : "",
		"data-variant": variant,
		"data-side": side,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex", side === "left" ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]" : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]", variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", className),
			...props,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-sidebar": "sidebar",
				className: "flex h-full w-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow",
				children
			})
		})]
	});
});
Sidebar.displayName = "Sidebar";
var SidebarTrigger = import_react.forwardRef(({ className, onClick, ...props }, ref) => {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		"data-sidebar": "trigger",
		variant: "ghost",
		size: "icon",
		className: cn("h-7 w-7", className),
		onClick: (event) => {
			onClick?.(event);
			toggleSidebar();
		},
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Toggle Sidebar"
		})]
	});
});
SidebarTrigger.displayName = "SidebarTrigger";
var SidebarRail = import_react.forwardRef(({ className, ...props }, ref) => {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		"data-sidebar": "rail",
		"aria-label": "Toggle Sidebar",
		tabIndex: -1,
		onClick: toggleSidebar,
		title: "Toggle Sidebar",
		className: cn("absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex", "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize", "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize", "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar", "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2", "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2", className),
		...props
	});
});
SidebarRail.displayName = "SidebarRail";
var SidebarInset = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		ref,
		className: cn("relative flex w-full flex-1 flex-col bg-background", "md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow", className),
		...props
	});
});
SidebarInset.displayName = "SidebarInset";
var SidebarInput = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		ref,
		"data-sidebar": "input",
		className: cn("h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring", className),
		...props
	});
});
SidebarInput.displayName = "SidebarInput";
var SidebarHeader = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "header",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
});
SidebarHeader.displayName = "SidebarHeader";
var SidebarFooter = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "footer",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
});
SidebarFooter.displayName = "SidebarFooter";
var SidebarSeparator = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		ref,
		"data-sidebar": "separator",
		className: cn("mx-2 w-auto bg-sidebar-border", className),
		...props
	});
});
SidebarSeparator.displayName = "SidebarSeparator";
var SidebarContent = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "content",
		className: cn("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", className),
		...props
	});
});
SidebarContent.displayName = "SidebarContent";
var SidebarGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		"data-sidebar": "group",
		className: cn("relative flex w-full min-w-0 flex-col p-2", className),
		...props
	});
});
SidebarGroup.displayName = "SidebarGroup";
var SidebarGroupLabel = import_react.forwardRef(({ className, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "div", {
		ref,
		"data-sidebar": "group-label",
		className: cn("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0", className),
		...props
	});
});
SidebarGroupLabel.displayName = "SidebarGroupLabel";
var SidebarGroupAction = import_react.forwardRef(({ className, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-sidebar": "group-action",
		className: cn("absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", "after:absolute after:-inset-2 after:md:hidden", "group-data-[collapsible=icon]:hidden", className),
		...props
	});
});
SidebarGroupAction.displayName = "SidebarGroupAction";
var SidebarGroupContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	"data-sidebar": "group-content",
	className: cn("w-full text-sm", className),
	...props
}));
SidebarGroupContent.displayName = "SidebarGroupContent";
var SidebarMenu = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	ref,
	"data-sidebar": "menu",
	className: cn("flex w-full min-w-0 flex-col gap-1", className),
	...props
}));
SidebarMenu.displayName = "SidebarMenu";
var SidebarMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
	ref,
	"data-sidebar": "menu-item",
	className: cn("group/menu-item relative", className),
	...props
}));
SidebarMenuItem.displayName = "SidebarMenuItem";
var sidebarMenuButtonVariants = cva("peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring cursor-pointer transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", {
	variants: {
		variant: {
			default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
			outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
		},
		size: {
			default: "h-8 text-sm",
			sm: "h-7 text-xs",
			lg: "h-12 text-sm group-data-[collapsible=icon]:!p-0"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var SidebarMenuButton = import_react.forwardRef(({ asChild = false, isActive = false, variant = "default", size = "default", tooltip, className, ...props }, ref) => {
	const Comp = asChild ? Slot : "button";
	const { isMobile, state } = useSidebar();
	const button = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {
		ref,
		"data-sidebar": "menu-button",
		"data-size": size,
		"data-active": isActive,
		className: cn(sidebarMenuButtonVariants({
			variant,
			size
		}), className),
		...props
	});
	if (!tooltip) return button;
	if (typeof tooltip === "string") tooltip = { children: tooltip };
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children: button
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		side: "right",
		align: "center",
		hidden: state !== "collapsed" || isMobile,
		...tooltip
	})] });
});
SidebarMenuButton.displayName = "SidebarMenuButton";
var SidebarMenuAction = import_react.forwardRef(({ className, asChild = false, showOnHover = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-sidebar": "menu-action",
		className: cn("absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0", "after:absolute after:-inset-2 after:md:hidden", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", showOnHover && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0", className),
		...props
	});
});
SidebarMenuAction.displayName = "SidebarMenuAction";
var SidebarMenuBadge = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	"data-sidebar": "menu-badge",
	className: cn("pointer-events-none absolute right-1 flex h-5 min-w-5 select-none items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground", "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground", "peer-data-[size=sm]/menu-button:top-1", "peer-data-[size=default]/menu-button:top-1.5", "peer-data-[size=lg]/menu-button:top-2.5", "group-data-[collapsible=icon]:hidden", className),
	...props
}));
SidebarMenuBadge.displayName = "SidebarMenuBadge";
var SidebarMenuSkeleton = import_react.forwardRef(({ className, showIcon = false, ...props }, ref) => {
	const width = import_react.useMemo(() => {
		return `${Math.floor(Math.random() * 40) + 50}%`;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		"data-sidebar": "menu-skeleton",
		className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
		...props,
		children: [showIcon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "size-4 rounded-md",
			"data-sidebar": "menu-skeleton-icon"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "h-4 max-w-(--skeleton-width) flex-1",
			"data-sidebar": "menu-skeleton-text",
			style: { "--skeleton-width": width }
		})]
	});
});
SidebarMenuSkeleton.displayName = "SidebarMenuSkeleton";
var SidebarMenuSub = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
	ref,
	"data-sidebar": "menu-sub",
	className: cn("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5", "group-data-[collapsible=icon]:hidden", className),
	...props
}));
SidebarMenuSub.displayName = "SidebarMenuSub";
var SidebarMenuSubItem = import_react.forwardRef(({ ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
	ref,
	...props
}));
SidebarMenuSubItem.displayName = "SidebarMenuSubItem";
var SidebarMenuSubButton = import_react.forwardRef(({ asChild = false, size = "md", isActive, className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "a", {
		ref,
		"data-sidebar": "menu-sub-button",
		"data-size": size,
		"data-active": isActive,
		className: cn("flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground", "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground", size === "sm" && "text-xs", size === "md" && "text-sm", "group-data-[collapsible=icon]:hidden", className),
		...props
	});
});
SidebarMenuSubButton.displayName = "SidebarMenuSubButton";
var Collapsible = Root$1;
var CollapsibleTrigger = CollapsibleTrigger$1;
var CollapsibleContent = CollapsibleContent$1;
var NAV = [
	{
		kind: "group",
		key: "nav.cadastro",
		icon: ClipboardList,
		items: [
			{
				to: "/identities",
				icon: Users,
				key: "nav.identities",
				dynamic: "workerTypes"
			},
			{
				to: "/visitas",
				icon: DoorOpen,
				key: "nav.visitas"
			},
			{
				to: "/regras",
				icon: ShieldCheck,
				key: "nav.regras"
			}
		]
	},
	{
		kind: "group",
		key: "nav.utilities",
		icon: Wrench,
		items: [{
			to: "/campanhas-foto",
			icon: Camera,
			key: "nav.campanhas-foto"
		}, {
			to: "/importar",
			icon: Upload,
			key: "nav.importar"
		}]
	},
	{
		kind: "group",
		key: "nav.tables",
		icon: Database,
		items: [{
			to: "/empresas",
			icon: Building2,
			key: "nav.empresas"
		}, {
			to: "/tipos-trabalhador",
			icon: BriefcaseBusiness,
			key: "nav.tipos-trabalhador"
		}]
	},
	{
		kind: "group",
		key: "nav.configGroup",
		icon: Settings2,
		items: [
			{
				to: "/campos-personalizados",
				icon: ListChecks,
				key: "nav.campos-personalizados"
			},
			{
				to: "/campos-do-site",
				icon: SlidersHorizontal,
				key: "nav.campos-do-site"
			},
			{
				to: "/apelidos",
				icon: Tag,
				key: "nav.apelidos"
			},
			{
				to: "/layout-formulario",
				icon: LayoutGrid,
				key: "nav.layout-formulario"
			}
		]
	},
	{
		kind: "group",
		key: "nav.properties",
		icon: Cog,
		items: [
			{
				to: "/diagnostics",
				icon: Activity,
				key: "nav.diagnostics"
			},
			{
				to: "/settings",
				icon: Settings,
				key: "nav.settings"
			},
			{
				to: "/branding",
				icon: Palette,
				key: "nav.branding"
			}
		]
	}
];
/** Normaliza a key do NAV (ex.: "nav.identities") para a key de menu do backend ("identities"). */
var menuKeyOf = (navKey) => navKey.replace(/^nav\./, "");
/** Coleta todas as keys de menu de uma árvore vinda do backend. */
function collectMenuKeys(tree, acc = /* @__PURE__ */ new Set()) {
	for (const node of tree) {
		acc.add(node.key);
		if (node.children?.length) collectMenuKeys(node.children, acc);
	}
	return acc;
}
/**
* Filtra o NAV pelas keys permitidas ao usuário (vindas do useMenuTree). `null` =
* sem restrição (fallback dev/sem backend) → mostra tudo. Um grupo aparece se ele
* próprio ou algum item filho estiver permitido.
*/
function filterNav(nav, allowed) {
	if (!allowed) return nav;
	const out = [];
	for (const entry of nav) {
		if (entry.kind === "item") {
			if (allowed.has(menuKeyOf(entry.key))) out.push(entry);
			continue;
		}
		const items = entry.items.filter((it) => allowed.has(menuKeyOf(it.key)));
		if (items.length > 0 || allowed.has(menuKeyOf(entry.key))) out.push({
			...entry,
			items
		});
	}
	return out;
}
function NavGroup({ group, pathname, t }) {
	const active = group.items.some((i) => pathname.startsWith(i.to));
	const [open, setOpen] = (0, import_react.useState)(active);
	(0, import_react.useEffect)(() => {
		if (active) setOpen(true);
	}, [active]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collapsible, {
		open,
		onOpenChange: setOpen,
		className: "group/nav",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuItem, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
				isActive: active,
				tooltip: t(group.key),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(group.icon, { className: "h-4 w-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(group.key) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "ml-auto h-4 w-4 transition-transform group-data-[state=open]/nav:rotate-180" })
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSub, { children: group.items.map((item) => item.dynamic === "workerTypes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentitiesSubNav, {
			item,
			pathname
		}, item.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubButton, {
			asChild: true,
			isActive: pathname.startsWith(item.to),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(item.key) })]
			})
		}) }, item.to)) }) })] })
	});
}
function IdentitiesSubNav({ item, pathname }) {
	const { t, lang } = useT();
	const activeProfile = useActiveProfile();
	const workerTypes = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("is_active", true).eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			});
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	}).data ?? [];
	const onSection = pathname.startsWith(item.to);
	const [open, setOpen] = (0, import_react.useState)(onSection);
	(0, import_react.useEffect)(() => {
		if (onSection) setOpen(true);
	}, [onSection]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collapsible, {
		open,
		onOpenChange: setOpen,
		className: "group/sub",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuSubItem, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuSubButton, {
				isActive: onSection,
				className: "cursor-pointer",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-4 w-4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(item.key) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "ml-auto h-4 w-4 transition-transform group-data-[state=open]/sub:rotate-180" })
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuSub, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubButton, {
			asChild: true,
			isActive: pathname === item.to,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("nav.identitiesAll") })
			})
		}) }), workerTypes.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSubButton, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/identities/new",
				search: { type: w.id },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pickLang(w.name_i18n, lang) || w.name })
			})
		}) }, w.id))] }) })] })
	});
}
function EnvBadge({ env }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wide", env.toLowerCase() === "prod" || env.toLowerCase() === "production" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-current" }), env]
	});
}
function AppShell({ children }) {
	const config = useArgusConfig();
	const env = useQuery({
		queryKey: ["backend-env", config.baseUrl],
		queryFn: argusApi.diagnostics,
		refetchInterval: 6e4,
		retry: false
	}).data?.environment ?? "…";
	const siteId = useDefaultSiteId();
	const systemObjectId = useSystemObjectId();
	const activeProfile = useActiveProfile();
	const sitesQuery = useQuery({
		queryKey: ["argus", "sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 5 * 6e4,
		retry: false
	});
	const currentSite = sitesQuery.data?.find((s) => s.siteId === siteId);
	const { data: currentUser } = useCurrentUser();
	const { data: menuData } = useMenuTree();
	const userSites = currentUser?.sites ?? [];
	const { restrictByUser, allowedClientCodes, visibleProfiles, filterSites } = useUserScope();
	useEnsureActiveSite(restrictByUser ? userSites : void 0);
	const visibleSites = filterSites(sitesQuery.data ?? [], activeProfile);
	const visibleNav = filterNav(NAV, menuData ? collectMenuKeys(menuData.tree) : null);
	(0, import_react.useEffect)(() => {
		if (!restrictByUser) return;
		if (allowedClientCodes.has(activeProfile.toLowerCase())) return;
		const first = visibleProfiles[0];
		if (first && first.code !== activeProfile) {
			setSessionProfile(first.code);
			setSessionSiteId(null);
		}
	}, [
		userSites.join(","),
		activeProfile,
		restrictByUser
	]);
	const branding = useBranding();
	useApplyBranding();
	const { t, lang, setLang } = useT();
	const queryClient = useQueryClient();
	const [refreshing, setRefreshing] = (0, import_react.useState)(false);
	const changeProfile = (code) => {
		if (code === activeProfile) return;
		setSessionProfile(code);
		setSessionSiteId(null);
		queryClient.clear();
	};
	(0, import_react.useEffect)(() => {
		applyTheme(getTheme());
	}, []);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const customFieldsQuery = useQuery({
		queryKey: ["custom-fields"],
		queryFn: () => argusApi.listCustomFields(),
		staleTime: 300 * 1e3
	});
	(0, import_react.useEffect)(() => {
		const defs = customFieldsQuery.data;
		if (defs?.length) mirrorCustomFieldDefs(defs.filter((d) => !d.isDeleted));
	}, [customFieldsQuery.data]);
	const invalidatePageQueries = () => {
		queryClient.invalidateQueries({ predicate: (q) => {
			const k0 = q.queryKey?.[0];
			const k1 = q.queryKey?.[1];
			if (k0 === "backend-env") return false;
			if (k0 === "argus" && k1 === "sites") return false;
			return true;
		} });
	};
	(0, import_react.useEffect)(() => {
		invalidatePageQueries();
	}, [config.baseUrl]);
	(0, import_react.useEffect)(() => {
		invalidatePageQueries();
	}, [siteId]);
	(0, import_react.useEffect)(() => {
		invalidatePageQueries();
	}, [systemObjectId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen w-full bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sidebar, {
			collapsible: "icon",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/identities",
					className: "flex items-center gap-2 px-2 py-1.5",
					children: [branding.clientLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: branding.clientLogo,
						alt: branding.clientName || "Logo",
						className: "h-8 w-8 shrink-0 rounded-md object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "leading-tight group-data-[collapsible=icon]:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold text-foreground",
							children: "Argus ClearID"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-wider text-muted-foreground",
							children: branding.clientName || t("shell.console")
						})]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenu, { children: visibleNav.map((entry) => entry.kind === "item" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuButton, {
					asChild: true,
					isActive: pathname.startsWith(entry.to),
					tooltip: t(entry.key),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: entry.to,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(entry.icon, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(entry.key) })]
					})
				}) }, entry.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavGroup, {
					group: entry,
					pathname,
					t
				}, entry.key)) }) }) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-2 group-data-[collapsible=icon]:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrentUserBadge, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoweredBy, {})]
				}) })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarInset, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-40 flex h-14 items-center gap-3 border-b bg-card/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-card/80 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { className: "-ml-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-3",
				children: [
					currentUser?.username ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-8 gap-1.5 font-normal",
							title: currentUser.username,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUser, { className: "h-4 w-4 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-[160px] truncate text-xs",
									children: currentUser.username
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 text-muted-foreground" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-64",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, {
								className: "flex flex-col gap-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-medium",
									children: currentUser.username
								}), currentUser.argusProfile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-xs font-normal text-muted-foreground",
									children: currentUser.argusProfile
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: () => redirectToLogout(),
								className: "flex items-center gap-2 text-destructive focus:text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sair" })]
							})
						]
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: cn("h-8 gap-1.5 font-normal", refreshing && "cursor-wait"),
						title: t("shell.refreshTitle"),
						disabled: refreshing,
						onClick: async () => {
							setRefreshing(true);
							try {
								await queryClient.invalidateQueries();
								toast.success(t("shell.refreshed"));
							} finally {
								setRefreshing(false);
							}
						},
						children: [refreshing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hourglass, { className: "h-3.5 w-3.5 animate-pulse text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: t("shell.refresh")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-8 gap-1.5 font-normal",
							title: t("shell.language"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlagIcon, { lang }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs",
									children: LANGS.find((l) => l.code === lang)?.short ?? lang
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 text-muted-foreground" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-44",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: t("shell.language") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: () => setLang(l.code),
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlagIcon, { lang: l.code }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1",
										children: l.label
									}),
									l.code === lang && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" })
								]
							}, l.code))
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-8 gap-1.5 font-normal",
							title: t("shell.profile"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "h-3.5 w-3.5 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "max-w-[160px] truncate text-xs",
									children: [
										t("shell.profile"),
										": ",
										activeProfile
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 text-muted-foreground" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "w-52",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: t("shell.profile") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							visibleProfiles.length ? visibleProfiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: () => changeProfile(p.code),
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: p.label
								}), p.code === activeProfile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" })]
							}, p.code)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								disabled: true,
								children: t("shell.noClients")
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "h-8 gap-1.5 font-normal",
							title: t("shell.defaultSite"),
							disabled: !visibleSites.length,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "h-3.5 w-3.5 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-[180px] truncate text-xs",
									children: currentSite?.name ?? siteId ?? t("shell.selectSite")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5 text-muted-foreground" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						className: "max-h-80 w-64 overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: t("shell.defaultSite") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							visibleSites.length ? [...visibleSites].sort((a, b) => (a.name ?? a.siteId).localeCompare(b.name ?? b.siteId, "pt-BR", { sensitivity: "base" })).map((s) => {
								const active = s.siteId === siteId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onClick: () => {
										setSessionSiteId(s.siteId);
										setActiveSite(`${activeProfile}:${s.name ?? s.siteId}`);
									},
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: s.name ?? s.siteId
									}), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" })]
								}, s.siteId);
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
								disabled: true,
								children: t("shell.noSites")
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnvBadge, { env })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: cn("flex-1 px-4 py-8 sm:px-6", refreshing && "cursor-wait"),
			"data-route": pathname,
			children
		})] })]
	}) });
}
/**
* Tela exibida quando o usuário está autenticado no Portal Argus (cookie SSO válido),
* porém NÃO tem grant para acessar o app ClearID (claim `apps` sem "argus"), ou tem
* grant no app mas não tem nenhum site vinculado.
*
* O usuário tem 2 saídas:
*   1. Voltar ao Portal Argus — para escolher outro app que ele tenha acesso.
*   2. Sair — remove o cookie SSO (via logout do Portal) e volta ao login.
*/
function AccessDenied({ username, reason }) {
	const message = reason === "no-app" ? "Você está autenticado, mas ainda não tem permissão para acessar o ClearID." : "Você tem acesso ao ClearID, mas nenhum site foi liberado ao seu usuário.";
	const detail = reason === "no-app" ? "Peça ao administrador para conceder o app 'ClearID' ao seu usuário no Portal Argus." : "Peça ao administrador para vincular ao menos um site (cliente + unidade) ao seu usuário no Portal Argus.";
	const portalUrl = getPortalArgusLoginUrl();
	const logoutUrl = getPortalArgusLogoutUrl();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-lg border bg-card p-8 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 text-amber-600",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-6 w-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-2 text-center text-xl font-semibold",
					children: "Acesso negado ao ClearID"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 text-center text-sm text-muted-foreground",
					children: ["Usuário autenticado: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: username
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-center text-sm text-muted-foreground",
					children: message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-6 rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900",
					children: detail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "default",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: portalUrl,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-2 h-4 w-4" }), "Voltar ao Portal Argus"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: logoutUrl,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "mr-2 h-4 w-4" }), "Sair"]
						})
					})]
				})
			]
		})
	});
}
var ARGUS_APP_CODE = "clearid";
/** Marca (por aba) do último redirect ao login — usada só p/ detectar loop rápido. */
var REDIRECTED_FLAG = "portal_auth_redirected";
/**
* Janela do loop-guard: só bloqueia um novo redirect se o anterior foi há menos que
* isto (ms). Assim um loop real (clearid → login → clearid automático) é contido, mas
* uma nova visita legítima sem sessão (o usuário digita a URL de novo) redireciona normal.
*/
var REDIRECT_LOOP_WINDOW_MS = 1e4;
/**
* Guarda de autenticação de USUÁRIO (Portal Argus / SSO por cookie).
*
* Comportamento (fail-closed): se NÃO houver um usuário confirmado — seja porque
* o backend respondeu "sem usuário" (401/403) OU porque não deu para verificar
* (erro de rede/CORS/timeout) — redireciona para o login do Portal Argus.
*
* Proteção contra loop (por tempo): se acabou de redirecionar (< janela) e voltou
* sem usuário, renderiza em vez de redirecionar de novo (evita loop clearid↔login).
* Uma nova visita sem sessão, fora da janela, redireciona normalmente. Ao autenticar,
* a marca é limpa.
*
* A auth de DADOS continua pela sessão técnica do Supabase (independente disto).
*/
function AuthGuard({ children }) {
	const { data, isError, isSuccess } = useCurrentUser();
	const [redirecting, setRedirecting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!!data && !!data.username && data.username.length > 0) {
			try {
				sessionStorage.removeItem(REDIRECTED_FLAG);
			} catch {}
			return;
		}
		if (!(isSuccess || isError)) return;
		let lastTs = 0;
		try {
			lastTs = Number(sessionStorage.getItem(REDIRECTED_FLAG)) || 0;
		} catch {}
		if (Date.now() - lastTs < REDIRECT_LOOP_WINDOW_MS) return;
		try {
			sessionStorage.setItem(REDIRECTED_FLAG, String(Date.now()));
		} catch {}
		setRedirecting(true);
		redirectToPortalLogin();
	}, [
		isSuccess,
		isError,
		data,
		false
	]);
	if (redirecting) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSplash, { label: "Redirecionando ao login…" });
	if (data && data.username) {
		if (!data.apps?.some((a) => a?.toLowerCase() === ARGUS_APP_CODE)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessDenied, {
			username: data.username,
			reason: "no-app"
		});
		if (!data.sites || data.sites.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessDenied, {
			username: data.username,
			reason: "no-sites"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function AuthSplash({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: label
		})]
	});
}
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthGuard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) });
//#endregion
export { SplitComponent as component };
