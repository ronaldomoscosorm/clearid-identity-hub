import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { a as typeOf, i as pickLang, n as isTruthy, r as optionsOf } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as STANDARD_IDENTITY_FIELDS, r as useIdentityFieldLabels } from "./identity-labels-B1NFjUho.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { n as buttonVariants, r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { B as History, E as Paperclip, J as Download, P as LoaderCircle, R as Image, U as FileText, ct as ChevronDown, dt as Calendar$1, it as ChevronsUpDown, lt as Check, ot as ChevronRight, s as Upload, st as ChevronLeft, t as X, v as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as objectType, n as enumType, o as stringType } from "../_libs/zod.mjs";
import { S as useDefaultSiteId, r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { t as useSpecialFields } from "./special-fields-B54wdzHo.mjs";
import { d as format, o as parse, t as ptBR } from "../_libs/date-fns.mjs";
import { n as signedUrlFor, r as useAttachmentVersions } from "./attachments-PsPmKuGo.mjs";
import { a as useFormLayoutConfig, r as layoutForWorkerType } from "./form-layout-BbQ23fKU.mjs";
import { t as PhotoCapture } from "./PhotoCapture-DfwwRG7z.mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
import { n as getDefaultClassNames, t as DayPicker } from "../_libs/react-day-picker.mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/radix-ui__react-popover.mjs";
import { t as _e } from "../_libs/cmdk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IdentityForm-DlM5ERWD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_ACCEPT = "image/*,application/pdf";
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
	return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}
function isImage(mime) {
	return mime.startsWith("image/");
}
/** Abre o arquivo (URL assinada temporária) em nova aba, para baixar/visualizar. */
async function openAttachment(path, onError) {
	try {
		const url = await signedUrlFor(path);
		window.open(url, "_blank", "noopener,noreferrer");
	} catch (e) {
		onError(e.message);
	}
}
/** Miniatura da imagem da versão atual (resolve URL assinada sob demanda). */
function CurrentThumb({ version }) {
	const { data: url } = useQuery({
		queryKey: ["attachment-thumb", version.id],
		queryFn: () => signedUrlFor(version.storage_path),
		enabled: isImage(version.mime_type),
		staleTime: 240 * 1e3
	});
	if (!isImage(version.mime_type)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-16 w-16 shrink-0 items-center justify-center rounded-md border bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-6 w-6 text-muted-foreground" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-md border bg-muted",
		children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: version.file_name,
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "h-6 w-6 text-muted-foreground" })
	});
}
function AttachmentField({ definitionId, identityDbId, label, required, disabled, accept, staged, onStage, error }) {
	const { t } = useT();
	const fileRef = (0, import_react.useRef)(null);
	const [showHistory, setShowHistory] = (0, import_react.useState)(false);
	const versionsQuery = useAttachmentVersions(identityDbId, definitionId);
	const versions = versionsQuery.data ?? [];
	const current = versions.find((v) => v.is_current) ?? null;
	const history = versions.filter((v) => !v.is_current);
	const onError = (msg) => toast.error(msg);
	const pick = (f) => {
		if (!f) return;
		onStage(f);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				className: "text-xs text-muted-foreground",
				children: [
					label,
					required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-0.5 text-destructive",
						children: "*"
					}),
					disabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1 text-muted-foreground",
						children: t("identityForm.readOnly")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-md border p-3", error && "border-destructive"),
				children: [
					versionsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
							" ",
							t("common.loading")
						]
					}) : current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrentThumb, { version: current }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: current.file_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										t("attachment.versionLabel", { n: current.version }),
										" ·",
										" ",
										formatBytes(current.size_bytes)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => openAttachment(current.storage_path, onError),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "mr-1 h-3.5 w-3.5" }),
									" ",
									t("attachment.download")
								]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-3.5 w-3.5" }),
							" ",
							t("attachment.none")
						]
					}),
					staged && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2 rounded-md bg-muted px-2.5 py-1.5 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-3.5 w-3.5 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate font-medium",
								children: staged.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-muted-foreground",
								children: formatBytes(staged.size)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "shrink-0 text-muted-foreground hover:text-destructive",
								onClick: () => onStage(null),
								"aria-label": t("common.remove"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
							})
						]
					}),
					!disabled && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => fileRef.current?.click(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-1 h-3.5 w-3.5" }), current || staged ? t("attachment.replace") : t("attachment.upload")]
							}),
							history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "ghost",
								onClick: () => setShowHistory((v) => !v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "mr-1 h-3.5 w-3.5" }), t("attachment.history", { n: history.length })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: accept || DEFAULT_ACCEPT,
								className: "hidden",
								onChange: (e) => {
									pick(e.target.files?.[0] ?? null);
									e.target.value = "";
								}
							})
						]
					}),
					showHistory && history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 border-t pt-3",
						children: history.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 text-xs",
							children: [
								isImage(v.mime_type) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-muted-foreground",
									children: t("attachment.versionLabel", { n: v.version })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: v.file_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "shrink-0 text-primary hover:underline",
									onClick: () => openAttachment(v.storage_path, onError),
									children: t("attachment.download")
								})
							]
						}, v.id))
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function Calendar({ className, classNames, showOutsideDays = true, captionLayout = "label", buttonVariant = "ghost", formatters, components, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayPicker, {
		showOutsideDays,
		className: cn("bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent", String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`, String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`, className),
		captionLayout,
		formatters: {
			formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
			...formatters
		},
		classNames: {
			root: cn("w-fit", defaultClassNames.root),
			months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
			month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
			nav: cn("absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1", defaultClassNames.nav),
			button_previous: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_previous),
			button_next: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_next),
			month_caption: cn("flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)", defaultClassNames.month_caption),
			dropdowns: cn("flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium", defaultClassNames.dropdowns),
			dropdown_root: cn("has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border", defaultClassNames.dropdown_root),
			dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
			caption_label: cn("select-none font-medium", captionLayout === "label" ? "text-sm" : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5", defaultClassNames.caption_label),
			table: "w-full border-collapse",
			weekdays: cn("flex", defaultClassNames.weekdays),
			weekday: cn("text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal", defaultClassNames.weekday),
			week: cn("mt-2 flex w-full", defaultClassNames.week),
			week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
			week_number: cn("text-muted-foreground select-none text-[0.8rem]", defaultClassNames.week_number),
			day: cn("group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md", defaultClassNames.day),
			range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
			range_middle: cn("rounded-none", defaultClassNames.range_middle),
			range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
			today: cn("bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none", defaultClassNames.today),
			outside: cn("text-muted-foreground aria-selected:text-muted-foreground", defaultClassNames.outside),
			disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
			hidden: cn("invisible", defaultClassNames.hidden),
			...classNames
		},
		components: {
			Root: ({ className, rootRef, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"data-slot": "calendar",
					ref: rootRef,
					className: cn(className),
					...props
				});
			},
			Chevron: ({ className, orientation, ...props }) => {
				if (orientation === "left") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: cn("size-4", className),
					...props
				});
				if (orientation === "right") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: cn("size-4", className),
					...props
				});
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-4", className),
					...props
				});
			},
			DayButton: CalendarDayButton,
			WeekNumber: ({ children, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					...props,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-(--cell-size) items-center justify-center text-center",
						children
					})
				});
			},
			...components
		},
		...props
	});
}
function CalendarDayButton({ className, day, modifiers, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	const ref = import_react.useRef(null);
	import_react.useEffect(() => {
		if (modifiers.focused) ref.current?.focus();
	}, [modifiers.focused]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		ref,
		variant: "ghost",
		size: "icon",
		"data-day": day.date.toLocaleDateString(),
		"data-selected-single": modifiers.selected && !modifiers.range_start && !modifiers.range_end && !modifiers.range_middle,
		"data-range-start": modifiers.range_start,
		"data-range-end": modifiers.range_end,
		"data-range-middle": modifiers.range_middle,
		className: cn("data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70", defaultClassNames.day, className),
		...props
	});
}
var Popover = Root2;
var PopoverTrigger = Trigger;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = Content2.displayName;
var Command$1 = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e, {
	ref,
	className: cn("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className),
	...props
}));
Command$1.displayName = _e.displayName;
var CommandInput = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex items-center border-b px-3",
	"cmdk-input-wrapper": "",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Input, {
		ref,
		className: cn("flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	})]
}));
CommandInput.displayName = _e.Input.displayName;
var CommandList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.List, {
	ref,
	className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
	...props
}));
CommandList.displayName = _e.List.displayName;
var CommandEmpty = import_react.forwardRef((props, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Empty, {
	ref,
	className: "py-6 text-center text-sm",
	...props
}));
CommandEmpty.displayName = _e.Empty.displayName;
var CommandGroup = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Group, {
	ref,
	className: cn("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
	...props
}));
CommandGroup.displayName = _e.Group.displayName;
var CommandSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Separator, {
	ref,
	className: cn("-mx-1 h-px bg-border", className),
	...props
}));
CommandSeparator.displayName = _e.Separator.displayName;
var CommandItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
	ref,
	className: cn("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", className),
	...props
}));
CommandItem.displayName = _e.Item.displayName;
var CommandShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	});
};
CommandShortcut.displayName = "CommandShortcut";
var formatCnpj = (raw) => {
	const d = raw.replace(/\D/g, "");
	if (d.length !== 14) return raw;
	return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
};
var makeBaseSchema = (t) => objectType({
	externalId: stringType().trim().max(120).optional().default(""),
	name: stringType().trim().min(1, t("identityForm.validation.required")).max(200),
	email: stringType().trim().email(t("identityForm.validation.invalidEmail")).max(255),
	status: enumType(["Active", "Inactive"])
});
/** Divide o nome completo: primeiro token = firstName, restante = lastName. */
function splitName(full) {
	const parts = full.trim().split(/\s+/).filter(Boolean);
	return {
		firstName: parts[0] ?? "",
		lastName: parts.slice(1).join(" ")
	};
}
var EXTRA_FIELDS = [
	{
		key: "middle_name",
		label: "Nome do meio",
		section: "ident",
		target: "top",
		argusKey: "middleName"
	},
	{
		key: "description",
		label: "Descrição",
		section: "ident",
		target: "top",
		argusKey: "description"
	},
	{
		key: "country_code",
		label: "País",
		section: "ident",
		target: "top",
		argusKey: "countryCode"
	},
	{
		key: "culture",
		label: "Idioma/Cultura",
		section: "ident",
		target: "top",
		argusKey: "culture"
	},
	{
		key: "private_birthday",
		label: "Data de nascimento",
		section: "personal",
		target: "private",
		argusKey: "birthday",
		type: "date"
	},
	{
		key: "private_employee_number",
		label: "Matrícula",
		section: "personal",
		target: "private",
		argusKey: "employeeNumber"
	},
	{
		key: "private_secondary_email",
		label: "E-mail secundário",
		section: "personal",
		target: "private",
		argusKey: "secondaryEmail",
		type: "email"
	},
	{
		key: "private_city_of_residence",
		label: "Cidade",
		section: "personal",
		target: "private",
		argusKey: "cityOfResidence"
	},
	{
		key: "private_state_of_residence",
		label: "Estado",
		section: "personal",
		target: "private",
		argusKey: "stateOfResidence"
	},
	{
		key: "private_zip_code",
		label: "CEP",
		section: "personal",
		target: "private",
		argusKey: "zipCode"
	},
	{
		key: "private_phone_primary",
		label: "Telefone principal",
		section: "personal",
		target: "private",
		argusKey: "phoneNumberPrimary"
	},
	{
		key: "private_phone_secondary",
		label: "Telefone secundário",
		section: "personal",
		target: "private",
		argusKey: "phoneNumberSecondary"
	},
	{
		key: "company_name",
		label: "Empresa",
		section: "company",
		target: "company",
		argusKey: "companyName"
	},
	{
		key: "company_job_title",
		label: "Cargo",
		section: "company",
		target: "company",
		argusKey: "jobTitle"
	},
	{
		key: "company_department_name",
		label: "Departamento",
		section: "company",
		target: "company",
		argusKey: "departmentName"
	},
	{
		key: "company_supervisor_name",
		label: "Supervisor",
		section: "company",
		target: "company",
		argusKey: "supervisorName"
	}
];
function IdentityForm({ initial, mode, submitting, onSubmit, onCancel, extraActions, statusBadge, showCustomFields = false, initialWorkerTypeId, lockWorkerType = false }) {
	const { t, lang } = useT();
	const [externalId, setExternalId] = (0, import_react.useState)(initial?.externalId ?? "");
	const [fullName, setFullName] = (0, import_react.useState)([initial?.firstName, initial?.lastName].filter(Boolean).join(" ").trim());
	const [email, setEmail] = (0, import_react.useState)(initial?.email ?? "");
	const [displayName, setDisplayName] = (0, import_react.useState)(initial?.displayName ?? "");
	const [status, setStatus] = (0, import_react.useState)(initial?.status ?? "Active");
	const [workerTypeId, setWorkerTypeId] = (0, import_react.useState)(initialWorkerTypeId ?? "");
	const [photo, setPhoto] = (0, import_react.useState)(null);
	const [companyId, setCompanyId] = (0, import_react.useState)("");
	const [companyOpen, setCompanyOpen] = (0, import_react.useState)(false);
	const defaultSiteId = useDefaultSiteId();
	const isEdit = mode === "edit";
	const [siteId, setSiteId] = (0, import_react.useState)(isEdit ? initial?.siteId ?? "" : initial?.siteId ?? defaultSiteId ?? "");
	(0, import_react.useEffect)(() => {
		if (isEdit || !defaultSiteId) return;
		setSiteId(defaultSiteId);
	}, [defaultSiteId]);
	const sitesQuery = useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	const identityActiveProfile = useActiveProfile();
	const sites = useUserScope().filterSites(sitesQuery.data ?? [], identityActiveProfile).slice().sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "pt-BR"));
	const [customFields, setCustomFields] = (0, import_react.useState)({ ...initial?.customFields ?? {} });
	const [attachments, setAttachments] = (0, import_react.useState)({});
	const setAttachment = (siteFieldId, file) => setAttachments((prev) => ({
		...prev,
		[siteFieldId]: file
	}));
	const [identityDbId, setIdentityDbId] = (0, import_react.useState)(null);
	const [extra, setExtra] = (0, import_react.useState)(() => {
		const priv = initial?.privateData ?? {};
		const comp = initial?.companyData ?? {};
		const top = initial ?? {};
		const out = {};
		for (const f of EXTRA_FIELDS) {
			const v = (f.target === "private" ? priv : f.target === "company" ? comp : top)[f.argusKey];
			out[f.key] = v == null ? "" : String(v);
		}
		return out;
	});
	const setExtraField = (key, value) => setExtra((prev) => ({
		...prev,
		[key]: value
	}));
	const fieldsQuery = useQuery({
		queryKey: ["custom-fields"],
		queryFn: () => argusApi.listCustomFields(),
		staleTime: 300 * 1e3
	});
	const sectionQuery = useQuery({
		queryKey: ["custom-fields-section", "VylorTerceiros"],
		queryFn: () => argusApi.getCustomFieldSection("VylorTerceiros"),
		staleTime: 300 * 1e3,
		enabled: showCustomFields
	});
	const orderMap = new Map((sectionQuery.data?.identityCustomFields ?? []).map((f) => [f.name, f.index]));
	const defs = (fieldsQuery.data ?? []).filter((f) => !f.isDeleted && f.customFieldName.startsWith("Vylor_")).sort((a, b) => {
		const ai = orderMap.get(a.customFieldName);
		const bi = orderMap.get(b.customFieldName);
		if (ai != null && bi != null) return ai - bi;
		if (ai != null) return -1;
		if (bi != null) return 1;
		return (a.displayName ?? a.customFieldName).localeCompare(b.displayName ?? b.customFieldName, "pt-BR");
	});
	const [errors, setErrors] = (0, import_react.useState)({});
	const { alias } = useIdentityFieldLabels();
	const activeProfile = useActiveProfile();
	const { config: formLayoutConfig } = useFormLayoutConfig(activeProfile, siteId);
	const workerTypes = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("is_active", true).eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			});
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	}).data ?? [];
	(0, import_react.useEffect)(() => {
		if (workerTypeId || !initial?.workerTypeCode || !workerTypes.length) return;
		const match = workerTypes.find((w) => w.argus_worker_type_code === initial.workerTypeCode);
		if (match) setWorkerTypeId(match.id);
	}, [
		workerTypes,
		initial?.workerTypeCode,
		workerTypeId
	]);
	const siteFieldsQuery = useQuery({
		queryKey: [
			"identity-site-fields",
			siteId,
			workerTypeId
		],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_custom_fields").select("id, is_required, fillable, value_range, display_name_override, definition:custom_field_definitions(id, custom_field_name, custom_field_type, attachment_accept, attachment_enabled, attachment_required)").eq("site_id", siteId).eq("entity_type", "identity").eq("worker_type_id", workerTypeId).eq("is_active", true).order("display_index", {
				ascending: true,
				nullsFirst: false
			}).returns();
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		enabled: Boolean(siteId && workerTypeId)
	});
	const siteFields = siteFieldsQuery.data ?? [];
	const siteFieldLabel = (sf) => pickLang(sf.display_name_override) || sf.definition?.custom_field_name || t("identityForm.fieldFallback");
	const attachmentFlagsQuery = useQuery({
		queryKey: ["cfd-attachment-flags"],
		queryFn: async () => {
			const { data, error } = await supabase.from("custom_field_definitions").select("id, custom_field_name, attachment_required, attachment_accept").eq("attachment_enabled", true);
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 60 * 1e3
	});
	const attachmentByName = new Map((attachmentFlagsQuery.data ?? []).map((d) => [d.custom_field_name, {
		id: d.id,
		required: d.attachment_required,
		accept: d.attachment_accept
	}]));
	const attachmentDefIds = [...attachmentByName.values()].map((a) => a.id);
	const existingAttachmentsQuery = useQuery({
		queryKey: [
			"identity-attachment-presence",
			identityDbId,
			attachmentDefIds.join(",")
		],
		queryFn: async () => {
			const { data, error } = await supabase.from("identity_attachments").select("custom_field_definition_id").eq("identity_id", identityDbId).eq("is_current", true).in("custom_field_definition_id", attachmentDefIds);
			if (error) throw new Error(error.message);
			return (data ?? []).map((r) => r.custom_field_definition_id);
		},
		enabled: Boolean(identityDbId && attachmentDefIds.length)
	});
	const existingAttachmentIds = new Set(existingAttachmentsQuery.data ?? []);
	const companies = useQuery({
		queryKey: ["companies", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("companies").select("id, name, tax_id").eq("profile", activeProfile).order("name", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	}).data ?? [];
	const companyLabel = (c) => c.tax_id ? `${c.name} - ${formatCnpj(c.tax_id)}` : c.name;
	const initialIdentityId = initial?.identityId;
	(0, import_react.useEffect)(() => {
		if (!initialIdentityId) return;
		let cancelled = false;
		supabase.from("identities").select("id, company_id, worker_type_id").eq("identity_id", initialIdentityId).maybeSingle().then(({ data }) => {
			if (cancelled || !data) return;
			setIdentityDbId(data.id ?? null);
			if (data.company_id) setCompanyId(data.company_id);
			const wt = data.worker_type_id;
			if (wt) setWorkerTypeId(wt);
		});
		return () => {
			cancelled = true;
		};
	}, [initialIdentityId]);
	const companyRelatedQuery = useQuery({
		queryKey: ["company-related-values", companyId],
		queryFn: async () => {
			const { data, error } = await supabase.from("company_custom_fields").select("value, site_custom_field:site_custom_fields(related_identity_field_id)").eq("company_id", companyId).returns();
			if (error) throw new Error(error.message);
			const out = [];
			for (const r of data ?? []) {
				const rel = r.site_custom_field?.related_identity_field_id;
				if (rel) out.push({
					rel,
					value: r.value ?? ""
				});
			}
			return out;
		},
		enabled: Boolean(companyId)
	});
	(0, import_react.useEffect)(() => {
		const rows = companyRelatedQuery.data;
		if (!rows?.length || !siteFields.length) return;
		const nameById = new Map(siteFields.filter((sf) => sf.definition).map((sf) => [sf.id, sf.definition.custom_field_name]));
		setCustomFields((prev) => {
			const next = { ...prev };
			for (const { rel, value } of rows) {
				const name = nameById.get(rel);
				if (name) next[name] = value;
			}
			return next;
		});
	}, [companyRelatedQuery.data, siteFieldsQuery.data]);
	const siteFieldByName = new Map(siteFields.filter((sf) => sf.definition).map((sf) => [sf.definition.custom_field_name, sf]));
	const cfDefByName = new Map((fieldsQuery.data ?? []).filter((f) => !f.isDeleted).map((f) => [f.customFieldName, f]));
	const { byName: specialByName, labelByName: specialLabelByName } = useSpecialFields();
	const renderSiteField = (sf) => {
		const name = sf.definition?.custom_field_name ?? sf.id;
		const kind = typeOf(sf.definition?.custom_field_type);
		const value = customFields[name] ?? "";
		const err = errors[`sf-${sf.id}`];
		const disabled = !sf.fillable;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
					htmlFor: `sf-${sf.id}`,
					className: "text-xs text-muted-foreground",
					children: [
						siteFieldLabel(sf),
						sf.is_required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-0.5 text-destructive",
							children: "*"
						}),
						disabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-muted-foreground",
							children: t("identityForm.readOnly")
						})
					]
				}),
				kind === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-9 items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						id: `sf-${sf.id}`,
						checked: isTruthy(value),
						onCheckedChange: (c) => setField(name, c ? "true" : "false"),
						disabled
					})
				}) : kind === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value,
					onValueChange: (v) => setField(name, v),
					disabled,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						id: `sf-${sf.id}`,
						className: cn(err && "border-destructive"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("identityForm.selectPlaceholder") })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: optionsOf(sf.value_range).map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: opt,
						children: opt
					}, opt)) })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: `sf-${sf.id}`,
					type: kind === "date" ? "date" : kind === "number" ? "number" : "text",
					value,
					onChange: (e) => setField(name, e.target.value),
					className: cn(err && "border-destructive"),
					disabled
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-destructive",
					children: err
				})
			]
		}, sf.id);
	};
	const renderFieldAttachment = (name) => {
		const att = attachmentByName.get(name);
		if (!att) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pt-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachmentField, {
				definitionId: att.id,
				identityDbId,
				label: t("attachment.evidenceLabel"),
				required: att.required,
				accept: att.accept,
				staged: attachments[att.id] ?? null,
				onStage: (file) => setAttachment(att.id, file),
				error: errors[`sf-att-${name}`]
			})
		});
	};
	const renderDefField = (def) => {
		const name = def.customFieldName;
		const kind = typeOf(def.customFieldType);
		const value = customFields[name] ?? "";
		const disabled = !!def.isReadOnly;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				htmlFor: `cf-${name}`,
				className: "text-xs text-muted-foreground",
				children: [alias(name, def.displayName || name), disabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-1 text-muted-foreground",
					children: t("identityForm.readOnly")
				})]
			}), kind === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-9 items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					id: `cf-${name}`,
					checked: isTruthy(value),
					onCheckedChange: (c) => setField(name, c ? "true" : "false"),
					disabled
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: `cf-${name}`,
				type: kind === "date" ? "date" : kind === "number" ? "number" : "text",
				value,
				onChange: (e) => setField(name, e.target.value),
				disabled
			})]
		}, `cf-${name}`);
	};
	const renderSpecialDropdown = (name, options) => {
		const value = customFields[name] ?? "";
		const label = specialLabelByName.get(name) || alias(name, cfDefByName.get(name)?.displayName || name);
		const sf = siteFieldByName.get(name);
		const required = !!(sf && sf.is_required && sf.fillable);
		const err = sf ? errors[`sf-${sf.id}`] : void 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
					className: "text-xs text-muted-foreground",
					children: [label, required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-0.5 text-destructive",
						children: "*"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value,
					onValueChange: (v) => setField(name, v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						id: `cf-${name}`,
						className: cn(err && "border-destructive"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("identityForm.selectPlaceholder") })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: o.value,
						children: o.label
					}, o.value)) })]
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-destructive",
					children: err
				})
			]
		}, `cf-${name}`);
	};
	const renderExtraField = (f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: `x-${f.key}`,
			children: alias(f.key, t(`identityForm.extra.${f.key}`))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			id: `x-${f.key}`,
			type: f.type === "date" ? "date" : f.type === "email" ? "email" : "text",
			value: extra[f.key] ?? "",
			onChange: (e) => setExtraField(f.key, e.target.value)
		})]
	}, f.key);
	const extraByKey = new Map(EXTRA_FIELDS.map((f) => [f.key, f]));
	const requiredStd = new Set(STANDARD_IDENTITY_FIELDS.filter((f) => f.required).map((f) => f.key));
	const includeKey = (k) => {
		if (k.startsWith("cf:")) {
			const n = k.slice(3);
			return siteFieldByName.has(n) || cfDefByName.has(n);
		}
		return true;
	};
	const formGroups = layoutForWorkerType(formLayoutConfig, workerTypeId).groups.map((g) => ({
		name: g.name,
		keys: g.fields.filter(includeKey)
	})).filter((g) => g.keys.length > 0);
	const consumedCf = /* @__PURE__ */ new Set();
	for (const g of formGroups) for (const k of g.keys) if (k.startsWith("cf:")) consumedCf.add(k.slice(3));
	const renderStandardField = (k) => {
		if (k.startsWith("cf:")) {
			const n = k.slice(3);
			const special = specialByName.get(n);
			const sf = siteFieldByName.get(n);
			const def = cfDefByName.get(n);
			const field = special && special.length ? renderSpecialDropdown(n, special) : sf ? renderSiteField(sf) : def ? renderDefField(def) : null;
			if (!field) return null;
			const attachment = renderFieldAttachment(n);
			return attachment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [field, attachment]
			}, `cf-wrap-${n}`) : field;
		}
		const star = requiredStd.has(k) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "ml-0.5 text-destructive",
			children: "*"
		}) : null;
		switch (k) {
			case "company_worker_type_code": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 sm:col-span-2 sm:max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [alias("company_worker_type_code", t("identityForm.workerType")), star] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: workerTypeId,
						onValueChange: (id) => setWorkerTypeId(id),
						disabled: lockWorkerType,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: cn(errors.workerTypeCode && "border-destructive"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("identityForm.selectWorkerTypePlaceholder") })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: workerTypes.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: w.id,
							children: pickLang(w.name_i18n, lang) || w.name
						}, w.id)) })]
					}),
					errors.workerTypeCode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.workerTypeCode
					})
				]
			}, k);
			case "first_name": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 sm:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						htmlFor: "fullName",
						children: [alias("first_name", t("common.name")), star]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "fullName",
						value: fullName,
						onChange: (e) => setFullName(e.target.value)
					}),
					errors.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.name
					})
				]
			}, k);
			case "last_name": return null;
			case "display_name": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 sm:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "displayName",
					children: alias("display_name", t("identityForm.displayName"))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "displayName",
					value: displayName,
					onChange: (e) => setDisplayName(e.target.value),
					placeholder: t("identityForm.displayNamePlaceholder")
				})]
			}, k);
			case "email": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 sm:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						htmlFor: "email",
						children: [alias("email", t("common.email")), star]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "email",
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value)
					}),
					errors.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.email
					})
				]
			}, k);
			case "company_site_id": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [alias("company_site_id", t("identityForm.site")), star] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: siteId,
						onValueChange: setSiteId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: cn(errors.siteId && "border-destructive"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: sitesQuery.isLoading ? t("common.loading") : t("identityForm.selectSitePlaceholder") })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: sites.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: s.siteId,
							children: s.name
						}, s.siteId)) })]
					}),
					errors.siteId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.siteId
					})
				]
			}, k);
			case "company_id": {
				const selected = companies.find((c) => c.id === companyId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: alias("company_id", t("identityForm.company")) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
						open: companyOpen,
						onOpenChange: setCompanyOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								role: "combobox",
								"aria-expanded": companyOpen,
								className: "w-full justify-between font-normal",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("truncate", !selected && "text-muted-foreground"),
									children: selected ? companyLabel(selected) : t("identityForm.none")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "ml-2 h-4 w-4 shrink-0 opacity-50" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
							className: "w-[var(--radix-popover-trigger-width)] p-0",
							align: "start",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: t("identityForm.companySearch") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: t("identityForm.companyEmpty") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
								value: "__none__",
								onSelect: () => {
									setCompanyId("");
									setCompanyOpen(false);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("mr-2 h-4 w-4", !companyId ? "opacity-100" : "opacity-0") }), t("identityForm.none")]
							}), companies.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
								value: `${c.name} ${c.tax_id ?? ""}`,
								onSelect: () => {
									setCompanyId(c.id);
									setCompanyOpen(false);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("mr-2 h-4 w-4", companyId === c.id ? "opacity-100" : "opacity-0") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 truncate",
										children: c.name
									}),
									c.tax_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 shrink-0 text-xs text-muted-foreground",
										children: formatCnpj(c.tax_id)
									})
								]
							}, c.id))] })] })] })
						})]
					})]
				}, k);
			}
			default: {
				const f = extraByKey.get(k);
				return f ? renderExtraField(f) : null;
			}
		}
	};
	const setField = (name, value) => setCustomFields((prev) => ({
		...prev,
		[name]: value
	}));
	const typeOf$1 = (t) => (t ?? "").toLowerCase();
	const isDate = (t) => typeOf$1(t) === "date" || typeOf$1(t) === "datetime";
	const isBool = (t) => [
		"bool",
		"boolean",
		"switch",
		"toggle"
	].includes(typeOf$1(t));
	const isBlank = (v) => {
		if (v == null) return true;
		const s = String(v).trim();
		return s === "" || s.toLowerCase() === "null" || s.toLowerCase() === "undefined";
	};
	const toTextValue = (v) => isBlank(v) ? "" : v;
	const toDateInputValue = (v) => {
		if (isBlank(v)) return "";
		const iso = /^\d{4}-\d{2}-\d{2}/.test(v) ? v.slice(0, 10) : "";
		if (iso) {
			if (iso.startsWith("0001-") || iso === "1900-01-01" || iso === "1970-01-01") return "";
			return iso;
		}
		const d = new Date(v);
		if (!isNaN(d.getTime())) {
			const out = d.toISOString().slice(0, 10);
			if (out.startsWith("0001-")) return "";
			return out;
		}
		return "";
	};
	const brToIso = (v) => {
		const s = (v ?? "").trim();
		if (!s) return "";
		const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s);
		if (!m) return null;
		const [, dd, mm, yyyy] = m;
		const d = Number(dd), mo = Number(mm), y = Number(yyyy);
		if (mo < 1 || mo > 12 || d < 1 || d > 31 || y < 1900 || y > 2999) return null;
		const dt = new Date(y, mo - 1, d);
		if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
		return `${yyyy}-${mm}-${dd}`;
	};
	const isTruthy$1 = (v) => !isBlank(v) && [
		"true",
		"1",
		"yes",
		"sim"
	].includes(v.toLowerCase());
	const submit = (e) => {
		e.preventDefault();
		const parsed = makeBaseSchema(t).safeParse({
			externalId,
			name: fullName,
			email,
			status
		});
		const out = {};
		if (!parsed.success) for (const i of parsed.error.issues) out[i.path[0]] = i.message;
		const effectiveWorkerTypeCode = workerTypes.find((w) => w.id === workerTypeId)?.argus_worker_type_code ?? "";
		if (!workerTypeId) out.workerTypeCode = t("identityForm.validation.selectWorkerType");
		else if (!effectiveWorkerTypeCode) out.workerTypeCode = t("identityForm.validation.workerTypeUnmapped");
		if (!siteId) out.siteId = t("identityForm.validation.selectSite");
		for (const sf of siteFields) {
			if (!sf.fillable || !sf.definition || !consumedCf.has(sf.definition.custom_field_name)) continue;
			if (sf.is_required && isBlank(customFields[sf.definition.custom_field_name])) out[`sf-${sf.id}`] = t("identityForm.validation.requiredField");
		}
		for (const [name, att] of attachmentByName) {
			if (!att.required || !consumedCf.has(name)) continue;
			if (!attachments[att.id] && !existingAttachmentIds.has(att.id)) out[`sf-att-${name}`] = t("identityForm.validation.requiredField");
		}
		if (Object.keys(out).length) {
			setErrors(out);
			return;
		}
		const parsedData = parsed.success ? parsed.data : null;
		if (!parsedData) return;
		const { name: _fullName, ...baseData } = parsedData;
		const { firstName, lastName } = splitName(_fullName);
		const cfErrors = {};
		const dateFieldNames = new Set(defs.filter((f) => isDate(f.customFieldType)).map((f) => f.customFieldName));
		const cf = {};
		for (const [k, v] of Object.entries(customFields)) {
			const key = k.trim();
			if (!key) continue;
			if (dateFieldNames.has(key)) {
				const raw = (v ?? "").trim();
				if (!raw) {
					cf[key] = "";
					continue;
				}
				const iso = /^\d{4}-\d{2}-\d{2}/.test(raw) ? raw.slice(0, 10) : brToIso(raw);
				if (iso === null || iso === "") {
					cfErrors[`cf-${key}`] = t("identityForm.validation.invalidDate");
					continue;
				}
				cf[key] = iso;
			} else {
				const val = (v ?? "").trim();
				if (!val) continue;
				cf[key] = /^\d{4}-\d{2}-\d{2}/.test(val) ? val.slice(0, 10) : val;
			}
		}
		if (Object.keys(cfErrors).length) {
			setErrors(cfErrors);
			return;
		}
		setErrors({});
		const siteFieldValues = siteFields.filter((sf) => sf.definition && consumedCf.has(sf.definition.custom_field_name)).map((sf) => ({
			site_custom_field_id: sf.id,
			value: cf[sf.definition.custom_field_name] ? cf[sf.definition.custom_field_name] : null
		}));
		const pendingAttachments = Object.entries(attachments).filter(([, file]) => file).map(([defId, file]) => ({
			custom_field_definition_id: defId,
			file
		}));
		const topExtra = {};
		const privExtra = { ...initial?.privateData ?? {} };
		const compExtra = { ...initial?.companyData ?? {} };
		for (const f of EXTRA_FIELDS) {
			const val = (extra[f.key] ?? "").trim();
			const bag = f.target === "private" ? privExtra : f.target === "company" ? compExtra : topExtra;
			if (val) bag[f.argusKey] = val;
			else if (f.argusKey in bag) bag[f.argusKey] = null;
		}
		onSubmit({
			...baseData,
			firstName,
			lastName,
			...topExtra,
			displayName: displayName.trim() || fullName.trim() || void 0,
			privateData: Object.keys(privExtra).length ? privExtra : void 0,
			companyData: Object.keys(compExtra).length ? compExtra : void 0,
			customFields: cf,
			siteId: siteId || void 0,
			workerTypeCode: effectiveWorkerTypeCode || void 0
		}, siteFieldValues, companyId || null, workerTypeId || null, photo, pendingAttachments);
	};
	const dateDefs = defs.filter((f) => isDate(f.customFieldType));
	const boolDefs = defs.filter((f) => isBool(f.customFieldType));
	const textDefs = defs.filter((f) => !isDate(f.customFieldType) && !isBool(f.customFieldType));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-6",
		children: [
			mode === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("photoCapture.title")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoCapture, {
				value: photo,
				onChange: setPhoto
			}) })] }),
			statusBadge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: statusBadge
			}),
			formGroups.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: g.name.trim() || t("identityForm.formData")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "grid gap-4 sm:grid-cols-2",
				children: g.keys.map((k) => renderStandardField(k))
			})] }, i)),
			showCustomFields && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("identityForm.customAttributes")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-3",
				children: fieldsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full" }, i))
				}) : defs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: t("identityForm.noCustomFields")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [(dateDefs.length > 0 || textDefs.length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: [...dateDefs, ...textDefs].map((f) => {
							const name = f.customFieldName;
							const label = alias(name, f.displayName || name);
							const value = customFields[name] ?? "";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `cf-${name}`,
									className: "text-xs text-muted-foreground",
									children: label
								}), isDate(f.customFieldType) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [(() => {
									const iso = toDateInputValue(value);
									const selected = iso ? parse(iso, "yyyy-MM-dd", /* @__PURE__ */ new Date()) : void 0;
									const today = /* @__PURE__ */ new Date();
									today.setHours(0, 0, 0, 0);
									const isExpired = !!selected && selected < today;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											id: `cf-${name}`,
											type: "button",
											variant: "outline",
											disabled: f.isReadOnly,
											className: cn("w-full justify-start rounded-full text-left font-normal", !selected && "text-muted-foreground", isExpired && "border-destructive bg-destructive/10 text-destructive hover:bg-destructive/15 hover:text-destructive"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar$1, { className: "mr-2 h-4 w-4" }),
												selected ? format(selected, "dd/MM/yyyy", { locale: ptBR }) : t("identityForm.datePlaceholder"),
												isExpired && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-auto rounded-full bg-destructive px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-destructive-foreground",
													children: t("identityForm.expiredBadge")
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
										className: "w-auto p-0",
										align: "start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
											mode: "single",
											locale: ptBR,
											selected,
											onSelect: (d) => setField(name, d ? format(d, "yyyy-MM-dd") : ""),
											initialFocus: true,
											className: cn("p-3 pointer-events-auto")
										}), selected && !f.isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "border-t p-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "sm",
												className: "w-full",
												onClick: () => setField(name, ""),
												children: t("identityForm.clear")
											})
										})]
									})] }), isExpired && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium text-destructive",
										children: t("identityForm.expiredDate")
									})] });
								})(), errors[`cf-${name}`] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-destructive",
									children: errors[`cf-${name}`]
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `cf-${name}`,
									value: toTextValue(value),
									onChange: (e) => setField(name, e.target.value),
									disabled: f.isReadOnly,
									className: "rounded-full"
								})]
							}, name);
						})
					}), boolDefs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
						children: boolDefs.map((f) => {
							const name = f.customFieldName;
							const label = alias(name, f.displayName || name);
							const value = customFields[name] ?? "";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									id: `cf-${name}`,
									checked: isTruthy$1(value),
									onCheckedChange: (v) => setField(name, v ? "true" : "false"),
									disabled: f.isReadOnly
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: `cf-${name}`,
									className: "cursor-pointer text-sm font-normal",
									children: label
								})]
							}, name);
						})
					})]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-end gap-2",
				children: [
					extraActions,
					onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: onCancel,
						children: t("common.cancel")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: submitting,
						children: submitting ? t("common.saving") : mode === "create" ? t("identityForm.create") : t("common.save")
					})
				]
			})
		]
	});
}
//#endregion
export { IdentityForm as t };
