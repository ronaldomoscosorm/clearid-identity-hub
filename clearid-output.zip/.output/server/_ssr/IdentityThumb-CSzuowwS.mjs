import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as cn } from "./button-PwNqyxv_.mjs";
import { i as User } from "../_libs/lucide-react.mjs";
import { S as useDefaultSiteId, r as argusApi } from "./argus-client-fTtea6N-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IdentityThumb-CSzuowwS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IdentityThumb({ identityId, className }) {
	const [url, setUrl] = (0, import_react.useState)(null);
	const q = useQuery({
		queryKey: [
			"identity-picture",
			useDefaultSiteId(),
			identityId
		],
		queryFn: () => argusApi.getIdentityPicture(identityId),
		retry: false,
		staleTime: 5 * 6e4
	});
	(0, import_react.useEffect)(() => {
		if (!q.data) {
			setUrl(null);
			return;
		}
		const u = URL.createObjectURL(q.data);
		setUrl(u);
		return () => URL.revokeObjectURL(u);
	}, [q.data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border bg-muted", className),
		children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: "",
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 text-muted-foreground" })
	});
}
//#endregion
export { IdentityThumb as t };
