import { t as supabase } from "./client-pXxOjxhm.mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/foto._token-BdRRslOk.js
var APP_EMAIL = "ronaldo@rmtecho.com.br";
var APP_PASSWORD = "T8yP@2jK$4r";
/** Garante uma sessão do usuário técnico. Retorna true se autenticado. */
async function ensureTechnicalSession() {
	const { data } = await supabase.auth.getSession();
	if (data.session) return true;
	const { error } = await supabase.auth.signInWithPassword({
		email: APP_EMAIL,
		password: APP_PASSWORD
	});
	if (error) {
		console.error("[auth] Falha ao autenticar o usuário técnico do Supabase:", error.message);
		return false;
	}
	return true;
}
var $$splitComponentImporter = () => import("./foto._token-U_rgpJ3a.mjs");
var Route = createFileRoute("/foto/$token")({
	ssr: false,
	head: () => ({ meta: [{ title: "Atualização de foto" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { ensureTechnicalSession as n, Route as t };
