import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { v as Search, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { S as useDefaultSiteId, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as IdentityThumb } from "./IdentityThumb-CSzuowwS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terceirizados.index-CqAu4H9b.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TerceirizadosPage() {
	const { t } = useT();
	const siteId = useDefaultSiteId();
	const SEARCH_KEY = "terceirizados:last-search";
	const emptyApplied = {
		firstName: "",
		email: "",
		company: "",
		jobTitle: "",
		department: "",
		status: "all",
		allSites: false
	};
	const saved = (() => {
		if (typeof window === "undefined") return null;
		try {
			const raw = sessionStorage.getItem(SEARCH_KEY);
			return raw ? JSON.parse(raw) : null;
		} catch {
			return null;
		}
	})();
	const [fFirstName, setFFirstName] = (0, import_react.useState)(saved?.firstName ?? "");
	const [fEmail, setFEmail] = (0, import_react.useState)(saved?.email ?? "");
	const [fCompany, setFCompany] = (0, import_react.useState)(saved?.company ?? "");
	const [fJobTitle, setFJobTitle] = (0, import_react.useState)(saved?.jobTitle ?? "");
	const [fDepartment, setFDepartment] = (0, import_react.useState)(saved?.department ?? "");
	const [fStatus, setFStatus] = (0, import_react.useState)(saved?.status ?? "all");
	const [fAllSites, setFAllSites] = (0, import_react.useState)(saved?.allSites ?? false);
	const [hasSearched, setHasSearched] = (0, import_react.useState)(true);
	const [applied, setApplied] = (0, import_react.useState)(saved ?? emptyApplied);
	const query = useQuery({
		queryKey: [
			"terceirizados",
			siteId,
			applied
		],
		queryFn: async () => {
			const base = (await argusApi.listIdentities({
				firstName: applied.firstName || void 0,
				email: applied.email || void 0,
				company: applied.company || void 0,
				jobTitle: applied.jobTitle || void 0,
				department: applied.department || void 0,
				status: applied.status === "all" ? void 0 : applied.status,
				allSites: applied.allSites
			})).items ?? [];
			const items = (await Promise.all(base.map(async (it) => {
				try {
					const full = await argusApi.getIdentity(it.identityId);
					return {
						...it,
						...full
					};
				} catch {
					return it;
				}
			}))).filter((it) => {
				const company = it.companyData ?? null;
				return ((company && typeof company.workerTypeCode === "string" ? company.workerTypeCode : null) ?? it.workerTypeCode ?? "").trim().toLowerCase() === "terceiros";
			});
			return {
				items,
				total: items.length
			};
		},
		enabled: hasSearched,
		retry: false
	});
	const totalCols = 5;
	const onSubmit = (e) => {
		e.preventDefault();
		setHasSearched(true);
		const next = {
			firstName: fFirstName.trim(),
			email: fEmail.trim(),
			company: fCompany.trim(),
			jobTitle: fJobTitle.trim(),
			department: fDepartment.trim(),
			status: fStatus,
			allSites: fAllSites
		};
		setApplied(next);
		try {
			sessionStorage.setItem(SEARCH_KEY, JSON.stringify(next));
		} catch {}
	};
	const onClear = () => {
		setFFirstName("");
		setFEmail("");
		setFCompany("");
		setFJobTitle("");
		setFDepartment("");
		setFStatus("all");
		setFAllSites(false);
		setApplied(emptyApplied);
		try {
			sessionStorage.removeItem(SEARCH_KEY);
		} catch {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("contractors.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("contractors.subtitle")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("contractors.workerType") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: "Terceiros",
									disabled: true,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "w-full sm:w-64",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Terceiros",
										children: t("contractors.workerTypeContractors")
									}) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: t("contractors.workerTypeHint")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-first-name",
										children: t("common.name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "t-first-name",
										value: fFirstName,
										onChange: (e) => setFFirstName(e.target.value),
										placeholder: t("contractors.firstNamePlaceholder")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-email",
										children: t("common.email")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "t-email",
										value: fEmail,
										onChange: (e) => setFEmail(e.target.value),
										placeholder: t("contractors.emailPlaceholder")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-company",
										children: t("contractors.company")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "t-company",
										value: fCompany,
										onChange: (e) => setFCompany(e.target.value),
										placeholder: t("contractors.company")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-job-title",
										children: t("contractors.jobTitle")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "t-job-title",
										value: fJobTitle,
										onChange: (e) => setFJobTitle(e.target.value),
										placeholder: t("contractors.jobTitle")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-department",
										children: t("contractors.department")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "t-department",
										value: fDepartment,
										onChange: (e) => setFDepartment(e.target.value),
										placeholder: t("contractors.department")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("common.status") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: fStatus,
										onValueChange: setFStatus,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Active",
												children: t("contractors.statusActive")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Inactive",
												children: t("contractors.statusInactive")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: t("contractors.statusAll")
											})
										] })]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mr-auto flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										id: "t-all-sites",
										checked: fAllSites,
										onCheckedChange: (v) => setFAllSites(!!v)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "t-all-sites",
										className: "cursor-pointer text-sm font-normal",
										children: t("contractors.allSites")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: onClear,
									disabled: query.isFetching,
									children: t("contractors.clear")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									size: "icon",
									onClick: () => query.refetch(),
									disabled: query.isFetching || !hasSearched,
									title: t("contractors.reload"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: query.isFetching ? "h-4 w-4 animate-spin" : "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									disabled: query.isFetching,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-1 h-4 w-4" }),
										" ",
										t("common.search")
									]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-14" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("contractors.col.identityId") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.email") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.status") })
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: !hasSearched ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
				colSpan: totalCols,
				className: "py-10 text-center text-sm text-muted-foreground",
				children: [
					t("contractors.emptyPromptBefore"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: t("common.search")
					}),
					" ",
					t("contractors.emptyPromptAfter")
				]
			}) }) : query.isLoading || query.isFetching ? Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: Array.from({ length: totalCols }).map((__, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }) }, j)) }, i)) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				colSpan: totalCols,
				className: "py-10 text-center text-sm text-destructive",
				children: query.error.message
			}) }) : !query.data?.items?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				colSpan: totalCols,
				className: "py-10 text-center text-sm text-muted-foreground",
				children: t("contractors.emptyState")
			}) }) : query.data.items.map((it) => {
				const status = String(it.status ?? "");
				const isActive = status.toLowerCase() === "active";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, { identityId: it.identityId }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-mono text-xs text-muted-foreground",
						children: it.identityId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/terceirizados/$id",
							params: { id: it.identityId },
							className: "hover:underline",
							children: [
								it.firstName,
								" ",
								it.lastName
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-muted-foreground",
						children: it.email ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: isActive ? "default" : "secondary",
						children: isActive ? "Active" : status || "—"
					}) })
				] }, it.identityId);
			}) })] }) })
		]
	});
}
//#endregion
export { TerceirizadosPage as component };
