import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { A as Mail, G as Eye, K as ExternalLink, P as LoaderCircle, i as User, q as Ellipsis, t as X, ut as Camera, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as objectType, o as stringType } from "../_libs/zod.mjs";
import { S as useDefaultSiteId, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as IdentityThumb } from "./IdentityThumb-CSzuowwS.mjs";
import { t as IdentityPictureDialog } from "./IdentityPictureDialog-BNrWvmUR.mjs";
import { n as DropdownMenuContent, o as DropdownMenuTrigger, r as DropdownMenuItem, t as DropdownMenu } from "./dropdown-menu-CsR71wG4.mjs";
import { t as Route } from "./regras-CeYhJ67H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/regras-BvkfUWt1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
objectType({
	teamId: stringType().optional(),
	view: stringType().optional()
});
function RegrasPage() {
	const { t } = useT();
	const navigate = useNavigate({ from: Route.fullPath });
	const { teamId, view } = Route.useSearch();
	const siteId = useDefaultSiteId();
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [pictureFor, setPictureFor] = (0, import_react.useState)(null);
	const teamsQuery = useQuery({
		queryKey: ["teams", siteId],
		queryFn: () => argusApi.listTeams({ take: 100 }),
		enabled: !!siteId,
		retry: false,
		refetchOnMount: "always",
		refetchOnWindowFocus: true,
		staleTime: 0
	});
	(0, import_react.useEffect)(() => {
		if (!siteId) return;
		const toastId = toast.loading(t("rules.checkingNew"));
		teamsQuery.refetch().then((res) => {
			if (res.error) toast.error(t("rules.refreshTeamsError"), { id: toastId });
			else toast.success(t("rules.refreshTeamsSuccess"), { id: toastId });
		}).catch((err) => {
			const msg = err instanceof Error ? err.message : t("rules.unknownError");
			toast.error(t("rules.refreshTeamsErrorDetail", { msg }), { id: toastId });
		});
	}, [siteId]);
	const sortedTeams = (teamsQuery.data ?? []).slice().sort((a, b) => a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base" }));
	const selectedTeam = sortedTeams.find((t) => t.teamId === teamId);
	const membersQuery = useQuery({
		queryKey: [
			"team-members",
			siteId,
			teamId
		],
		queryFn: () => argusApi.listTeamMembers(teamId, { count: 500 }),
		enabled: !!teamId,
		retry: false
	});
	const setTeam = (id) => {
		navigate({ search: () => ({
			teamId: id || void 0,
			view: void 0
		}) });
	};
	const openView = (id) => {
		navigate({ search: (prev) => ({
			...prev,
			view: id
		}) });
	};
	const closeView = () => {
		navigate({ search: (prev) => ({
			...prev,
			view: void 0
		}) });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("rules.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("rules.subtitle")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-[280px] flex-1 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "team",
							children: t("rules.teamLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: teamId ?? "",
							onValueChange: setTeam,
							disabled: !siteId || teamsQuery.isLoading || !!teamsQuery.error,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "team",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: !siteId ? t("rules.selectSiteFirst") : teamsQuery.isLoading ? t("rules.loadingTeams") : teamsQuery.error ? t("rules.loadTeamsError") : t("rules.selectTeam") })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: sortedTeams.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: t.teamId,
								children: t.name
							}, t.teamId)) })]
						})]
					}), teamId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => membersQuery.refetch(),
						disabled: membersQuery.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-2 h-4 w-4 ${membersQuery.isFetching ? "animate-spin" : ""}` }), t("rules.refresh")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setAddOpen(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 h-4 w-4" }),
							" ",
							t("rules.addMembers")
						]
					})] })]
				}), teamsQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-destructive",
					children: teamsQuery.error.message
				})]
			}),
			!teamId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-12 text-center text-sm text-muted-foreground",
				children: t("rules.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "flex items-center gap-2 text-sm font-semibold text-foreground",
					children: [selectedTeam?.name ?? t("rules.members"), membersQuery.isFetching && !membersQuery.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-xs font-normal text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3 w-3 animate-spin" }), t("rules.updating")]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: membersQuery.isLoading ? t("common.loading") : t("rules.memberCount", { count: membersQuery.data?.length ?? 0 })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-14" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("rules.col.email") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "hidden font-mono text-xs md:table-cell",
					children: t("rules.col.identityId")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-14" })
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: membersQuery.isLoading ? Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: Array.from({ length: 5 }).map((__, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-full" }) }, j)) }, i)) : membersQuery.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				colSpan: 5,
				className: "text-center text-sm text-destructive",
				children: membersQuery.error.message
			}) }) : (membersQuery.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				colSpan: 5,
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("rules.noMembers")
			}) }) : (membersQuery.data ?? []).slice().sort((a, b) => {
				const an = (a.identityName ?? "").trim();
				const bn = (b.identityName ?? "").trim();
				return an.localeCompare(bn, "pt-BR", { sensitivity: "base" });
			}).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
				className: "cursor-pointer",
				onClick: () => openView(m.identityId),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, { identityId: m.identityId }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "font-medium",
						children: m.identityName?.trim() || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-sm text-muted-foreground",
						children: m.identityEmail ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "hidden font-mono text-xs text-muted-foreground md:table-cell",
						children: m.identityId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						onClick: (e) => e.stopPropagation(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "icon",
								className: "h-8 w-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: t("common.actions")
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
							align: "end",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onClick: () => openView(m.identityId),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "mr-2 h-4 w-4" }),
										" ",
										t("rules.view")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onClick: () => setPictureFor({
										id: m.identityId,
										name: m.identityName?.trim() || m.identityId
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-2 h-4 w-4" }),
										" ",
										t("rules.updatePhoto")
									]
								}),
								m.identityEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: `mailto:${m.identityEmail}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mr-2 h-4 w-4" }),
											" ",
											t("rules.sendEmail")
										]
									})
								})
							]
						})] })
					})
				]
			}, m.identityId)) })] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewIdentityDialog, {
				identityId: view ?? null,
				onClose: closeView
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddMembersDialog, {
				open: addOpen,
				onClose: () => setAddOpen(false),
				teamId: teamId ?? null,
				teamName: selectedTeam?.name ?? null,
				siteId
			}),
			pictureFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPictureDialog, {
				identityId: pictureFor.id,
				identityName: pictureFor.name,
				open: !!pictureFor,
				onOpenChange: (o) => !o && setPictureFor(null)
			})
		]
	});
}
function ViewIdentityDialog({ identityId, onClose }) {
	const { t } = useT();
	const open = !!identityId;
	const query = useQuery({
		queryKey: ["identity", identityId],
		queryFn: () => identityId ? argusApi.getIdentity(identityId) : Promise.resolve(null),
		enabled: open,
		retry: false
	});
	const data = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => !o ? onClose() : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: data ? `${data.firstName ?? ""} ${data.lastName ?? ""}`.trim() : t("rules.identity") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "font-mono text-xs",
					children: identityId
				})] }),
				query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-2/3" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-1/2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full" })
					]
				}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: query.error.message
				}) : data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2 flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, {
								identityId: data.identityId,
								className: "h-16 w-16"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-semibold",
								children: `${data.firstName ?? ""} ${data.lastName ?? ""}`.trim()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: data.status === "Active" ? "default" : "secondary",
								children: data.status
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.email"),
							value: data.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.externalId"),
							value: data.externalId ?? data.systemData?.externalId,
							mono: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.identityType"),
							value: data.identityType
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.country"),
							value: data.countryCode
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.jobTitle"),
							value: data.companyData?.jobTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.company"),
							value: data.companyData?.companyName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.department"),
							value: data.companyData?.departmentName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("rules.field.description"),
							value: data.description
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: onClose,
						children: t("common.close")
					}), data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/identities/$id",
							params: { id: data.identityId },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "mr-2 h-4 w-4" }),
								" ",
								t("rules.openEdit")
							]
						})
					})]
				})
			]
		})
	});
}
function Field({ label, value, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: mono ? "font-mono text-sm" : "text-sm",
			children: value || "—"
		})]
	});
}
function toUtcIso(local) {
	if (!local) return null;
	const d = new Date(local);
	if (isNaN(d.getTime())) return null;
	return d.toISOString();
}
function currentLocalDateTimeValue() {
	const d = /* @__PURE__ */ new Date();
	d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
	return d.toISOString().slice(0, 16);
}
function AddMembersDialog({ open, onClose, teamId, teamName, siteId }) {
	const { t } = useT();
	const queryClient = useQueryClient();
	const [searchInput, setSearchInput] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)({});
	const [startAt, setStartAt] = (0, import_react.useState)(() => currentLocalDateTimeValue());
	const [endAt, setEndAt] = (0, import_react.useState)("");
	const [searchAllSites, setSearchAllSites] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setSelected({});
		setSearchInput("");
		setQuery("");
		setSearchAllSites(false);
		setStartAt(currentLocalDateTimeValue());
		setEndAt("");
	}, [open]);
	const [query, setQuery] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setQuery(searchInput.trim()), 300);
		return () => clearTimeout(t);
	}, [searchInput]);
	const searchQuery = useQuery({
		queryKey: [
			"identity-search",
			siteId,
			query,
			searchAllSites
		],
		queryFn: () => argusApi.listIdentities({
			query,
			take: 50,
			allSites: searchAllSites
		}),
		enabled: open && !!query,
		retry: false
	});
	const items = (0, import_react.useMemo)(() => {
		const arr = (searchQuery.data?.items ?? []).slice();
		arr.sort((a, b) => {
			const an = `${a.firstName ?? ""} ${a.lastName ?? ""}`.trim();
			const bn = `${b.firstName ?? ""} ${b.lastName ?? ""}`.trim();
			return an.localeCompare(bn, "pt-BR", { sensitivity: "base" });
		});
		return arr;
	}, [searchQuery.data]);
	const selectedList = Object.values(selected);
	const toggle = (i) => {
		setSelected((prev) => {
			const next = { ...prev };
			if (next[i.identityId]) delete next[i.identityId];
			else {
				next[i.identityId] = i;
				setSearchInput("");
				setQuery("");
			}
			return next;
		});
	};
	const submit = useMutation({
		mutationFn: async (ids) => {
			if (!teamId) throw new Error(t("rules.selectTeamFirst"));
			return argusApi.addTeamMembers(teamId, {
				identityIds: ids,
				sourceId: siteId ?? null,
				startDateTimeUtc: toUtcIso(startAt),
				endDateTimeUtc: toUtcIso(endAt),
				reason: "Portal Argus"
			});
		},
		onSuccess: (_d, ids) => {
			toast.success(t("rules.membersAdded", { count: ids.length }));
			queryClient.invalidateQueries({ queryKey: ["team-members"] });
			queryClient.invalidateQueries({ queryKey: ["teams"] });
			setSelected({});
			setSearchInput("");
			setQuery("");
			setStartAt(currentLocalDateTimeValue());
			setEndAt("");
			onClose();
			const toastId = toast.loading(t("rules.updatingMembers"));
			queryClient.refetchQueries({ queryKey: [
				"team-members",
				siteId,
				teamId
			] }).then(() => toast.success(t("rules.membersUpdated"), { id: toastId })).catch((e) => toast.error(e.message || t("rules.membersUpdateError"), { id: toastId }));
		},
		onError: (e) => {
			toast.error(e.message || t("rules.addMembersError"));
		}
	});
	const handleClose = () => {
		if (submit.isPending) return;
		onClose();
	};
	const handleAdd = () => {
		if (!startAt) {
			toast.error(t("rules.startDateRequired"));
			return;
		}
		const start = new Date(startAt);
		if (isNaN(start.getTime())) {
			toast.error(t("rules.startDateInvalid"));
			return;
		}
		if (endAt) {
			const end = new Date(endAt);
			if (isNaN(end.getTime())) {
				toast.error(t("rules.endDateInvalid"));
				return;
			}
			if (end <= start) {
				toast.error(t("rules.endAfterStart"));
				return;
			}
		}
		const count = selectedList.length;
		const endMsg = endAt ? t("rules.untilDate", { date: new Date(endAt).toLocaleString() }) : t("rules.noEndDate");
		if (!window.confirm(t("rules.confirmAdd", {
			count,
			start: new Date(startAt).toLocaleString(),
			end: endMsg
		}))) return;
		submit.mutate(selectedList.map((i) => i.identityId));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => !o ? handleClose() : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [t("rules.addMembers"), teamName ? ` — ${teamName}` : ""] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("rules.addMembersDesc") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
							className: "text-primary",
							children: [
								t("rules.identities"),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "*"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-11 flex-wrap items-center gap-1.5 rounded-md border border-input bg-background px-2 py-1.5 focus-within:ring-2 focus-within:ring-ring",
							onClick: (e) => {
								e.currentTarget.querySelector("input[data-chip-input]")?.focus();
							},
							children: [selectedList.map((i) => {
								const name = `${i.firstName ?? ""} ${i.lastName ?? ""}`.trim() || i.identityId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 rounded-full bg-muted px-2 py-1 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-3.5 w-3.5 text-muted-foreground" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: (e) => {
												e.stopPropagation();
												toggle(i);
											},
											className: "ml-0.5 rounded-full p-0.5 text-muted-foreground hover:bg-muted-foreground/20",
											"aria-label": t("rules.removeAria", { name }),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
										})
									]
								}, i.identityId);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"data-chip-input": true,
								value: searchInput,
								onChange: (e) => setSearchInput(e.target.value),
								placeholder: t("rules.searchPlaceholder"),
								autoFocus: true,
								className: "min-w-[12rem] flex-1 border-0 bg-transparent px-1 py-1 text-sm outline-none placeholder:text-muted-foreground",
								onKeyDown: (e) => {
									if (e.key === "Backspace" && !searchInput && selectedList.length > 0) toggle(selectedList[selectedList.length - 1]);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground",
								children: [selectedList.length, " / 99"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex cursor-pointer items-center gap-2 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: searchAllSites,
									onCheckedChange: (v) => setSearchAllSites(!!v)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("rules.searchAllSites") })]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-72 overflow-auto rounded-md border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-10" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-14" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("rules.col.email") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "hidden font-mono text-xs md:table-cell",
							children: t("rules.col.identityId")
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: !query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						colSpan: 5,
						className: "py-6 text-center text-sm text-muted-foreground",
						children: t("rules.searchHint")
					}) }) : searchQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						colSpan: 5,
						className: "py-6 text-center text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 inline h-4 w-4 animate-spin" }),
							" ",
							t("rules.searching")
						]
					}) }) : searchQuery.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						colSpan: 5,
						className: "py-6 text-center text-sm text-destructive",
						children: searchQuery.error.message
					}) }) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						colSpan: 5,
						className: "py-6 text-center text-sm text-muted-foreground",
						children: t("rules.noResults")
					}) }) : items.map((i) => {
						const checked = !!selected[i.identityId];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "cursor-pointer",
							onClick: () => toggle(i),
							"data-state": checked ? "selected" : void 0,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									onClick: (e) => e.stopPropagation(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked,
										onCheckedChange: () => toggle(i)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, { identityId: i.identityId }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-medium",
									children: `${i.firstName ?? ""} ${i.lastName ?? ""}`.trim() || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-sm text-muted-foreground",
									children: i.email ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "hidden font-mono text-xs text-muted-foreground md:table-cell",
									children: i.identityId
								})
							]
						}, i.identityId);
					}) })] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "startAt",
							children: t("rules.startDate")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "startAt",
							type: "datetime-local",
							value: startAt,
							onChange: (e) => setStartAt(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "endAt",
							children: t("rules.endDate")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: endAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "endAt",
								type: "datetime-local",
								value: endAt,
								onChange: (e) => setEndAt(e.target.value)
							}, "endAt-filled"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								size: "icon",
								onClick: () => setEndAt(""),
								disabled: submit.isPending,
								"aria-label": t("rules.clearEndDate"),
								title: t("rules.clear"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "endAt",
								type: "text",
								value: "",
								readOnly: true,
								"aria-label": t("rules.endDateBlank")
							}, "endAt-empty"), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setEndAt(currentLocalDateTimeValue()),
								disabled: submit.isPending,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-2 h-4 w-4" }),
									" ",
									t("rules.set")
								]
							})] })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: handleClose,
						disabled: submit.isPending,
						children: t("common.cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: handleAdd,
						disabled: selectedList.length === 0 || submit.isPending || !teamId,
						children: [
							submit.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
							t("common.add"),
							" ",
							selectedList.length > 0 ? `(${selectedList.length})` : ""
						]
					})]
				})
			]
		})
	});
}
//#endregion
export { RegrasPage as component };
