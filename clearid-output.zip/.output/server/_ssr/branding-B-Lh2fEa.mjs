import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-C5Nmk_bj.mjs";
import { b as RotateCcw, d as Sun, k as Moon, l as Trash2, s as Upload } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as saveBranding, i as resetBranding, n as applyBranding, r as getBranding, t as DEFAULT_BRANDING } from "./branding-lYWRBKZ3.mjs";
import { n as pushSettings } from "./supabase-settings-DI2-qLO-.mjs";
import { n as getTheme, r as setTheme } from "./theme-CZ6cvH_Z.mjs";
import { t as PoweredBy } from "./PoweredBy-CRi75zGX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/branding-B-Lh2fEa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BrandingPage() {
	const { t } = useT();
	const [cfg, setCfg] = (0, import_react.useState)(() => getBranding());
	const [theme, setThemeState] = (0, import_react.useState)(() => getTheme());
	const fileRef = (0, import_react.useRef)(null);
	const changeTheme = (v) => {
		setThemeState(v);
		setTheme(v);
	};
	const update = (patch) => setCfg((c) => ({
		...c,
		...patch
	}));
	const onPickLogo = (file) => {
		if (file.size > 1024 * 1024) {
			toast.error(t("branding.toast.logoTooLarge"));
			return;
		}
		const reader = new FileReader();
		reader.onload = () => update({ clientLogo: String(reader.result ?? "") });
		reader.onerror = () => toast.error(t("branding.toast.readError"));
		reader.readAsDataURL(file);
	};
	const handleSave = () => {
		saveBranding(cfg);
		applyBranding(cfg);
		pushSettings().then(() => toast.success(t("branding.toast.applied"))).catch(() => toast.warning(t("branding.toast.syncFail")));
	};
	const handleReset = () => {
		resetBranding();
		setCfg(DEFAULT_BRANDING);
		applyBranding(DEFAULT_BRANDING);
		pushSettings();
		toast.success(t("branding.toast.restored"));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("branding.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("branding.subtitle")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: t("branding.client.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("branding.client.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "clientName",
							children: t("branding.client.nameLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "clientName",
							value: cfg.clientName,
							onChange: (e) => update({ clientName: e.target.value }),
							placeholder: t("branding.client.namePlaceholder")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("branding.logo.label") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-16 w-16 items-center justify-center overflow-hidden rounded-md border bg-card",
									children: cfg.clientLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: cfg.clientLogo,
										alt: t("branding.logo.alt"),
										className: "h-full w-full object-contain"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: t("branding.logo.none")
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											ref: fileRef,
											type: "file",
											accept: "image/png,image/jpeg,image/svg+xml,image/webp",
											className: "hidden",
											onChange: (e) => {
												const f = e.target.files?.[0];
												if (f) onPickLogo(f);
												e.target.value = "";
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => fileRef.current?.click(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-2 h-4 w-4" }), t("branding.logo.upload")]
										}),
										cfg.clientLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "ghost",
											size: "sm",
											onClick: () => update({ clientLogo: "" }),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mr-2 h-4 w-4" }), t("common.remove")]
										}) : null
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("branding.logo.hint")
							})
						]
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: t("branding.colors.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("branding.colors.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("branding.theme.label") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex rounded-lg border p-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => changeTheme("light"),
									className: cn("flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors", theme === "light" ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:text-foreground"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }),
										" ",
										t("branding.theme.light")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => changeTheme("dark"),
									className: cn("flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors", theme === "dark" ? "bg-secondary text-secondary-foreground" : "text-muted-foreground hover:text-foreground"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" }),
										" ",
										t("branding.theme.dark")
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "primary",
								children: t("branding.colors.primaryLabel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "primary",
									type: "color",
									value: cfg.primaryColor,
									onChange: (e) => update({ primaryColor: e.target.value }),
									className: "h-10 w-14 cursor-pointer rounded border bg-card"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: cfg.primaryColor,
									onChange: (e) => update({ primaryColor: e.target.value }),
									placeholder: "#1e3a5f"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-2 text-xs font-medium text-muted-foreground",
								children: t("branding.preview.label")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center rounded-md px-3 py-1.5 text-sm font-medium text-white",
									style: { background: cfg.primaryColor },
									children: t("branding.preview.primaryButton")
								})
							})]
						})
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					onClick: handleReset,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "mr-2 h-4 w-4" }), t("branding.resetButton")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: handleSave,
					children: t("branding.saveButton")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoweredBy, {})
		]
	});
}
//#endregion
export { BrandingPage as component };
