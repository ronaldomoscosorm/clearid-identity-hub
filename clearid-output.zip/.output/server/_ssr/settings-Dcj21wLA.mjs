import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Switch } from "./switch-DtEVXaE2.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-C5Nmk_bj.mjs";
import { rt as CircleCheck, tt as CircleX } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as getConfiguredSiteId, h as setDefaultProfile, l as getSystemObjectId, m as setConfiguredSiteId, r as argusApi, s as getConfig, u as saveConfig, v as setSystemObjectId, x as useDefaultProfile } from "./argus-client-fTtea6N-.mjs";
import { n as pushSettings } from "./supabase-settings-DI2-qLO-.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Dcj21wLA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Settings() {
	const [cfg, setCfg] = (0, import_react.useState)(() => getConfig());
	const [lastResult, setLastResult] = (0, import_react.useState)(null);
	const [siteId, setSiteId] = (0, import_react.useState)(() => getConfiguredSiteId() ?? "");
	const [systemObjectId, setSystemObjectIdState] = (0, import_react.useState)(() => getSystemObjectId() ?? "");
	const [ruleId, setRuleId] = (0, import_react.useState)(() => getConfig().defaultRuleId ?? "");
	const qc = useQueryClient();
	const { t } = useT();
	const configuredProfile = useDefaultProfile();
	const scope = useUserScope();
	const changeProfile = (code) => {
		if (code === configuredProfile) return;
		setDefaultProfile(code);
		setSiteId("");
		setSystemObjectIdState("");
		setRuleId("");
		setConfiguredSiteId(null);
		setSystemObjectId(null);
		qc.invalidateQueries();
	};
	const sitesQuery = useQuery({
		queryKey: [
			"argus",
			"sites",
			configuredProfile
		],
		queryFn: () => argusApi.listSites(configuredProfile),
		staleTime: 6e4
	});
	const systemsQuery = useQuery({
		queryKey: [
			"argus",
			"systems",
			configuredProfile
		],
		queryFn: () => argusApi.listSystems(configuredProfile),
		staleTime: 6e4
	});
	const teamsQuery = useQuery({
		queryKey: [
			"argus",
			"teams",
			configuredProfile,
			siteId
		],
		queryFn: () => argusApi.listTeams({
			take: 200,
			siteId: siteId || void 0,
			environment: configuredProfile
		}),
		staleTime: 6e4
	});
	const test = useMutation({
		mutationFn: argusApi.diagnostics,
		onSuccess: (r) => {
			setLastResult(r);
			if (r.backend.reachable) toast.success(t("settings.toast.connectionOk", { environment: r.environment }));
			else toast.error(t("settings.toast.connectionFail", { message: r.backend.message ?? t("settings.unreachable") }));
		}
	});
	const handleSave = () => {
		const ruleName = teamsQuery.data?.find((t) => t.teamId === ruleId)?.name;
		const nextCfg = {
			...cfg,
			defaultSiteId: siteId || void 0,
			defaultSiteName: sitesQuery.data?.find((s) => s.siteId === siteId)?.name,
			defaultRuleId: ruleId || void 0,
			defaultRuleName: ruleName
		};
		saveConfig(nextCfg);
		setConfiguredSiteId(siteId || null);
		setSystemObjectId(systemObjectId || null);
		setCfg(nextCfg);
		qc.invalidateQueries();
		pushSettings().then(() => toast.success(t("settings.toast.saved"))).catch(() => toast.warning(t("settings.toast.savedLocalSyncFail")));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("settings.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("settings.subtitle")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.backend.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.backend.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "baseUrl",
							children: t("settings.baseUrl.label")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "baseUrl",
							value: cfg.baseUrl,
							onChange: (e) => setCfg({
								...cfg,
								baseUrl: e.target.value
							}),
							placeholder: "https://argusclearid.rm.local"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "apiKey",
							children: t("settings.apiKey.label")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "apiKey",
							type: "password",
							value: cfg.apiKey,
							onChange: (e) => setCfg({
								...cfg,
								apiKey: e.target.value
							}),
							placeholder: t("settings.apiKey.placeholder")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => test.mutate(),
							disabled: test.isPending,
							children: test.isPending ? t("settings.testing") : test.isSuccess && lastResult?.backend.reachable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mr-1 h-4 w-4 text-[var(--success)]" }),
								" ",
								t("settings.ok")
							] }) : test.isSuccess && !lastResult?.backend.reachable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "mr-1 h-4 w-4 text-destructive" }),
								" ",
								t("settings.failed")
							] }) : t("settings.testConnection")
						}), lastResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: t("settings.currentEnvironment")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: lastResult.environment.toLowerCase().startsWith("prod") ? "default" : "secondary",
									children: lastResult.environment
								}),
								lastResult.clientCode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: t("settings.clientCode")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: lastResult.clientCode
								})] }),
								typeof lastResult.backend.latencyMs === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [lastResult.backend.latencyMs, " ms"]
								})
							]
						})]
					}),
					lastResult?.backend.message && !lastResult.backend.reachable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: lastResult.backend.message
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.client.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.client.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "client",
							children: t("settings.client.label")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: configuredProfile,
							onValueChange: changeProfile,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "client",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: scope.visibleProfiles.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: p.code,
								children: p.label
							}, p.code)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: t("settings.client.hint")
						})
					]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.site.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.site.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "site",
							children: t("settings.site.label")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: siteId,
							onValueChange: setSiteId,
							disabled: sitesQuery.isLoading || !!sitesQuery.error,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "site",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: sitesQuery.isLoading ? t("settings.site.loading") : sitesQuery.error ? t("settings.site.loadError") : t("settings.site.placeholder") })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: scope.filterSites(sitesQuery.data ?? [], configuredProfile).slice().sort((a, b) => a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base" })).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: s.siteId,
								children: s.name
							}, s.siteId)) })]
						}),
						sitesQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: sitesQuery.error.message
						})
					]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.rule.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.rule.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "rule",
							children: t("settings.rule.label")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: ruleId,
							onValueChange: setRuleId,
							disabled: teamsQuery.isLoading || !!teamsQuery.error,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "rule",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: teamsQuery.isLoading ? t("settings.rule.loading") : teamsQuery.error ? t("settings.rule.loadError") : t("settings.rule.placeholder") })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (teamsQuery.data ?? []).filter((t) => !t.isDeleted).slice().sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "pt-BR", { sensitivity: "base" })).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: t.teamId,
								children: t.name
							}, t.teamId)) })]
						}),
						teamsQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: teamsQuery.error.message
						})
					]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.system.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.system.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "system",
							children: t("settings.system.label")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: systemObjectId,
							onValueChange: setSystemObjectIdState,
							disabled: systemsQuery.isLoading || !!systemsQuery.error,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "system",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: systemsQuery.isLoading ? t("settings.system.loading") : systemsQuery.error ? t("settings.system.loadError") : t("settings.system.placeholder") })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (systemsQuery.data ?? []).slice().sort((a, b) => a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base" })).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: s.systemObjectId,
								children: s.name || s.systemObjectId
							}, s.systemObjectId)) })]
						}),
						systemsQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: systemsQuery.error.message
						}),
						systemObjectId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted-foreground",
							children: systemObjectId
						})
					]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("settings.visits.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("settings.visits.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: Boolean(cfg.linkVisitorToIdentity),
					onCheckedChange: (v) => setCfg((c) => ({
						...c,
						linkVisitorToIdentity: v
					}))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-foreground",
						children: t("settings.visits.linkLabel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: t("settings.visits.linkHint")
					})]
				})]
			}) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: handleSave,
					children: t("settings.saveButton")
				})
			})
		]
	});
}
//#endregion
export { Settings as component };
