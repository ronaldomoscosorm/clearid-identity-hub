import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/branding-lYWRBKZ3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var KEY = "argus.branding";
var DEFAULT_BRANDING = {
	clientName: "",
	clientLogo: "",
	primaryColor: "#FD5300",
	accentColor: "#102943"
};
function isBrowser() {
	return typeof window !== "undefined";
}
function getBranding() {
	if (!isBrowser()) return DEFAULT_BRANDING;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return DEFAULT_BRANDING;
		const parsed = JSON.parse(raw);
		if (parsed.primaryColor === "#1e3a5f") parsed.primaryColor = DEFAULT_BRANDING.primaryColor;
		if (parsed.accentColor === "#3b6fa0") parsed.accentColor = DEFAULT_BRANDING.accentColor;
		return {
			...DEFAULT_BRANDING,
			...parsed
		};
	} catch {
		return DEFAULT_BRANDING;
	}
}
function saveBranding(cfg) {
	if (!isBrowser()) return;
	localStorage.setItem(KEY, JSON.stringify(cfg));
	notify();
}
function resetBranding() {
	if (!isBrowser()) return;
	localStorage.removeItem(KEY);
	notify();
}
var listeners = /* @__PURE__ */ new Set();
function notify() {
	for (const l of listeners) l();
}
function subscribe(cb) {
	listeners.add(cb);
	const onStorage = (e) => {
		if (e.key === KEY) cb();
	};
	if (isBrowser()) window.addEventListener("storage", onStorage);
	return () => {
		listeners.delete(cb);
		if (isBrowser()) window.removeEventListener("storage", onStorage);
	};
}
function useBranding() {
	const json = (0, import_react.useSyncExternalStore)(subscribe, () => JSON.stringify(getBranding()), () => JSON.stringify(DEFAULT_BRANDING));
	return JSON.parse(json);
}
/** Apply brand colors as CSS variables on :root */
function applyBranding(cfg) {
	if (!isBrowser()) return;
	const root = document.documentElement;
	const props = [
		"--primary",
		"--sidebar-primary",
		"--ring",
		"--rm-brand",
		"--rm-brand-ink"
	];
	if (cfg.primaryColor) for (const p of props) root.style.setProperty(p, cfg.primaryColor);
	else for (const p of props) root.style.removeProperty(p);
}
function useApplyBranding() {
	const b = useBranding();
	(0, import_react.useEffect)(() => {
		applyBranding(b);
	}, [b]);
}
//#endregion
export { saveBranding as a, resetBranding as i, applyBranding as n, useApplyBranding as o, getBranding as r, useBranding as s, DEFAULT_BRANDING as t };
