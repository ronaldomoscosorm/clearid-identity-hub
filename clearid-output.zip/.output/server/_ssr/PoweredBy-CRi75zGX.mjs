import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PoweredBy-CRi75zGX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RmLogo({ className }) {
	const navy = "#17324a";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 100",
		className,
		role: "img",
		"aria-label": "R&M Tecnologia",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: navy,
				d: "M38 6 H40 A6 6 0 0 1 46 12 V44 A2 2 0 0 1 44 46 H12 A6 6 0 0 1 6 40 V38 A32 32 0 0 1 38 6 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: navy,
				d: "M60 6 H62 A32 32 0 0 1 94 38 V40 A6 6 0 0 1 88 46 H56 A2 2 0 0 1 54 44 V12 A6 6 0 0 1 60 6 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: navy,
				d: "M12 54 H44 A2 2 0 0 1 46 56 V88 A6 6 0 0 1 40 94 H38 A32 32 0 0 1 6 62 V60 A6 6 0 0 1 12 54 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: navy,
				d: "M56 54 H88 A6 6 0 0 1 94 60 V62 A32 32 0 0 1 62 94 H60 A6 6 0 0 1 54 88 V56 A2 2 0 0 1 56 54 Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "26",
				cy: "26",
				r: "15",
				fill: "#fff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#f4571f",
				d: "M26 15 C27 22 30 25 37 26 C30 27 27 30 26 37 C25 30 22 27 15 26 C22 25 25 22 26 15 Z"
			})
		]
	});
}
function PoweredBy() {
	const [imgOk, setImgOk] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-center gap-1.5 py-4 text-[11px] text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Powered by" }), imgOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/rm-tecnologia-logo.png",
			alt: "R&M Tecnologia",
			className: "h-6 w-auto opacity-80",
			loading: "lazy",
			onError: () => setImgOk(false)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1 font-semibold text-[#f4571f]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RmLogo, { className: "h-4 w-4" }), "R&M Tecnologia"]
		})]
	});
}
//#endregion
export { PoweredBy as t };
