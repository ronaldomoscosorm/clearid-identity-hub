import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { G as Eye, P as LoaderCircle, T as Pencil, l as Trash2, ut as Camera, v as Search, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campanhas-foto-NLQCNIlZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatDate(iso) {
	if (!iso) return "—";
	try {
		return new Date(iso).toLocaleString("pt-BR");
	} catch {
		return iso;
	}
}
function statusBadge(t, status) {
	switch (status) {
		case "Sent": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t("campaigns.status.sent") });
		case "Used": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: t("campaigns.status.used")
		});
		case "Failed": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "destructive",
			children: t("campaigns.status.failed")
		});
		case "SkippedNoEmail": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "outline",
			children: t("campaigns.noEmailLabel")
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: t("campaigns.status.pending")
		});
	}
}
function CampanhasFotoPage() {
	const { t } = useT();
	const siteId = useDefaultSiteId();
	const qc = useQueryClient();
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [deleting, setDeleting] = (0, import_react.useState)(null);
	const deleteMutation = useMutation({
		mutationFn: (id) => argusApi.deletePhotoCampaign(id),
		onSuccess: () => {
			toast.success(t("campaigns.deleteSuccess"));
			setDeleting(null);
			qc.invalidateQueries({ queryKey: ["photo-campaigns"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const listQuery = useQuery({
		queryKey: ["photo-campaigns"],
		queryFn: () => argusApi.listPhotoCampaigns(),
		retry: false
	});
	const items = listQuery.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: t("campaigns.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("campaigns.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => listQuery.refetch(),
						disabled: listQuery.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${listQuery.isFetching ? "animate-spin" : ""}` }), t("campaigns.refresh")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setCreateOpen(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("campaigns.newCampaign")
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: listQuery.data ? items.length === 1 ? t("campaigns.countOne", { count: items.length }) : t("campaigns.countOther", { count: items.length }) : t("campaigns.heading")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: listQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
			}) : listQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: listQuery.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("campaigns.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.environment") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.targets") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.sent") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.noEmailLabel") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.failed") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.created") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[130px] text-right",
					children: t("common.actions")
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: c.name || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: c.environment
				}), c.dryRun && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					className: "ml-1",
					children: t("campaigns.dryRun")
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.totalTargets }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.sent }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: c.skippedNoEmail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: c.failed ? "text-destructive" : "text-muted-foreground",
					children: c.failed
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-sm text-muted-foreground",
					children: formatDate(c.createdUtc)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: t("campaigns.detailAction"),
								onClick: () => setDetailId(c.campaignId),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: t("common.rename"),
								onClick: () => setEditing(c),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: t("common.delete"),
								className: "text-destructive hover:text-destructive",
								onClick: () => setDeleting(c),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					})
				})
			] }, c.campaignId)) })] }) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateCampaignDialog, {
				open: createOpen,
				onOpenChange: setCreateOpen,
				siteId,
				onCreated: () => {
					qc.invalidateQueries({ queryKey: ["photo-campaigns"] });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CampaignDetailDialog, {
				id: detailId,
				onClose: () => setDetailId(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RenameCampaignDialog, {
				campaign: editing,
				onClose: () => setEditing(null),
				onSaved: () => {
					setEditing(null);
					qc.invalidateQueries({ queryKey: ["photo-campaigns"] });
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(deleting),
				onOpenChange: (v) => !v && setDeleting(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("campaigns.deleteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					t("campaigns.deleteConfirmPrefix"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: deleting?.name || t("campaigns.unnamed") }),
					" ",
					t("campaigns.deleteConfirmSuffix")
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: deleteMutation.isPending,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					disabled: deleteMutation.isPending,
					onClick: (e) => {
						e.preventDefault();
						if (deleting) deleteMutation.mutate(deleting.campaignId);
					},
					children: deleteMutation.isPending ? t("campaigns.deleting") : t("common.delete")
				})] })] })
			})
		]
	});
}
function RenameCampaignDialog({ campaign, onClose, onSaved }) {
	const { t } = useT();
	const [name, setName] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setName(campaign?.name ?? "");
	}, [campaign]);
	const rename = useMutation({
		mutationFn: () => argusApi.updatePhotoCampaign(campaign.campaignId, { name: name.trim() || null }),
		onSuccess: () => {
			toast.success(t("campaigns.updateSuccess"));
			onSaved();
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(campaign),
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[440px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" }),
						" ",
						t("campaigns.renameTitle")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("campaigns.renameDescription") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "rename",
						children: t("common.name")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rename",
						value: name,
						onChange: (e) => setName(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && !rename.isPending && rename.mutate(),
						placeholder: t("campaigns.namePlaceholder")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => rename.mutate(),
					disabled: rename.isPending,
					children: rename.isPending ? t("common.saving") : t("common.save")
				})] })
			]
		})
	});
}
function CreateCampaignDialog({ open, onOpenChange, siteId, onCreated }) {
	const { t } = useT();
	const [name, setName] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("site");
	const [search, setSearch] = (0, import_react.useState)("");
	const [applied, setApplied] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)({});
	const idsQuery = useQuery({
		queryKey: [
			"identities-search-campaign",
			siteId,
			applied
		],
		queryFn: () => argusApi.listIdentities({
			query: applied,
			take: 50
		}),
		enabled: mode === "identities" && applied.length > 0,
		retry: false
	});
	const create = useMutation({
		mutationFn: () => argusApi.createPhotoCampaign({
			name: name.trim() || void 0,
			...mode === "site" ? { siteId: siteId ?? null } : { identityIds: Object.keys(selected) }
		}),
		onSuccess: (r) => {
			toast.success(r.dryRun ? t("campaigns.createdDryRun", { total: r.totalTargets }) : t("campaigns.createdResult", {
				sent: r.sent,
				noEmail: r.skippedNoEmail,
				failed: r.failed
			}));
			onCreated();
			reset();
			onOpenChange(false);
		},
		onError: (e) => toast.error(e.message)
	});
	const reset = () => {
		setName("");
		setMode("site");
		setSearch("");
		setApplied("");
		setSelected({});
	};
	const toggle = (id, displayName) => setSelected((prev) => {
		const next = { ...prev };
		if (next[id]) delete next[id];
		else next[id] = displayName;
		return next;
	});
	const submit = () => {
		if (mode === "site" && !siteId) {
			toast.error(t("campaigns.selectDefaultSite"));
			return;
		}
		if (mode === "identities" && Object.keys(selected).length === 0) {
			toast.error(t("campaigns.selectAtLeastOne"));
			return;
		}
		create.mutate();
	};
	const results = idsQuery.data?.items ?? [];
	const selectedCount = Object.keys(selected).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => v ? onOpenChange(v) : (reset(), onOpenChange(false)),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[560px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-5 w-5" }),
						" ",
						t("campaigns.createTitle")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("campaigns.createDescription") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "camp-name",
								children: t("campaigns.nameOptional")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "camp-name",
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: t("campaigns.namePlaceholderExample")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("campaigns.targets") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: mode === "site" ? "default" : "outline",
									size: "sm",
									onClick: () => setMode("site"),
									children: t("campaigns.wholeSite")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: mode === "identities" ? "default" : "outline",
									size: "sm",
									onClick: () => setMode("identities"),
									children: t("campaigns.selectIdentities")
								})]
							})]
						}),
						mode === "identities" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: search,
										onChange: (e) => setSearch(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && setApplied(search.trim()),
										placeholder: t("campaigns.searchPlaceholder")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "sm",
										onClick: () => setApplied(search.trim()),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-h-56 space-y-1 overflow-y-auto rounded-md border p-2",
									children: idsQuery.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 p-2 text-sm text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
											" ",
											t("campaigns.searching")
										]
									}) : applied && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "p-2 text-sm text-muted-foreground",
										children: t("campaigns.noIdentitiesFound")
									}) : results.map((i) => {
										const dn = `${i.firstName} ${i.lastName}`.trim();
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex cursor-pointer items-center gap-2 rounded p-1.5 text-sm hover:bg-muted",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
													checked: Boolean(selected[i.identityId]),
													onCheckedChange: () => toggle(i.identityId, dn)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex-1",
													children: dn
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted-foreground",
													children: i.email ?? t("campaigns.noEmailValue")
												})
											]
										}, i.identityId);
									})
								}),
								selectedCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: t("campaigns.selectedCount", { count: selectedCount })
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => (reset(), onOpenChange(false)),
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: submit,
					disabled: create.isPending,
					children: create.isPending ? t("campaigns.dispatching") : t("campaigns.dispatch")
				})] })
			]
		})
	});
}
function CampaignDetailDialog({ id, onClose }) {
	const { t } = useT();
	const query = useQuery({
		queryKey: ["photo-campaign", id],
		queryFn: () => argusApi.getPhotoCampaign(id),
		enabled: Boolean(id),
		retry: false
	});
	const targets = query.data?.targets ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: Boolean(id),
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[85vh] overflow-y-auto sm:max-w-[720px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: query.data?.name || t("campaigns.detailFallbackTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("campaigns.detailDescription") })] }), query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" }) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: query.error.message
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.identity") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.email") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.status") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.expires") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("campaigns.col.used") })
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: targets.map((target) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: target.displayName ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: target.email ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [
					statusBadge(t, target.status),
					target.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-destructive",
						children: target.error
					}),
					target.dryRunLink && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: target.dryRunLink,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-1 block text-xs text-primary underline",
						children: t("campaigns.dryRunLink")
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-sm text-muted-foreground",
					children: formatDate(target.expiresUtc)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-sm text-muted-foreground",
					children: formatDate(target.usedUtc)
				})
			] }, target.identityId)) })] })]
		})
	});
}
//#endregion
export { CampanhasFotoPage as component };
