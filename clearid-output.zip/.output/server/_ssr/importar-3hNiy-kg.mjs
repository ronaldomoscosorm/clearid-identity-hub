import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Switch } from "./switch-DtEVXaE2.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { P as LoaderCircle, W as FileSpreadsheet, c as TriangleAlert, rt as CircleCheck, s as Upload } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, r as argusApi, t as ArgusApiError, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/importar-3hNiy-kg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Retorna um novo File (CSV) com a coluna `siteId` definida como `siteId` em
* todas as linhas de dados. Qualquer coluna de site pré-existente (em qualquer
* caixa: SiteId, siteid…) é substituída, evitando colunas duplicadas.
*/
async function withSiteId(file, siteId) {
	const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
	const buf = await file.arrayBuffer();
	const wb = XLSX.read(buf, { type: "array" });
	const sheetName = wb.SheetNames[0];
	if (!sheetName) throw new Error("Planilha vazia ou ilegível.");
	const ws = wb.Sheets[sheetName];
	const rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
	if (!rows.length) throw new Error("A planilha não contém linhas de dados.");
	const normalized = rows.map((row) => {
		const next = {};
		for (const [key, value] of Object.entries(row)) {
			if (key.trim().toLowerCase() === "siteid") continue;
			next[key] = value;
		}
		next.siteId = siteId;
		return next;
	});
	const outWs = XLSX.utils.json_to_sheet(normalized);
	const csv = XLSX.utils.sheet_to_csv(outWs);
	const baseName = file.name.replace(/\.(csv|xlsx|xls)$/i, "");
	return new File([csv], `${baseName}.csv`, { type: "text/csv" });
}
var ACCEPT = ".csv,.xlsx,.xls";
function actionTone(action) {
	const a = action.toLowerCase();
	if (a.includes("fail")) return {
		variant: "destructive",
		label: action
	};
	if (a.includes("skip")) return {
		variant: "outline",
		label: action
	};
	return {
		variant: a.includes("would") ? "secondary" : "default",
		label: action
	};
}
function ImportPage() {
	const { t } = useT();
	const defaultSiteId = useDefaultSiteId();
	const inputRef = (0, import_react.useRef)(null);
	const [file, setFile] = (0, import_react.useState)(null);
	const [siteId, setSiteId] = (0, import_react.useState)(defaultSiteId ?? "");
	const [dryRun, setDryRun] = (0, import_react.useState)(true);
	const [result, setResult] = (0, import_react.useState)(null);
	const importActiveProfile = useActiveProfile();
	const importScope = useUserScope();
	const sitesQuery = useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	const sites = importScope.filterSites(sitesQuery.data ?? [], importActiveProfile).slice().sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "pt-BR"));
	const importMut = useMutation({
		mutationFn: async (f) => {
			const prepared = await withSiteId(f, siteId);
			return argusApi.importIdentities(prepared, { dryRun });
		},
		onSuccess: (r) => {
			setResult(r);
			const msg = t("import.toast.done", {
				created: r.created,
				updated: r.updated,
				skipped: r.skipped,
				failed: r.failed
			});
			if (r.failed > 0) toast.warning(msg);
			else toast.success(msg);
		},
		onError: (e) => {
			const message = e instanceof ArgusApiError ? e.message : e.message;
			toast.error(t("import.toast.error", { message }));
		}
	});
	const onPick = (e) => {
		const f = e.target.files?.[0] ?? null;
		setFile(f);
		setResult(null);
	};
	const onSubmit = () => {
		if (!file || !siteId) return;
		importMut.mutate(file);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("import.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("import.subtitle")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("import.file.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: t("import.file.description") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "file",
								children: t("import.file.label")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								ref: inputRef,
								id: "file",
								type: "file",
								accept: ACCEPT,
								onChange: onPick,
								disabled: importMut.isPending
							}),
							file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "h-4 w-4" }),
									file.name,
									" · ",
									(file.size / 1024).toFixed(1),
									" KB"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "site",
								children: t("import.site.label")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: siteId,
								onValueChange: setSiteId,
								disabled: importMut.isPending || sitesQuery.isLoading,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									id: "site",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: sitesQuery.isLoading ? t("import.site.loading") : t("import.site.placeholder") })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: sites.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s.siteId,
									children: s.name
								}, s.siteId)) })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t("import.site.hint")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: dryRun,
							onCheckedChange: setDryRun,
							disabled: importMut.isPending
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium text-foreground",
								children: t("import.dryRun.label")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: t("import.dryRun.hint")
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onSubmit,
							disabled: !file || !siteId || importMut.isPending,
							children: importMut.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }),
								" ",
								t("import.running")
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-1 h-4 w-4" }),
								" ",
								dryRun ? t("import.simulate") : t("import.execute")
							] })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: t("import.columnsHint")
					})
				]
			})] }),
			result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2 text-base",
				children: [result.failed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4 text-[var(--rm-inactive-ink)]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-[var(--success)]" }), result.dryRun ? t("import.result.simTitle") : t("import.result.title")]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
				result.fileName,
				" · ",
				result.environment
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: result.totalRows,
								label: t("import.stat.total")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: result.created,
								label: t("import.stat.created"),
								tone: "active"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: result.updated,
								label: t("import.stat.updated"),
								tone: "brand"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: result.skipped,
								label: t("import.stat.skipped")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: result.failed,
								label: t("import.stat.failed"),
								tone: result.failed > 0 ? "inactive" : void 0
							})
						]
					}),
					result.unknownColumns.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-[var(--rm-line)] bg-[var(--rm-panel-2)] p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: t("import.unknownColumns")
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: result.unknownColumns.join(", ")
							})
						]
					}),
					result.detectedColumns.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: result.detectedColumns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							className: "font-normal",
							children: c
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-lg border border-[var(--rm-line)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "w-14",
								children: t("import.col.row")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "w-28",
								children: t("import.col.action")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("import.col.identity") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "w-16 text-right",
								children: t("import.col.custom")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("import.col.messages") })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: result.rows.map((r) => {
							const tone = actionTone(r.action);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "tabular-nums text-muted-foreground",
									children: r.rowNumber
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: tone.variant,
									children: tone.label
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-foreground",
									children: r.displayName || r.email || r.externalId || "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: [r.email, r.externalId && `ext: ${r.externalId}`].filter(Boolean).join(" · ") || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums text-muted-foreground",
									children: r.customFieldsSet ?? 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-xs text-muted-foreground",
									children: r.messages.length ? r.messages.join(" ") : "—"
								})
							] }, r.rowNumber);
						}) })] })
					})
				]
			})] })
		]
	});
}
function Stat({ value, label, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-[var(--rm-line)] bg-[var(--rm-panel)] p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-2xl font-semibold tabular-nums",
			style: { color: tone === "active" ? "var(--rm-active-ink)" : tone === "inactive" ? "var(--rm-inactive-ink)" : tone === "brand" ? "var(--rm-brand-ink)" : "var(--foreground)" },
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground",
			children: label
		})]
	});
}
//#endregion
export { ImportPage as component };
