import { t as supabase } from "./client-pXxOjxhm.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as STANDARD_IDENTITY_FIELDS } from "./identity-labels-B1NFjUho.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/form-layout-BbQ23fKU.js
var ALL_KEYS = STANDARD_IDENTITY_FIELDS.map((f) => f.key);
var ALL_SET = new Set(ALL_KEYS);
var REQUIRED_KEYS = STANDARD_IDENTITY_FIELDS.filter((f) => f.required).map((f) => f.key);
/** Aceita chaves padrão do catálogo ou campos customizáveis (cf:...). */
var isValidKey = (k) => typeof k === "string" && (ALL_SET.has(k) || k.startsWith("cf:"));
var DEFAULT_LAYOUT_ID = "default";
/** Layout default: um único grupo com todos os campos padrão, na ordem do catálogo. */
function defaultLayout(name = "Padrão") {
	return {
		id: DEFAULT_LAYOUT_ID,
		name,
		groups: [{
			name: "",
			fields: [...ALL_KEYS]
		}]
	};
}
/** Normaliza os grupos de um layout: descarta chaves inválidas/duplicadas e garante os obrigatórios. */
function normalizeGroups(groups) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	if (Array.isArray(groups)) for (const g of groups) {
		const src = g;
		const fields = [];
		for (const k of Array.isArray(src?.fields) ? src.fields : []) {
			if (!isValidKey(k) || seen.has(k)) continue;
			seen.add(k);
			fields.push(k);
		}
		out.push({
			name: typeof src?.name === "string" ? src.name : "",
			fields
		});
	}
	if (out.length === 0) out.push({
		name: "",
		fields: []
	});
	const missing = REQUIRED_KEYS.filter((k) => !seen.has(k));
	if (missing.length) out[0].fields.push(...missing);
	return out;
}
/** Normaliza a config completa: garante ao menos um layout e vínculos válidos. */
function normalizeConfig(raw) {
	const obj = raw ?? {};
	let layouts = [];
	if (Array.isArray(obj.layouts)) layouts = obj.layouts.map((l, i) => {
		const src = l;
		return {
			id: typeof src?.id === "string" && src.id ? src.id : `layout-${i}`,
			name: typeof src?.name === "string" ? src.name : "",
			groups: normalizeGroups(src?.groups)
		};
	});
	if (layouts.length === 0) layouts = [defaultLayout()];
	const ids = new Set(layouts.map((l) => l.id));
	const links = {};
	const rawLinks = obj.links ?? {};
	for (const [wt, lid] of Object.entries(rawLinks)) if (typeof lid === "string" && ids.has(lid)) links[wt] = lid;
	return {
		layouts,
		links
	};
}
/** Retorna o layout vinculado ao tipo de trabalhador, ou o primeiro (default). */
function layoutForWorkerType(config, workerTypeId) {
	if (workerTypeId) {
		const lid = config.links[workerTypeId];
		const found = lid ? config.layouts.find((l) => l.id === lid) : void 0;
		if (found) return found;
	}
	return config.layouts[0] ?? defaultLayout();
}
/** Chave do mapa de layouts por CLIENTE (perfil ClearID) dentro de preferences. */
var BY_CLIENT_KEY = "formLayoutsByClient";
/** Chave legada: layouts por site (mantida só para migração/fallback de leitura). */
var BY_SITE_KEY = "formLayoutsBySite";
/**
* Cliente dono dos layouts LEGADOS (por-site e global). Antes da separação por
* cliente existia só o RM, então esses dados pertencem a ele — e SÓ ele os
* herda. Os demais clientes começam do layout padrão.
*/
var LEGACY_PROFILE = "RM";
/**
* Extrai o raw de layout para um cliente. Ordem: layout do cliente → (só para o
* RM, compat.) layout do site-semente no formato antigo por-site → global antigo
* → documento único. Outros clientes sem layout próprio começam do padrão.
*/
function rawForClient(prefs, profile, seedSiteId) {
	const byClient = prefs[BY_CLIENT_KEY] ?? {};
	if (profile && byClient[profile]) return byClient[profile];
	if (profile === LEGACY_PROFILE) {
		const bySite = prefs[BY_SITE_KEY] ?? {};
		if (seedSiteId && bySite[seedSiteId]) return bySite[seedSiteId];
		if (prefs.formLayouts) return prefs.formLayouts;
		if (prefs.formLayout) return {
			layouts: [{
				id: DEFAULT_LAYOUT_ID,
				name: "Padrão",
				groups: prefs.formLayout.groups ?? []
			}],
			links: {}
		};
	}
	return null;
}
async function fetchConfig(profile, seedSiteId) {
	const { data, error } = await supabase.from("settings").select("preferences").limit(1).maybeSingle();
	if (error) throw new Error(error.message);
	return normalizeConfig(rawForClient(data?.preferences ?? {}, profile, seedSiteId));
}
/**
* Config de layout do CLIENTE (perfil). `seedSiteId` é usado apenas como
* semente de compatibilidade quando o cliente ainda não tem layout próprio.
*/
function useFormLayoutConfig(profile, seedSiteId) {
	const query = useQuery({
		queryKey: ["form-layout", profile ?? null],
		queryFn: () => fetchConfig(profile, seedSiteId),
		staleTime: 0,
		refetchOnMount: "always"
	});
	return {
		config: query.data ?? normalizeConfig(null),
		loaded: query.isSuccess
	};
}
/** Lê as preferences atuais do usuário técnico (para gravação). */
async function loadPrefs() {
	const { data: userData } = await supabase.auth.getUser();
	const userId = userData.user?.id;
	if (!userId) throw new Error("Sem usuário autenticado.");
	const { data: cur } = await supabase.from("settings").select("preferences").eq("user_id", userId).maybeSingle();
	return {
		userId,
		prefs: { ...cur?.preferences ?? {} }
	};
}
async function persistPrefs(userId, prefs) {
	const { error } = await supabase.from("settings").upsert({
		user_id: userId,
		preferences: prefs
	}, { onConflict: "user_id" });
	if (error) throw new Error(error.message);
}
/** Persiste a config de layout de UM CLIENTE preservando as demais preferences. */
async function saveFormLayoutConfig(profile, config) {
	if (!profile) throw new Error("Cliente não definido para salvar o layout.");
	const { userId, prefs } = await loadPrefs();
	const byClient = { ...prefs[BY_CLIENT_KEY] ?? {} };
	byClient[profile] = config;
	prefs[BY_CLIENT_KEY] = byClient;
	delete prefs.formLayout;
	await persistPrefs(userId, prefs);
}
/** Copia a config de layout para outros clientes. */
async function exportFormLayoutToClients(config, targetProfiles) {
	const targets = targetProfiles.filter(Boolean);
	if (targets.length === 0) return;
	const { userId, prefs } = await loadPrefs();
	const byClient = { ...prefs[BY_CLIENT_KEY] ?? {} };
	for (const p of targets) byClient[p] = config;
	prefs[BY_CLIENT_KEY] = byClient;
	await persistPrefs(userId, prefs);
}
//#endregion
export { useFormLayoutConfig as a, saveFormLayoutConfig as i, exportFormLayoutToClients as n, layoutForWorkerType as r, REQUIRED_KEYS as t };
