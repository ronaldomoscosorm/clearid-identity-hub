import { t as supabase } from "./client-pXxOjxhm.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/attachments-PsPmKuGo.js
var ATTACHMENT_BUCKET = "identity-attachments";
/** Extensão do arquivo a partir do nome (fallback: bin). */
function extOf(name) {
	const i = name.lastIndexOf(".");
	return (i >= 0 ? name.slice(i + 1) : "").replace(/[^a-zA-Z0-9]/g, "").toLowerCase() || "bin";
}
/** Resolve o identities.id (uuid) a partir do identityId (texto) do ClearID. */
async function resolveIdentityDbId(clearIdIdentityId) {
	if (!clearIdIdentityId) return null;
	const { data, error } = await supabase.from("identities").select("id").eq("identity_id", clearIdIdentityId).maybeSingle();
	if (error) {
		console.error("[attachments] identidade não encontrada:", error.message);
		return null;
	}
	return data?.id ?? null;
}
/** Lista as versões de um anexo (mais recente primeiro). */
async function listAttachmentVersions(identityDbId, customFieldDefinitionId) {
	const { data, error } = await supabase.from("identity_attachments").select("*").eq("identity_id", identityDbId).eq("custom_field_definition_id", customFieldDefinitionId).order("version", { ascending: false });
	if (error) throw new Error(error.message);
	return data ?? [];
}
/** Gera uma URL assinada temporária para baixar/visualizar um objeto do bucket. */
async function signedUrlFor(storagePath, expiresInSeconds = 300) {
	const { data, error } = await supabase.storage.from(ATTACHMENT_BUCKET).createSignedUrl(storagePath, expiresInSeconds);
	if (error || !data?.signedUrl) throw new Error(error?.message ?? "Falha ao gerar link do arquivo.");
	return data.signedUrl;
}
/**
* Envia um arquivo como uma nova versão do anexo. Marca a versão anterior como
* não-atual antes de inserir a nova (o índice parcial garante 1 atual por campo).
*/
async function uploadAttachmentVersion(identityDbId, customFieldDefinitionId, file) {
	const { data: last, error: eLast } = await supabase.from("identity_attachments").select("version").eq("identity_id", identityDbId).eq("custom_field_definition_id", customFieldDefinitionId).order("version", { ascending: false }).limit(1).maybeSingle();
	if (eLast) throw new Error(eLast.message);
	const nextVersion = (last?.version ?? 0) + 1;
	const path = `${identityDbId}/${customFieldDefinitionId}/v${nextVersion}-${crypto.randomUUID()}.${extOf(file.name)}`;
	const { error: eUp } = await supabase.storage.from(ATTACHMENT_BUCKET).upload(path, file, {
		contentType: file.type || "application/octet-stream",
		upsert: false
	});
	if (eUp) throw new Error(eUp.message);
	const { error: eClear } = await supabase.from("identity_attachments").update({ is_current: false }).eq("identity_id", identityDbId).eq("custom_field_definition_id", customFieldDefinitionId).eq("is_current", true);
	if (eClear) {
		await supabase.storage.from(ATTACHMENT_BUCKET).remove([path]).catch(() => {});
		throw new Error(eClear.message);
	}
	const { data: row, error: eIns } = await supabase.from("identity_attachments").insert({
		identity_id: identityDbId,
		custom_field_definition_id: customFieldDefinitionId,
		version: nextVersion,
		storage_path: path,
		file_name: file.name,
		mime_type: file.type || "application/octet-stream",
		size_bytes: file.size,
		is_current: true
	}).select("*").single();
	if (eIns || !row) {
		await supabase.storage.from(ATTACHMENT_BUCKET).remove([path]).catch(() => {});
		throw new Error(eIns?.message ?? "Falha ao registrar o anexo.");
	}
	return row;
}
/**
* Envia os anexos pendentes de um formulário (best-effort). Resolve o id da
* identidade e sobe cada arquivo como nova versão. Retorna a lista de campos
* que falharam (custom_field_definition_id) para o chamador reportar.
*/
async function saveIdentityAttachments(clearIdIdentityId, pending) {
	const failed = [];
	if (!clearIdIdentityId || !pending.length) return { failed };
	const identityDbId = await resolveIdentityDbId(clearIdIdentityId);
	if (!identityDbId) return { failed: pending.map((p) => p.custom_field_definition_id) };
	for (const p of pending) try {
		await uploadAttachmentVersion(identityDbId, p.custom_field_definition_id, p.file);
	} catch (e) {
		console.error("[attachments] falha ao enviar anexo:", e.message);
		failed.push(p.custom_field_definition_id);
	}
	return { failed };
}
/** Lista os anexos ATUAIS (is_current) de uma identidade, com o campo de origem. */
async function listCurrentAttachments(identityDbId) {
	const { data, error } = await supabase.from("identity_attachments").select("*, definition:custom_field_definitions(custom_field_name, display_name)").eq("identity_id", identityDbId).eq("is_current", true).order("created_at", { ascending: false }).returns();
	if (error) throw new Error(error.message);
	return data ?? [];
}
/**
* Hook: anexos atuais de uma identidade a partir do identityId (texto) do ClearID.
* Resolve o id no Supabase (espelhado) e lista os comprovantes vigentes.
*/
function useCurrentAttachments(clearIdIdentityId) {
	return useQuery({
		queryKey: ["identity-current-attachments", clearIdIdentityId],
		queryFn: async () => {
			const dbId = await resolveIdentityDbId(clearIdIdentityId);
			if (!dbId) return [];
			return listCurrentAttachments(dbId);
		},
		enabled: Boolean(clearIdIdentityId)
	});
}
/** Hook: versões de um anexo para uma identidade já existente (modo edição). */
function useAttachmentVersions(identityDbId, customFieldDefinitionId) {
	return useQuery({
		queryKey: [
			"identity-attachments",
			identityDbId,
			customFieldDefinitionId
		],
		queryFn: () => listAttachmentVersions(identityDbId, customFieldDefinitionId),
		enabled: Boolean(identityDbId && customFieldDefinitionId)
	});
}
//#endregion
export { useCurrentAttachments as i, signedUrlFor as n, useAttachmentVersions as r, saveIdentityAttachments as t };
