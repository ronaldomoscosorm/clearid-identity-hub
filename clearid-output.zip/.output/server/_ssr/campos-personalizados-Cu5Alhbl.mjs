import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang, t as ATTACHMENT_FIELD_TYPE } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { E as Paperclip, F as ListChecks, P as LoaderCircle, T as Pencil, l as Trash2, v as Search, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { t as mirrorCustomFieldDefs } from "./supabase-mirror--nGFXAER.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { t as useClientSettings } from "./client-settings-DnLX0jMS.mjs";
import { t as useSpecialFields } from "./special-fields-B54wdzHo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campos-personalizados-Cu5Alhbl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Lista seções gravadas no Supabase para um cliente. */
async function listSupabaseSections(profile) {
	const { data, error } = await supabase.from("custom_field_sections").select("id, section_name, display_name, display_index, storage").eq("profile", profile).order("display_index", { ascending: true });
	if (error) throw new Error(error.message);
	return (data ?? []).map((r) => ({
		id: r.id,
		sectionName: r.section_name,
		displayName: r.display_name,
		displayIndex: r.display_index,
		storage: r.storage ?? "both"
	}));
}
async function upsertSupabaseSection(input) {
	const { error } = await supabase.from("custom_field_sections").upsert({
		profile: input.profile,
		section_name: input.sectionName,
		display_name: input.displayName,
		display_index: input.displayIndex,
		storage: input.storage
	}, { onConflict: "profile,section_name" });
	if (error) throw new Error(error.message);
}
async function deleteSupabaseSection(profile, sectionName) {
	const { error } = await supabase.from("custom_field_sections").delete().eq("profile", profile).eq("section_name", sectionName);
	if (error) throw new Error(error.message);
}
function unifySections(clearIdSections, supaSections) {
	const bySupaName = new Map(supaSections.map((s) => [s.sectionName, s]));
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const s of clearIdSections) {
		const supa = bySupaName.get(s.sectionName);
		out.push({
			...s,
			storage: supa?.storage ?? "clearid"
		});
		seen.add(s.sectionName);
	}
	for (const s of supaSections) {
		if (seen.has(s.sectionName)) continue;
		out.push({
			sectionName: s.sectionName,
			displayName: s.displayName,
			index: s.displayIndex,
			eTag: null,
			fields: [],
			storage: s.storage
		});
	}
	return out;
}
function SpecialFieldsDialog({ open, onOpenChange, fields }) {
	const { t } = useT();
	const qc = useQueryClient();
	const { list } = useSpecialFields();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const labelOfField = (name) => fields.find((f) => f.customFieldName === name)?.displayName || name;
	const save = useMutation({
		mutationFn: async (d) => {
			const options = d.options.map((o) => ({
				value: o.value.trim(),
				label: o.label.trim() || o.value.trim()
			})).filter((o) => o.value);
			const { error } = await supabase.from("special_custom_fields").upsert({
				custom_field_name: d.custom_field_name,
				label: d.label.trim() || null,
				options
			}, { onConflict: "custom_field_name" });
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("specialFields.saved"));
			qc.invalidateQueries({ queryKey: ["special-custom-fields"] });
			setDraft(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (name) => {
			const { error } = await supabase.from("special_custom_fields").delete().eq("custom_field_name", name);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("specialFields.removed"));
			qc.invalidateQueries({ queryKey: ["special-custom-fields"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const startNew = () => setDraft({
		custom_field_name: "",
		label: "",
		options: [{
			value: "",
			label: ""
		}]
	});
	const setOption = (i, patch) => setDraft((d) => d ? {
		...d,
		options: d.options.map((o, j) => j === i ? {
			...o,
			...patch
		} : o)
	} : d);
	const addOption = () => setDraft((d) => d ? {
		...d,
		options: [...d.options, {
			value: "",
			label: ""
		}]
	} : d);
	const removeOption = (i) => setDraft((d) => d ? {
		...d,
		options: d.options.filter((_, j) => j !== i)
	} : d);
	const canSave = !!draft && !!draft.custom_field_name && !!draft.label.trim() && draft.options.some((o) => o.value.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => {
			onOpenChange(v);
			if (!v) setDraft(null);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("specialFields.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("specialFields.subtitle") })] }), !draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: startNew,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("specialFields.new")
						]
					})
				}), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-6 text-center text-sm text-muted-foreground",
					children: t("specialFields.empty")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-md border",
					children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: s.label || labelOfField(s.custom_field_name)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										labelOfField(s.custom_field_name),
										" · ",
										t("specialFields.optionCount", { count: s.options.length })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: t("common.edit"),
								onClick: () => setDraft({
									custom_field_name: s.custom_field_name,
									label: s.label,
									options: s.options.length ? s.options : [{
										value: "",
										label: ""
									}]
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "text-muted-foreground hover:text-destructive",
								title: t("common.delete"),
								onClick: () => remove.mutate(s.custom_field_name),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, s.custom_field_name))
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: t("specialFields.label")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.label,
							placeholder: t("specialFields.labelPlaceholder"),
							onChange: (e) => setDraft({
								...draft,
								label: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: t("specialFields.field")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: draft.custom_field_name,
							onValueChange: (v) => setDraft({
								...draft,
								custom_field_name: v
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("specialFields.fieldPlaceholder") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: fields.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: f.customFieldName,
								children: f.displayName || f.customFieldName
							}, f.customFieldName)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[1fr_1fr_auto] gap-2 text-xs font-medium text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("specialFields.optionLabel") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("specialFields.optionValue") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								]
							}),
							draft.options.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[1fr_1fr_auto] items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: o.label,
										placeholder: t("specialFields.optionLabelPlaceholder"),
										onChange: (e) => setOption(i, { label: e.target.value })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: o.value,
										placeholder: t("specialFields.optionValuePlaceholder"),
										onChange: (e) => setOption(i, { value: e.target.value })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										className: "text-muted-foreground hover:text-destructive",
										onClick: () => removeOption(i),
										disabled: draft.options.length <= 1,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									})
								]
							}, i)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: addOption,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
									" ",
									t("specialFields.addOption")
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDraft(null),
							children: t("common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => save.mutate(draft),
							disabled: !canSave || save.isPending,
							children: [save.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }), t("common.save")]
						})]
					})
				]
			})]
		})
	});
}
var FIELD_TYPES = [
	"Text",
	"Numeric",
	"Boolean",
	"DateTime",
	"Decimal",
	"Date"
];
var OTHER_SECTION = "__other__";
var SECTION_NAME_MAX = 30;
var FIELD_NAME_MAX = 50;
var DISPLAY_NAME_MAX = 100;
var ACCEPT_OPTIONS = [
	{
		value: "image/*,application/pdf",
		key: "attachmentDef.acceptBoth"
	},
	{
		value: "image/*",
		key: "attachmentDef.acceptImage"
	},
	{
		value: "application/pdf",
		key: "attachmentDef.acceptPdf"
	}
];
/** Minúsculas sem acento, para a busca casar "apolice" com "Apólice". */
function normalize(s) {
	return (s ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
}
function formatDate(iso) {
	if (!iso) return "—";
	try {
		return new Date(iso).toLocaleString("pt-BR");
	} catch {
		return iso;
	}
}
function CustomFieldsPage() {
	const { t } = useT();
	const qc = useQueryClient();
	const activeProfile = useActiveProfile();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [deleting, setDeleting] = (0, import_react.useState)(null);
	const [editingSection, setEditingSection] = (0, import_react.useState)(null);
	const [creatingSection, setCreatingSection] = (0, import_react.useState)(false);
	const [specialOpen, setSpecialOpen] = (0, import_react.useState)(false);
	const [deletingSection, setDeletingSection] = (0, import_react.useState)(null);
	const [attachmentDialog, setAttachmentDialog] = (0, import_react.useState)(null);
	const [deletingAttachment, setDeletingAttachment] = (0, import_react.useState)(null);
	const [attSettings, setAttSettings] = (0, import_react.useState)(null);
	const [search, setSearch] = (0, import_react.useState)("");
	const query = useQuery({
		queryKey: ["custom-fields"],
		queryFn: () => argusApi.listCustomFields(),
		retry: false
	});
	const supaFieldsQuery = useQuery({
		queryKey: ["supabase-custom-fields", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("custom_field_definitions").select("custom_field_name, display_name, custom_field_type, is_read_only, synchronization_enabled, is_deleted, storage, section_name").eq("profile", activeProfile).in("storage", ["supabase", "both"]).eq("is_deleted", false);
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const reload = () => {
		qc.invalidateQueries({ queryKey: ["custom-fields"] });
		qc.invalidateQueries({ queryKey: ["supabase-custom-fields"] });
	};
	const reloadSections = () => qc.invalidateQueries({ queryKey: ["custom-field-sections"] });
	const attachmentsQuery = useQuery({
		queryKey: ["local-attachment-fields"],
		queryFn: async () => {
			const { data, error } = await supabase.from("custom_field_definitions").select("id, custom_field_name, display_name, attachment_accept").eq("is_local", true).eq("is_deleted", false).order("custom_field_name", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const reloadAttachments = () => qc.invalidateQueries({ queryKey: ["local-attachment-fields"] });
	const attachmentDefs = attachmentsQuery.data ?? [];
	const delAttachment = useMutation({
		mutationFn: async (def) => {
			const { error } = await supabase.from("custom_field_definitions").delete().eq("id", def.id);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("attachmentDef.deleted"));
			setDeletingAttachment(null);
			reloadAttachments();
		},
		onError: (e) => toast.error(e.message)
	});
	const delSection = useMutation({
		mutationFn: async (sec) => {
			const storage = (sectionsQuery.data ?? []).find((u) => u.sectionName === sec.sectionName)?.storage ?? "clearid";
			if (storage === "clearid" || storage === "both") await argusApi.deleteCustomFieldSection(sec.sectionName);
			if (storage === "supabase" || storage === "both") await deleteSupabaseSection(activeProfile, sec.sectionName);
		},
		onSuccess: () => {
			toast.success(t("customFields.sectionDeleted"));
			setDeletingSection(null);
			reloadSections();
		},
		onError: (e) => toast.error(e.message)
	});
	const del = useMutation({
		mutationFn: async (f) => {
			const storage = (supaFieldsQuery.data ?? []).find((r) => r.custom_field_name === f.customFieldName)?.storage ?? "clearid";
			const goesToClearId = storage === "clearid" || storage === "both";
			const goesToSupabase = storage === "supabase" || storage === "both";
			if (goesToClearId) {
				const secName = sectionOfField.get(f.customFieldName);
				const sec = secName ? sectionByName.get(secName) : void 0;
				if (sec && (sec.storage === "clearid" || sec.storage === "both")) await argusApi.updateCustomFieldSection(sec.sectionName, {
					displayName: sec.displayName,
					index: sec.index,
					identityCustomFields: sec.fields.filter((x) => x.name !== f.customFieldName),
					eTag: sec.eTag
				});
				await argusApi.deleteCustomField(f.customFieldName);
			}
			if (goesToSupabase) {
				const { error } = await supabase.from("custom_field_definitions").delete().eq("profile", activeProfile).eq("custom_field_name", f.customFieldName);
				if (error) throw new Error(error.message);
			}
		},
		onSuccess: () => {
			toast.success(t("customFields.deleted"));
			setDeleting(null);
			reload();
			reloadSections();
		},
		onError: (e) => toast.error(e.message)
	});
	const q = normalize(search);
	const allItems = (0, import_react.useMemo)(() => {
		const clearIdItems = (query.data ?? []).filter((f) => !f.isDeleted);
		const seen = new Set(clearIdItems.map((f) => f.customFieldName));
		const supaOnly = (supaFieldsQuery.data ?? []).filter((r) => r.storage === "supabase" && !seen.has(r.custom_field_name)).map((r) => ({
			customFieldName: r.custom_field_name,
			displayName: r.display_name?.default ?? r.custom_field_name,
			customFieldType: r.custom_field_type,
			isReadOnly: r.is_read_only,
			synchronizationEnabled: r.synchronization_enabled,
			isDeleted: false,
			eTag: null
		}));
		return [...clearIdItems, ...supaOnly];
	}, [query.data, supaFieldsQuery.data]);
	const items = (0, import_react.useMemo)(() => q ? allItems.filter((f) => normalize(f.displayName).includes(q) || normalize(f.customFieldName).includes(q)) : allItems, [allItems, q]);
	const sectionsQuery = useQuery({
		queryKey: ["custom-field-sections", activeProfile],
		queryFn: async () => {
			const [clearIdSecs, supaSecs] = await Promise.all([argusApi.listCustomFieldSections(), listSupabaseSections(activeProfile)]);
			return unifySections(clearIdSecs, supaSecs);
		},
		staleTime: 300 * 1e3
	});
	const sectionOfField = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const sec of sectionsQuery.data ?? []) for (const f of sec.fields) m.set(f.name, sec.sectionName);
		for (const r of supaFieldsQuery.data ?? []) if (r.section_name && !m.has(r.custom_field_name)) m.set(r.custom_field_name, r.section_name);
		return m;
	}, [sectionsQuery.data, supaFieldsQuery.data]);
	const sectionByName = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const s of sectionsQuery.data ?? []) m.set(s.sectionName, s);
		return m;
	}, [sectionsQuery.data]);
	const storageOfField = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const r of supaFieldsQuery.data ?? []) {
			const s = r.storage ?? "both";
			if (s === "clearid" || s === "supabase" || s === "both") m.set(r.custom_field_name, s);
		}
		return m;
	}, [supaFieldsQuery.data]);
	/** Etiqueta em parênteses para exibir junto do nome. */
	const storageLabel = (s) => s === "supabase" ? "(supabase)" : s === "both" ? "(ambos)" : "(clearid)";
	const labelOf = (key) => key === OTHER_SECTION ? t("customFields.sectionOther") : sectionByName.get(key)?.displayName || key;
	const groupedItems = (0, import_react.useMemo)(() => {
		const groups = /* @__PURE__ */ new Map();
		if (!q) for (const s of sectionsQuery.data ?? []) groups.set(s.sectionName, []);
		for (const f of items) {
			const key = sectionOfField.get(f.customFieldName) ?? OTHER_SECTION;
			if (!groups.has(key)) groups.set(key, []);
			groups.get(key).push(f);
		}
		if (groups.get(OTHER_SECTION)?.length === 0) groups.delete(OTHER_SECTION);
		const name = (k) => k === OTHER_SECTION ? t("customFields.sectionOther") : sectionByName.get(k)?.displayName || k;
		const arr = [...groups.entries()].sort((a, b) => name(a[0]).localeCompare(name(b[0]), "pt-BR", { sensitivity: "base" }));
		for (const [, fs] of arr) fs.sort((a, b) => (a.displayName || a.customFieldName).localeCompare(b.displayName || b.customFieldName, "pt-BR", { sensitivity: "base" }));
		return arr;
	}, [
		items,
		sectionOfField,
		sectionByName,
		sectionsQuery.data,
		q,
		t
	]);
	(0, import_react.useEffect)(() => {
		if (query.data?.length) mirrorCustomFieldDefs(query.data);
	}, [query.data]);
	const renderRow = (f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
			className: "font-medium",
			children: [f.displayName || f.customFieldName, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-1 text-xs font-normal text-muted-foreground",
				children: storageLabel(storageOfField.get(f.customFieldName))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "font-mono text-xs text-muted-foreground",
			children: f.customFieldName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: f.customFieldType ?? "—"
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: f.synchronizationEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t("customFields.syncActive") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "outline",
			children: t("customFields.syncInactive")
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-sm text-muted-foreground",
			children: f.isReadOnly ? t("common.yes") : t("common.no")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-sm text-muted-foreground",
			children: formatDate(f.lastModificationDateUtc)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-right",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: t("attachmentField.settingsTitle"),
						onClick: () => setAttSettings(f),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: t("common.edit"),
						onClick: () => setEditing(f),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: t("common.delete"),
						className: "text-destructive hover:text-destructive",
						onClick: () => setDeleting(f),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})
				]
			})
		})
	] }, f.customFieldName);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: t("customFields.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("customFields.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => query.refetch(),
							disabled: query.isFetching,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${query.isFetching ? "animate-spin" : ""}` }), t("customFields.refresh")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setCreatingSection(true),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
								" ",
								t("customFields.newSection")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setSpecialOpen(true),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "mr-1 h-4 w-4" }),
								" ",
								t("specialFields.button")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => setCreating(true),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
								" ",
								t("customFields.newField")
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row items-center justify-between gap-3 space-y-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: query.data ? items.length === 1 ? t("customFields.countSingular", { count: items.length }) : t("customFields.countPlural", { count: items.length }) : t("customFields.fieldsLabel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full max-w-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: t("customFields.searchPlaceholder"),
						className: "pl-8"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })
				]
			}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: query.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: q ? t("customFields.noSearchResults", { query: search.trim() }) : t("customFields.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: groupedItems.map(([sectionKey, fields]) => {
					const sec = sectionKey === OTHER_SECTION ? null : sectionByName.get(sectionKey);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-medium text-foreground",
								children: [labelOf(sectionKey), sec && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-xs font-normal text-muted-foreground",
									children: storageLabel(sec.storage)
								})]
							}), sec && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "h-6 w-6",
								title: t("customFields.editSection"),
								onClick: () => setEditingSection(sec),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3 w-3" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "h-6 w-6 text-destructive hover:text-destructive",
								title: t("customFields.deleteSection"),
								onClick: () => setDeletingSection(sec),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3 w-3" })
							})] })]
						}), fields.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-2 text-xs text-muted-foreground",
							children: t("customFields.sectionEmpty")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.displayName") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.identifier") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.type") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.synchronization") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.readOnly") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.lastModified") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "w-[100px] text-right",
								children: t("common.actions")
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: fields.map(renderRow) })] })]
					}, sectionKey);
				})
			}) })] }),
			attachmentDefs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
				className: "flex-row items-center justify-between gap-3 space-y-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2 text-base",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
						" ",
						t("attachmentDef.sectionTitle")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: t("attachmentDef.sectionHint")
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: attachmentsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }) : attachmentDefs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-6 text-center text-sm text-muted-foreground",
				children: t("attachmentDef.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.displayName") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("customFields.col.identifier") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("attachmentDef.acceptCol") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[100px] text-right",
					children: t("common.actions")
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: attachmentDefs.map((def) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: pickLang(def.display_name) || def.custom_field_name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-mono text-xs text-muted-foreground",
					children: def.custom_field_name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: t(ACCEPT_OPTIONS.find((o) => o.value === (def.attachment_accept ?? "image/*,application/pdf"))?.key ?? "attachmentDef.acceptBoth")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							title: t("common.edit"),
							onClick: () => setAttachmentDialog({
								mode: "edit",
								def
							}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							title: t("common.delete"),
							className: "text-destructive hover:text-destructive",
							onClick: () => setDeletingAttachment(def),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})]
					})
				})
			] }, def.id)) })] }) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomFieldDialog, {
				mode: "create",
				sections: sectionsQuery.data ?? [],
				open: creating,
				onClose: () => setCreating(false),
				onSaved: () => {
					setCreating(false);
					reload();
					reloadSections();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomFieldDialog, {
				mode: "edit",
				field: editing ?? void 0,
				sections: sectionsQuery.data ?? [],
				open: Boolean(editing),
				onClose: () => setEditing(null),
				onSaved: () => {
					setEditing(null);
					reload();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldAttachmentDialog, {
				field: attSettings,
				onClose: () => setAttSettings(null),
				onSaved: () => setAttSettings(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecialFieldsDialog, {
				open: specialOpen,
				onOpenChange: setSpecialOpen,
				fields: (query.data ?? []).filter((f) => !f.isDeleted)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionDialog, {
				mode: "create",
				sections: sectionsQuery.data ?? [],
				open: creatingSection,
				onClose: () => setCreatingSection(false),
				onSaved: () => {
					setCreatingSection(false);
					reloadSections();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionDialog, {
				mode: "edit",
				section: editingSection ?? void 0,
				sections: sectionsQuery.data ?? [],
				open: Boolean(editingSection),
				onClose: () => setEditingSection(null),
				onSaved: () => {
					setEditingSection(null);
					reloadSections();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(deletingSection),
				onOpenChange: (v) => !v && setDeletingSection(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("customFields.confirmDeleteSectionTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("customFields.confirmDeleteSectionDesc", { name: deletingSection?.displayName || deletingSection?.sectionName || "" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: delSection.isPending,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					disabled: delSection.isPending,
					onClick: (e) => {
						e.preventDefault();
						if (deletingSection) delSection.mutate(deletingSection);
					},
					children: delSection.isPending ? t("common.saving") : t("common.delete")
				})] })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(deleting),
				onOpenChange: (v) => !v && setDeleting(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("customFields.confirmDeleteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("customFields.confirmDeleteDesc", { name: deleting?.displayName || deleting?.customFieldName || "" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: del.isPending,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					disabled: del.isPending,
					onClick: (e) => {
						e.preventDefault();
						if (deleting) del.mutate(deleting);
					},
					children: del.isPending ? t("common.saving") : t("common.delete")
				})] })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachmentDefDialog, {
				open: Boolean(attachmentDialog),
				mode: attachmentDialog?.mode ?? "create",
				def: attachmentDialog?.def,
				existingNames: attachmentDefs.map((d) => d.custom_field_name),
				onClose: () => setAttachmentDialog(null),
				onSaved: () => {
					setAttachmentDialog(null);
					reloadAttachments();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(deletingAttachment),
				onOpenChange: (v) => !v && setDeletingAttachment(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("attachmentDef.confirmDeleteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("attachmentDef.confirmDeleteDesc", { name: deletingAttachment && pickLang(deletingAttachment.display_name) || deletingAttachment?.custom_field_name || "" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: delAttachment.isPending,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					disabled: delAttachment.isPending,
					onClick: (e) => {
						e.preventDefault();
						if (deletingAttachment) delAttachment.mutate(deletingAttachment);
					},
					children: delAttachment.isPending ? t("common.saving") : t("common.delete")
				})] })] })
			})
		]
	});
}
/** Criação/edição de um campo de Anexo (local — só do sistema). */
/**
* Configura o ANEXO COMPROBATÓRIO de um campo (complemento): permitir, exigir e
* o tipo de arquivo aceito. Grava os flags na definição (por custom_field_name),
* funcionando para campos do Argus (mirrados) e locais.
*/
function FieldAttachmentDialog({ field, onClose, onSaved }) {
	const { t } = useT();
	const open = Boolean(field);
	const [enabled, setEnabled] = (0, import_react.useState)(false);
	const [required, setRequired] = (0, import_react.useState)(false);
	const [accept, setAccept] = (0, import_react.useState)(ACCEPT_OPTIONS[0].value);
	const current = useQuery({
		queryKey: ["cfd-attachment", field?.customFieldName],
		queryFn: async () => {
			const { data, error } = await supabase.from("custom_field_definitions").select("id, attachment_enabled, attachment_required, attachment_accept").eq("custom_field_name", field.customFieldName).maybeSingle();
			if (error) throw new Error(error.message);
			return data;
		},
		enabled: open && Boolean(field?.customFieldName)
	});
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const d = current.data;
		setEnabled(d?.attachment_enabled ?? false);
		setRequired(d?.attachment_required ?? false);
		setAccept(d?.attachment_accept ?? ACCEPT_OPTIONS[0].value);
	}, [open, current.data]);
	const save = useMutation({
		mutationFn: async () => {
			const patch = {
				attachment_enabled: enabled,
				attachment_required: enabled ? required : false,
				attachment_accept: enabled ? accept : null
			};
			const { data, error } = await supabase.from("custom_field_definitions").update(patch).eq("custom_field_name", field.customFieldName).select("id");
			if (error) throw new Error(error.message);
			if (!data || data.length === 0) {
				const { error: eIns } = await supabase.from("custom_field_definitions").insert({
					custom_field_name: field.customFieldName,
					display_name: field.displayName ? { default: field.displayName } : {},
					custom_field_type: field.customFieldType ?? null,
					...patch
				});
				if (eIns) throw new Error(eIns.message);
			}
		},
		onSuccess: () => {
			toast.success(t("attachmentField.saved"));
			onSaved();
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[460px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("attachmentField.settingsTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("attachmentField.settingsHint", { field: field?.displayName || field?.customFieldName || "" }) })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: enabled,
								onCheckedChange: (c) => setEnabled(Boolean(c))
							}), t("attachmentField.enable")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: cn("flex items-center gap-2 text-sm", !enabled && "opacity-50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: required,
								disabled: !enabled,
								onCheckedChange: (c) => setRequired(Boolean(c))
							}), t("attachmentField.require")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("space-y-2", !enabled && "opacity-50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("attachmentDef.acceptCol") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: accept,
								onValueChange: setAccept,
								disabled: !enabled,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ACCEPT_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: o.value,
									children: t(o.key)
								}, o.value)) })]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => save.mutate(),
					disabled: save.isPending || current.isLoading,
					children: save.isPending ? t("common.saving") : t("common.save")
				})] })
			]
		})
	});
}
function AttachmentDefDialog({ open, mode, def, existingNames, onClose, onSaved }) {
	const { t } = useT();
	const [name, setName] = (0, import_react.useState)("");
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [accept, setAccept] = (0, import_react.useState)(ACCEPT_OPTIONS[0].value);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setName(def?.custom_field_name ?? "");
		setDisplayName(pickLang(def?.display_name) || "");
		setAccept(def?.attachment_accept ?? ACCEPT_OPTIONS[0].value);
	}, [open, def]);
	const cleanName = name.trim().replace(/\s+/g, "_").replace(/[^a-zA-Z0-9_]/g, "");
	const nameTaken = mode === "create" && existingNames.some((n) => n.toLowerCase() === cleanName.toLowerCase());
	const save = useMutation({
		mutationFn: async () => {
			const display_name = { default: displayName.trim() };
			if (mode === "edit") {
				const { error } = await supabase.from("custom_field_definitions").update({
					display_name,
					attachment_accept: accept
				}).eq("id", def.id);
				if (error) throw new Error(error.message);
				return;
			}
			const { error } = await supabase.from("custom_field_definitions").insert({
				custom_field_name: cleanName,
				display_name,
				custom_field_type: ATTACHMENT_FIELD_TYPE,
				is_local: true,
				synchronization_enabled: false,
				attachment_accept: accept
			});
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(mode === "create" ? t("attachmentDef.created") : t("attachmentDef.updated"));
			onSaved();
		},
		onError: (e) => toast.error(e.message)
	});
	const canSave = displayName.trim().length > 0 && (mode === "edit" || cleanName.length > 0 && !nameTaken) && !save.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[480px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: mode === "create" ? t("attachmentDef.newTitle") : t("attachmentDef.editTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("attachmentDef.dialogHint") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "att-name",
									children: t("customFields.col.identifier")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "att-name",
									value: name,
									onChange: (e) => setName(e.target.value),
									disabled: mode === "edit",
									maxLength: FIELD_NAME_MAX,
									placeholder: "ex.: contrato_assinado",
									className: cn(nameTaken && "border-destructive")
								}),
								mode === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: nameTaken ? t("attachmentDef.nameTaken") : cleanName ? `${t("attachmentDef.identifierPreview")}: ${cleanName}` : `${name.length}/${FIELD_NAME_MAX}`
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "att-display",
								children: t("customFields.col.displayName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "att-display",
								value: displayName,
								onChange: (e) => setDisplayName(e.target.value),
								maxLength: DISPLAY_NAME_MAX
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("attachmentDef.acceptCol") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: accept,
								onValueChange: setAccept,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ACCEPT_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: o.value,
									children: t(o.key)
								}, o.value)) })]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => save.mutate(),
					disabled: !canSave,
					children: save.isPending ? t("common.saving") : t("common.save")
				})] })
			]
		})
	});
}
/** Criação/edição de seção. O nome e o storage são imutáveis na edição. */
function SectionDialog({ mode, section, sections, open, onClose, onSaved }) {
	const { t } = useT();
	const activeProfile = useActiveProfile();
	const clientSettings = useClientSettings(activeProfile);
	const [name, setName] = (0, import_react.useState)("");
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [index, setIndex] = (0, import_react.useState)("0");
	const [storage, setStorage] = (0, import_react.useState)("both");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setName(section?.sectionName ?? "");
		setDisplayName(section?.displayName ?? "");
		const next = sections.length ? Math.max(...sections.map((s) => s.index)) + 1 : 0;
		setIndex(String(section?.index ?? next));
		setStorage(mode === "edit" ? section?.storage ?? "both" : clientSettings.data?.defaultCustomFieldStorage ?? "both");
	}, [
		open,
		section,
		sections,
		mode,
		clientSettings.data?.defaultCustomFieldStorage
	]);
	const idxNum = Number.parseInt(index, 10);
	const indexTaken = Number.isFinite(idxNum) && sections.some((s) => s.index === idxNum && s.sectionName !== section?.sectionName);
	const save = useMutation({
		mutationFn: async () => {
			const idx = Number.parseInt(index, 10);
			const safeIdx = Number.isFinite(idx) ? idx : 0;
			const trimmedName = name.trim();
			const trimmedDisplay = displayName.trim();
			const goesToClearId = storage === "clearid" || storage === "both";
			const goesToSupabase = storage === "supabase" || storage === "both";
			if (mode === "edit") {
				if (goesToClearId && section?.eTag !== void 0) await argusApi.updateCustomFieldSection(section.sectionName, {
					displayName: trimmedDisplay,
					index: safeIdx,
					identityCustomFields: section.fields,
					eTag: section.eTag
				});
				if (goesToSupabase) await upsertSupabaseSection({
					profile: activeProfile,
					sectionName: section.sectionName,
					displayName: trimmedDisplay,
					displayIndex: safeIdx,
					storage
				});
				return;
			}
			if (goesToClearId) await argusApi.createCustomFieldSection({
				identityCustomFieldsSectionName: trimmedName,
				displayName: trimmedDisplay,
				index: safeIdx
			});
			if (goesToSupabase) await upsertSupabaseSection({
				profile: activeProfile,
				sectionName: trimmedName,
				displayName: trimmedDisplay,
				displayIndex: safeIdx,
				storage
			});
		},
		onSuccess: () => {
			toast.success(mode === "create" ? t("customFields.sectionCreated") : t("customFields.sectionUpdated"));
			onSaved();
		},
		onError: (e) => toast.error(e.message)
	});
	const canSave = displayName.trim().length > 0 && (mode === "edit" || name.trim().length > 0) && !indexTaken && !save.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[440px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: mode === "create" ? t("customFields.newSection") : t("customFields.editSection") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("customFields.sectionHint") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "sec-name",
									children: t("customFields.sectionIdentifier")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "sec-name",
									value: name,
									onChange: (e) => setName(e.target.value),
									disabled: mode === "edit",
									maxLength: SECTION_NAME_MAX,
									placeholder: "ex.: DocumentosEmpresa"
								}),
								mode === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										name.length,
										"/",
										SECTION_NAME_MAX
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "sec-display",
								children: t("customFields.col.displayName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "sec-display",
								value: displayName,
								onChange: (e) => setDisplayName(e.target.value),
								maxLength: DISPLAY_NAME_MAX
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "sec-index",
									children: t("customFields.sectionIndex")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "sec-index",
									type: "number",
									value: index,
									onChange: (e) => setIndex(e.target.value),
									className: cn(indexTaken && "border-destructive")
								}),
								indexTaken && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-destructive",
									children: t("customFields.sectionIndexTaken")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 border-t pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Armazenar em" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: storage,
									onValueChange: (v) => setStorage(v),
									disabled: mode === "edit",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "clearid",
											children: "ClearID (SaaS)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "supabase",
											children: "Local (Supabase)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "both",
											children: "Ambos"
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Padrão do cliente ",
										activeProfile,
										":",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: clientSettings.data?.defaultCustomFieldStorage ?? "both"
										}),
										". Só configurável na criação."
									]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => save.mutate(),
					disabled: !canSave,
					children: save.isPending ? t("common.saving") : t("common.save")
				})] })
			]
		})
	});
}
/** Criação/edição de campo personalizado. Nome e tipo são imutáveis na edição. */
function CustomFieldDialog({ mode, field, sections, open, onClose, onSaved }) {
	const { t } = useT();
	const activeProfile = useActiveProfile();
	const clientSettings = useClientSettings(activeProfile);
	const [name, setName] = (0, import_react.useState)("");
	const [displayName, setDisplayName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("Text");
	const [isReadOnly, setIsReadOnly] = (0, import_react.useState)(false);
	const [sync, setSync] = (0, import_react.useState)(true);
	const [sectionName, setSectionName] = (0, import_react.useState)("");
	const [storage, setStorage] = (0, import_react.useState)("both");
	const [attEnabled, setAttEnabled] = (0, import_react.useState)(false);
	const [attRequired, setAttRequired] = (0, import_react.useState)(false);
	const [attAccept, setAttAccept] = (0, import_react.useState)(ACCEPT_OPTIONS[0].value);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setName(field?.customFieldName ?? "");
		setDisplayName(field?.displayName ?? "");
		setType(field?.customFieldType ?? "Text");
		setIsReadOnly(Boolean(field?.isReadOnly));
		setSync(field?.synchronizationEnabled ?? true);
		setSectionName("");
		setStorage(mode === "create" ? clientSettings.data?.defaultCustomFieldStorage ?? "both" : "both");
	}, [
		open,
		field,
		mode,
		clientSettings.data?.defaultCustomFieldStorage
	]);
	const attFlags = useQuery({
		queryKey: ["cfd-attachment-flags", field?.customFieldName],
		queryFn: async () => {
			const { data, error } = await supabase.from("custom_field_definitions").select("attachment_enabled, attachment_required, attachment_accept, storage").eq("custom_field_name", field.customFieldName).maybeSingle();
			if (error) throw new Error(error.message);
			return data;
		},
		enabled: open && mode === "edit" && Boolean(field?.customFieldName)
	});
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (mode === "create") {
			setAttEnabled(false);
			setAttRequired(false);
			setAttAccept(ACCEPT_OPTIONS[0].value);
			return;
		}
		const d = attFlags.data;
		setAttEnabled(d?.attachment_enabled ?? false);
		setAttRequired(d?.attachment_required ?? false);
		setAttAccept(d?.attachment_accept ?? ACCEPT_OPTIONS[0].value);
		const s = d?.storage ?? "both";
		setStorage(s === "clearid" || s === "supabase" || s === "both" ? s : "both");
	}, [
		open,
		mode,
		attFlags.data
	]);
	const save = useMutation({
		mutationFn: async () => {
			const attPatch = {
				attachment_enabled: attEnabled,
				attachment_required: attEnabled ? attRequired : false,
				attachment_accept: attEnabled ? attAccept : null
			};
			const goesToClearId = storage === "clearid" || storage === "both";
			if (mode === "edit") {
				if (goesToClearId) await argusApi.updateCustomField(field.customFieldName, {
					displayName: displayName.trim(),
					isReadOnly,
					synchronizationEnabled: sync,
					eTag: field?.eTag ?? null
				});
				const { error } = await supabase.from("custom_field_definitions").update({
					display_name: { default: displayName.trim() },
					is_read_only: isReadOnly,
					synchronization_enabled: sync,
					...attPatch
				}).eq("profile", activeProfile).eq("custom_field_name", field.customFieldName);
				if (error) throw new Error(error.message);
				return null;
			}
			const sec = sections.find((s) => s.sectionName === sectionName);
			if (goesToClearId) {
				await argusApi.createCustomField({
					customFieldName: name.trim(),
					displayName: displayName.trim(),
					customFieldType: type,
					isReadOnly,
					synchronizationEnabled: sync
				});
				if (sec && (sec.storage === "clearid" || sec.storage === "both")) {
					const nextIdx = sec.fields.length ? Math.max(...sec.fields.map((f) => f.index)) + 1 : 0;
					await argusApi.updateCustomFieldSection(sec.sectionName, {
						displayName: sec.displayName,
						index: sec.index,
						identityCustomFields: [...sec.fields, {
							name: name.trim(),
							index: nextIdx
						}],
						eTag: sec.eTag
					});
				}
			}
			const { error } = await supabase.from("custom_field_definitions").upsert({
				profile: activeProfile,
				custom_field_name: name.trim(),
				display_name: { default: displayName.trim() },
				custom_field_type: type,
				is_read_only: isReadOnly,
				synchronization_enabled: sync,
				storage,
				section_name: sec?.sectionName ?? null,
				...attPatch
			}, { onConflict: "profile,custom_field_name" });
			if (error) throw new Error(error.message);
			return null;
		},
		onSuccess: () => {
			toast.success(mode === "create" ? t("customFields.created") : t("customFields.updated"));
			onSaved();
		},
		onError: (e) => toast.error(e.message)
	});
	const compatibleSections = (0, import_react.useMemo)(() => sections.filter((s) => {
		if (storage === "clearid") return s.storage === "clearid" || s.storage === "both";
		if (storage === "supabase") return s.storage === "supabase" || s.storage === "both";
		return s.storage === "both";
	}), [sections, storage]);
	const canSave = displayName.trim().length > 0 && (mode === "edit" || name.trim().length > 0) && (mode === "edit" || sectionName.trim().length > 0) && !save.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-[480px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: mode === "create" ? t("customFields.newField") : t("customFields.editField") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: mode === "create" ? t("customFields.createHint") : t("customFields.editHint") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cf-name",
									children: t("customFields.col.identifier")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "cf-name",
									value: name,
									onChange: (e) => setName(e.target.value),
									disabled: mode === "edit",
									maxLength: FIELD_NAME_MAX,
									placeholder: "ex.: cpf_colaborador"
								}),
								mode === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										name.length,
										"/",
										FIELD_NAME_MAX
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cf-display",
								children: t("customFields.col.displayName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "cf-display",
								value: displayName,
								onChange: (e) => setDisplayName(e.target.value),
								maxLength: DISPLAY_NAME_MAX
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("customFields.col.type") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: type,
								onValueChange: setType,
								disabled: mode === "edit",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: FIELD_TYPES.map((ft) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: ft,
									children: ft
								}, ft)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 border-t pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Armazenar em" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: storage,
									onValueChange: (v) => {
										setStorage(v);
										setSectionName("");
									},
									disabled: mode === "edit",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "clearid",
											children: "ClearID (SaaS)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "supabase",
											children: "Local (Supabase)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "both",
											children: "Ambos"
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Padrão do cliente ",
										activeProfile,
										":",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: clientSettings.data?.defaultCustomFieldStorage ?? "both"
										}),
										". Só configurável na criação — para trocar depois, recrie o campo."
									]
								})
							]
						}),
						mode === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [
									t("customFields.sectionLabel"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: "*"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: sectionName,
									onValueChange: setSectionName,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione uma seção..." }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: compatibleSections.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "px-2 py-3 text-xs text-muted-foreground",
										children: [
											"Nenhuma seção compatível com storage ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: storage
											}),
											". Crie uma seção antes de cadastrar o campo."
										]
									}) : compatibleSections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: s.sectionName,
										children: [s.displayName || s.sectionName, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-2 text-xs text-muted-foreground",
											children: [
												"[",
												s.storage,
												"]"
											]
										})]
									}, s.sectionName)) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"A seção precisa estar compatível com o storage do campo (",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: "clearid"
										}),
										" ↔ clearid/both,",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: "supabase"
										}),
										" ↔ supabase/both,",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: "both"
										}),
										" ↔ both)."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: isReadOnly,
								onCheckedChange: (v) => setIsReadOnly(Boolean(v))
							}), t("customFields.col.readOnly")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: sync,
								onCheckedChange: (v) => setSync(Boolean(v))
							}), t("customFields.col.synchronization")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 border-t pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex cursor-pointer items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: attEnabled,
										onCheckedChange: (v) => setAttEnabled(Boolean(v))
									}), t("attachmentField.enable")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: cn("flex items-center gap-2 text-sm", !attEnabled && "opacity-50"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: attRequired,
										disabled: !attEnabled,
										onCheckedChange: (v) => setAttRequired(Boolean(v))
									}), t("attachmentField.require")]
								}),
								attEnabled && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("attachmentDef.acceptCol") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: attAccept,
										onValueChange: setAttAccept,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ACCEPT_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: o.value,
											children: t(o.key)
										}, o.value)) })]
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => save.mutate(),
					disabled: !canSave,
					children: save.isPending ? t("common.saving") : t("common.save")
				})] })
			]
		})
	});
}
//#endregion
export { CustomFieldsPage as component };
