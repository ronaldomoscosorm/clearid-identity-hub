import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { C as PowerOff, P as LoaderCircle, S as Power, ht as ArrowLeft, lt as Check, m as ShieldCheck, ot as ChevronRight, st as ChevronLeft } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, a as clearIdToFormValues, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { i as saveIdentityCustomFields, n as mirrorIdentities } from "./supabase-mirror--nGFXAER.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./identities._id-DlwPfeR9.mjs";
import { n as updateIdentityAtomic } from "./identity-atomic-DXMsrL_T.mjs";
import { t as saveIdentityAttachments } from "./attachments-PsPmKuGo.mjs";
import { t as IdentityPicturePanel } from "./IdentityPicturePanel-C-xh0PoR.mjs";
import { t as IdentityForm } from "./IdentityForm-DlM5ERWD.mjs";
import { t as CredentialsDialog } from "./CredentialsDialog-Dh7PlQvT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identities._id-n56Oi29-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TeamsDialog({ identityId, siteId }) {
	const { t } = useT();
	const [open, setOpen] = (0, import_react.useState)(false);
	const allQuery = useQuery({
		queryKey: ["teams-all", siteId ?? "default"],
		queryFn: () => argusApi.listTeams({
			take: 1e3,
			siteId
		}),
		enabled: open,
		staleTime: 300 * 1e3
	});
	const assignedQuery = useQuery({
		queryKey: [
			"identity-teams",
			identityId,
			siteId ?? "default"
		],
		queryFn: () => argusApi.getIdentityTeams(identityId, { siteId }),
		enabled: open
	});
	const [assignedIds, setAssignedIds] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [inited, setInited] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) {
			setInited(false);
			return;
		}
		if (!inited && !allQuery.isLoading && !assignedQuery.isLoading) {
			setAssignedIds(new Set((assignedQuery.data ?? []).map((m) => m.teamId)));
			setInited(true);
		}
	}, [
		open,
		inited,
		allQuery.isLoading,
		assignedQuery.isLoading,
		assignedQuery.data
	]);
	const loading = allQuery.isLoading || assignedQuery.isLoading || !inited;
	const nameById = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(allQuery.data ?? []).forEach((tm) => m.set(tm.teamId, tm.name));
		(assignedQuery.data ?? []).forEach((x) => {
			if (!m.has(x.teamId)) m.set(x.teamId, x.teamName ?? x.teamId);
		});
		return m;
	}, [allQuery.data, assignedQuery.data]);
	const catalogIds = (0, import_react.useMemo)(() => (allQuery.data ?? []).map((tm) => tm.teamId), [allQuery.data]);
	const sortRows = (ids) => ids.map((id) => ({
		teamId: id,
		name: nameById.get(id) ?? id
	})).sort((a, b) => a.name.localeCompare(b.name, void 0, { sensitivity: "base" }));
	const available = sortRows(catalogIds.filter((id) => !assignedIds.has(id)));
	const assigned = sortRows([...assignedIds]);
	const [leftSel, setLeftSel] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [rightSel, setRightSel] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [confirmRemove, setConfirmRemove] = (0, import_react.useState)(null);
	const include = useMutation({
		mutationFn: (ids) => Promise.all(ids.map((tid) => argusApi.addTeamMembers(tid, {
			identityIds: [identityId],
			siteId
		}))),
		onSuccess: (_r, ids) => {
			toast.success(t("teams.included", { n: ids.length }));
			setAssignedIds((prev) => /* @__PURE__ */ new Set([...prev, ...ids]));
			setLeftSel(/* @__PURE__ */ new Set());
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: (ids) => Promise.all(ids.map((tid) => argusApi.removeTeamMembers(tid, {
			identityIds: [identityId],
			siteId
		}))),
		onSuccess: (_r, ids) => {
			toast.success(t("teams.removed", { n: ids.length }));
			setAssignedIds((prev) => {
				const next = new Set(prev);
				ids.forEach((id) => next.delete(id));
				return next;
			});
			setRightSel(/* @__PURE__ */ new Set());
		},
		onError: (e) => toast.error(e.message)
	});
	const busy = include.isPending || remove.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: (v) => {
			setOpen(v);
			if (!v) {
				setLeftSel(/* @__PURE__ */ new Set());
				setRightSel(/* @__PURE__ */ new Set());
			}
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mr-1 h-4 w-4" }),
						" ",
						t("teams.button")
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "sm:max-w-[760px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-5 w-5" }),
						" ",
						t("teams.title")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("teams.description") })] }), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2 py-16 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-5 w-5 animate-spin" }),
						" ",
						t("common.loading")
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-stretch gap-3 sm:grid-cols-[1fr_auto_1fr]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListColumn, {
							title: t("teams.available"),
							rows: available,
							selected: leftSel,
							onToggle: (idx) => toggle(setLeftSel, idx),
							searchPlaceholder: t("teams.search"),
							emptyLabel: t("teams.empty"),
							disabled: busy
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-center gap-2 sm:flex-col sm:justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								disabled: leftSel.size === 0 || busy,
								onClick: () => include.mutate([...leftSel]),
								title: t("teams.include"),
								children: include.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: t("teams.include")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								disabled: rightSel.size === 0 || busy,
								onClick: () => setConfirmRemove([...rightSel]),
								title: t("teams.remove"),
								children: remove.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: t("teams.remove")
								})] })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListColumn, {
							title: t("teams.assigned"),
							rows: assigned,
							selected: rightSel,
							onToggle: (idx) => toggle(setRightSel, idx),
							searchPlaceholder: t("teams.search"),
							emptyLabel: t("teams.empty"),
							disabled: busy
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: confirmRemove !== null,
				onOpenChange: (v) => !v && setConfirmRemove(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("teams.confirmRemoveTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("teams.confirmRemoveDesc", { n: confirmRemove?.length ?? 0 }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: remove.isPending,
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					disabled: remove.isPending,
					onClick: (e) => {
						e.preventDefault();
						const ids = confirmRemove ?? [];
						setConfirmRemove(null);
						if (ids.length) remove.mutate(ids);
					},
					children: t("teams.remove")
				})] })] })
			})
		]
	});
}
function toggle(setter, teamId) {
	setter((prev) => {
		const next = new Set(prev);
		if (next.has(teamId)) next.delete(teamId);
		else next.add(teamId);
		return next;
	});
}
function ListColumn({ title, rows, selected, onToggle, searchPlaceholder, emptyLabel, disabled }) {
	const [q, setQ] = (0, import_react.useState)("");
	const filtered = q.trim() ? rows.filter((r) => r.name.toLowerCase().includes(q.trim().toLowerCase())) : rows;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-col rounded-md border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 border-b px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: rows.length
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b p-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: searchPlaceholder,
					className: "h-8"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-64 min-h-[8rem] flex-1 overflow-y-auto p-1",
				children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: emptyLabel
				}) : filtered.map((r) => {
					const isSel = selected.has(r.teamId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled,
						onClick: () => onToggle(r.teamId),
						className: `flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm hover:bg-muted disabled:opacity-50 ${isSel ? "bg-primary/10 ring-1 ring-primary/40" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex h-4 w-4 shrink-0 items-center justify-center rounded border ${isSel ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40"}`,
							children: isSel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: r.name
						})]
					}, r.teamId);
				})
			})
		]
	});
}
function IdentityDetail() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const siteId = useDefaultSiteId();
	const { t } = useT();
	const query = useQuery({
		queryKey: [
			"identity",
			siteId,
			id
		],
		queryFn: () => argusApi.getIdentity(id),
		retry: false
	});
	const sitesQuery = useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	(0, import_react.useEffect)(() => {
		if (query.data) mirrorIdentities([query.data]).catch((err) => console.error("[mirror] falha ao espelhar identidade em cache:", err));
	}, [query.data]);
	const identitySiteId = query.data ? query.data.siteId ?? query.data.companyData?.siteId ?? query.data.systemData?.siteId ?? void 0 : void 0;
	const scopeSiteId = identitySiteId ?? siteId ?? void 0;
	const siteName = identitySiteId ? sitesQuery.data?.find((s) => s.siteId === identitySiteId)?.name : void 0;
	const update = useMutation({
		mutationFn: async (vars) => {
			const originalIdentity = query.data ?? await argusApi.getIdentity(id);
			return updateIdentityAtomic(id, vars.data, {
				companyId: vars.companyId,
				workerTypeId: vars.workerTypeId
			}, originalIdentity);
		},
		onSuccess: async (updated, vars) => {
			const ok = [t("identityDetail.mainData")];
			const fail = [];
			const cf = Object.entries(vars.data.customFields ?? {}).filter(([, v]) => (v ?? "").toString().trim()).map(([customFieldName, customFieldValue]) => ({
				customFieldName,
				customFieldValue: String(customFieldValue)
			}));
			if (cf.length) try {
				await argusApi.patchIdentityCustomFields(id, cf);
				ok.push(t("identityDetail.customFieldsShort"));
			} catch (e) {
				fail.push(t("identityDetail.customFieldsFail", { error: e.message }));
			}
			try {
				const rule = await argusApi.ensureDefaultRule(id);
				if (rule.assigned) ok.push(t("identityDetail.defaultRuleAssigned", { rule: rule.ruleName ?? t("identityDetail.rule") }));
			} catch (e) {
				fail.push(t("identityDetail.defaultRuleFail", { error: e.message }));
			}
			try {
				await argusApi.synchronizeIdentities([id], scopeSiteId);
				ok.push(t("identityDetail.syncShort"));
			} catch (e) {
				fail.push(t("identityDetail.syncFail", { error: e.message }));
			}
			if (fail.length) toast.warning(t("identityDetail.updatePartial", { saved: ok.join(", ") }), {
				description: t("identityDetail.updateFailedDesc", { failed: fail.join("; ") }),
				duration: 12e3
			});
			else toast.success(t("identityDetail.updateSuccess", { saved: ok.join(", ") }));
			mirrorIdentities([updated]).catch((err) => console.error("[mirror] falha pós-update:", err));
			await saveIdentityCustomFields(id, vars.siteFieldValues);
			if (vars.attachments.length) {
				const { failed } = await saveIdentityAttachments(id, vars.attachments);
				if (failed.length) toast.warning(t("attachment.uploadPartial", { n: failed.length }));
				qc.invalidateQueries({ queryKey: ["identity-attachments"] });
				qc.invalidateQueries({ queryKey: ["identity-attachment-presence"] });
			}
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const deactivate = useMutation({
		mutationFn: () => argusApi.deactivateIdentity(id),
		onSuccess: () => {
			toast.success(t("identityDetail.deactivated"));
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const activate = useMutation({
		mutationFn: () => argusApi.activateIdentity(id),
		onSuccess: () => {
			toast.success(t("identityDetail.activated"));
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const isActive = String(query.data?.status ?? "").toLowerCase() === "active";
	const isToggling = deactivate.isPending || activate.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/identities",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 h-4 w-4" }),
						" ",
						t("identityDetail.back")
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-semibold tracking-tight text-foreground",
				children: query.data ? `${query.data.firstName} ${query.data.lastName}` : t("identityDetail.fallbackTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-xs text-muted-foreground",
				children: id
			}),
			identitySiteId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: t("identityDetail.siteLabel")
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: siteName ?? "—" }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[10px] opacity-70",
						children: [
							"(",
							identitySiteId,
							")"
						]
					})
				]
			})
		] }), query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full" })]
		}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
			children: query.error.message
		}) : query.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPicturePanel, { identityId: id })
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityForm, {
			mode: "edit",
			initial: clearIdToFormValues(query.data),
			submitting: update.isPending,
			onSubmit: (data, siteFieldValues, companyId, workerTypeId, _photo, attachments) => {
				const original = query.data;
				update.mutate({
					data: {
						...data,
						identityType: (original.identityType ?? "employee").toLowerCase(),
						eTag: original.eTag,
						systemData: original.systemData ?? void 0
					},
					siteFieldValues,
					companyId,
					workerTypeId,
					attachments
				});
			},
			onCancel: () => navigate({ to: "/identities" }),
			statusBadge: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				"aria-label": isActive ? t("identityDetail.active") : t("identityDetail.inactive"),
				title: isActive ? t("identityDetail.active") : t("identityDetail.inactive"),
				className: `inline-flex items-center gap-1.5 rounded-full border-2 px-2.5 py-1 text-xs font-bold uppercase tracking-wide shadow-sm sm:gap-2 sm:px-3.5 sm:py-1.5 sm:text-sm ${isActive ? "border-green-700 bg-green-600 text-white dark:border-green-400 dark:bg-green-500" : "border-red-700 bg-red-600 text-white dark:border-red-400 dark:bg-red-500"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block h-2 w-2 rounded-full bg-white ring-2 ring-white/40 sm:h-2.5 sm:w-2.5 ${isActive ? "animate-pulse" : ""}` }), isActive ? t("identityDetail.active") : t("identityDetail.inactive")]
			}),
			extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamsDialog, {
					identityId: id,
					siteId: scopeSiteId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialsDialog, { identityId: id }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
					asChild: true,
					children: isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "destructive",
						disabled: isToggling,
						children: [isToggling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerOff, { className: "mr-1 h-4 w-4" }), isToggling ? t("identityDetail.processing") : t("identityDetail.deactivate")]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						disabled: isToggling,
						children: [isToggling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { className: "mr-1 h-4 w-4" }), isToggling ? t("identityDetail.processing") : t("identityDetail.activate")]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: isActive ? t("identityDetail.confirmDeactivateTitle") : t("identityDetail.confirmActivateTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: isActive ? t("identityDetail.confirmDeactivateDesc") : t("identityDetail.confirmActivateDesc") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => isActive ? deactivate.mutate() : activate.mutate(),
					children: isActive ? t("identityDetail.deactivate") : t("identityDetail.activate")
				})] })] })] })
			] })
		})] }) : null]
	});
}
//#endregion
export { IdentityDetail as component };
