import { t as supabase } from "./client-pXxOjxhm.mjs";
import { a as saveBranding, n as applyBranding, r as getBranding } from "./branding-lYWRBKZ3.mjs";
import { c as getConfiguredSiteId, f as setAccountId, l as getSystemObjectId, m as setConfiguredSiteId, o as getAccountId, s as getConfig, u as saveConfig, v as setSystemObjectId } from "./argus-client-fTtea6N-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-settings-DI2-qLO-.js
async function currentUserId() {
	const { data } = await supabase.auth.getUser();
	return data.user?.id ?? null;
}
/** Envia o estado local (config + branding) para a tabela `settings`. */
async function pushSettings() {
	const userId = await currentUserId();
	if (!userId) return;
	const cfg = getConfig();
	const branding = getBranding();
	const row = {
		user_id: userId,
		argus_base_url: cfg.baseUrl,
		argus_api_key: cfg.apiKey || null,
		default_site_id: getConfiguredSiteId() ?? cfg.defaultSiteId ?? null,
		default_site_name: cfg.defaultSiteName ?? null,
		default_rule_id: cfg.defaultRuleId ?? null,
		default_rule_name: cfg.defaultRuleName ?? null,
		link_visitor_to_identity: cfg.linkVisitorToIdentity ?? false,
		system_object_id: getSystemObjectId() ?? null,
		account_id: getAccountId() ?? null,
		client_name: branding.clientName,
		client_logo: branding.clientLogo,
		primary_color: branding.primaryColor,
		accent_color: branding.accentColor
	};
	const { error } = await supabase.from("settings").upsert(row, { onConflict: "user_id" });
	if (error) {
		console.error("[settings] falha ao salvar no Supabase:", error.message);
		throw error;
	}
}
/**
* Carrega a linha de `settings` do usuário e popula o localStorage.
* Usa os setters locais (não reenvia ao Supabase), evitando loop.
*/
async function hydrateSettings() {
	const userId = await currentUserId();
	if (!userId) return;
	const { data, error } = await supabase.from("settings").select("*").eq("user_id", userId).maybeSingle();
	if (error) {
		console.error("[settings] falha ao carregar do Supabase:", error.message);
		return;
	}
	if (!data) return;
	const cfg = getConfig();
	saveConfig({
		...cfg,
		baseUrl: data.argus_base_url ?? cfg.baseUrl,
		apiKey: data.argus_api_key ?? "",
		defaultSiteId: data.default_site_id ?? void 0,
		defaultSiteName: data.default_site_name ?? void 0,
		defaultRuleId: data.default_rule_id ?? void 0,
		defaultRuleName: data.default_rule_name ?? void 0,
		linkVisitorToIdentity: data.link_visitor_to_identity ?? false
	});
	setConfiguredSiteId(data.default_site_id ?? null);
	setSystemObjectId(data.system_object_id ?? null);
	setAccountId(data.account_id ?? null);
	const branding = {
		clientName: data.client_name ?? "",
		clientLogo: data.client_logo ?? "",
		primaryColor: data.primary_color ?? "#1e3a5f",
		accentColor: data.accent_color ?? "#3b6fa0"
	};
	saveBranding(branding);
	applyBranding(branding);
}
//#endregion
export { pushSettings as n, hydrateSettings as t };
