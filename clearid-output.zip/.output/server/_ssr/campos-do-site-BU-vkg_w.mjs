import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { a as typeOf, i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Switch } from "./switch-DtEVXaE2.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { T as Pencil, f as SlidersHorizontal, l as Trash2, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { t as mirrorCustomFieldDefs } from "./supabase-mirror--nGFXAER.mjs";
import { t as Textarea } from "./textarea-DjqHhWkA.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campos-do-site-BU-vkg_w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ALL_WORKER_TYPES = "__ALL__";
var ALL_SECTIONS = "__ALL_SECTIONS__";
var NO_RELATION = "__NONE__";
var EMPTY_FORM = {
	entity_type: "identity",
	section: ALL_SECTIONS,
	definition_id: "",
	selectedIds: [],
	worker_type_id: "",
	is_required: false,
	is_active: true,
	fillable: true,
	related_identity_field_id: NO_RELATION,
	display_index: "",
	override: {
		"pt-BR": "",
		"en-US": "",
		"es-ES": ""
	},
	rangeMin: "",
	rangeMax: "",
	options: ""
};
function maskDate(raw) {
	const d = raw.replace(/\D/g, "").slice(0, 8);
	if (d.length <= 2) return d;
	if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`;
	return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
}
function isoToBr(s) {
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
	return m ? `${m[3]}/${m[2]}/${m[1]}` : s;
}
function langFromJson(v) {
	const o = v && typeof v === "object" ? v : {};
	return {
		"pt-BR": String(o["pt-BR"] ?? ""),
		"en-US": String(o["en-US"] ?? ""),
		"es-ES": String(o["es-ES"] ?? "")
	};
}
function buildOverride(m) {
	const o = {};
	if (m["pt-BR"].trim()) o["pt-BR"] = m["pt-BR"].trim();
	if (m["en-US"].trim()) o["en-US"] = m["en-US"].trim();
	if (m["es-ES"].trim()) o["es-ES"] = m["es-ES"].trim();
	return o;
}
function buildRange(kind, f) {
	if (kind === "number" || kind === "date") {
		const min = f.rangeMin.trim();
		const max = f.rangeMax.trim();
		if (!min && !max) return null;
		return {
			min: min || null,
			max: max || null
		};
	}
	if (kind === "list") {
		const opts = f.options.split("\n").map((s) => s.trim()).filter(Boolean);
		if (!opts.length) return null;
		return { options: opts };
	}
	if (kind === "text") {
		const t = f.rangeMin.trim();
		return t ? { text: t } : null;
	}
	return null;
}
function rangeToForm(v) {
	const o = v && typeof v === "object" ? v : {};
	const opts = Array.isArray(o.options) ? o.options.map(String) : [];
	return {
		rangeMin: isoToBr(o.min != null ? String(o.min) : o.text != null ? String(o.text) : ""),
		rangeMax: isoToBr(o.max == null ? "" : String(o.max)),
		options: opts.join("\n")
	};
}
function CamposDoSitePage() {
	const { t, lang } = useT();
	const siteId = useDefaultSiteId();
	const qc = useQueryClient();
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(EMPTY_FORM);
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const fieldsQuery = useQuery({
		queryKey: ["site-custom-fields", siteId],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_custom_fields").select("*, definition:custom_field_definitions(custom_field_name, custom_field_type, display_name), worker_type:worker_types(name, name_i18n)").eq("site_id", siteId).order("display_index", {
				ascending: true,
				nullsFirst: false
			}).returns();
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		enabled: Boolean(siteId)
	});
	const activeProfile = useActiveProfile();
	const workerTypes = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("is_active", true).eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			});
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	}).data ?? [];
	const sections = useQuery({
		queryKey: ["custom-field-sections"],
		queryFn: () => argusApi.listCustomFieldSections(),
		staleTime: 300 * 1e3
	}).data ?? [];
	const sectionByField = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const sec of sections) for (const f of sec.fields) m.set(f.name, sec.displayName || sec.sectionName);
		return m;
	}, [sections]);
	const sectionFieldNames = (0, import_react.useMemo)(() => {
		if (!form.section || form.section === ALL_SECTIONS) return null;
		const sec = sections.find((s) => s.sectionName === form.section);
		return new Set((sec?.fields ?? []).map((f) => f.name));
	}, [sections, form.section]);
	const defsQuery = useQuery({
		queryKey: ["custom-field-definitions", siteId],
		queryFn: async () => {
			try {
				await mirrorCustomFieldDefs((await argusApi.listCustomFields()).filter((d) => !d.isDeleted));
			} catch {}
			const { data, error } = await supabase.from("custom_field_definitions").select("*").eq("is_deleted", false).order("custom_field_name", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const usedIdsForScope = (0, import_react.useMemo)(() => new Set((fieldsQuery.data ?? []).filter((f) => f.entity_type === form.entity_type && (form.entity_type === "company" || f.worker_type_id === form.worker_type_id)).map((f) => f.definition_id)), [
		fieldsQuery.data,
		form.entity_type,
		form.worker_type_id
	]);
	const availableDefs = (0, import_react.useMemo)(() => (defsQuery.data ?? []).filter((d) => editing?.definition_id === d.id || !usedIdsForScope.has(d.id) && (!sectionFieldNames || sectionFieldNames.has(d.custom_field_name)) && !(form.entity_type === "company" && typeOf(d.custom_field_type) === "attachment")), [
		defsQuery.data,
		usedIdsForScope,
		editing,
		sectionFieldNames,
		form.entity_type
	]);
	const defsById = (0, import_react.useMemo)(() => new Map((defsQuery.data ?? []).map((d) => [d.id, d])), [defsQuery.data]);
	const availableBySection = (0, import_react.useMemo)(() => {
		const groups = /* @__PURE__ */ new Map();
		for (const d of availableDefs) {
			const key = sectionByField.get(d.custom_field_name) ?? t("siteFields.otherSection");
			if (!groups.has(key)) groups.set(key, []);
			groups.get(key).push(d);
		}
		return [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "pt-BR", { sensitivity: "base" }));
	}, [
		availableDefs,
		sectionByField,
		t
	]);
	const kind = typeOf((0, import_react.useMemo)(() => (defsQuery.data ?? []).find((d) => d.id === form.definition_id) ?? null, [defsQuery.data, form.definition_id])?.custom_field_type);
	const upsert = useMutation({
		mutationFn: async (f) => {
			const common = {
				site_id: siteId,
				entity_type: f.entity_type,
				is_required: f.is_required,
				is_active: f.is_active,
				fillable: f.entity_type === "identity" ? f.fillable : true,
				related_identity_field_id: f.entity_type === "company" && f.related_identity_field_id !== NO_RELATION ? f.related_identity_field_id : null,
				display_index: f.display_index.trim() ? Number(f.display_index) : null
			};
			if (editing) {
				const { error } = await supabase.from("site_custom_fields").update({
					...common,
					definition_id: f.definition_id,
					worker_type_id: f.entity_type === "identity" ? f.worker_type_id : null,
					display_name_override: buildOverride(f.override),
					value_range: buildRange(kind, f)
				}).eq("id", editing.id);
				if (error) throw new Error(error.message);
				return;
			}
			const workerTypeIds = f.entity_type === "company" ? [null] : f.worker_type_id === ALL_WORKER_TYPES ? workerTypes.map((w) => w.id) : [f.worker_type_id];
			const existing = new Set((fieldsQuery.data ?? []).filter((r) => r.entity_type === f.entity_type).map((r) => `${r.definition_id}|${r.worker_type_id ?? ""}`));
			const rows = [];
			for (const defId of f.selectedIds) {
				const def = defsById.get(defId);
				for (const wt of workerTypeIds) {
					if (existing.has(`${defId}|${wt ?? ""}`)) continue;
					rows.push({
						...common,
						definition_id: defId,
						worker_type_id: wt,
						display_name_override: def?.display_name ?? {},
						value_range: null
					});
				}
			}
			if (!rows.length) return;
			const { error } = await supabase.from("site_custom_fields").insert(rows);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(editing ? t("siteFields.toast.updated") : t("siteFields.toast.added"));
			qc.invalidateQueries({ queryKey: ["site-custom-fields", siteId] });
			setDialogOpen(false);
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("site_custom_fields").delete().eq("id", id);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("siteFields.toast.removed"));
			qc.invalidateQueries({ queryKey: ["site-custom-fields", siteId] });
			setToDelete(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const openCreate = () => {
		setEditing(null);
		setForm(EMPTY_FORM);
		setDialogOpen(true);
	};
	const openEdit = (row) => {
		setEditing(row);
		setForm({
			entity_type: row.entity_type,
			section: ALL_SECTIONS,
			definition_id: row.definition_id,
			selectedIds: [],
			worker_type_id: row.worker_type_id ?? "",
			is_required: row.is_required,
			fillable: row.fillable,
			related_identity_field_id: row.related_identity_field_id ?? NO_RELATION,
			is_active: row.is_active,
			display_index: row.display_index == null ? "" : String(row.display_index),
			override: langFromJson(row.display_name_override),
			...rangeToForm(row.value_range)
		});
		setDialogOpen(true);
	};
	const submit = () => {
		if (form.entity_type === "identity" && !form.worker_type_id) {
			toast.error(t("siteFields.validation.workerType"));
			return;
		}
		if (editing ? !form.definition_id : form.selectedIds.length === 0) {
			toast.error(t("siteFields.validation.field"));
			return;
		}
		upsert.mutate(form);
	};
	const toggleSelected = (id) => setForm((f) => ({
		...f,
		selectedIds: f.selectedIds.includes(id) ? f.selectedIds.filter((x) => x !== id) : [...f.selectedIds, id]
	}));
	const toggleGroup = (ids, all) => setForm((f) => ({
		...f,
		selectedIds: all ? f.selectedIds.filter((x) => !ids.includes(x)) : [.../* @__PURE__ */ new Set([...f.selectedIds, ...ids])]
	}));
	const items = fieldsQuery.data ?? [];
	const groupedItems = (0, import_react.useMemo)(() => {
		const groups = /* @__PURE__ */ new Map();
		for (const row of items) {
			const key = sectionByField.get(row.definition?.custom_field_name ?? "") ?? t("siteFields.otherSection");
			if (!groups.has(key)) groups.set(key, []);
			groups.get(key).push(row);
		}
		const arr = [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0], "pt-BR", { sensitivity: "base" }));
		for (const [, rows] of arr) rows.sort((a, b) => (a.definition?.custom_field_name ?? "").localeCompare(b.definition?.custom_field_name ?? "", "pt-BR", { sensitivity: "base" }));
		return arr;
	}, [
		items,
		sectionByField,
		t
	]);
	const renderRow = (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "font-medium",
			children: row.definition?.custom_field_name ?? "—"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: row.entity_type === "company" ? "default" : "secondary",
			children: row.entity_type === "company" ? t("siteFields.entity.company") : t("siteFields.entity.identity")
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "outline",
			children: pickLang(row.worker_type?.name_i18n, lang) || row.worker_type?.name || "—"
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-muted-foreground",
			children: row.definition?.custom_field_type ?? "—"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-muted-foreground",
			children: langFromJson(row.display_name_override)["pt-BR"] || "—"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: row.is_required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t("common.yes") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: t("common.no")
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: row.is_active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: t("common.yes")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "outline",
			children: t("common.no")
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-right",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					onClick: () => openEdit(row),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "text-destructive hover:text-destructive",
					onClick: () => setToDelete(row),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			})
		})
	] }, row.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: t("siteFields.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("siteFields.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => fieldsQuery.refetch(),
						disabled: fieldsQuery.isFetching || !siteId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${fieldsQuery.isFetching ? "animate-spin" : ""}` }), t("siteFields.refresh")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: openCreate,
						disabled: !siteId,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("siteFields.addButton")
						]
					})]
				})]
			}),
			!siteId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: [
					t("siteFields.noSite.prefix"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: t("siteFields.noSite.settings")
					}),
					" ",
					t("siteFields.noSite.suffix")
				]
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: fieldsQuery.data ? items.length === 1 ? t("siteFields.countOne", { count: items.length }) : t("siteFields.countOther", { count: items.length }) : t("siteFields.countLabel")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: fieldsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
			}) : fieldsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: fieldsQuery.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("siteFields.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: groupedItems.map(([section, rows]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-foreground",
						children: section
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.field") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.entity") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.worker") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.type") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.display") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.required") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("siteFields.col.active") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
							className: "w-[100px] text-right",
							children: t("common.actions")
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map(renderRow) })] })]
				}, section))
			}) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: setDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[560px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-5 w-5" }), editing ? t("siteFields.dialog.editTitle") : t("siteFields.dialog.addTitle")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("siteFields.dialog.description") })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.entity") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.entity_type,
										onValueChange: (v) => setForm((f) => ({
											...f,
											entity_type: v,
											worker_type_id: "",
											definition_id: ""
										})),
										disabled: Boolean(editing),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "identity",
											children: t("siteFields.entity.identity")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "company",
											children: t("siteFields.entity.company")
										})] })]
									})]
								}),
								form.entity_type === "identity" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.workerType") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.worker_type_id,
										onValueChange: (v) => setForm((f) => ({
											...f,
											worker_type_id: v,
											definition_id: ""
										})),
										disabled: Boolean(editing),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("siteFields.form.workerTypePlaceholder") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: ALL_WORKER_TYPES,
											children: t("siteFields.form.allWorkerTypes")
										}), workerTypes.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: w.id,
											children: pickLang(w.name_i18n, lang) || w.name
										}, w.id))] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.section") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.section,
										onValueChange: (v) => setForm((f) => ({
											...f,
											section: v,
											definition_id: ""
										})),
										disabled: Boolean(editing),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("siteFields.form.allSections") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: ALL_SECTIONS,
											children: t("siteFields.form.allSections")
										}), [...sections].sort((a, b) => (a.displayName || a.sectionName).localeCompare(b.displayName || b.sectionName, "pt-BR", { sensitivity: "base" })).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: s.sectionName,
											children: s.displayName || s.sectionName
										}, s.sectionName))] })]
									})]
								}),
								editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.col.field") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: form.definition_id,
										onValueChange: () => {},
										disabled: true,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("siteFields.form.fieldPlaceholder") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: availableDefs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
											value: d.id,
											children: [pickLang(d.display_name) || d.custom_field_name, d.custom_field_type ? ` · ${d.custom_field_type}` : ""]
										}, d.id)) })]
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [
										t("siteFields.form.fields"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												"(",
												form.selectedIds.length,
												")"
											]
										})
									] }), form.entity_type === "identity" && !form.worker_type_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: t("siteFields.form.selectWorkerFirst")
									}) : defsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: t("siteFields.form.loadingFields")
									}) : availableBySection.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: t("siteFields.form.noFieldsAvailable")
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "max-h-64 space-y-3 overflow-y-auto rounded-md border p-3",
										children: availableBySection.map(([section, defs]) => {
											const ids = defs.map((d) => d.id);
											const allSelected = ids.every((id) => form.selectedIds.includes(id));
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "flex cursor-pointer items-center gap-2 text-sm font-medium",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
														checked: allSelected,
														onCheckedChange: () => toggleGroup(ids, allSelected)
													}), section]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "ml-6 space-y-1",
													children: defs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "flex cursor-pointer items-center gap-2 text-sm",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
																checked: form.selectedIds.includes(d.id),
																onCheckedChange: () => toggleSelected(d.id)
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pickLang(d.display_name) || d.custom_field_name }),
															d.custom_field_type && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-xs text-muted-foreground",
																children: ["· ", d.custom_field_type]
															})
														]
													}, d.id))
												})]
											}, section);
										})
									})]
								}),
								editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.displayName") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.override["pt-BR"],
												onChange: (e) => setForm((f) => ({
													...f,
													override: {
														...f.override,
														"pt-BR": e.target.value
													}
												})),
												placeholder: t("siteFields.form.ptDefault")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.override["en-US"],
												onChange: (e) => setForm((f) => ({
													...f,
													override: {
														...f.override,
														"en-US": e.target.value
													}
												})),
												placeholder: "en-US"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.override["es-ES"],
												onChange: (e) => setForm((f) => ({
													...f,
													override: {
														...f.override,
														"es-ES": e.target.value
													}
												})),
												placeholder: "es-ES"
											})
										]
									})]
								}), kind === "number" || kind === "date" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.minValue") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: kind === "date" ? "text" : "number",
											inputMode: kind === "date" ? "numeric" : void 0,
											placeholder: kind === "date" ? "dd/MM/yyyy" : void 0,
											value: form.rangeMin,
											onChange: (e) => setForm((f) => ({
												...f,
												rangeMin: kind === "date" ? maskDate(e.target.value) : e.target.value
											}))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.maxValue") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: kind === "date" ? "text" : "number",
											inputMode: kind === "date" ? "numeric" : void 0,
											placeholder: kind === "date" ? "dd/MM/yyyy" : void 0,
											value: form.rangeMax,
											onChange: (e) => setForm((f) => ({
												...f,
												rangeMax: kind === "date" ? maskDate(e.target.value) : e.target.value
											}))
										})]
									})]
								}) : kind === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.options") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: form.options,
										onChange: (e) => setForm((f) => ({
											...f,
											options: e.target.value
										})),
										rows: 4,
										placeholder: t("siteFields.form.optionsPlaceholder")
									})]
								}) : kind === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.defaultValue") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: form.rangeMin,
										onChange: (e) => setForm((f) => ({
											...f,
											rangeMin: e.target.value
										})),
										placeholder: t("siteFields.form.defaultValuePlaceholder")
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: t("siteFields.form.rangeNotApplicable")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 items-end gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.order") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "number",
												value: form.display_index,
												onChange: (e) => setForm((f) => ({
													...f,
													display_index: e.target.value
												})),
												placeholder: "0"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: form.is_required,
												onCheckedChange: (v) => setForm((f) => ({
													...f,
													is_required: v
												}))
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "cursor-pointer",
												children: t("siteFields.form.required")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: form.is_active,
												onCheckedChange: (v) => setForm((f) => ({
													...f,
													is_active: v
												}))
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "cursor-pointer",
												children: t("siteFields.form.active")
											})]
										})
									]
								}),
								form.entity_type === "identity" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: form.fillable,
										onCheckedChange: (v) => setForm((f) => ({
											...f,
											fillable: v
										}))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "cursor-pointer",
										children: t("siteFields.form.fillable")
									})]
								}),
								form.entity_type === "company" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("siteFields.form.relatedField") }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: form.related_identity_field_id,
											onValueChange: (v) => setForm((f) => ({
												...f,
												related_identity_field_id: v
											})),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("siteFields.form.none") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: NO_RELATION,
												children: t("siteFields.form.none")
											}), (fieldsQuery.data ?? []).filter((r) => r.entity_type === "identity").map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
												value: r.id,
												children: [r.definition?.custom_field_name ?? "—", r.worker_type ? ` · ${pickLang(r.worker_type.name_i18n, lang) || r.worker_type.name}` : ""]
											}, r.id))] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: t("siteFields.form.relatedFieldHint")
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDialogOpen(false),
							children: t("common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: submit,
							disabled: upsert.isPending,
							children: upsert.isPending ? t("common.saving") : t("common.save")
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(toDelete),
				onOpenChange: (o) => !o && setToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("siteFields.delete.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					t("siteFields.delete.prefix"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: toDelete?.definition?.custom_field_name
					}),
					" ",
					t("siteFields.delete.suffix")
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					onClick: () => toDelete && remove.mutate(toDelete.id),
					disabled: remove.isPending,
					children: remove.isPending ? t("siteFields.delete.removing") : t("common.remove")
				})] })] })
			})
		]
	});
}
//#endregion
export { CamposDoSitePage as component };
