import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { y as ScanFace } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CameraGuide-4uqiXU09.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var detectorPromise = null;
async function load() {
	try {
		const [tf, blazeface] = await Promise.all([import("../_libs/@tensorflow/tfjs+[...].mjs").then((n) => n.t), import("../_libs/@tensorflow-models/blazeface.mjs").then((n) => n.t)]);
		await tf.ready();
		const model = await blazeface.load();
		return { detect: async (video) => {
			if (!video || video.readyState < 2 || !video.videoWidth) return false;
			return (await model.estimateFaces(video, false)).length > 0;
		} };
	} catch {
		return null;
	}
}
/** Carrega (uma vez) e retorna o detector, ou `null` se indisponível. */
function loadFaceDetector() {
	if (!detectorPromise) detectorPromise = load();
	return detectorPromise;
}
/**
* Silhueta-guia (cabeça + ombros) desenhada sobre o vídeo da câmera. Escurece a
* área externa ao busto e destaca o contorno; a cor reflete o estado da detecção
* de pessoa (neutro quando indisponível, verde com pessoa, âmbar sem pessoa).
*/
function SilhouetteGuide({ state }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "pointer-events-none absolute inset-0 h-full w-full",
		viewBox: "0 0 160 90",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mask", {
				id: "rm-bust-mask",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "160",
						height: "90",
						fill: "white"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "80",
						cy: "33",
						rx: "15",
						ry: "19",
						fill: "black"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M53 90 C53 68 64 60 80 60 C96 60 107 68 107 90 Z",
						fill: "black"
					})
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "160",
				height: "90",
				fill: "rgba(0,0,0,0.45)",
				mask: "url(#rm-bust-mask)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "none",
				stroke: state === "ok" ? "#34d399" : state === "warn" ? "#fbbf24" : "rgba(255,255,255,0.75)",
				strokeWidth: "0.7",
				strokeDasharray: "2.5 2",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "80",
					cy: "33",
					rx: "15",
					ry: "19"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M53 90 C53 68 64 60 80 60 C96 60 107 68 107 90" })]
			})
		]
	});
}
/**
* Detecção de pessoa no vídeo. Retorna `null` enquanto indisponível/carregando
* (silhueta como guia), `true`/`false` conforme houver rosto enquadrado.
*/
function usePersonDetection(videoRef, active) {
	const [detected, setDetected] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!active) {
			setDetected(null);
			return;
		}
		let cancelled = false;
		let timer = null;
		loadFaceDetector().then((det) => {
			if (!det || cancelled) return;
			timer = window.setInterval(async () => {
				const v = videoRef.current;
				if (!v) return;
				try {
					const ok = await det.detect(v);
					if (!cancelled) setDetected(ok);
				} catch {}
			}, 400);
		});
		return () => {
			cancelled = true;
			if (timer) clearInterval(timer);
			setDetected(null);
		};
	}, [active, videoRef]);
	return detected;
}
/** Chip de status ("Pessoa detectada" / "Nenhuma pessoa detectada"). */
function PersonBadge({ detected }) {
	const { t } = useT();
	if (detected === null) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute left-1/2 top-2 flex -translate-x-1/2 items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium text-white backdrop-blur " + (detected ? "bg-emerald-500/85" : "bg-amber-500/85"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanFace, { className: "h-3.5 w-3.5" }), detected ? t("picturePanel.person.detected") : t("picturePanel.person.notDetected")]
	});
}
//#endregion
export { SilhouetteGuide as n, usePersonDetection as r, PersonBadge as t };
