import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { C as PowerOff, S as Power, ht as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, a as clearIdToFormValues, d as serializeCustomFieldsForPatch, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as IdentityPicturePanel } from "./IdentityPicturePanel-C-xh0PoR.mjs";
import { t as IdentityForm } from "./IdentityForm-DlM5ERWD.mjs";
import { t as CredentialsDialog } from "./CredentialsDialog-Dh7PlQvT.mjs";
import { t as Route } from "./terceirizados._id-D2ukSORI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terceirizados._id-DoGzUoCO.js
var import_jsx_runtime = require_jsx_runtime();
function IdentityDetail() {
	const { t } = useT();
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const siteId = useDefaultSiteId();
	const query = useQuery({
		queryKey: [
			"identity",
			siteId,
			id
		],
		queryFn: () => argusApi.getIdentity(id),
		retry: false
	});
	const sitesQuery = useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	const credentialsQuery = useQuery({
		queryKey: ["credentials", id],
		queryFn: () => argusApi.listCredentials(id)
	});
	const identitySiteId = query.data ? query.data.siteId ?? query.data.companyData?.siteId ?? query.data.systemData?.siteId ?? void 0 : void 0;
	const scopeSiteId = identitySiteId ?? siteId ?? void 0;
	const siteName = identitySiteId ? sitesQuery.data?.find((s) => s.siteId === identitySiteId)?.name : void 0;
	const update = useMutation({
		mutationFn: async (data) => {
			const { customFields, ...general } = data;
			await argusApi.updateIdentity(id, {
				...general,
				customFields: void 0
			});
			if (customFields) {
				const patch = serializeCustomFieldsForPatch((await argusApi.listCustomFields()).filter((f) => !f.isDeleted && f.customFieldName.startsWith("Vylor_")), customFields, query.data?.systemData?.customFields ?? null);
				if (patch.length > 0) await argusApi.patchIdentityCustomFields(id, patch);
			}
		},
		onSuccess: async () => {
			try {
				await argusApi.synchronizeIdentities([id], scopeSiteId);
				toast.success(t("contractorDetail.toast.updated"));
			} catch (e) {
				toast.warning(t("contractorDetail.toast.updatedNoSync"), { description: e.message });
			}
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const deactivate = useMutation({
		mutationFn: () => argusApi.deactivateIdentity(id),
		onSuccess: () => {
			toast.success(t("contractorDetail.toast.deactivated"));
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const activate = useMutation({
		mutationFn: () => argusApi.activateIdentity(id),
		onSuccess: () => {
			toast.success(t("contractorDetail.toast.activated"));
			qc.invalidateQueries({ queryKey: ["identities"] });
			qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				id
			] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const isActive = String(query.data?.status ?? "").toLowerCase() === "active";
	const activationDate = (() => {
		const dates = (credentialsQuery.data ?? []).map((c) => c.activationDateUtc).filter((d) => !!d).map((d) => new Date(d).getTime()).filter((t) => !Number.isNaN(t));
		if (dates.length === 0) return null;
		return new Date(Math.min(...dates)).toISOString();
	})();
	const fmtDate = (v) => {
		if (!v) return "—";
		const d = new Date(v);
		if (Number.isNaN(d.getTime())) return v;
		return d.toLocaleDateString("pt-BR");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/terceirizados",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 h-4 w-4" }),
						" ",
						t("contractorDetail.back")
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-semibold tracking-tight text-foreground",
				children: query.data ? `${query.data.firstName} ${query.data.lastName}` : t("contractorDetail.identity")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-xs text-muted-foreground",
				children: id
			}),
			identitySiteId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: t("contractorDetail.siteLabel")
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: siteName ?? "—" }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[10px] opacity-70",
						children: [
							"(",
							identitySiteId,
							")"
						]
					})
				]
			}),
			activationDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: t("contractorDetail.activationDateLabel")
					}),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtDate(activationDate) })
				]
			})
		] }), query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full" })]
		}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
			children: query.error.message
		}) : query.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPicturePanel, { identityId: id })
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityForm, {
			mode: "edit",
			showCustomFields: true,
			initial: clearIdToFormValues(query.data),
			submitting: update.isPending,
			onSubmit: (data) => {
				const original = query.data;
				update.mutate({
					...data,
					identityType: (original.identityType ?? "employee").toLowerCase(),
					eTag: original.eTag,
					description: original.description ?? void 0,
					countryCode: original.countryCode ?? void 0,
					culture: original.culture ?? void 0,
					middleName: original.middleName ?? void 0,
					displayName: original.displayName ?? void 0,
					privateData: original.privateData ?? void 0,
					companyData: original.companyData ?? void 0,
					systemData: original.systemData ?? void 0
				});
			},
			onCancel: () => navigate({ to: "/terceirizados" }),
			statusBadge: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				"aria-label": isActive ? t("contractorDetail.active") : t("contractorDetail.inactive"),
				title: isActive ? t("contractorDetail.active") : t("contractorDetail.inactive"),
				className: `inline-flex items-center gap-1.5 rounded-full border-2 px-2.5 py-1 text-xs font-bold uppercase tracking-wide shadow-sm sm:gap-2 sm:px-3.5 sm:py-1.5 sm:text-sm ${isActive ? "border-green-700 bg-green-600 text-white dark:border-green-400 dark:bg-green-500" : "border-red-700 bg-red-600 text-white dark:border-red-400 dark:bg-red-500"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block h-2 w-2 rounded-full bg-white ring-2 ring-white/40 sm:h-2.5 sm:w-2.5 ${isActive ? "animate-pulse" : ""}` }), isActive ? t("contractorDetail.active") : t("contractorDetail.inactive")]
			}),
			extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialsDialog, { identityId: id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
				asChild: true,
				children: isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerOff, { className: "mr-1 h-4 w-4" }),
						" ",
						t("contractorDetail.deactivate")
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "secondary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { className: "mr-1 h-4 w-4" }),
						" ",
						t("contractorDetail.activate")
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: isActive ? t("contractorDetail.deactivateConfirmTitle") : t("contractorDetail.activateConfirmTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: isActive ? t("contractorDetail.deactivateConfirmDesc") : t("contractorDetail.activateConfirmDesc") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				onClick: () => isActive ? deactivate.mutate() : activate.mutate(),
				children: isActive ? t("contractorDetail.deactivate") : t("contractorDetail.activate")
			})] })] })] })] })
		})] }) : null]
	});
}
//#endregion
export { IdentityDetail as component };
