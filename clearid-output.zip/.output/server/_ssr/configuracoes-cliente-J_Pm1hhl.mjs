import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-C5Nmk_bj.mjs";
import { _ as Settings2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { n as useUpdateClientSettings, t as useClientSettings } from "./client-settings-DnLX0jMS.mjs";
import { n as useCurrentUser, t as isAdmin } from "./current-user-BxaXazZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/configuracoes-cliente-J_Pm1hhl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClientSettingsPage() {
	const activeProfile = useActiveProfile();
	const admin = isAdmin(useCurrentUser().data ?? null);
	const query = useClientSettings(activeProfile);
	const update = useUpdateClientSettings();
	const [storage, setStorage] = (0, import_react.useState)("both");
	(0, import_react.useEffect)(() => {
		if (query.data) setStorage(query.data.defaultCustomFieldStorage);
	}, [query.data]);
	const dirty = query.data ? storage !== query.data.defaultCustomFieldStorage : false;
	const submit = () => {
		update.mutate({
			profile: activeProfile,
			defaultCustomFieldStorage: storage
		}, {
			onSuccess: () => toast.success("Configurações salvas."),
			onError: (e) => toast.error(e.message)
		});
	};
	if (!admin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight text-foreground",
			children: "Configurações do cliente"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Acesso restrito ao perfil Administrador."
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-start justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: "Configurações do cliente"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full border px-2 py-0.5 text-xs font-medium text-muted-foreground",
					children: ["Cliente: ", activeProfile]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Padrões aplicados a todos os usuários deste cliente."
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
			className: "flex items-center gap-2 text-base",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "h-4 w-4" }), "Campos personalizados"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Define onde novas definições de campo personalizado são gravadas por padrão. O usuário ainda pode escolher outro local em cada campo, no dialog de criação." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Armazenamento padrão" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: storage,
						onValueChange: (v) => setStorage(v),
						disabled: query.isLoading || update.isPending,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "clearid",
								children: "ClearID (SaaS)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "supabase",
								children: "Local (Supabase)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "both",
								children: "Ambos"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "ClearID:" }),
							" a definição e o valor por identidade ficam no Genetec.",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Local:" }),
							" só no Supabase (não trafega no PIAM).",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Ambos:" }),
							" criado nos dois — ClearID é fonte da verdade."
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: submit,
					disabled: !dirty || update.isPending,
					children: update.isPending ? "Salvando..." : "Salvar"
				})
			})]
		})] })]
	});
}
//#endregion
export { ClientSettingsPage as component };
