import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { P as LoaderCircle, R as Image, rt as CircleCheck, s as Upload, tt as CircleX, ut as Camera } from "../_libs/lucide-react.mjs";
import { o as useApplyBranding, s as useBranding } from "./branding-lYWRBKZ3.mjs";
import { t as hydrateSettings } from "./supabase-settings-DI2-qLO-.mjs";
import { t as PoweredBy } from "./PoweredBy-CRi75zGX.mjs";
import { n as ensureTechnicalSession, t as Route } from "./foto._token-BdRRslOk.mjs";
import { n as SilhouetteGuide, r as usePersonDetection, t as PersonBadge } from "./CameraGuide-4uqiXU09.mjs";
import { d as format, t as ptBR } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/foto._token-U_rgpJ3a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API_BASE = "https://argusclearidapi.rmtecho.com.br".replace(/\/+$/, "");
async function parse$1(res, fallback) {
	const body = await res.json().catch(() => null);
	if (res.ok && body && body.data != null) return {
		ok: true,
		data: body.data
	};
	return {
		ok: false,
		status: res.status,
		message: body?.message ?? fallback
	};
}
/** Valida o link e retorna os dados da identidade. */
async function getPhotoInfo(token) {
	try {
		return parse$1(await fetch(`${API_BASE}/api/photo-update/${encodeURIComponent(token)}`, { headers: { accept: "application/json" } }), "Link inválido.");
	} catch (e) {
		return {
			ok: false,
			status: 0,
			message: e.message
		};
	}
}
/** Envia a nova foto (multipart, campo "picture"). */
async function submitPhoto(token, file) {
	try {
		const form = new FormData();
		form.append("picture", file);
		return parse$1(await fetch(`${API_BASE}/api/photo-update/${encodeURIComponent(token)}`, {
			method: "POST",
			body: form
		}), "Falha ao enviar a foto.");
	} catch (e) {
		return {
			ok: false,
			status: 0,
			message: e.message
		};
	}
}
var MAX_MB = 8;
function PhotoUpdatePage() {
	const { token } = Route.useParams();
	useApplyBranding();
	const branding = useBranding();
	const [state, setState] = (0, import_react.useState)({ kind: "loading" });
	const [file, setFile] = (0, import_react.useState)(null);
	const [previewUrl, setPreviewUrl] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [cameraOn, setCameraOn] = (0, import_react.useState)(false);
	const inputRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const personDetected = usePersonDetection(videoRef, cameraOn);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getPhotoInfo(token).then((r) => {
			if (cancelled) return;
			if (r.ok) setState({
				kind: "form",
				info: r.data
			});
			else setState({
				kind: "unavailable",
				message: r.message
			});
		});
		return () => {
			cancelled = true;
		};
	}, [token]);
	(0, import_react.useEffect)(() => {
		ensureTechnicalSession().then((ok) => ok ? hydrateSettings() : void 0).catch(() => {});
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (previewUrl) URL.revokeObjectURL(previewUrl);
		};
	}, [previewUrl]);
	(0, import_react.useEffect)(() => stopCamera, []);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!cameraOn || !video || !streamRef.current) return;
		video.srcObject = streamRef.current;
		const tryPlay = () => video.play().catch(() => {});
		if (video.readyState >= 1) tryPlay();
		else video.onloadedmetadata = tryPlay;
		return () => {
			video.onloadedmetadata = null;
		};
	}, [cameraOn]);
	function stopCamera() {
		streamRef.current?.getTracks().forEach((t) => t.stop());
		streamRef.current = null;
		setCameraOn(false);
	}
	const setImage = (f) => {
		if (previewUrl) URL.revokeObjectURL(previewUrl);
		setFile(f);
		setPreviewUrl(URL.createObjectURL(f));
	};
	const pickFile = (f) => {
		setError(null);
		if (!f) return;
		if (!f.type.startsWith("image/")) {
			setError("Selecione um arquivo de imagem.");
			return;
		}
		if (f.size > MAX_MB * 1024 * 1024) {
			setError(`A imagem deve ter no máximo ${MAX_MB} MB.`);
			return;
		}
		setImage(f);
	};
	async function startCamera() {
		setError(null);
		if (!navigator.mediaDevices?.getUserMedia) {
			setError("Câmera não disponível neste dispositivo/navegador.");
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: {
					facingMode: "user",
					width: { ideal: 1280 },
					height: { ideal: 1280 }
				},
				audio: false
			});
			streamRef.current = stream;
			setCameraOn(true);
		} catch {
			setError("Não foi possível acessar a câmera. Verifique a permissão do navegador.");
		}
	}
	function capturePhoto() {
		const video = videoRef.current;
		if (!video || !video.videoWidth) return;
		const canvas = document.createElement("canvas");
		canvas.width = video.videoWidth;
		canvas.height = video.videoHeight;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
		canvas.toBlob((blob) => {
			if (!blob) return;
			setImage(new File([blob], "foto.jpg", { type: "image/jpeg" }));
			stopCamera();
		}, "image/jpeg", .92);
	}
	const send = async () => {
		if (!file || state.kind !== "form") return;
		const info = state.info;
		setState({
			kind: "sending",
			info
		});
		const r = await submitPhoto(token, file);
		if (r.ok) setState({ kind: "success" });
		else if (r.status === 404 || r.status === 410) setState({
			kind: "unavailable",
			message: r.message
		});
		else {
			setError(r.message);
			setState({
				kind: "form",
				info
			});
		}
	};
	const expires = (state.kind === "form" || state.kind === "sending") && state.info.expiresUtc ? safeFormat(state.info.expiresUtc) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-2 text-center",
					children: [
						branding.clientLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: branding.clientLogo,
							alt: branding.clientName || "Logo",
							className: "max-h-16 w-auto object-contain"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-6 w-6" })
						}),
						branding.clientName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: branding.clientName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-semibold text-foreground",
							children: "Atualização de foto"
						})
					]
				}),
				state.kind === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-3 py-10 text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Validando o link…"
					})]
				}),
				(state.kind === "form" || state.kind === "sending") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 rounded-lg border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-base font-medium text-foreground",
								children: [
									"Olá, ",
									state.info.displayName,
									"!"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: state.info.hasPhoto ? "Envie ou tire uma nova foto para substituir a atual." : "Envie ou tire uma foto para o seu cadastro."
							}),
							expires && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									"Este link expira em ",
									expires,
									"."
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							type: "file",
							accept: "image/*",
							capture: "user",
							className: "hidden",
							onChange: (e) => pickFile(e.target.files?.[0] ?? null)
						}),
						cameraOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mx-auto h-64 w-full overflow-hidden rounded-md bg-black",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										ref: videoRef,
										autoPlay: true,
										playsInline: true,
										muted: true,
										className: "h-full w-full object-cover"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SilhouetteGuide, { state: personDetected === null ? "neutral" : personDetected ? "ok" : "warn" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonBadge, { detected: personDetected })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									className: "flex-1",
									onClick: capturePhoto,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-1 h-4 w-4" }), " Capturar"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									onClick: stopCamera,
									children: "Cancelar"
								})]
							})]
						}) : previewUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: previewUrl,
							alt: "Prévia",
							className: "mx-auto max-h-64 w-full rounded-md object-contain"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: startCamera,
								className: "flex flex-col items-center gap-2 rounded-md border border-dashed py-8 text-muted-foreground hover:bg-muted",
								disabled: state.kind === "sending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: "Tirar foto"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => inputRef.current?.click(),
								className: "flex flex-col items-center gap-2 rounded-md border border-dashed py-8 text-muted-foreground hover:bg-muted",
								disabled: state.kind === "sending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-6 w-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: "Enviar arquivo"
								})]
							})]
						}),
						previewUrl && !cameraOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1",
								onClick: startCamera,
								disabled: state.kind === "sending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-1 h-4 w-4" }), " Tirar de novo"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1",
								onClick: () => inputRef.current?.click(),
								disabled: state.kind === "sending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "mr-1 h-4 w-4" }), " Trocar arquivo"]
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							className: "w-full",
							onClick: send,
							disabled: !file || cameraOn || state.kind === "sending",
							children: state.kind === "sending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }), " Enviando…"] }) : "Enviar foto"
						})
					]
				}),
				state.kind === "success" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-3 rounded-lg border bg-card p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-10 w-10 text-[var(--success)]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-medium text-foreground",
							children: "Foto atualizada!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Pronto — você já pode fechar esta página."
						})
					]
				}),
				state.kind === "unavailable" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-3 rounded-lg border bg-card p-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-10 w-10 text-destructive" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-medium text-foreground",
							children: "Link indisponível"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: state.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Solicite um novo link ao administrador."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoweredBy, {})
				})
			]
		})
	});
}
function safeFormat(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return null;
	return format(d, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
}
//#endregion
export { PhotoUpdatePage as component };
