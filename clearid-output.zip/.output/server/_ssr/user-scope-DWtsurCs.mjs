import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { n as CLEARID_PROFILES } from "./argus-client-fTtea6N-.mjs";
import { n as useCurrentUser } from "./current-user-BxaXazZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/user-scope-DWtsurCs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useUserScope() {
	const { data: currentUser } = useCurrentUser();
	const userSites = currentUser?.sites ?? [];
	return (0, import_react.useMemo)(() => {
		const restrictByUser = userSites.length > 0;
		const allowedClientCodes = new Set(userSites.map((s) => (s.split(":")[0] ?? "").toLowerCase()));
		const visibleProfiles = restrictByUser ? CLEARID_PROFILES.filter((p) => allowedClientCodes.has(p.code.toLowerCase())) : CLEARID_PROFILES;
		const allowedSiteNames = (profile) => new Set(userSites.filter((s) => (s.split(":")[0] ?? "").toLowerCase() === profile.toLowerCase()).map((s) => s.split(":").slice(1).join(":").toLowerCase()));
		/**
		* Filtra sites do ClearID pelo grant do usuário.
		* - Compara por `name` E por `siteId` (o que o Portal Argus guardar em
		*   UserSites.SiteCode pode ser o nome de exibição OU o guid — aceitamos
		*   ambos para não engessar o cadastro).
		* - Soft-fallback: se o usuário tem grant no cliente mas o filtro
		*   devolveria vazio (naming divergiu entre Portal Argus e ClearID),
		*   retorna a lista SEM filtrar e loga um aviso. É mais seguro exibir
		*   demais do que esconder tudo e travar o operador.
		*/
		const filterSites = (sites, profile) => {
			if (!restrictByUser) return sites;
			const allowed = allowedSiteNames(profile);
			if (allowed.size === 0) return [];
			const filtered = sites.filter((s) => {
				const name = (s.name ?? "").toLowerCase();
				const id = (s.siteId ?? "").toLowerCase();
				return allowed.has(name) || id && allowed.has(id);
			});
			if (filtered.length === 0 && sites.length > 0) {
				console.warn(`[user-scope] grant do usuário em '${profile}' (${[...allowed].join(", ")}) não bateu com nenhum site retornado pelo ClearID (${sites.map((s) => s.name).join(", ")}). Exibindo lista completa como fallback — ajuste UserSites.SiteCode no Portal Argus para bater com Site.Name do ClearID.`);
				return sites;
			}
			return filtered;
		};
		return {
			restrictByUser,
			allowedClientCodes,
			visibleProfiles,
			allowedSiteNames,
			filterSites
		};
	}, [userSites.join(",")]);
}
//#endregion
export { useUserScope as t };
