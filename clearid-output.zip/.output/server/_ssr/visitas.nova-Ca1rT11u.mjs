import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { P as LoaderCircle, ht as ArrowLeft, l as Trash2, t as X, v as Search, w as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, b as useArgusConfig, r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PhotoCapture } from "./PhotoCapture-DfwwRG7z.mjs";
import { t as useUserScope } from "./user-scope-DWtsurCs.mjs";
import { t as CredentialsDialog } from "./CredentialsDialog-Dh7PlQvT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visitas.nova-Ca1rT11u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** datetime-local (hora local) → ISO UTC exigido pela API. */
function toUtcIso(local) {
	return new Date(local).toISOString();
}
/** Date → valor de <input type="datetime-local"> (hora local). */
function toLocalInput(d) {
	const p = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
/** Duração padrão da visita: o término é 12h após o início. */
var VISIT_HOURS = 12;
function NovaVisitaPage() {
	const { t } = useT();
	const navigate = useNavigate();
	const defaultSite = useDefaultSiteId();
	const linkVisitor = Boolean(useArgusConfig().linkVisitorToIdentity);
	const [mode, setMode] = (0, import_react.useState)("now");
	const [name, setName] = (0, import_react.useState)("");
	const [reason, setReason] = (0, import_react.useState)("");
	const [siteId, setSiteId] = (0, import_react.useState)(defaultSite ?? "");
	(0, import_react.useEffect)(() => {
		if (defaultSite) setSiteId(defaultSite);
	}, [defaultSite]);
	const [start, setStart] = (0, import_react.useState)(() => toLocalInput(/* @__PURE__ */ new Date()));
	const [end, setEnd] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setHours(d.getHours() + VISIT_HOURS);
		return toLocalInput(d);
	});
	const [requester, setRequester] = (0, import_react.useState)(null);
	const [hosts, setHosts] = (0, import_react.useState)([]);
	const [visitors, setVisitors] = (0, import_react.useState)([{
		firstName: "",
		lastName: "",
		email: "",
		photo: null
	}]);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [checkedIn, setCheckedIn] = (0, import_react.useState)(null);
	const visitActiveProfile = useActiveProfile();
	const visitScope = useUserScope();
	const sitesQuery = useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	});
	const profilesQuery = useQuery({
		queryKey: ["visit-profiles"],
		queryFn: () => argusApi.listVisitProfiles(),
		staleTime: 300 * 1e3
	});
	const profile = (profilesQuery.data ?? []).find((p) => p.siteId === siteId && p.isDefault) ?? (profilesQuery.data ?? []).find((p) => p.siteId === siteId);
	const reasons = profile?.plannedVisitSettings?.visitReasons ?? [];
	const validate = () => {
		const e = {};
		if (!name.trim()) e.name = t("visits.validation.required");
		if (!reason.trim()) e.reason = t("visits.validation.required");
		if (!siteId) e.siteId = t("visits.validation.required");
		if (!start) e.start = t("visits.validation.required");
		if (!end) e.end = t("visits.validation.required");
		if (start && end && new Date(end) <= new Date(start)) e.end = t("visits.validation.endAfterStart");
		if (!requester) e.requester = t("visits.validation.required");
		if (hosts.length === 0) e.hosts = t("visits.validation.atLeastOneHost");
		if (!visitors.some((v) => v.firstName.trim())) e.visitors = t("visits.validation.atLeastOneVisitor");
		visitors.forEach((v, i) => {
			if (v.photo && (!v.firstName.trim() || !v.lastName.trim() || !v.email.trim())) e[`visitor_${i}`] = t("visits.validation.photoNeedsIdentity");
		});
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const resolveVisitorIdentity = async (v) => {
		if (!v.photo) return null;
		const email = v.email.trim();
		const existing = email ? await argusApi.findIdentitiesByEmail(email) : [];
		let id;
		if (existing.length) id = existing[0].identityId;
		else id = (await argusApi.createIdentity({
			externalId: "",
			firstName: v.firstName.trim(),
			lastName: v.lastName.trim(),
			email,
			status: "Active",
			identityType: "Visitor",
			workerTypeCode: "Terceiros",
			siteId
		})).identityId;
		await argusApi.uploadIdentityPicture(id, v.photo);
		try {
			await argusApi.synchronizeIdentities([id], siteId);
		} catch {}
		return id;
	};
	const create = useMutation({
		mutationFn: async () => {
			const warnings = [];
			const rows = visitors.filter((v) => v.firstName.trim());
			const builtVisitors = await Promise.all(rows.map(async (v) => {
				let identityId = null;
				if (v.photo) try {
					identityId = await resolveVisitorIdentity(v);
				} catch (e) {
					warnings.push(`${v.firstName.trim()}: ${e.message}`);
				}
				return {
					firstName: v.firstName.trim(),
					lastName: v.lastName.trim() || null,
					email: v.email.trim() || null,
					...identityId ? { identityId } : {}
				};
			}));
			const visit = await argusApi.createVisit({
				visitEventName: name.trim(),
				startDateTimeUtc: toUtcIso(start),
				endDateTimeUtc: toUtcIso(end),
				reason: reason.trim(),
				siteId,
				requesterId: requester.identityId,
				visitProfileId: profile?.visitProfileId ?? null,
				...mode === "now" ? { type: "Planned" } : {},
				hosts: hosts.map((h) => ({ identityId: h.identityId })),
				visitors: builtVisitors
			});
			if (warnings.length) toast.warning(t("visits.photoIssues"), {
				description: warnings.join("; "),
				duration: 12e3
			});
			if (mode === "schedule") return {
				visit,
				visitors: []
			};
			const ids = (await argusApi.listVisitVisitors(visit.visitEventId)).map((v) => v.visitorId).filter(Boolean);
			if (ids.length) await argusApi.checkInVisitors(visit.visitEventId, ids);
			return {
				visit,
				visitors: await argusApi.listVisitVisitors(visit.visitEventId)
			};
		},
		onSuccess: ({ visitors: vs }) => {
			if (mode === "schedule") {
				toast.success(t("visits.createdScheduled"));
				navigate({ to: "/visitas" });
				return;
			}
			toast.success(t("visits.createdCheckedIn", { n: vs.length }));
			setCheckedIn(vs);
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, {
				description: err.traceId ? `TraceId: ${err.traceId}` : void 0,
				duration: 12e3
			});
		}
	});
	const submit = () => {
		if (!validate()) return;
		create.mutate();
	};
	if (checkedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("visits.credentialStep")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("visits.credentialStepHint")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("visits.visitors")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-2",
				children: checkedIn.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded border p-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: [v.firstName, v.lastName].filter(Boolean).join(" ") || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t("visits.state.checkedIn") }),
						v.identityId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialsDialog, { identityId: v.identityId }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: t("visits.noIdentityForCredential")
						})
					]
				}, v.visitorId))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => navigate({ to: "/visitas" }),
					children: t("visits.finish")
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/visitas",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 h-4 w-4" }),
						" ",
						t("visits.back")
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-2xl font-semibold tracking-tight text-foreground",
				children: t("visits.newVisit")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("visits.mode")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMode("now"),
					className: cn("flex-1 rounded-md border p-3 text-left text-sm", mode === "now" ? "border-primary bg-primary/5 ring-1 ring-primary/40" : "hover:bg-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-foreground",
						children: t("visits.modeNow")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: t("visits.modeNowHint")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMode("schedule"),
					className: cn("flex-1 rounded-md border p-3 text-left text-sm", mode === "schedule" ? "border-primary bg-primary/5 ring-1 ring-primary/40" : "hover:bg-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-foreground",
						children: t("visits.modeSchedule")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: t("visits.modeScheduleHint")
					})]
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("visits.details")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("visits.name"),
						error: errors.name,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("visits.reason"),
						error: errors.reason,
						children: reasons.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: reason,
							onValueChange: setReason,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("visits.selectReason") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: r,
								children: r
							}, r)) })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: reason,
							onChange: (e) => setReason(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("visits.site"),
						error: errors.siteId,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: siteId,
							onValueChange: setSiteId,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("visits.selectSite") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: visitScope.filterSites(sitesQuery.data ?? [], visitActiveProfile).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: s.siteId,
								children: s.name ?? s.siteId
							}, s.siteId)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: t("visits.start"),
						error: errors.start,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "datetime-local",
							value: start,
							onChange: (e) => {
								const v = e.target.value;
								setStart(v);
								if (v) {
									const d = new Date(v);
									d.setHours(d.getHours() + VISIT_HOURS);
									setEnd(toLocalInput(d));
								}
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: t("visits.end"),
						error: errors.end,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "datetime-local",
							value: end,
							onChange: (e) => setEnd(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: t("visits.endHint")
						})]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: t("visits.people")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("visits.requester"),
					error: errors.requester,
					children: requester ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: requester.label,
						onRemove: () => setRequester(null)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPicker, { onPick: (p) => setRequester(p) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: t("visits.hosts"),
					error: errors.hosts,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [hosts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1",
							children: hosts.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								label: h.label,
								onRemove: () => setHosts((prev) => prev.filter((x) => x.identityId !== h.identityId))
							}, h.identityId))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPicker, { onPick: (p) => setHosts((prev) => prev.some((x) => x.identityId === p.identityId) ? prev : [...prev, p]) })]
					})
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row items-center justify-between space-y-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: t("visits.visitors")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setVisitors((p) => [...p, {
						firstName: "",
						lastName: "",
						email: "",
						photo: null
					}]),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
						" ",
						t("visits.addVisitor")
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [visitors.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 rounded-md border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-[1fr_1fr_1.5fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: t("visits.firstName"),
									value: v.firstName,
									onChange: (e) => setVisitors((p) => p.map((x, j) => j === i ? {
										...x,
										firstName: e.target.value
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: t("visits.lastName"),
									value: v.lastName,
									onChange: (e) => setVisitors((p) => p.map((x, j) => j === i ? {
										...x,
										lastName: e.target.value
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									placeholder: t("common.email"),
									value: v.email,
									onChange: (e) => setVisitors((p) => p.map((x, j) => j === i ? {
										...x,
										email: e.target.value
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "text-destructive hover:text-destructive",
									disabled: visitors.length === 1,
									onClick: () => setVisitors((p) => p.filter((_, j) => j !== i)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							]
						}),
						linkVisitor && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoCapture, {
							value: v.photo,
							onChange: (blob) => setVisitors((p) => p.map((x, j) => j === i ? {
								...x,
								photo: blob
							} : x))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: t("visits.photoHint")
						})] }),
						errors[`visitor_${i}`] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-destructive",
							children: errors[`visitor_${i}`]
						})
					]
				}, i)), errors.visitors && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-destructive",
					children: errors.visitors
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => navigate({ to: "/visitas" }),
					children: t("common.cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: submit,
					disabled: create.isPending,
					children: [create.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }), mode === "now" ? t("visits.createAndCheckIn") : t("visits.schedule")]
				})]
			})
		]
	});
}
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function Chip({ label, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		variant: "secondary",
		className: "gap-1",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onRemove,
			className: "ml-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" })
		})]
	});
}
/** Busca identidades e devolve a escolhida (para requester/host). */
function IdentityPicker({ onPick }) {
	const { t } = useT();
	const [q, setQ] = (0, import_react.useState)("");
	const [applied, setApplied] = (0, import_react.useState)("");
	const query = useQuery({
		queryKey: ["identity-picker", applied],
		queryFn: () => argusApi.listIdentities({
			query: applied,
			take: 10
		}),
		enabled: applied.length > 0,
		retry: false
	});
	const results = query.data?.items ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter") {
						e.preventDefault();
						setApplied(q.trim());
					}
				},
				placeholder: t("visits.searchIdentity")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "icon",
				onClick: () => setApplied(q.trim()),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4" })
			})]
		}), applied && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-h-40 overflow-y-auto rounded-md border",
			children: query.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-2 text-sm text-muted-foreground",
				children: t("common.loading")
			}) : results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-2 text-sm text-muted-foreground",
				children: t("visits.noIdentityFound")
			}) : results.map((i) => {
				const label = `${i.firstName} ${i.lastName}`.trim();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						onPick({
							identityId: i.identityId,
							label
						});
						setQ("");
						setApplied("");
					},
					className: "flex w-full items-center justify-between gap-2 p-2 text-left text-sm hover:bg-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: i.email ?? ""
					})]
				}, i.identityId);
			})
		})]
	});
}
//#endregion
export { NovaVisitaPage as component };
