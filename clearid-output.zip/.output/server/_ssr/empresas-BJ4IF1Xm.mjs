import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { a as typeOf, i as pickLang, n as isTruthy, r as optionsOf } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { T as Pencil, ft as Building2, l as Trash2, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { t as Checkbox } from "./checkbox-Th7i6qaL.mjs";
import { t as Textarea } from "./textarea-DjqHhWkA.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/empresas-BJ4IF1Xm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_FORM = {
	name: "",
	legal_name: "",
	tax_id: "",
	description: "",
	status: "Active"
};
function toForm(c) {
	return {
		name: c.name ?? "",
		legal_name: c.legal_name ?? "",
		tax_id: c.tax_id ?? "",
		description: c.description ?? "",
		status: c.status ?? "Active"
	};
}
function fieldLabel(sf, t) {
	return pickLang(sf.display_name_override) || sf.definition?.custom_field_name || t("companies.customField.fallback");
}
function EmpresasPage() {
	const { t } = useT();
	const siteId = useDefaultSiteId();
	const activeProfile = useActiveProfile();
	const qc = useQueryClient();
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(EMPTY_FORM);
	const [customValues, setCustomValues] = (0, import_react.useState)({});
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const query = useQuery({
		queryKey: ["companies", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("companies").select("*").eq("profile", activeProfile).order("name", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const siteFields = useQuery({
		queryKey: ["site-custom-fields-active", siteId],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_custom_fields").select("id, is_required, value_range, display_name_override, definition:custom_field_definitions(custom_field_name, custom_field_type)").eq("site_id", siteId).eq("entity_type", "company").eq("is_active", true).order("display_index", {
				ascending: true,
				nullsFirst: false
			}).returns();
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		enabled: Boolean(siteId)
	}).data ?? [];
	const upsert = useMutation({
		mutationFn: async (values) => {
			const payload = {
				name: values.name.trim(),
				legal_name: values.legal_name.trim() || null,
				tax_id: values.tax_id.trim() || null,
				description: values.description.trim() || null,
				status: values.status
			};
			let companyId = editing?.id;
			if (editing) {
				const { error } = await supabase.from("companies").update(payload).eq("id", editing.id);
				if (error) throw new Error(error.message);
			} else {
				const { data, error } = await supabase.from("companies").insert({
					...payload,
					profile: activeProfile
				}).select("id").single();
				if (error) throw new Error(error.message);
				companyId = data.id;
			}
			if (companyId && siteFields.length) {
				const rows = siteFields.map((sf) => ({
					company_id: companyId,
					site_custom_field_id: sf.id,
					value: customValues[sf.id]?.trim() ? customValues[sf.id].trim() : null
				}));
				const { error } = await supabase.from("company_custom_fields").upsert(rows, { onConflict: "company_id,site_custom_field_id" });
				if (error) throw new Error(error.message);
			}
		},
		onSuccess: () => {
			toast.success(editing ? t("companies.toast.updated") : t("companies.toast.created"));
			qc.invalidateQueries({ queryKey: ["companies"] });
			setDialogOpen(false);
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("companies").delete().eq("id", id);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("companies.toast.deleted"));
			qc.invalidateQueries({ queryKey: ["companies"] });
			setToDelete(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const openCreate = () => {
		setEditing(null);
		setForm(EMPTY_FORM);
		setCustomValues({});
		setDialogOpen(true);
	};
	const openEdit = async (c) => {
		setEditing(c);
		setForm(toForm(c));
		setCustomValues({});
		setDialogOpen(true);
		const { data } = await supabase.from("company_custom_fields").select("site_custom_field_id, value").eq("company_id", c.id);
		setCustomValues(Object.fromEntries((data ?? []).map((r) => [r.site_custom_field_id, r.value ?? ""])));
	};
	const submit = () => {
		if (!form.name.trim()) {
			toast.error(t("companies.validation.nameRequired"));
			return;
		}
		const missing = siteFields.find((sf) => sf.is_required && !customValues[sf.id]?.trim());
		if (missing) {
			toast.error(t("companies.validation.requiredField", { field: fieldLabel(missing, t) }));
			return;
		}
		upsert.mutate(form);
	};
	const setCV = (id, v) => setCustomValues((c) => ({
		...c,
		[id]: v
	}));
	const items = query.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight text-foreground",
						children: t("companies.title")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full border px-2 py-0.5 text-xs font-medium text-muted-foreground",
						children: [
							t("shell.profile"),
							": ",
							activeProfile
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("companies.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => query.refetch(),
						disabled: query.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${query.isFetching ? "animate-spin" : ""}` }), t("companies.refreshButton")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: openCreate,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("companies.newButton")
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: query.data ? items.length === 1 ? t("companies.count.one", { count: items.length }) : t("companies.count.other", { count: items.length }) : t("companies.title")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })
				]
			}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: query.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("companies.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("companies.col.legalName") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("companies.col.taxId") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.status") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[100px] text-right",
					children: t("common.actions")
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: c.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: c.legal_name ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: c.tax_id ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: c.status === "Active" ? "default" : "secondary",
					children: c.status === "Active" ? t("companies.status.active") : t("companies.status.inactive")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => openEdit(c),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "text-destructive hover:text-destructive",
							onClick: () => setToDelete(c),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})]
					})
				})
			] }, c.id)) })] }) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: setDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[85vh] overflow-y-auto sm:max-w-[560px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "h-5 w-5" }), editing ? t("companies.dialog.editTitle") : t("companies.newButton")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: editing ? t("companies.dialog.editDescription") : t("companies.dialog.createDescription") })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "name",
										children: t("companies.form.name")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "name",
										value: form.name,
										onChange: (e) => setForm((f) => ({
											...f,
											name: e.target.value
										})),
										placeholder: t("companies.form.namePlaceholder")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "legal_name",
										children: t("companies.col.legalName")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "legal_name",
										value: form.legal_name,
										onChange: (e) => setForm((f) => ({
											...f,
											legal_name: e.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "tax_id",
											children: t("companies.col.taxId")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "tax_id",
											value: form.tax_id,
											onChange: (e) => setForm((f) => ({
												...f,
												tax_id: e.target.value
											})),
											placeholder: "00.000.000/0000-00"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "status",
											children: t("common.status")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: form.status,
											onValueChange: (v) => setForm((f) => ({
												...f,
												status: v
											})),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												id: "status",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Active",
												children: t("companies.status.active")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Inactive",
												children: t("companies.status.inactive")
											})] })]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "description",
										children: t("companies.form.description")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "description",
										value: form.description,
										onChange: (e) => setForm((f) => ({
											...f,
											description: e.target.value
										})),
										rows: 3
									})]
								}),
								siteFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 border-t pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-foreground",
										children: t("companies.customField.section")
									}), siteFields.map((sf) => {
										const kind = typeOf(sf.definition?.custom_field_type);
										const value = customValues[sf.id] ?? "";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [fieldLabel(sf, t), sf.is_required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-0.5 text-destructive",
												children: "*"
											})] }), kind === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex h-9 items-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
													checked: isTruthy(value),
													onCheckedChange: (c) => setCV(sf.id, c ? "true" : "false")
												})
											}) : kind === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value,
												onValueChange: (v) => setCV(sf.id, v),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("companies.customField.selectPlaceholder") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: optionsOf(sf.value_range).map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: opt,
													children: opt
												}, opt)) })]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: kind === "date" ? "date" : kind === "number" ? "number" : "text",
												value,
												onChange: (e) => setCV(sf.id, e.target.value)
											})]
										}, sf.id);
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDialogOpen(false),
							children: t("common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: submit,
							disabled: upsert.isPending,
							children: upsert.isPending ? t("common.saving") : t("common.save")
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(toDelete),
				onOpenChange: (o) => !o && setToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("companies.delete.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					t("companies.delete.confirmBefore"),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: toDelete?.name
					}),
					t("companies.delete.confirmAfter")
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					onClick: () => toDelete && remove.mutate(toDelete.id),
					disabled: remove.isPending,
					children: remove.isPending ? t("companies.delete.deleting") : t("common.delete")
				})] })] })
			})
		]
	});
}
//#endregion
export { EmpresasPage as component };
