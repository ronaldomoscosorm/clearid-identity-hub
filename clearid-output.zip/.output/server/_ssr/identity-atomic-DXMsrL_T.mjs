import { a as clearIdToFormValues, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { a as saveIdentityWorkerType, n as mirrorIdentities, r as saveIdentityCompany } from "./supabase-mirror--nGFXAER.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identity-atomic-DXMsrL_T.js
async function persistSupabaseSide(identityId, updated, extras) {
	await mirrorIdentities([updated]);
	await saveIdentityCompany(identityId, extras.companyId);
	await saveIdentityWorkerType(identityId, extras.workerTypeId);
}
/**
* CREATE atômico. Sequência:
*   1) createIdentity no ClearID.
*   2) mirror + company + workerType no Supabase.
*   3) Se (2) falhar, marca a identity criada como Inactive no ClearID.
*
* Retorna a identity do ClearID em caso de sucesso; lança em qualquer falha
* (o caller precisa capturar e exibir).
*/
async function createIdentityAtomic(payload, extras) {
	const created = await argusApi.createIdentity(payload);
	try {
		await persistSupabaseSide(created.identityId, created, extras);
		return created;
	} catch (err) {
		const compensationErr = await tryCompensateCreate(created.identityId);
		const msg = err.message;
		if (compensationErr) throw new Error(`Falha ao gravar no Supabase (${msg}). ATENÇÃO: a compensação no ClearID também falhou (${compensationErr}). Estado inconsistente — verifique a identity ${created.identityId} manualmente.`);
		throw new Error(`Falha ao gravar no Supabase (${msg}). A identity foi marcada como Inativa no ClearID (${created.identityId}); nenhuma alteração ficou persistida em ambos os sistemas.`);
	}
}
/**
* UPDATE atômico. Requer `originalIdentity` (snapshot do ClearID ANTES do
* update) para poder restaurar em caso de falha do Supabase. Sequência:
*   1) updateIdentity no ClearID (com o novo payload).
*   2) mirror + company + workerType no Supabase.
*   3) Se (2) falhar, faz updateIdentity de volta com o payload original,
*      usando o eTag NOVO devolvido em (1).
*/
async function updateIdentityAtomic(identityId, payload, extras, originalIdentity) {
	const updated = await argusApi.updateIdentity(identityId, payload);
	try {
		await persistSupabaseSide(identityId, updated, extras);
		return updated;
	} catch (err) {
		const compensationErr = await tryCompensateUpdate(identityId, originalIdentity, updated.eTag ?? null);
		const msg = err.message;
		if (compensationErr) throw new Error(`Falha ao gravar no Supabase (${msg}). ATENÇÃO: a reversão no ClearID também falhou (${compensationErr}). Estado inconsistente — verifique a identity ${identityId} manualmente.`);
		throw new Error(`Falha ao gravar no Supabase (${msg}). As alterações no ClearID foram revertidas para o estado anterior; nenhum campo ficou salvo.`);
	}
}
/** Retorna a mensagem de erro se a compensação falhou, ou null em sucesso. */
async function tryCompensateCreate(identityId) {
	try {
		await argusApi.deactivateIdentity(identityId);
		return null;
	} catch (e) {
		return e.message;
	}
}
/** Retorna a mensagem de erro se a reversão do update falhou, ou null em sucesso. */
async function tryCompensateUpdate(identityId, originalIdentity, newETag) {
	try {
		const rollbackPayload = clearIdToFormValues(originalIdentity);
		await argusApi.updateIdentity(identityId, {
			...rollbackPayload,
			eTag: newETag ?? originalIdentity.eTag ?? null
		});
		return null;
	} catch (e) {
		return e.message;
	}
}
//#endregion
export { updateIdentityAtomic as n, createIdentityAtomic as t };
