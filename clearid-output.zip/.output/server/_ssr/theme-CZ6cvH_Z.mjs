//#region node_modules/.nitro/vite/services/ssr/assets/theme-CZ6cvH_Z.js
var KEY = "rm-theme";
function getTheme() {
	if (typeof localStorage === "undefined") return "light";
	return localStorage.getItem(KEY) === "dark" ? "dark" : "light";
}
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	document.documentElement.classList.toggle("dark", theme === "dark");
}
function setTheme(theme) {
	if (typeof localStorage !== "undefined") localStorage.setItem(KEY, theme);
	applyTheme(theme);
}
//#endregion
export { getTheme as n, setTheme as r, applyTheme as t };
