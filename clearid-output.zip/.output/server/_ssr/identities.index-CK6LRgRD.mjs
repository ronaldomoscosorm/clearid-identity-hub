import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { r as cn, t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { E as Paperclip, G as Eye, K as ExternalLink, a as UserX, mt as ArrowRight, o as UserCheck, q as Ellipsis, r as Users, ut as Camera, v as Search, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, r as argusApi, y as useActiveProfile } from "./argus-client-fTtea6N-.mjs";
import { n as mirrorIdentities } from "./supabase-mirror--nGFXAER.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useCurrentAttachments, n as signedUrlFor } from "./attachments-PsPmKuGo.mjs";
import { t as IdentityThumb } from "./IdentityThumb-CSzuowwS.mjs";
import { t as IdentityPictureDialog } from "./IdentityPictureDialog-BNrWvmUR.mjs";
import { n as DropdownMenuContent, o as DropdownMenuTrigger, r as DropdownMenuItem, t as DropdownMenu } from "./dropdown-menu-CsR71wG4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identities.index-CK6LRgRD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var panel = "rounded-2xl border border-[var(--rm-line)] bg-[var(--rm-panel)]";
var fullName = (it) => `${it.firstName ?? ""} ${it.lastName ?? ""}`.trim() || it.identityId;
var ALL_SITES = "__all__";
var persistedSearch = null;
function IdentitiesList() {
	const { t, lang } = useT();
	const siteId = useDefaultSiteId();
	const [pictureFor, setPictureFor] = (0, import_react.useState)(null);
	const [sel, setSel] = (0, import_react.useState)(persistedSearch?.sel ?? null);
	const [fFirstName, setFFirstName] = (0, import_react.useState)(persistedSearch?.fFirstName ?? "");
	const [fEmail, setFEmail] = (0, import_react.useState)(persistedSearch?.fEmail ?? "");
	const [fCompany, setFCompany] = (0, import_react.useState)(persistedSearch?.fCompany ?? "");
	const [fStatus, setFStatus] = (0, import_react.useState)(persistedSearch?.fStatus ?? "all");
	const [fWorkerType, setFWorkerType] = (0, import_react.useState)(persistedSearch?.fWorkerType ?? "all");
	const [fSite, setFSite] = (0, import_react.useState)(persistedSearch?.fSite ?? "");
	(0, import_react.useEffect)(() => {
		if (!fSite && siteId) setFSite(siteId);
	}, [siteId, fSite]);
	const sites = (useQuery({
		queryKey: ["sites"],
		queryFn: () => argusApi.listSites(),
		staleTime: 300 * 1e3
	}).data ?? []).slice().sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "", "pt-BR"));
	const activeProfile = useActiveProfile();
	const workerTypes = useQuery({
		queryKey: ["worker-types", activeProfile],
		queryFn: async () => {
			const { data, error } = await supabase.from("worker_types").select("*").eq("is_active", true).eq("profile", activeProfile).order("display_index", {
				ascending: true,
				nullsFirst: false
			});
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	}).data ?? [];
	const [hasSearched, setHasSearched] = (0, import_react.useState)(persistedSearch?.hasSearched ?? false);
	const [applied, setApplied] = (0, import_react.useState)(persistedSearch?.applied ?? {
		firstName: "",
		email: "",
		company: "",
		status: "all",
		workerTypeId: "all",
		allSites: false
	});
	(0, import_react.useEffect)(() => {
		persistedSearch = {
			fFirstName,
			fEmail,
			fCompany,
			fStatus,
			fWorkerType,
			fSite,
			hasSearched,
			applied,
			sel
		};
	}, [
		fFirstName,
		fEmail,
		fCompany,
		fStatus,
		fWorkerType,
		fSite,
		hasSearched,
		applied,
		sel
	]);
	const query = useQuery({
		queryKey: ["identities", applied],
		queryFn: () => argusApi.listIdentities({
			firstName: applied.firstName || void 0,
			email: applied.email || void 0,
			company: applied.company || void 0,
			status: applied.status === "all" ? void 0 : applied.status,
			take: applied.workerTypeId !== "all" ? 200 : void 0,
			allSites: applied.allSites,
			siteId: applied.siteId || void 0
		}),
		enabled: hasSearched,
		retry: false
	});
	const rawItems = query.data?.items ?? [];
	(0, import_react.useEffect)(() => {
		if (rawItems.length) mirrorIdentities(rawItems).catch((err) => console.error("[mirror] falha ao espelhar listagem:", err));
	}, [query.data]);
	const rawIdsKey = rawItems.map((i) => i.identityId).sort().join(",");
	const filterByType = applied.workerTypeId !== "all";
	const localTypesQuery = useQuery({
		queryKey: ["identities-local-worker-type", rawIdsKey],
		enabled: filterByType && rawItems.length > 0,
		queryFn: async () => {
			const ids = rawItems.map((i) => i.identityId);
			const { data, error } = await supabase.from("identities").select("identity_id, worker_type_id").in("identity_id", ids);
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 60 * 1e3
	});
	const items = (0, import_react.useMemo)(() => {
		if (!filterByType) return rawItems;
		const allowed = new Set((localTypesQuery.data ?? []).filter((r) => r.worker_type_id === applied.workerTypeId).map((r) => r.identity_id));
		return rawItems.filter((i) => allowed.has(i.identityId));
	}, [
		rawItems,
		filterByType,
		localTypesQuery.data,
		applied.workerTypeId
	]);
	const typeFilterLoading = filterByType && rawItems.length > 0 && localTypesQuery.isLoading;
	const isActive = (s) => String(s ?? "").toLowerCase() === "active";
	const activeCount = items.filter((i) => isActive(i.status)).length;
	const displayTotal = filterByType ? items.length : query.data?.total ?? items.length;
	(0, import_react.useEffect)(() => {
		if (items.length) setSel((prev) => prev && items.some((i) => i.identityId === prev) ? prev : items[0].identityId);
		else setSel(null);
	}, [rawIdsKey, items.length]);
	const onSubmit = (e) => {
		e.preventDefault();
		const allSites = fSite === ALL_SITES;
		setHasSearched(true);
		setApplied({
			firstName: fFirstName.trim(),
			email: fEmail.trim(),
			company: fCompany.trim(),
			status: fStatus,
			workerTypeId: fWorkerType,
			allSites,
			siteId: allSites ? void 0 : fSite || void 0
		});
	};
	const onClear = () => {
		setFFirstName("");
		setFEmail("");
		setFCompany("");
		setFStatus("all");
		setFWorkerType("all");
		setFSite(siteId ?? "");
		setHasSearched(false);
		setApplied({
			firstName: "",
			email: "",
			company: "",
			status: "all",
			workerTypeId: "all",
			allSites: false
		});
		persistedSearch = null;
	};
	const resetResults = () => {
		setHasSearched(false);
		setSel(null);
	};
	const selected = items.find((i) => i.identityId === sel) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rm space-y-5 text-[var(--rm-ink)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight text-[var(--rm-ink)]",
					children: t("identities.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-[var(--rm-dim)]",
					children: t("identities.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "rounded-full font-semibold text-white hover:brightness-105",
					style: {
						background: "var(--rm-brand)",
						boxShadow: "0 8px 18px -7px rgba(253,83,0,.5)"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/identities/new",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("identities.newButton")
						]
					})
				})]
			}),
			hasSearched && items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-5 w-5" }),
						tone: "brand",
						value: displayTotal,
						label: t("identities.metric.results")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-5 w-5" }),
						tone: "active",
						value: activeCount,
						label: t("identities.metric.active")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "h-5 w-5" }),
						tone: "inactive",
						value: items.length - activeCount,
						label: t("identities.metric.inactive")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: cn(panel, "space-y-4 p-4"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("common.name"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: fFirstName,
								onChange: (e) => setFFirstName(e.target.value),
								placeholder: t("identities.filter.namePlaceholder")
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("common.email"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: fEmail,
								onChange: (e) => setFEmail(e.target.value),
								placeholder: t("identities.filter.emailPlaceholder")
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("identities.filter.company"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: fCompany,
								onChange: (e) => setFCompany(e.target.value),
								placeholder: t("identities.filter.company")
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("common.status"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: fStatus,
								onValueChange: (v) => {
									setFStatus(v);
									resetResults();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Active",
										children: t("identities.status.active")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Inactive",
										children: t("identities.status.inactive")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "all",
										children: t("identities.status.all")
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("identities.filter.workerType"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: fWorkerType,
								onValueChange: (v) => {
									setFWorkerType(v);
									resetResults();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: t("identities.workerType.all")
								}), workerTypes.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: w.id,
									children: pickLang(w.name_i18n, lang) || w.name
								}, w.id))] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t("identities.filter.site"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: fSite,
								onValueChange: (v) => {
									setFSite(v);
									resetResults();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: t("identities.filter.sitePlaceholder") }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: ALL_SITES,
									children: t("identities.filter.allSites")
								}), sites.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s.siteId,
									children: s.name
								}, s.siteId))] })]
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: onClear,
							disabled: query.isFetching,
							className: "text-[var(--rm-dim)]",
							children: t("identities.filter.clear")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "icon",
							onClick: () => query.refetch(),
							disabled: query.isFetching,
							title: t("identities.filter.reload"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: query.isFetching ? "h-4 w-4 animate-spin" : "h-4 w-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: query.isFetching,
							className: "rounded-full font-semibold text-white hover:brightness-105",
							style: { background: "var(--rm-brand)" },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "mr-1 h-4 w-4" }),
								" ",
								t("common.search")
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1fr_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn(panel, "overflow-hidden"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[12px_40px_1fr_110px_64px_36px] items-center gap-3 border-b border-[var(--rm-line)] px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.11em] text-[var(--rm-faint)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t("identities.col.identity") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t("common.status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-right",
								children: t("identities.col.relevance")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {})
						]
					}), !hasSearched ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyState, { children: [
						t("identities.emptyPrompt.before"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-[var(--rm-brand-ink)]",
							children: t("common.search")
						}),
						" ",
						t("identities.emptyPrompt.after")
					] }) : query.isLoading || query.isFetching || typeFilterLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-[var(--rm-line-soft)]",
						children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-4 rounded-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-9 w-9 rounded-lg" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 flex-1" })
							]
						}, i))
					}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						tone: "error",
						children: query.error.message
					}) : !items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { children: t("identities.emptyResult") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [displayTotal > items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-b border-[var(--rm-line-soft)] bg-[var(--rm-panel-2)] px-4 py-2 text-xs text-[var(--rm-dim)]",
						children: t("identities.showingFirst", {
							shown: items.length,
							total: displayTotal
						})
					}), items.map((it) => {
						const active = isActive(it.status);
						const on = it.identityId === sel;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onClick: () => setSel(it.identityId),
							className: cn("grid cursor-pointer grid-cols-[12px_40px_1fr_110px_64px_36px] items-center gap-3 border-b border-[var(--rm-line-soft)] px-4 py-3 transition-colors", on ? "bg-[color-mix(in_srgb,var(--rm-brand)_9%,transparent)]" : "hover:bg-[var(--rm-panel-2)]"),
							style: on ? { boxShadow: "inset 2px 0 0 var(--rm-brand)" } : void 0,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-2.5 w-2.5 justify-self-center rounded-full",
									style: active ? {
										background: "var(--rm-active)",
										boxShadow: "0 0 8px var(--rm-active)"
									} : { background: "var(--rm-inactive)" }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, { identityId: it.identityId }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/identities/$id",
										params: { id: it.identityId },
										onClick: (e) => e.stopPropagation(),
										className: "block truncate text-sm font-semibold text-[var(--rm-ink)] hover:text-[var(--rm-brand-ink)] hover:underline",
										children: fullName(it)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "truncate text-xs text-[var(--rm-dim)] tnum",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[var(--rm-faint)]",
												children: it.identityId.slice(0, 8)
											}),
											" · ",
											it.email ?? "—"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-semibold tracking-wide",
									style: { color: active ? "var(--rm-active-ink)" : "var(--rm-inactive-ink)" },
									children: active ? "● " + t("identities.status.active") : "○ " + (String(it.status ?? "") || "—")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-right text-xs text-[var(--rm-dim)] tnum",
									children: typeof it.score === "number" ? it.score.toFixed(2) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									onClick: (e) => e.stopPropagation(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "ghost",
											size: "icon",
											className: "h-8 w-8 text-[var(--rm-faint)]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sr-only",
												children: t("common.actions")
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
										align: "end",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
											asChild: true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/identities/$id",
												params: { id: it.identityId },
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "mr-2 h-4 w-4" }),
													" ",
													t("identities.action.view")
												]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onClick: () => setPictureFor({
												id: it.identityId,
												name: fullName(it)
											}),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-2 h-4 w-4" }),
												" ",
												t("identities.action.updatePhoto")
											]
										})]
									})] })
								})
							]
						}, it.identityId);
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: cn(panel, "hidden self-start p-5 lg:block"),
					children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-[0.14em] text-[var(--rm-faint)]",
								children: t("identities.inspector.title")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "[&_span]:!h-16 [&_span]:!w-16 [&_img]:!h-16 [&_img]:!w-16",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityThumb, { identityId: selected.identityId })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-base font-bold text-[var(--rm-ink)]",
										children: fullName(selected)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-xs text-[var(--rm-dim)] tnum",
										children: selected.identityId.slice(0, 13)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "space-y-2.5 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspRow, {
										k: t("common.status"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											style: { color: isActive(selected.status) ? "var(--rm-active-ink)" : "var(--rm-inactive-ink)" },
											className: "font-semibold",
											children: isActive(selected.status) ? t("identities.status.active") : String(selected.status ?? "") || "—"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspRow, {
										k: t("common.email"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[var(--rm-ink)]",
											children: selected.email ?? "—"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspRow, {
										k: t("identities.col.relevance"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[var(--rm-ink)] tnum",
											children: typeof selected.score === "number" ? selected.score.toFixed(2) : "—"
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspectorAttachments, { identityId: selected.identityId }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "flex-1 rounded-lg text-white hover:brightness-105",
									style: { background: "var(--rm-brand)" },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/identities/$id",
										params: { id: selected.identityId },
										children: [
											t("identities.inspector.open"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1 h-4 w-4" })
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									title: t("identities.action.updatePhoto"),
									onClick: () => setPictureFor({
										id: selected.identityId,
										name: fullName(selected)
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" })
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-10 text-center text-sm text-[var(--rm-faint)]",
						children: t("identities.inspector.empty")
					})
				})]
			}),
			pictureFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPictureDialog, {
				identityId: pictureFor.id,
				identityName: pictureFor.name,
				open: !!pictureFor,
				onOpenChange: (o) => !o && setPictureFor(null)
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-[var(--rm-dim)]",
			children: label
		}), children]
	});
}
function InspectorAttachments({ identityId }) {
	const { t } = useT();
	const items = useCurrentAttachments(identityId).data ?? [];
	if (!items.length) return null;
	const open = async (path) => {
		try {
			window.open(await signedUrlFor(path), "_blank", "noopener,noreferrer");
		} catch (e) {
			toast.error(e.message);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5 border-t border-[var(--rm-line-soft)] pt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-bold uppercase tracking-[0.14em] text-[var(--rm-faint)]",
			children: t("identities.inspector.attachments")
		}), items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => open(a.storage_path),
			title: t("attachment.download"),
			className: "flex w-full items-center gap-2 rounded-md border border-[var(--rm-line-soft)] px-2.5 py-1.5 text-left transition-colors hover:bg-[var(--rm-panel-2)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-3.5 w-3.5 shrink-0 text-[var(--rm-dim)]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-xs font-medium text-[var(--rm-ink)]",
						children: pickLang(a.definition?.display_name) || a.definition?.custom_field_name || a.file_name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-[11px] text-[var(--rm-faint)]",
						children: a.file_name
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5 shrink-0 text-[var(--rm-dim)]" })
			]
		}, a.id))]
	});
}
function Metric({ icon, value, label, tone }) {
	const tint = tone === "brand" ? {
		background: "color-mix(in srgb, var(--rm-brand) 12%, transparent)",
		color: "var(--rm-brand-ink)"
	} : tone === "active" ? {
		background: "color-mix(in srgb, var(--rm-active) 16%, transparent)",
		color: "var(--rm-active-ink)"
	} : {
		background: "color-mix(in srgb, var(--rm-inactive) 14%, transparent)",
		color: "var(--rm-inactive-ink)"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn(panel, "flex items-center gap-3.5 p-4"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-11 w-11 place-items-center rounded-xl",
			style: tint,
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[22px] font-bold leading-none tracking-tight text-[var(--rm-ink)] tnum",
			children: value.toLocaleString("pt-BR")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1.5 text-[13px] text-[var(--rm-dim)]",
			children: label
		})] })]
	});
}
function EmptyState({ children, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("px-6 py-12 text-center text-sm", tone === "error" ? "text-destructive" : "text-[var(--rm-faint)]"),
		children
	});
}
function InspRow({ k, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 border-b border-dashed border-[var(--rm-line)] pb-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[10px] font-semibold uppercase tracking-[0.07em] text-[var(--rm-faint)]",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "min-w-0 truncate text-right",
			children
		})]
	});
}
//#endregion
export { IdentitiesList as component };
