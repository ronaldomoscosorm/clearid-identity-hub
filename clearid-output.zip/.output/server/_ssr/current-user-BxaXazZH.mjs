import "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as getConfig } from "./argus-client-fTtea6N-.mjs";
require_react();
async function fetchCurrentUser() {
	const url = `${getConfig().baseUrl.replace(/\/+$/, "")}/api/auth/me`;
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), 8e3);
	let res;
	try {
		res = await fetch(url, {
			method: "GET",
			credentials: "include",
			headers: { Accept: "application/json" },
			signal: controller.signal
		});
	} finally {
		clearTimeout(timer);
	}
	if (res.status === 401 || res.status === 403) return null;
	if (!res.ok) throw new Error(`Falha ao consultar /api/auth/me (HTTP ${res.status})`);
	return (await res.json()).data;
}
/**
* Hook que retorna o usuário logado. Retorna `null` quando não autenticado
* (o consumidor decide se redireciona pro login).
*
* Cache de 5 min — o perfil raramente muda dentro de uma sessão.
*/
function useCurrentUser() {
	return useQuery({
		queryKey: ["auth", "me"],
		queryFn: fetchCurrentUser,
		staleTime: 5 * 6e4,
		retry: false
	});
}
/**
* Helpers de permissão — mapeiam o perfil do JWT nas policies do backend.
*/
function isAdmin(user) {
	return user?.argusProfile?.toLowerCase() === "administrador";
}
//#endregion
export { useCurrentUser as n, isAdmin as t };
