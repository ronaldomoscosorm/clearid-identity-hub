//#region node_modules/.nitro/vite/services/ssr/assets/custom-fields-DtVKazAo.js
/** Tipo (custom_field_type) usado para os campos de anexo — só do sistema. */
var ATTACHMENT_FIELD_TYPE = "Attachment";
/** Classifica o tipo do campo (ClearID) em uma categoria de UI. */
function typeOf(t) {
	const s = (t ?? "").toLowerCase();
	if (/(attach|anexo|file|upload)/.test(s)) return "attachment";
	if (/(bool|boolean|switch|toggle|checkbox)/.test(s)) return "boolean";
	if (/(number|numeric|int|decimal|float)/.test(s)) return "number";
	if (/date|time/.test(s)) return "date";
	if (/(list|enum|option|select)/.test(s)) return "list";
	return "text";
}
/** Interpreta um valor string como booleano (formato do ClearID). */
function isTruthy(v) {
	return [
		"true",
		"1",
		"yes",
		"sim"
	].includes((v ?? "").trim().toLowerCase());
}
/** Resolve um texto multilíngue jsonb pelo idioma, com fallback para "default". */
function pickLang(v, lang = "pt-BR") {
	const o = v && typeof v === "object" ? v : {};
	return String(o[lang] ?? o["default"] ?? "");
}
/** Extrai as opções de um value_range de campo tipo lista. */
function optionsOf(v) {
	const o = v && typeof v === "object" ? v : {};
	return Array.isArray(o.options) ? o.options.map(String) : [];
}
//#endregion
export { typeOf as a, pickLang as i, isTruthy as n, optionsOf as r, ATTACHMENT_FIELD_TYPE as t };
