import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identity-labels-B1NFjUho.js
/** Chaves de campo sugeridas (para o editor de apelidos). */
var IDENTITY_FIELD_KEYS = [
	"first_name",
	"last_name",
	"middle_name",
	"display_name",
	"email",
	"identity_type",
	"status",
	"description",
	"country_code",
	"culture",
	"company_name",
	"company_job_title",
	"company_department_name",
	"company_supervisor_name",
	"company_site_id",
	"company_worker_type_code",
	"private_birthday",
	"private_employee_number",
	"private_secondary_email",
	"private_phone_primary",
	"private_phone_secondary",
	"system_external_id"
];
var STANDARD_IDENTITY_FIELDS = [
	{
		key: "company_worker_type_code",
		required: true
	},
	{
		key: "first_name",
		required: true
	},
	{
		key: "display_name",
		required: false
	},
	{
		key: "email",
		required: true
	},
	{
		key: "company_site_id",
		required: true
	},
	{
		key: "company_id",
		required: false
	},
	{
		key: "middle_name",
		required: false
	},
	{
		key: "description",
		required: false
	},
	{
		key: "country_code",
		required: false
	},
	{
		key: "culture",
		required: false
	},
	{
		key: "private_birthday",
		required: false
	},
	{
		key: "private_employee_number",
		required: false
	},
	{
		key: "private_secondary_email",
		required: false
	},
	{
		key: "private_city_of_residence",
		required: false
	},
	{
		key: "private_state_of_residence",
		required: false
	},
	{
		key: "private_zip_code",
		required: false
	},
	{
		key: "private_phone_primary",
		required: false
	},
	{
		key: "private_phone_secondary",
		required: false
	},
	{
		key: "company_name",
		required: false
	},
	{
		key: "company_job_title",
		required: false
	},
	{
		key: "company_department_name",
		required: false
	},
	{
		key: "company_supervisor_name",
		required: false
	}
];
var DEFAULT_INDEX = new Map(STANDARD_IDENTITY_FIELDS.map((f, i) => [f.key, i]));
function useIdentityFieldLabels(lang = "pt-BR") {
	const query = useQuery({
		queryKey: ["identity-field-labels"],
		queryFn: async () => {
			const { data, error } = await supabase.from("identity_field_labels").select("field_key, alias, is_visible, display_order");
			if (error) throw new Error(error.message);
			return data ?? [];
		},
		staleTime: 300 * 1e3
	});
	const map = new Map((query.data ?? []).map((r) => [r.field_key, r]));
	/** Retorna o apelido do campo no idioma ativo, com fallback para o texto padrão. */
	const alias = (fieldKey, fallback) => {
		const row = map.get(fieldKey);
		if (!row) return fallback;
		return pickLang(row.alias, lang) || fallback;
	};
	/**
	* Visibilidade do campo. Sem apelido cadastrado → visível (mostra tudo).
	* Só oculta quando existe um apelido com is_visible = false.
	*/
	const isVisible = (fieldKey) => {
		const row = map.get(fieldKey);
		return row ? row.is_visible : true;
	};
	/** Posição do campo: display_order do banco, ou a ordem default do catálogo. */
	const orderOf = (fieldKey) => {
		const row = map.get(fieldKey);
		if (row && row.display_order != null) return row.display_order;
		return DEFAULT_INDEX.get(fieldKey) ?? 999;
	};
	/** Ordena uma lista de field keys pela posição configurada. */
	const orderKeys = (keys) => [...keys].sort((a, b) => orderOf(a) - orderOf(b));
	return {
		alias,
		isVisible,
		orderOf,
		orderKeys,
		labels: query.data ?? [],
		loaded: query.isSuccess
	};
}
//#endregion
export { STANDARD_IDENTITY_FIELDS as n, useIdentityFieldLabels as r, IDENTITY_FIELD_KEYS as t };
