import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { t as IdentityPicturePanel } from "./IdentityPicturePanel-C-xh0PoR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IdentityPictureDialog-BNrWvmUR.js
var import_jsx_runtime = require_jsx_runtime();
function IdentityPictureDialog({ identityId, identityName, open, onOpenChange }) {
	const { t } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("pictureDialog.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: identityName ? t("pictureDialog.identity", { value: identityName }) : t("pictureDialog.identity", { value: identityId }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentityPicturePanel, { identityId })]
		})
	});
}
//#endregion
export { IdentityPictureDialog as t };
