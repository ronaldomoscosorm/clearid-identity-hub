import { t as supabase } from "./client-pXxOjxhm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-mirror--nGFXAER.js
var rec = (v) => v && typeof v === "object" ? v : {};
var str = (v) => v == null ? null : String(v);
var bool = (v) => v == null ? null : Boolean(v);
var int = (v) => v == null || v === "" ? null : Number.isFinite(Number(v)) ? Number(v) : null;
var jsonOrNull = (v) => v == null ? null : v;
function toIdentityRow(i) {
	const root = i;
	const priv = rec(i.privateData);
	const comp = rec(i.companyData);
	const sys = rec(i.systemData);
	return {
		account_id: i.accountId ?? null,
		identity_id: i.identityId,
		etag: i.eTag ?? null,
		first_name: i.firstName,
		last_name: i.lastName,
		middle_name: i.middleName ?? null,
		display_name: i.displayName ?? null,
		email: i.email ?? null,
		identity_type: i.identityType ?? null,
		status: i.status ?? "Active",
		description: i.description ?? null,
		country_code: i.countryCode ?? null,
		culture: i.culture ?? null,
		has_vehicles: bool(root.hasVehicles),
		has_licensed_vehicles: bool(root.hasLicensedVehicles),
		created_by: str(root.createdBy),
		creation_date_utc: i.creationDateUtc ?? null,
		creation_on_behalf: str(root.creationOnBehalf),
		last_modified_by: str(root.lastModifiedBy),
		last_modification_date_utc: i.lastModificationDateUtc ?? null,
		ordinal: int(root.ordinal),
		is_deleted: Boolean(root.isDeleted ?? false),
		private_picture_blob_name: str(priv.pictureBlobName),
		private_birthday: str(priv.birthday),
		private_employee_number: str(priv.employeeNumber),
		private_secondary_email: str(priv.secondaryEmail),
		private_city_of_residence: str(priv.cityOfResidence),
		private_state_of_residence: str(priv.stateOfResidence),
		private_zip_code: str(priv.zipCode),
		private_phone_primary: str(priv.phoneNumberPrimary),
		private_phone_secondary: str(priv.phoneNumberSecondary),
		company_name: str(comp.companyName),
		company_job_title: str(comp.jobTitle),
		company_department_name: str(comp.departmentName),
		company_supervisor_name: str(comp.supervisorName),
		company_site_id: str(comp.siteId),
		company_worker_type_code: str(comp.workerTypeCode) ?? i.workerTypeCode ?? null,
		company_worker_type_desc: str(comp.workerTypeDescription),
		company_approvers: jsonOrNull(comp.approvers),
		system_external_id: str(sys.externalId) ?? i.externalId ?? null,
		system_external_sync_source_id: str(sys.externalSyncSourceId),
		system_external_sync_time_utc: str(sys.externalSyncTimeUtc),
		system_horizon_id: str(sys.horizonId),
		system_activation_date_utc: str(sys.activationDateUtc),
		system_expiration_date_utc: str(sys.expirationDateUtc),
		system_has_extended_time: bool(sys.hasExtendedTime),
		system_can_escort: bool(sys.canEscort),
		system_antipassback_exemption: bool(sys.antipassbackExemption),
		system_trigger_code: int(sys.triggerCode),
		system_access_permission_level: int(sys.accessPermissionLevel),
		system_provisioning_attributes: jsonOrNull(sys.provisioningAttributes),
		system_custom_fields: jsonOrNull(sys.customFields),
		system_resource_filters: jsonOrNull(sys.resourceFilters)
	};
}
/**
* Faz upsert das identidades na tabela `identities` (por identity_id).
* LANÇA em caso de erro — callers passivos (listagens/cache) devem envolver em
* try/catch e apenas logar; o save atomic de identity precisa do throw para
* disparar a saga de compensação.
*/
async function mirrorIdentities(items) {
	if (!items?.length) return;
	const rows = items.filter((i) => i.identityId).map(toIdentityRow);
	if (!rows.length) return;
	const { error } = await supabase.from("identities").upsert(rows, { onConflict: "identity_id" });
	if (error) throw new Error(`Falha ao espelhar identidades: ${error.message}`);
}
/**
* Grava o vínculo da identidade com uma empresa (company_id) no Supabase.
* LANÇA em caso de erro.
*/
async function saveIdentityCompany(clearIdIdentityId, companyId) {
	if (!clearIdIdentityId) return;
	const { error } = await supabase.from("identities").update({ company_id: companyId }).eq("identity_id", clearIdIdentityId);
	if (error) throw new Error(`Falha ao gravar empresa da identidade: ${error.message}`);
}
/**
* Grava o tipo do trabalhador EXATO (worker_type_id) da identidade no Supabase.
* Necessário porque o workerTypeCode do Argus não distingue Visitante de Terceiro
* (ambos "Terceiros"); este valor garante o round-trip correto na edição.
* LANÇA em caso de erro — o worker_type só existe no Supabase; perder essa
* gravação corrompe a semântica de tipo.
*/
async function saveIdentityWorkerType(clearIdIdentityId, workerTypeId) {
	if (!clearIdIdentityId) return;
	const { error } = await supabase.from("identities").update({ worker_type_id: workerTypeId }).eq("identity_id", clearIdIdentityId);
	if (error) throw new Error(`Falha ao gravar tipo do trabalhador: ${error.message}`);
}
/**
* Grava os valores dos campos personalizados de uma identidade na tabela
* identity_custom_fields (vinculados aos campos do site). A identidade precisa
* já estar espelhada em `identities` (chame mirrorIdentities antes).
*/
async function saveIdentityCustomFields(clearIdIdentityId, values) {
	if (!clearIdIdentityId || !values?.length) return;
	const { data: idRow, error: e1 } = await supabase.from("identities").select("id").eq("identity_id", clearIdIdentityId).maybeSingle();
	if (e1 || !idRow) {
		if (e1) console.error("[mirror] identidade não encontrada p/ campos:", e1.message);
		return;
	}
	const rows = values.map((v) => ({
		identity_id: idRow.id,
		site_custom_field_id: v.site_custom_field_id,
		value: v.value
	}));
	const { error } = await supabase.from("identity_custom_fields").upsert(rows, { onConflict: "identity_id,site_custom_field_id" });
	if (error) console.error("[mirror] falha ao gravar campos da identidade:", error.message);
}
/** Faz upsert das definições globais de campos personalizados (por nome). */
async function mirrorCustomFieldDefs(defs) {
	if (!defs?.length) return;
	const rows = defs.filter((d) => d.customFieldName).map((d) => ({
		custom_field_name: d.customFieldName,
		display_name: d.displayName ? { default: d.displayName } : {},
		custom_field_type: d.customFieldType ?? null,
		is_read_only: d.isReadOnly ?? false,
		synchronization_enabled: d.synchronizationEnabled ?? true,
		is_deleted: d.isDeleted ?? false,
		etag: d.eTag ?? null
	}));
	if (!rows.length) return;
	const { error } = await supabase.from("custom_field_definitions").upsert(rows, { onConflict: "custom_field_name" });
	if (error) console.error("[mirror] falha ao espelhar definições de campos:", error.message);
}
//#endregion
export { saveIdentityWorkerType as a, saveIdentityCustomFields as i, mirrorIdentities as n, saveIdentityCompany as r, mirrorCustomFieldDefs as t };
