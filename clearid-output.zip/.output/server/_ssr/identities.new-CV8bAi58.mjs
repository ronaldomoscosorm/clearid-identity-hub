import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identities.new-CV8bAi58.js
var $$splitComponentImporter = () => import("./identities.new-Cpt02fox.mjs");
var Route = createFileRoute("/_authenticated/identities/new")({
	head: () => ({ meta: [{ title: "Nova identity — Argus ClearID" }] }),
	validateSearch: (search) => ({ type: typeof search.type === "string" ? search.type : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
