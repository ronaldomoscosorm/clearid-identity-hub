import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-pXxOjxhm.mjs";
import { i as pickLang } from "./custom-fields-DtVKazAo.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as IDENTITY_FIELD_KEYS } from "./identity-labels-B1NFjUho.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Switch } from "./switch-DtEVXaE2.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { T as Pencil, l as Trash2, u as Tag, w as Plus, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apelidos-DGJl0RLx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_FORM = {
	field_key: "",
	ptBR: "",
	enUS: "",
	esES: "",
	display_index: "",
	is_visible: true
};
function ApelidosPage() {
	const { t } = useT();
	const qc = useQueryClient();
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(EMPTY_FORM);
	const [toDelete, setToDelete] = (0, import_react.useState)(null);
	const query = useQuery({
		queryKey: ["identity-field-labels-admin"],
		queryFn: async () => {
			const { data, error } = await supabase.from("identity_field_labels").select("*").order("display_index", {
				ascending: true,
				nullsFirst: false
			}).order("field_key", { ascending: true });
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const upsert = useMutation({
		mutationFn: async (f) => {
			const alias = {};
			if (f.ptBR.trim()) alias["pt-BR"] = f.ptBR.trim();
			if (f.enUS.trim()) alias["en-US"] = f.enUS.trim();
			if (f.esES.trim()) alias["es-ES"] = f.esES.trim();
			const payload = {
				field_key: f.field_key.trim(),
				alias,
				display_index: f.display_index.trim() ? Number(f.display_index) : null,
				is_visible: f.is_visible
			};
			if (editing) {
				const { error } = await supabase.from("identity_field_labels").update(payload).eq("id", editing.id);
				if (error) throw new Error(error.message);
			} else {
				const { error } = await supabase.from("identity_field_labels").insert(payload);
				if (error) throw new Error(error.message);
			}
		},
		onSuccess: () => {
			toast.success(editing ? t("aliases.toast.updated") : t("aliases.toast.created"));
			qc.invalidateQueries({ queryKey: ["identity-field-labels-admin"] });
			qc.invalidateQueries({ queryKey: ["identity-field-labels"] });
			setDialogOpen(false);
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("identity_field_labels").delete().eq("id", id);
			if (error) throw new Error(error.message);
		},
		onSuccess: () => {
			toast.success(t("aliases.toast.removed"));
			qc.invalidateQueries({ queryKey: ["identity-field-labels-admin"] });
			qc.invalidateQueries({ queryKey: ["identity-field-labels"] });
			setToDelete(null);
		},
		onError: (e) => toast.error(e.message)
	});
	const openCreate = () => {
		setEditing(null);
		setForm(EMPTY_FORM);
		setDialogOpen(true);
	};
	const openEdit = (row) => {
		setEditing(row);
		setForm({
			field_key: row.field_key,
			ptBR: pickLang(row.alias, "pt-BR"),
			enUS: pickLang(row.alias, "en-US"),
			esES: pickLang(row.alias, "es-ES"),
			display_index: row.display_index == null ? "" : String(row.display_index),
			is_visible: row.is_visible
		});
		setDialogOpen(true);
	};
	const submit = () => {
		if (!form.field_key.trim()) {
			toast.error(t("aliases.validation.fieldKeyRequired"));
			return;
		}
		if (!form.ptBR.trim() && !form.enUS.trim()) {
			toast.error(t("aliases.validation.aliasRequired"));
			return;
		}
		upsert.mutate(form);
	};
	const items = query.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight text-foreground",
					children: t("aliases.title")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: t("aliases.subtitle")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => query.refetch(),
						disabled: query.isFetching,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `mr-1 h-4 w-4 ${query.isFetching ? "animate-spin" : ""}` }), t("aliases.refresh")]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: openCreate,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }),
							" ",
							t("aliases.newButton")
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: query.data ? items.length === 1 ? t("aliases.countOne", { count: items.length }) : t("aliases.countMany", { count: items.length }) : t("aliases.cardTitle")
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-full" })]
			}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
				children: query.error.message
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: t("aliases.emptyState")
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("aliases.col.field") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "pt-BR" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "en-US" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("aliases.col.visible") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
					className: "w-[100px] text-right",
					children: t("common.actions")
				})
			] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: items.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-mono text-xs",
					children: row.field_key
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: pickLang(row.alias, "pt-BR") || "—" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-muted-foreground",
					children: pickLang(row.alias, "en-US") || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: row.is_visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: t("common.yes")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: t("common.no")
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => openEdit(row),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "text-destructive hover:text-destructive",
							onClick: () => setToDelete(row),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})]
					})
				})
			] }, row.id)) })] }) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: dialogOpen,
				onOpenChange: setDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-[520px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "h-5 w-5" }), editing ? t("aliases.dialog.editTitle") : t("aliases.dialog.newTitle")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("aliases.dialog.description") })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "field_key",
											children: t("aliases.form.fieldKeyLabel")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "field_key",
											list: "identity-field-keys",
											value: form.field_key,
											onChange: (e) => setForm((f) => ({
												...f,
												field_key: e.target.value
											})),
											placeholder: t("aliases.form.fieldKeyPlaceholder"),
											disabled: Boolean(editing)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
											id: "identity-field-keys",
											children: IDENTITY_FIELD_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: k }, k))
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("aliases.form.aliasLabel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.ptBR,
												onChange: (e) => setForm((f) => ({
													...f,
													ptBR: e.target.value
												})),
												placeholder: "pt-BR"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.enUS,
												onChange: (e) => setForm((f) => ({
													...f,
													enUS: e.target.value
												})),
												placeholder: "en-US"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: form.esES,
												onChange: (e) => setForm((f) => ({
													...f,
													esES: e.target.value
												})),
												placeholder: "es-ES"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 items-end gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t("aliases.form.orderLabel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											value: form.display_index,
											onChange: (e) => setForm((f) => ({
												...f,
												display_index: e.target.value
											})),
											placeholder: "0"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											checked: form.is_visible,
											onCheckedChange: (v) => setForm((f) => ({
												...f,
												is_visible: v
											}))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "cursor-pointer",
											children: t("aliases.col.visible")
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDialogOpen(false),
							children: t("common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: submit,
							disabled: upsert.isPending,
							children: upsert.isPending ? t("common.saving") : t("common.save")
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: Boolean(toDelete),
				onOpenChange: (o) => !o && setToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("aliases.delete.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					t("aliases.delete.confirmPrefix"),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono",
						children: toDelete?.field_key
					}),
					"?"
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					onClick: () => toDelete && remove.mutate(toDelete.id),
					disabled: remove.isPending,
					children: remove.isPending ? t("aliases.delete.removing") : t("aliases.delete.confirm")
				})] })] })
			})
		]
	});
}
//#endregion
export { ApelidosPage as component };
