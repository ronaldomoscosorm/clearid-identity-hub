import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terceirizados._id-D2ukSORI.js
var $$splitComponentImporter = () => import("./terceirizados._id-DoGzUoCO.mjs");
var Route = createFileRoute("/_authenticated/terceirizados/$id")({
	head: () => ({ meta: [{ title: "Terceirizado — Argus ClearID" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
