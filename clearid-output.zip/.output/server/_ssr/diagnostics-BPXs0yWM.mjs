import { t as supabase } from "./client-pXxOjxhm.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Badge } from "./badge-B3f60TId.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-C5Nmk_bj.mjs";
import { X as Database, gt as Activity, rt as CircleCheck, tt as CircleX, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { b as useArgusConfig, r as argusApi } from "./argus-client-fTtea6N-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diagnostics-BPXs0yWM.js
var import_jsx_runtime = require_jsx_runtime();
var DOMAIN_TABLES = [
	"identities",
	"companies",
	"custom_field_definitions",
	"site_custom_fields",
	"identity_custom_fields",
	"company_custom_fields",
	"identity_field_labels",
	"settings"
];
async function getSupabaseStatus() {
	const projectId = "keyddqiaeqzfwdamublk";
	const url = "https://keyddqiaeqzfwdamublk.supabase.co";
	const { data: userData } = await supabase.auth.getUser();
	const authenticated = Boolean(userData.user?.id);
	const results = await Promise.all(DOMAIN_TABLES.map(async (table) => {
		const { count, error } = await supabase.from(table).select("*", {
			count: "exact",
			head: true
		});
		return {
			table,
			count: error ? null : count ?? 0
		};
	}));
	const reachable = results.some((r) => r.count !== null);
	const firstError = results.find((r) => r.count === null);
	return {
		projectId,
		url,
		reachable,
		authenticated,
		tables: results,
		error: reachable ? void 0 : firstError ? "Falha ao consultar as tabelas" : void 0
	};
}
function StatRow({ label, value, ok }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between border-b py-2 text-sm last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2 font-medium text-foreground",
			children: [typeof ok === "boolean" && (ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-[var(--success)]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4 text-destructive" })), value]
		})]
	});
}
function Diagnostics() {
	const { t } = useT();
	const config = useArgusConfig();
	const query = useQuery({
		queryKey: ["diagnostics", config.baseUrl],
		queryFn: argusApi.diagnostics,
		refetchInterval: 3e4,
		retry: false
	});
	const env = query.data?.environment ?? "—";
	const supa = useQuery({
		queryKey: ["supabase-status"],
		queryFn: getSupabaseStatus,
		refetchInterval: 6e4,
		retry: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-foreground",
				children: t("diagnostics.title")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: t("diagnostics.subtitle")
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => query.refetch(),
				disabled: query.isFetching,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: query.isFetching ? "mr-1 h-4 w-4 animate-spin" : "mr-1 h-4 w-4" }), t("diagnostics.refresh")]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center gap-2 text-base",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-4 w-4" }),
						" ",
						t("diagnostics.environment")
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.environment"),
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: env === "prod" ? "default" : "secondary",
							children: env
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.clientCode"),
						value: query.data?.clientCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-xs",
							children: query.data.clientCode
						}) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.baseUrl"),
						value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-xs",
							children: config.baseUrl || "—"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.apiKeyConfigured"),
						value: config.apiKey ? t("common.yes") : t("common.no")
					})
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: t("diagnostics.backend")
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full" }) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm text-destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 font-medium",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4" }),
							" ",
							t("diagnostics.unreachable")
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: query.error.message
					})]
				}) : query.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.reachable"),
						value: query.data.backend.reachable ? t("common.yes") : t("common.no"),
						ok: query.data.backend.reachable
					}),
					typeof query.data.backend.latencyMs === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.latency"),
						value: `${query.data.backend.latencyMs} ms`
					}),
					typeof query.data.backend.status === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.httpStatus"),
						value: String(query.data.backend.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
						label: t("diagnostics.lastCheck"),
						value: new Date(query.data.checkedAt).toLocaleTimeString()
					})
				] }) : null })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "flex items-center gap-2 text-base",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "h-4 w-4" }),
							" ",
							t("diagnostics.supabaseTitle")
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: supa.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full" }) : supa.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 font-medium",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4" }),
								" ",
								t("diagnostics.unreachable")
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: supa.error.message
						})]
					}) : supa.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-x-8 gap-y-0 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
								label: t("diagnostics.connection"),
								value: supa.data.reachable ? t("diagnostics.ok") : t("diagnostics.fail"),
								ok: supa.data.reachable
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
								label: t("diagnostics.project"),
								value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "text-xs",
									children: supa.data.projectId
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
								label: t("diagnostics.url"),
								value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "text-xs",
									children: supa.data.url
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
								label: t("diagnostics.authenticatedSession"),
								value: supa.data.authenticated ? t("common.yes") : t("common.no"),
								ok: supa.data.authenticated
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: supa.data.tables.map((tbl) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {
							label: tbl.table,
							value: tbl.count === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: t("diagnostics.error")
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: tbl.count
							})
						}, tbl.table)) })]
					}) : null })]
				})
			]
		})]
	});
}
//#endregion
export { Diagnostics as component };
