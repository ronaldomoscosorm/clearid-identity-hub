import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { i as User, s as Upload, t as X, ut as Camera } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as WebcamDialog } from "./IdentityPicturePanel-C-xh0PoR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PhotoCapture-DfwwRG7z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Captura de foto (webcam / arquivo) que NÃO faz upload — guarda o blob
* localmente e devolve por `onChange`. Usada em cadastros onde a foto só pode
* ser enviada depois (ex.: nova identity, cujo id só existe após a criação).
*/
function PhotoCapture({ value, onChange }) {
	const { t } = useT();
	const [webcamOpen, setWebcamOpen] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!value) {
			setPreview(null);
			return;
		}
		const u = URL.createObjectURL(value);
		setPreview(u);
		return () => URL.revokeObjectURL(u);
	}, [value]);
	const pick = (blob) => {
		if (!blob.type.startsWith("image/")) {
			toast.error(t("photoCapture.notImage"));
			return;
		}
		onChange(blob);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-32 w-32 shrink-0 items-center justify-center overflow-hidden rounded-md border bg-muted",
				children: preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: t("photoCapture.previewAlt"),
					className: "h-full w-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-10 w-10 text-muted-foreground" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: t("photoCapture.title")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: value ? t("photoCapture.ready") : t("photoCapture.optional")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => setWebcamOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-1 h-4 w-4" }),
									" ",
									t("photoCapture.takePhoto")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => fileRef.current?.click(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-1 h-4 w-4" }),
									" ",
									t("photoCapture.uploadFile")
								]
							}),
							value && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "ghost",
								className: "text-destructive hover:text-destructive",
								onClick: () => onChange(null),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mr-1 h-4 w-4" }),
									" ",
									t("common.remove")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) pick(f);
									e.target.value = "";
								}
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebcamDialog, {
				open: webcamOpen,
				onOpenChange: setWebcamOpen,
				uploading: false,
				onCapture: (blob) => {
					pick(blob);
					setWebcamOpen(false);
				}
			})
		]
	});
}
//#endregion
export { PhotoCapture as t };
