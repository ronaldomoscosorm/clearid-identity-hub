import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { Q as ClipboardPaste, i as User, s as Upload, t as X, ut as Camera, x as RefreshCw } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useDefaultSiteId, r as argusApi } from "./argus-client-fTtea6N-.mjs";
import { n as SilhouetteGuide, r as usePersonDetection, t as PersonBadge } from "./CameraGuide-4uqiXU09.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/IdentityPicturePanel-C-xh0PoR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function toJpeg(t, blob, quality = .92) {
	const bitmap = await createImageBitmap(blob);
	const canvas = document.createElement("canvas");
	canvas.width = bitmap.width;
	canvas.height = bitmap.height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error(t("picturePanel.canvasUnavailable"));
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.drawImage(bitmap, 0, 0);
	return await new Promise((resolve, reject) => {
		canvas.toBlob((b) => b ? resolve(b) : reject(new Error(t("picturePanel.convertError"))), "image/jpeg", quality);
	});
}
function IdentityPicturePanel({ identityId }) {
	const { t } = useT();
	const qc = useQueryClient();
	const siteId = useDefaultSiteId();
	const [url, setUrl] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [pasteBlob, setPasteBlob] = (0, import_react.useState)(null);
	const [pasteUrl, setPasteUrl] = (0, import_react.useState)(null);
	const fileInputRef = (0, import_react.useRef)(null);
	const q = useQuery({
		queryKey: [
			"identity-picture",
			siteId,
			identityId
		],
		queryFn: () => argusApi.getIdentityPicture(identityId),
		retry: false
	});
	(0, import_react.useEffect)(() => {
		if (!q.data) {
			setUrl(null);
			return;
		}
		const u = URL.createObjectURL(q.data);
		setUrl(u);
		return () => URL.revokeObjectURL(u);
	}, [q.data]);
	const upload = useMutation({
		mutationFn: (blob) => argusApi.uploadIdentityPicture(identityId, blob),
		onSuccess: async () => {
			toast.success(t("picturePanel.toast.updated"));
			await Promise.all([qc.invalidateQueries({ queryKey: [
				"identity-picture",
				siteId,
				identityId
			] }), qc.invalidateQueries({ queryKey: [
				"identity",
				siteId,
				identityId
			] })]);
			qc.invalidateQueries({ queryKey: ["identity-picture"] });
			qc.invalidateQueries({ queryKey: ["identity"] });
			setOpen(false);
			clearPaste();
		},
		onError: (e) => toast.error(e.message)
	});
	const clearPaste = () => {
		setPasteBlob(null);
		setPasteUrl((prev) => {
			if (prev) URL.revokeObjectURL(prev);
			return null;
		});
	};
	const handleBlob = async (blob) => {
		if (!blob.type.startsWith("image/")) {
			toast.error(t("picturePanel.toast.notImage"));
			return;
		}
		try {
			const jpeg = blob.type === "image/jpeg" ? blob : await toJpeg(t, blob);
			clearPaste();
			setPasteBlob(jpeg);
			setPasteUrl(URL.createObjectURL(jpeg));
		} catch (e) {
			toast.error(t("picturePanel.toast.processError", { message: e.message }));
		}
	};
	const pasteFromClipboard = async () => {
		try {
			if (navigator.clipboard?.read) {
				const items = await navigator.clipboard.read();
				for (const item of items) {
					const type = item.types.find((t) => t.startsWith("image/"));
					if (type) {
						const blob = await item.getType(type);
						await handleBlob(blob);
						return;
					}
				}
				toast.message(t("picturePanel.toast.noImageFound"));
				return;
			}
			toast.message(t("picturePanel.toast.pressCtrlV"));
		} catch {
			toast.message(t("picturePanel.toast.pressCtrlV"));
		}
	};
	(0, import_react.useEffect)(() => {
		const onPaste = (e) => {
			const items = e.clipboardData?.items;
			if (!items) return;
			for (const item of items) if (item.kind === "file" && item.type.startsWith("image/")) {
				const file = item.getAsFile();
				if (file) {
					e.preventDefault();
					handleBlob(file);
					return;
				}
			}
		};
		window.addEventListener("paste", onPaste);
		return () => window.removeEventListener("paste", onPaste);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-32 w-32 shrink-0 items-center justify-center overflow-hidden rounded-md border bg-muted",
				children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: url,
					alt: t("picturePanel.imgAlt"),
					className: "h-full w-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-10 w-10 text-muted-foreground" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: t("picturePanel.biometricPhoto")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							url ? t("picturePanel.registered") : t("picturePanel.notRegistered"),
							" ",
							t("picturePanel.pasteHint")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => setOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-1 h-4 w-4" }),
									" ",
									t("picturePanel.takePhoto")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: pasteFromClipboard,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "mr-1 h-4 w-4" }),
									" ",
									t("picturePanel.pasteImage")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => fileInputRef.current?.click(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-1 h-4 w-4" }),
									" ",
									t("picturePanel.uploadFile")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileInputRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => {
									const file = e.target.files?.[0];
									if (file) handleBlob(file);
									e.target.value = "";
								}
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebcamDialog, {
				open,
				onOpenChange: setOpen,
				onCapture: (blob) => upload.mutate(blob),
				uploading: upload.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!pasteBlob,
				onOpenChange: (o) => {
					if (upload.isPending) return;
					if (!o) clearPaste();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("picturePanel.confirmPasteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("picturePanel.confirmPasteDescription") })] }),
					pasteUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-md border bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: pasteUrl,
							alt: t("picturePanel.previewAlt"),
							className: "mx-auto max-h-64 object-contain"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						disabled: upload.isPending,
						children: t("common.cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						disabled: upload.isPending || !pasteBlob,
						onClick: (e) => {
							e.preventDefault();
							if (pasteBlob) upload.mutate(pasteBlob);
						},
						children: upload.isPending ? t("picturePanel.sending") : t("picturePanel.yesSave")
					})] })
				] })
			})
		]
	});
}
function WebcamDialog({ open, onOpenChange, onCapture, uploading }) {
	const { t } = useT();
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const [snapshot, setSnapshot] = (0, import_react.useState)(null);
	const [snapshotBlob, setSnapshotBlob] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const personDetected = usePersonDetection(videoRef, open && !err && !snapshot);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		let cancelled = false;
		setErr(null);
		setSnapshot(null);
		setSnapshotBlob(null);
		navigator.mediaDevices.getUserMedia({
			video: { facingMode: "user" },
			audio: false
		}).then((stream) => {
			if (cancelled) {
				stream.getTracks().forEach((t) => t.stop());
				return;
			}
			streamRef.current = stream;
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				videoRef.current.play().catch(() => {});
			}
		}).catch((e) => setErr(e.message));
		return () => {
			cancelled = true;
			streamRef.current?.getTracks().forEach((t) => t.stop());
			streamRef.current = null;
		};
	}, [open]);
	const capture = () => {
		const video = videoRef.current;
		if (!video) return;
		const w = video.videoWidth;
		const h = video.videoHeight;
		if (!w || !h) return;
		const canvas = document.createElement("canvas");
		canvas.width = w;
		canvas.height = h;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.drawImage(video, 0, 0, w, h);
		canvas.toBlob((blob) => {
			if (!blob) return;
			setSnapshotBlob(blob);
			setSnapshot(URL.createObjectURL(blob));
			setConfirmOpen(true);
		}, "image/jpeg", .92);
	};
	const retake = () => {
		if (snapshot) URL.revokeObjectURL(snapshot);
		setSnapshot(null);
		setSnapshotBlob(null);
		setConfirmOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("picturePanel.captureTitle") }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative aspect-video w-full overflow-hidden rounded-md border bg-black",
					children: err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full items-center justify-center p-4 text-center text-sm text-destructive",
						children: err
					}) : snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: snapshot,
						alt: t("picturePanel.captureAlt"),
						className: "h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							ref: videoRef,
							className: "h-full w-full object-cover",
							playsInline: true,
							muted: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SilhouetteGuide, { state: personDetected === null ? "neutral" : personDetected ? "ok" : "warn" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonBadge, { detected: personDetected })
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mr-1 h-4 w-4" }),
							" ",
							t("common.cancel")
						]
					}), snapshot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: retake,
						disabled: uploading,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "mr-1 h-4 w-4" }),
							" ",
							t("picturePanel.retake")
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: capture,
						disabled: !!err,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "mr-1 h-4 w-4" }),
							" ",
							t("picturePanel.capture")
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
					open: confirmOpen,
					onOpenChange: (o) => {
						if (uploading) return;
						setConfirmOpen(o);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("picturePanel.confirmPhotoTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("picturePanel.confirmPhotoDescription") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						disabled: uploading,
						onClick: () => retake(),
						children: t("picturePanel.noRetake")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						disabled: uploading || !snapshotBlob,
						onClick: (e) => {
							e.preventDefault();
							if (snapshotBlob) onCapture(snapshotBlob);
						},
						children: uploading ? t("picturePanel.sending") : t("picturePanel.yesSave")
					})] })] })
				})
			]
		})
	});
}
//#endregion
export { WebcamDialog as n, IdentityPicturePanel as t };
