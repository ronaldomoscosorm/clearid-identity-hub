import { o as __toESM } from "../_runtime.mjs";
import { i as require_react } from "../_libs/dnd-kit__accessibility+react.mjs";
import { L as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as useT } from "./i18n-Box3vBJj.mjs";
import { t as Button } from "./button-PwNqyxv_.mjs";
import { t as Input } from "./input-uzm9g8Y7.mjs";
import { t as Label } from "./label-BeT0bXvu.mjs";
import { t as Skeleton } from "./skeleton-DcnTQsWF.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-BcaWptOW.mjs";
import { L as KeyRound, P as LoaderCircle, l as Trash2, w as Plus } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-BvYONHWJ.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-Bz_ok53Q.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as getAccountId, r as argusApi, w as useSystemObjectId } from "./argus-client-fTtea6N-.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DamjaduW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/CredentialsDialog-Dh7PlQvT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fmtDate(v) {
	if (!v) return "—";
	const d = new Date(v);
	if (Number.isNaN(d.getTime())) return v;
	return d.toLocaleDateString("pt-BR");
}
function toIsoOrNull(v) {
	if (!v) return null;
	const d = /* @__PURE__ */ new Date(`${v}T00:00:00Z`);
	return Number.isNaN(d.getTime()) ? null : d.toISOString();
}
function CredentialsDialog({ identityId }) {
	const { t } = useT();
	const [open, setOpen] = (0, import_react.useState)(false);
	const systemObjectId = useSystemObjectId();
	const accountId = getAccountId();
	const canQuery = Boolean(systemObjectId && accountId);
	const [formatId, setFormatId] = (0, import_react.useState)("");
	const [facilityCode, setFacilityCode] = (0, import_react.useState)("");
	const [cardNumber, setCardNumber] = (0, import_react.useState)("");
	const [activation, setActivation] = (0, import_react.useState)("");
	const [expiration, setExpiration] = (0, import_react.useState)("");
	const qc = useQueryClient();
	const formatsQuery = useQuery({
		queryKey: [
			"credential-formats",
			systemObjectId,
			accountId
		],
		queryFn: () => argusApi.listCredentialFormats(),
		enabled: open && canQuery,
		staleTime: 300 * 1e3
	});
	const credsQuery = useQuery({
		queryKey: ["credentials", identityId],
		queryFn: () => argusApi.listCredentials(identityId),
		enabled: open
	});
	const create = useMutation({
		mutationFn: (data) => argusApi.createCredential(data),
		onSuccess: () => {
			toast.success(t("credentials.toast.created"));
			qc.invalidateQueries({ queryKey: ["credentials", identityId] });
			setFormatId("");
			setFacilityCode("");
			setCardNumber("");
			setActivation("");
			setExpiration("");
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const remove = useMutation({
		mutationFn: (credentialId) => argusApi.deleteCredential(credentialId),
		onSuccess: () => {
			toast.success(t("credentials.toast.deleted"));
			qc.invalidateQueries({ queryKey: ["credentials", identityId] });
		},
		onError: (e) => {
			const err = e;
			toast.error(err.message, { description: err.traceId ? `TraceId: ${err.traceId}` : void 0 });
		}
	});
	const canSubmit = !!formatId && !!cardNumber.trim() && !create.isPending;
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!canSubmit) return;
		create.mutate({
			identityId,
			formatId,
			facilityCode: facilityCode.trim() || null,
			cardNumber: cardNumber.trim(),
			activationDateUtc: toIsoOrNull(activation),
			expirationDateUtc: toIsoOrNull(expiration)
		});
	};
	const formatName = (id) => formatsQuery.data?.find((f) => f.formatId === id)?.name ?? id ?? "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "mr-1 h-4 w-4" }),
					" ",
					t("credentials.title")
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("credentials.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("credentials.description") })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cred-format",
									children: t("credentials.field.format")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: formatId,
									onValueChange: setFormatId,
									disabled: !canQuery || formatsQuery.isLoading || !!formatsQuery.error,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "cred-format",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: !canQuery ? t("credentials.format.placeholderNoConfig") : formatsQuery.isLoading ? t("common.loading") : formatsQuery.error ? t("credentials.format.placeholderError") : (formatsQuery.data ?? []).length === 0 ? t("credentials.format.placeholderEmpty") : t("credentials.format.placeholder") })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (formatsQuery.data ?? []).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: f.formatId,
										children: f.name
									}, f.formatId)) })]
								}),
								formatsQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-destructive",
									children: formatsQuery.error.message
								}),
								!canQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: t("credentials.format.configHint")
								}),
								canQuery && !formatsQuery.isLoading && !formatsQuery.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: t("credentials.format.availableCount", { count: (formatsQuery.data ?? []).length })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cred-facility",
							children: t("credentials.field.facilityCode")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cred-facility",
							value: facilityCode,
							onChange: (e) => setFacilityCode(e.target.value),
							inputMode: "numeric"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cred-card",
							children: t("credentials.field.cardNumber")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cred-card",
							value: cardNumber,
							onChange: (e) => setCardNumber(e.target.value),
							inputMode: "numeric",
							required: true
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cred-activation",
							children: t("credentials.field.activation")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cred-activation",
							type: "date",
							value: activation,
							onChange: (e) => setActivation(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cred-expiration",
							children: t("credentials.field.expiration")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cred-expiration",
							type: "date",
							value: expiration,
							onChange: (e) => setExpiration(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sm:col-span-2 flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								disabled: !canSubmit,
								children: [create.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 h-4 w-4" }), t("common.save")]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-2 text-sm font-semibold",
						children: t("credentials.listTitle")
					}), credsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })]
					}) : credsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: credsQuery.error.message
					}) : (credsQuery.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: t("credentials.emptyState")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-h-64 overflow-auto rounded-md border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.name") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("credentials.col.type") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("credentials.col.facility") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("credentials.col.card") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("credentials.field.activation") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("credentials.field.expiration") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: t("common.status") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-10" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: (credsQuery.data ?? []).map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.name ?? "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.formatName ?? formatName(c.formatId) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.facilityCode ?? "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.cardNumber ?? "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: fmtDate(c.activationDateUtc) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: fmtDate(c.expirationDateUtc) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.status ?? "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: c.credentialId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "h-8 w-8 text-destructive hover:text-destructive",
									disabled: remove.isPending,
									"aria-label": t("credentials.deleteAria"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("credentials.deleteConfirmTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("credentials.deleteConfirmDescription", { name: c.name ?? c.cardNumber ?? "" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
								onClick: () => remove.mutate(c.credentialId),
								children: t("common.delete")
							})] })] })] }) : null })
						] }, c.credentialId ?? i)) })] })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => setOpen(false),
					children: t("common.close")
				}) })
			]
		})]
	});
}
//#endregion
export { CredentialsDialog as t };
