//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BFfric2K.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/foto/$token"
		],
		preloads: [
			"/assets/index-CM8pIUBn.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/jsx-runtime-DRF4vMFQ.js",
			"/assets/react-dom-CEVbmmCH.js",
			"/assets/useStore-DLRajplM.js",
			"/assets/Match-CYF2oa3B.js",
			"/assets/matchContext-CENV2JN6.js",
			"/assets/link-D598-iML.js",
			"/assets/lazyRouteComponent-DPANSoMT.js",
			"/assets/client-CII52-eM.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/QueryClientProvider-CBSNk7VU.js",
			"/assets/argus-client-ByG8kf7V.js",
			"/assets/branding-ApGiJ1wz.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CM8pIUBn.js"
		} }]
	},
	"/": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DJ7LAi8J.js"]
	},
	"/_authenticated": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/apelidos",
			"/_authenticated/branding",
			"/_authenticated/campanhas-foto",
			"/_authenticated/campos-do-site",
			"/_authenticated/campos-personalizados",
			"/_authenticated/configuracoes-cliente",
			"/_authenticated/diagnostics",
			"/_authenticated/empresas",
			"/_authenticated/identities",
			"/_authenticated/importar",
			"/_authenticated/layout-formulario",
			"/_authenticated/regras",
			"/_authenticated/settings",
			"/_authenticated/tipos-trabalhador",
			"/_authenticated/terceirizados/$id",
			"/_authenticated/visitas/nova",
			"/_authenticated/terceirizados/",
			"/_authenticated/visitas/"
		],
		preloads: [
			"/assets/route-CAvP8chW.js",
			"/assets/useMatch-KJVpuKdT.js",
			"/assets/useQuery-B5Z9JMjv.js",
			"/assets/button-ymfswjnW.js",
			"/assets/database-BKPlNJ9f.js",
			"/assets/arrow-left-7lW3nen1.js",
			"/assets/briefcase-business-CtPfZ7Fm.js",
			"/assets/building-2-CQbQ7Yt6.js",
			"/assets/camera-pQCPZoP4.js",
			"/assets/check-Blu5MfpC.js",
			"/assets/dist-BATWxhHZ.js",
			"/assets/dropdown-menu-doZfu7fU.js",
			"/assets/hourglass-BAdvOfu1.js",
			"/assets/list-checks-BhoYAqbg.js",
			"/assets/loader-circle-y8_I5plS.js",
			"/assets/log-out-CQeIanrK.js",
			"/assets/skeleton-De01zw5A.js",
			"/assets/settings-2-BvbVzZcA.js",
			"/assets/shield-check-C6MWZFHk.js",
			"/assets/sliders-horizontal-BHrsfZ20.js",
			"/assets/tag-DTZdlFLg.js",
			"/assets/triangle-alert-BldsQOSp.js",
			"/assets/upload-tTpgWLcH.js",
			"/assets/users-3ZZQknvv.js",
			"/assets/dist-lEYgMziq.js",
			"/assets/custom-fields-C7QSSsUi.js",
			"/assets/i18n-BBjNVUCL.js",
			"/assets/input-DFTNPuw7.js",
			"/assets/dist-1ujI-9ms.js",
			"/assets/es2015-9G6OCaRj.js",
			"/assets/theme-CAZBmoUW.js",
			"/assets/PoweredBy-jHcGkbw2.js",
			"/assets/supabase-mirror-NZx-xKci.js",
			"/assets/current-user-DITjwRne.js",
			"/assets/user-scope-CZlnLHr1.js"
		]
	},
	"/_authenticated/apelidos": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/apelidos.tsx",
		children: void 0,
		preloads: [
			"/assets/apelidos-CQkfkPZz.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/identity-labels-C_dWwHpx.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/switch-Czyd6i5T.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js"
		]
	},
	"/_authenticated/branding": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/branding.tsx",
		children: void 0,
		preloads: [
			"/assets/branding-DCLyUAlc.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/card-CeXlCuWD.js"
		]
	},
	"/_authenticated/campanhas-foto": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/campanhas-foto.tsx",
		children: void 0,
		preloads: [
			"/assets/campanhas-foto-C9-fLXBR.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/eye--hi3N952.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js"
		]
	},
	"/_authenticated/campos-do-site": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/campos-do-site.tsx",
		children: void 0,
		preloads: [
			"/assets/campos-do-site-xhhgihMO.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/switch-Czyd6i5T.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/textarea-7YELtNGR.js"
		]
	},
	"/_authenticated/campos-personalizados": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/campos-personalizados.tsx",
		children: void 0,
		preloads: [
			"/assets/campos-personalizados-BPznvF1J.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/paperclip-BQ8fmcKO.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/client-settings-DY6oLSVs.js",
			"/assets/special-fields-DRtkncnN.js"
		]
	},
	"/_authenticated/configuracoes-cliente": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/configuracoes-cliente.tsx",
		children: void 0,
		preloads: [
			"/assets/configuracoes-cliente-lOMZNBaN.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/client-settings-DY6oLSVs.js"
		]
	},
	"/_authenticated/diagnostics": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/diagnostics.tsx",
		children: void 0,
		preloads: [
			"/assets/diagnostics-ovWFmXRO.js",
			"/assets/circle-check-4VfgK2hL.js",
			"/assets/circle-x-0sKojHfu.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js"
		]
	},
	"/_authenticated/empresas": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/empresas.tsx",
		children: void 0,
		preloads: [
			"/assets/empresas-CxS8yqBR.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/textarea-7YELtNGR.js"
		]
	},
	"/_authenticated/identities": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/identities.tsx",
		children: [
			"/_authenticated/identities/$id",
			"/_authenticated/identities/new",
			"/_authenticated/identities/"
		],
		preloads: ["/assets/identities-DFRRyeqJ.js"]
	},
	"/_authenticated/importar": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/importar.tsx",
		children: void 0,
		preloads: [
			"/assets/importar-CjCYn2AX.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/circle-check-4VfgK2hL.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/switch-Czyd6i5T.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js"
		]
	},
	"/_authenticated/layout-formulario": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/layout-formulario.tsx",
		children: void 0,
		preloads: [
			"/assets/layout-formulario-CNamK3Mt.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/identity-labels-C_dWwHpx.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/special-fields-DRtkncnN.js",
			"/assets/form-layout-DWBOx8XO.js"
		]
	},
	"/_authenticated/regras": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/regras.tsx",
		children: void 0,
		preloads: [
			"/assets/regras-B2KMoEEc.js",
			"/assets/useNavigate-D_z5dYzM.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/IdentityPictureDialog-3zvqOBDH.js",
			"/assets/eye--hi3N952.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/user-DDWeUZDh.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/IdentityThumb-D-dsrFgK.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-x1PY5AwO.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/circle-check-4VfgK2hL.js",
			"/assets/circle-x-0sKojHfu.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/switch-Czyd6i5T.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js"
		]
	},
	"/_authenticated/tipos-trabalhador": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/tipos-trabalhador.tsx",
		children: void 0,
		preloads: [
			"/assets/tipos-trabalhador-BIgzVbBv.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/pencil-CHJsrzgK.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js"
		]
	},
	"/foto/$token": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/foto.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/foto._token-DM5x8mCo.js",
			"/assets/button-ymfswjnW.js",
			"/assets/camera-pQCPZoP4.js",
			"/assets/circle-check-4VfgK2hL.js",
			"/assets/circle-x-0sKojHfu.js",
			"/assets/pt-BR-CjiyFE6S.js",
			"/assets/loader-circle-y8_I5plS.js",
			"/assets/CameraGuide-BTUfF4ul.js",
			"/assets/upload-tTpgWLcH.js",
			"/assets/PoweredBy-jHcGkbw2.js"
		]
	},
	"/_authenticated/identities/$id": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/identities.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/identities._id-CyX6zusE.js",
			"/assets/useNavigate-D_z5dYzM.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/IdentityForm-a8mbxQq4.js",
			"/assets/chevron-right-BxYz9UKq.js",
			"/assets/IdentityPicturePanel-K0kEq-LV.js",
			"/assets/CredentialsDialog-aoquT7V8.js",
			"/assets/power-CQRrkFv2.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/dialog-DGujnyZW.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/identity-atomic-ByDCkSbj.js",
			"/assets/attachments-BKuiAZQo.js"
		]
	},
	"/_authenticated/identities/new": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/identities.new.tsx",
		children: void 0,
		preloads: [
			"/assets/identities.new-wGKmVaAC.js",
			"/assets/useNavigate-D_z5dYzM.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/IdentityForm-a8mbxQq4.js",
			"/assets/identity-atomic-ByDCkSbj.js",
			"/assets/attachments-BKuiAZQo.js"
		]
	},
	"/_authenticated/terceirizados/$id": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/terceirizados.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/terceirizados._id-DNF7wtyz.js",
			"/assets/useNavigate-D_z5dYzM.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/IdentityForm-a8mbxQq4.js",
			"/assets/IdentityPicturePanel-K0kEq-LV.js",
			"/assets/CredentialsDialog-aoquT7V8.js",
			"/assets/power-CQRrkFv2.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/alert-dialog-B_1frWW5.js"
		]
	},
	"/_authenticated/visitas/nova": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/visitas.nova.tsx",
		children: void 0,
		preloads: [
			"/assets/visitas.nova-DJpFCfgP.js",
			"/assets/useNavigate-D_z5dYzM.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/CredentialsDialog-aoquT7V8.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/PhotoCapture-D8A9O9I5.js"
		]
	},
	"/_authenticated/identities/": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/identities.index.tsx",
		children: void 0,
		preloads: [
			"/assets/identities.index-CXbvWzth.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/IdentityPictureDialog-3zvqOBDH.js",
			"/assets/eye--hi3N952.js",
			"/assets/paperclip-BQ8fmcKO.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/attachments-BKuiAZQo.js",
			"/assets/IdentityThumb-D-dsrFgK.js"
		]
	},
	"/_authenticated/terceirizados/": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/terceirizados.index.tsx",
		children: void 0,
		preloads: [
			"/assets/terceirizados.index-j4b8KBm4.js",
			"/assets/select-qXLaAzL-.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/label-C0gGA0Rd.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/table-DMoKyVAR.js",
			"/assets/checkbox-DFeVrDwZ.js",
			"/assets/IdentityThumb-D-dsrFgK.js"
		]
	},
	"/_authenticated/visitas/": {
		filePath: "/Users/ronaldomoscoso/Library/CloudStorage/OneDrive-R&MTecnologia/DevOps/React/clearid-identity-hub/src/routes/_authenticated/visitas.index.tsx",
		children: void 0,
		preloads: [
			"/assets/visitas.index-DjhLoKj5.js",
			"/assets/useMutation-HG10n2VB.js",
			"/assets/CredentialsDialog-aoquT7V8.js",
			"/assets/plus-BJGdrUKp.js",
			"/assets/search-DZUfRaCg.js",
			"/assets/trash-2-BlgU53F5.js",
			"/assets/badge-DACc6Gj5.js",
			"/assets/card-CeXlCuWD.js",
			"/assets/alert-dialog-B_1frWW5.js",
			"/assets/checkbox-DFeVrDwZ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
