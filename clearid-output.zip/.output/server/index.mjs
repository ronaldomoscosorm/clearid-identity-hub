globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as toEventHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/README.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"14a-h34Kh5VfVgzMfGPrMOZVoGmAP1k\"",
		"mtime": "2026-09-08T17:28:10.411Z",
		"size": 330,
		"path": "../public/README.txt"
	},
	"/assets/CameraGuide-BTUfF4ul.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae7-YFb5mH7S8Sy+voxHX5Fb6HLfXx0\"",
		"mtime": "2026-09-08T17:28:09.548Z",
		"size": 2791,
		"path": "../public/assets/CameraGuide-BTUfF4ul.js"
	},
	"/assets/IdentityForm-a8mbxQq4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d2a9-WRayfvoADl+u/xug3flsvLABTyw\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 119465,
		"path": "../public/assets/IdentityForm-a8mbxQq4.js"
	},
	"/assets/IdentityPictureDialog-3zvqOBDH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f7-UsNT5o4Rlvh/cPlX0eM+wUizpJE\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 1015,
		"path": "../public/assets/IdentityPictureDialog-3zvqOBDH.js"
	},
	"/assets/IdentityPicturePanel-K0kEq-LV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f90-VABLycWsOu6vyGYFjBLGObbnNFQ\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 8080,
		"path": "../public/assets/IdentityPicturePanel-K0kEq-LV.js"
	},
	"/assets/IdentityThumb-D-dsrFgK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"382-dTnZb26ZZVWyBdt5YvD3FOd5PEE\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 898,
		"path": "../public/assets/IdentityThumb-D-dsrFgK.js"
	},
	"/assets/Match-CYF2oa3B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be33-yUgX+lyWrR0d73OVsbzvcLkIZPc\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 48691,
		"path": "../public/assets/Match-CYF2oa3B.js"
	},
	"/assets/PhotoCapture-D8A9O9I5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c9-2gKSPjTc5TwJDKbOgQI7IpE6k3k\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 2249,
		"path": "../public/assets/PhotoCapture-D8A9O9I5.js"
	},
	"/assets/PoweredBy-jHcGkbw2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5eb-E5OwgAHqdZ2fUjCX5fZeIchLLtY\"",
		"mtime": "2026-09-08T17:28:09.549Z",
		"size": 1515,
		"path": "../public/assets/PoweredBy-jHcGkbw2.js"
	},
	"/assets/QueryClientProvider-CBSNk7VU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3bc5-3s1xfz2UpVCDZBiHqyjbqKZr2IA\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 15301,
		"path": "../public/assets/QueryClientProvider-CBSNk7VU.js"
	},
	"/assets/argus-client-ByG8kf7V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13862-YsB0TZd1jibV4ncNjbNXlftPsGg\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 79970,
		"path": "../public/assets/argus-client-ByG8kf7V.js"
	},
	"/assets/alert-dialog-B_1frWW5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e62-YZIV1bGefHfRNq3JUSeYnjgSG8E\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 3682,
		"path": "../public/assets/alert-dialog-B_1frWW5.js"
	},
	"/assets/CredentialsDialog-aoquT7V8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d85-BkSaggnXEsTdaNCzeE7iFo6joOw\"",
		"mtime": "2026-09-08T17:28:09.548Z",
		"size": 7557,
		"path": "../public/assets/CredentialsDialog-aoquT7V8.js"
	},
	"/assets/attachments-BKuiAZQo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af5-qgd7+rQdlukIPZTvW5trsOqYAmI\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 2805,
		"path": "../public/assets/attachments-BKuiAZQo.js"
	},
	"/assets/arrow-left-7lW3nen1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-cVUm2B27PCTeW4BAADSIqiUdv1g\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 155,
		"path": "../public/assets/arrow-left-7lW3nen1.js"
	},
	"/assets/badge-DACc6Gj5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"327-XLeRMEpYL2Vq25mieKMO7oRjuEM\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 807,
		"path": "../public/assets/badge-DACc6Gj5.js"
	},
	"/assets/blazeface.esm-BN6Phy4d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a33-4kAueo0g44BExlfFSIqu/2nPrE0\"",
		"mtime": "2026-09-08T17:28:09.551Z",
		"size": 6707,
		"path": "../public/assets/blazeface.esm-BN6Phy4d.js"
	},
	"/assets/branding-ApGiJ1wz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"516-4wzTfO0bzsEKM9h8fLiSFdvbCsk\"",
		"mtime": "2026-09-08T17:28:09.551Z",
		"size": 1302,
		"path": "../public/assets/branding-ApGiJ1wz.js"
	},
	"/assets/branding-DCLyUAlc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1844-sz6QKM7svYlJPkjJ5n6z0X9FWLs\"",
		"mtime": "2026-09-08T17:28:09.551Z",
		"size": 6212,
		"path": "../public/assets/branding-DCLyUAlc.js"
	},
	"/assets/briefcase-business-CtPfZ7Fm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-7tvf0kBSR5cb0t43lwTqrAK2ap4\"",
		"mtime": "2026-09-08T17:28:09.551Z",
		"size": 315,
		"path": "../public/assets/briefcase-business-CtPfZ7Fm.js"
	},
	"/assets/building-2-CQbQ7Yt6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"175-pKR3/wUwqY0xyQUhin5yDmbX+uA\"",
		"mtime": "2026-09-08T17:28:09.551Z",
		"size": 373,
		"path": "../public/assets/building-2-CQbQ7Yt6.js"
	},
	"/assets/button-ymfswjnW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8197-ny4uLBe7If6Oj3EzYK2JscsQReY\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 33175,
		"path": "../public/assets/button-ymfswjnW.js"
	},
	"/assets/camera-pQCPZoP4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"146-kih3Q3e01jJ2w71rR0JmjFuizaY\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 326,
		"path": "../public/assets/camera-pQCPZoP4.js"
	},
	"/assets/campanhas-foto-C9-fLXBR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31c3-GJ6ZhWM78GAhGncKSY+Z00Kmc70\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 12739,
		"path": "../public/assets/campanhas-foto-C9-fLXBR.js"
	},
	"/assets/apelidos-CQkfkPZz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20aa-qh2k7yJ0ujyd3VdqplDNQX0GsGw\"",
		"mtime": "2026-09-08T17:28:09.550Z",
		"size": 8362,
		"path": "../public/assets/apelidos-CQkfkPZz.js"
	},
	"/assets/campos-do-site-xhhgihMO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"503f-kKTZQho7XlBuebyOrGjDSiVNx44\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 20543,
		"path": "../public/assets/campos-do-site-xhhgihMO.js"
	},
	"/assets/campos-personalizados-BPznvF1J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"954b-DCtO688BroiM63FqPqSatfkereo\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 38219,
		"path": "../public/assets/campos-personalizados-BPznvF1J.js"
	},
	"/assets/card-CeXlCuWD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"44b-3ePAKu1FKvzwgb6c5Uidn5ElKz8\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 1099,
		"path": "../public/assets/card-CeXlCuWD.js"
	},
	"/assets/check-Blu5MfpC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"72-k2emSH7oRS7nxBm49GwHbQfJhGc\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 114,
		"path": "../public/assets/check-Blu5MfpC.js"
	},
	"/assets/checkbox-DFeVrDwZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a8-7+ZrhpeHeUIdd6+ZdhE5k4/2E/8\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 4520,
		"path": "../public/assets/checkbox-DFeVrDwZ.js"
	},
	"/assets/chevron-right-BxYz9UKq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"78-3uk5MFcAQAYF4lgsAFyYS3NQjBw\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 120,
		"path": "../public/assets/chevron-right-BxYz9UKq.js"
	},
	"/assets/circle-check-4VfgK2hL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-nJEKr+fC4YqjQnEqa3y66v+xU6c\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 168,
		"path": "../public/assets/circle-check-4VfgK2hL.js"
	},
	"/assets/circle-x-0sKojHfu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c5-R7un9hcHujjdHfjnx+LaQLQ5AnI\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 197,
		"path": "../public/assets/circle-x-0sKojHfu.js"
	},
	"/assets/client-settings-DY6oLSVs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3e1-gptsNZojEt6lof/P3fXx0HsMY4s\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 993,
		"path": "../public/assets/client-settings-DY6oLSVs.js"
	},
	"/assets/client-CII52-eM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32841-bxuJ3ssV5X/vk835YdoBUwCYLaE\"",
		"mtime": "2026-09-08T17:28:09.552Z",
		"size": 206913,
		"path": "../public/assets/client-CII52-eM.js"
	},
	"/assets/configuracoes-cliente-lOMZNBaN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cbc-FKJJAtJm1NatvN+A5M2XH8xRVBg\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 3260,
		"path": "../public/assets/configuracoes-cliente-lOMZNBaN.js"
	},
	"/assets/current-user-DITjwRne.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f9-R4aaZ/TVj30SpjEn0DA/q4W6Np4\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 761,
		"path": "../public/assets/current-user-DITjwRne.js"
	},
	"/assets/custom-fields-C7QSSsUi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"270-4xyxdHbgTKSEqANPZJ92mJKB7SI\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 624,
		"path": "../public/assets/custom-fields-C7QSSsUi.js"
	},
	"/assets/database-BKPlNJ9f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19e-dDa53LXZNWN9MunrnZeP5f9Y5N4\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 414,
		"path": "../public/assets/database-BKPlNJ9f.js"
	},
	"/assets/dialog-DGujnyZW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"862-/YClBiHPBJKGxF9WEJTt+NPU29c\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 2146,
		"path": "../public/assets/dialog-DGujnyZW.js"
	},
	"/assets/dist-1ujI-9ms.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f1-h+/UQV4GPFYKG7K1vI7KJbholAs\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 753,
		"path": "../public/assets/dist-1ujI-9ms.js"
	},
	"/assets/dist-BATWxhHZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"821d-nqCexAIQDhTu8UMFZa+6csKnz/4\"",
		"mtime": "2026-09-08T17:28:09.554Z",
		"size": 33309,
		"path": "../public/assets/dist-BATWxhHZ.js"
	},
	"/assets/dist-CaQa9MMr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"559cc-L7kYs3XBFbR2bSvIbxThRpOfWm0\"",
		"mtime": "2026-09-08T17:28:09.554Z",
		"size": 350668,
		"path": "../public/assets/dist-CaQa9MMr.js"
	},
	"/assets/dist-lEYgMziq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1353-lZHKaJx1Y7Exsjsj7sXhmlEWxY4\"",
		"mtime": "2026-09-08T17:28:09.554Z",
		"size": 4947,
		"path": "../public/assets/dist-lEYgMziq.js"
	},
	"/assets/dropdown-menu-doZfu7fU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6045-4+teCuGirfX25YosaduRZilfP1Y\"",
		"mtime": "2026-09-08T17:28:09.554Z",
		"size": 24645,
		"path": "../public/assets/dropdown-menu-doZfu7fU.js"
	},
	"/assets/empresas-CxS8yqBR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29db-dLRK64CPz5h4TumMh3ylj+D9FHE\"",
		"mtime": "2026-09-08T17:28:09.554Z",
		"size": 10715,
		"path": "../public/assets/empresas-CxS8yqBR.js"
	},
	"/assets/es2015-9G6OCaRj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74a3-d7UPk0Xzig9bwruKlnGmnjJrfqg\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 29859,
		"path": "../public/assets/es2015-9G6OCaRj.js"
	},
	"/assets/diagnostics-ovWFmXRO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1649-RQDTpo11La3fhyn3kLOgdaMGoeg\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 5705,
		"path": "../public/assets/diagnostics-ovWFmXRO.js"
	},
	"/assets/dist-B-AFHpyn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5084-CHNlErIGDmb2IVIQRvCs8zbUE2A\"",
		"mtime": "2026-09-08T17:28:09.553Z",
		"size": 741508,
		"path": "../public/assets/dist-B-AFHpyn.js"
	},
	"/assets/eye--hi3N952.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-8So5lzVu6GRKWXpKYiOAEhyyo9w\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 246,
		"path": "../public/assets/eye--hi3N952.js"
	},
	"/assets/form-layout-DWBOx8XO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a36-Jb+RBo2wlwm6YYP8R6p/wxJdgWw\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 2614,
		"path": "../public/assets/form-layout-DWBOx8XO.js"
	},
	"/assets/foto._token-DM5x8mCo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2074-MjyYulCLsGsuhXLH/uBx8GARY5M\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 8308,
		"path": "../public/assets/foto._token-DM5x8mCo.js"
	},
	"/assets/hourglass-BAdvOfu1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15e-8BIsyHnnpxN4X16/BHIy+mb71Eo\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 350,
		"path": "../public/assets/hourglass-BAdvOfu1.js"
	},
	"/assets/i18n-BBjNVUCL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20dfa-G+zlOLvcQcWKVRDP+MhT0Oj0dag\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 134650,
		"path": "../public/assets/i18n-BBjNVUCL.js"
	},
	"/assets/identities-DFRRyeqJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-+Bb9RGPc/v64vNYh/gbjVWTC3gM\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 141,
		"path": "../public/assets/identities-DFRRyeqJ.js"
	},
	"/assets/identities.index-CXbvWzth.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4168-GlV9+lnYMLJ2G+wrLRk9faDXwTw\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 16744,
		"path": "../public/assets/identities.index-CXbvWzth.js"
	},
	"/assets/identities.new-wGKmVaAC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f23-VmcHpttdknSYU5saPLRxb5KpewQ\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 3875,
		"path": "../public/assets/identities.new-wGKmVaAC.js"
	},
	"/assets/identity-atomic-ByDCkSbj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"572-4jzv0i4ZK+TQqW0DltXJ4vaAc6M\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 1394,
		"path": "../public/assets/identity-atomic-ByDCkSbj.js"
	},
	"/assets/identity-labels-C_dWwHpx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f3-4uJqguucSWa2IN1tSTSDB1SZC80\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 2035,
		"path": "../public/assets/identity-labels-C_dWwHpx.js"
	},
	"/assets/importar-CjCYn2AX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20bc-WsiH03Li+UY4y9/9JNxpXyrU3t4\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 8380,
		"path": "../public/assets/importar-CjCYn2AX.js"
	},
	"/assets/input-DFTNPuw7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"295-ZWPb642ePaZ5sZNZ26lo7+DB0pE\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 661,
		"path": "../public/assets/input-DFTNPuw7.js"
	},
	"/assets/identities._id-CyX6zusE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3370-9Lp7W2xewyuuqMI8/tqVqYk+gnw\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 13168,
		"path": "../public/assets/identities._id-CyX6zusE.js"
	},
	"/assets/index-CM8pIUBn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47116-10YD2+4oMnerwiuWRR9T01FfpjY\"",
		"mtime": "2026-09-08T17:28:09.548Z",
		"size": 291094,
		"path": "../public/assets/index-CM8pIUBn.js"
	},
	"/assets/label-C0gGA0Rd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2da-XDwrREiUtb7psBrPxihp9NMPZO0\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 730,
		"path": "../public/assets/label-C0gGA0Rd.js"
	},
	"/assets/jsx-runtime-DRF4vMFQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1edb-lC00gjXxHcAWDdKhrb0gSnVSjVI\"",
		"mtime": "2026-09-08T17:28:09.555Z",
		"size": 7899,
		"path": "../public/assets/jsx-runtime-DRF4vMFQ.js"
	},
	"/assets/lazyRouteComponent-DPANSoMT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1030-o0N0h/QxI0OKrhZyOluhVVxWQR4\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 4144,
		"path": "../public/assets/lazyRouteComponent-DPANSoMT.js"
	},
	"/assets/link-D598-iML.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114f-RV7ma5KH7EPalNKCJrVnh4AW4Jw\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 4431,
		"path": "../public/assets/link-D598-iML.js"
	},
	"/assets/loader-circle-y8_I5plS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86-BSvPwTxqrywnx7lFswM2fVXSa2Q\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 134,
		"path": "../public/assets/loader-circle-y8_I5plS.js"
	},
	"/assets/layout-formulario-CNamK3Mt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e99d-b2oUAdB2zgK6zCBmqE+p1m5AAgQ\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 59805,
		"path": "../public/assets/layout-formulario-CNamK3Mt.js"
	},
	"/assets/log-out-CQeIanrK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-06u59igmralZGGj3ujZAgCbpmCw\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 220,
		"path": "../public/assets/log-out-CQeIanrK.js"
	},
	"/assets/matchContext-CENV2JN6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c8-73kRcIwah+EnPk4jBNsRTX31fZI\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 712,
		"path": "../public/assets/matchContext-CENV2JN6.js"
	},
	"/assets/list-checks-BhoYAqbg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-jXpl3Sodg/FUtSMi2fhpNrpzENU\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 269,
		"path": "../public/assets/list-checks-BhoYAqbg.js"
	},
	"/assets/paperclip-BQ8fmcKO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df-EUZK+QjiTcArz7cG5trLezBJt1Q\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 223,
		"path": "../public/assets/paperclip-BQ8fmcKO.js"
	},
	"/assets/pencil-CHJsrzgK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10a-yuEdmaWccDF6aiG20e84e/ZEZxk\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 266,
		"path": "../public/assets/pencil-CHJsrzgK.js"
	},
	"/assets/plus-BJGdrUKp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f-GyzTeMAp4z+iCflvleDOeIPIcR0\"",
		"mtime": "2026-09-08T17:28:09.556Z",
		"size": 143,
		"path": "../public/assets/plus-BJGdrUKp.js"
	},
	"/assets/power-CQRrkFv2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"185-d269mdYzdut0j/OLmKjQxGFtdO0\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 389,
		"path": "../public/assets/power-CQRrkFv2.js"
	},
	"/assets/preload-helper-Czpn1I53.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ac-sE+5KsaRXTMfwOfrOATQajMSGV4\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 1196,
		"path": "../public/assets/preload-helper-Czpn1I53.js"
	},
	"/assets/react-dom-CEVbmmCH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e06-8Q4GwIZrJfmPgjH3ntZH8MmjVd8\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 3590,
		"path": "../public/assets/react-dom-CEVbmmCH.js"
	},
	"/assets/pt-BR-CjiyFE6S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"633d-wTysfs3quZnOn6ySUNvQMFkzqao\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 25405,
		"path": "../public/assets/pt-BR-CjiyFE6S.js"
	},
	"/assets/regras-B2KMoEEc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4226-k1WXScqLXxZBnPzS1moXMk6HNqs\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 16934,
		"path": "../public/assets/regras-B2KMoEEc.js"
	},
	"/assets/rolldown-runtime-QTnfLwEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6-wnqLLSlp3SaE+lbe74bKNe5Rpds\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 694,
		"path": "../public/assets/rolldown-runtime-QTnfLwEv.js"
	},
	"/assets/route-CAvP8chW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c542-GILsxKVMIMDZLir0HF+GkIjVrj4\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 50498,
		"path": "../public/assets/route-CAvP8chW.js"
	},
	"/assets/routes-DJ7LAi8J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26-SoFMfAHVJ5oqB5t+mpFRoQvFIoc\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 38,
		"path": "../public/assets/routes-DJ7LAi8J.js"
	},
	"/assets/search-DZUfRaCg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a4-q4DiFZ0iDdJuLY8etZC0Eryb7aY\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 164,
		"path": "../public/assets/search-DZUfRaCg.js"
	},
	"/assets/select-qXLaAzL-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5712-Ft8w4uZtaUBYRQJ+gpFRfJhX/ns\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 22290,
		"path": "../public/assets/select-qXLaAzL-.js"
	},
	"/assets/settings-2-BvbVzZcA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f2-DtpykisnBWnvpaE/CRwSzhJTyXQ\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 242,
		"path": "../public/assets/settings-2-BvbVzZcA.js"
	},
	"/assets/settings-x1PY5AwO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21cf-SZhkSSsq7iw5Awjq5ILf7AN6FOc\"",
		"mtime": "2026-09-08T17:28:09.557Z",
		"size": 8655,
		"path": "../public/assets/settings-x1PY5AwO.js"
	},
	"/assets/shield-check-C6MWZFHk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-fOXzAer7U4UkdH/sJIIzkCUtECo\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 310,
		"path": "../public/assets/shield-check-C6MWZFHk.js"
	},
	"/assets/skeleton-De01zw5A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f3-rhi9nreGCg/1bcmgtKe3qqjrrBs\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 499,
		"path": "../public/assets/skeleton-De01zw5A.js"
	},
	"/assets/sliders-horizontal-BHrsfZ20.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19e-v7mz3Bqacg7Ia1npdG+6YrTk800\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 414,
		"path": "../public/assets/sliders-horizontal-BHrsfZ20.js"
	},
	"/assets/special-fields-DRtkncnN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2fb-BVID2Co3ecixN1DTCL1Ca8s2+EY\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 763,
		"path": "../public/assets/special-fields-DRtkncnN.js"
	},
	"/assets/supabase-mirror-NZx-xKci.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1004-qELOtXIOYYV/eJSw8Cqerxqr80A\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 4100,
		"path": "../public/assets/supabase-mirror-NZx-xKci.js"
	},
	"/assets/switch-Czyd6i5T.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10ed-X7ljImiDCr10TdJIT1h9dbNKQ4g\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 4333,
		"path": "../public/assets/switch-Czyd6i5T.js"
	},
	"/assets/styles-g8kBPNYU.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"15ca5-cGPCYhPx5aCPqiKu4YkcRGggivg\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 89253,
		"path": "../public/assets/styles-g8kBPNYU.css"
	},
	"/assets/table-DMoKyVAR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"694-yBhrZqHnPTkxsyPC5lyQoJV95hA\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 1684,
		"path": "../public/assets/table-DMoKyVAR.js"
	},
	"/assets/tag-DTZdlFLg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-x8/wcNP/AhSlnLS+ClRr+K/D99A\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 316,
		"path": "../public/assets/tag-DTZdlFLg.js"
	},
	"/assets/terceirizados._id-DNF7wtyz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19ee-vsvDNyRJPZXXpaZZks95dlRmRZI\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 6638,
		"path": "../public/assets/terceirizados._id-DNF7wtyz.js"
	},
	"/assets/terceirizados.index-j4b8KBm4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d15-YTnYX434d9ZXQDvnyRgjL9QB/9M\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 7445,
		"path": "../public/assets/terceirizados.index-j4b8KBm4.js"
	},
	"/assets/textarea-7YELtNGR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22f-MNi/3C7KMPoCrb1Jbhl8Pkna+Ek\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 559,
		"path": "../public/assets/textarea-7YELtNGR.js"
	},
	"/assets/theme-CAZBmoUW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133-YlNy5TPVpBnSwbl/iY8ChljWYPk\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 307,
		"path": "../public/assets/theme-CAZBmoUW.js"
	},
	"/assets/tipos-trabalhador-BIgzVbBv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2775-9604/TjAuLxVNmDZRq/cpf+w1c4\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 10101,
		"path": "../public/assets/tipos-trabalhador-BIgzVbBv.js"
	},
	"/assets/trash-2-BlgU53F5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-+REnoam61lvWD0VAGAEQyDwO/D0\"",
		"mtime": "2026-09-08T17:28:09.558Z",
		"size": 318,
		"path": "../public/assets/trash-2-BlgU53F5.js"
	},
	"/assets/triangle-alert-BldsQOSp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ff-3tJXvUwx3qD5IlfO45zbjRmEnxc\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 255,
		"path": "../public/assets/triangle-alert-BldsQOSp.js"
	},
	"/assets/tslib.es6-Tae09705.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"42d-qJHuGuq51+EbLaebsBAkbj1JLbk\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 1069,
		"path": "../public/assets/tslib.es6-Tae09705.js"
	},
	"/assets/useNavigate-D_z5dYzM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10a-/QK/POg0zUYOilsHxjxLZi8ZmP0\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 266,
		"path": "../public/assets/useNavigate-D_z5dYzM.js"
	},
	"/assets/useQuery-B5Z9JMjv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2290-JpXfw90ris1qpnBzy2Cn+/dfPNY\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 8848,
		"path": "../public/assets/useQuery-B5Z9JMjv.js"
	},
	"/assets/useStore-DLRajplM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b12-07szq42zESs90UmFipHSs9zvPtU\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 19218,
		"path": "../public/assets/useStore-DLRajplM.js"
	},
	"/assets/user-DDWeUZDh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ba-sCviRXeYKj75scGekFi+inoHXGE\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 186,
		"path": "../public/assets/user-DDWeUZDh.js"
	},
	"/assets/user-scope-CZlnLHr1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47b-/F39vwAIHv8Ub5JC1Sd4B8wDiF0\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 1147,
		"path": "../public/assets/user-scope-CZlnLHr1.js"
	},
	"/assets/useMutation-HG10n2VB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"925-4l5j3LfUv7u9qjui9tfHVFUlxv0\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 2341,
		"path": "../public/assets/useMutation-HG10n2VB.js"
	},
	"/assets/upload-tTpgWLcH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-ZJdwmbHosFiRU4h2dPqMesX7nfI\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 220,
		"path": "../public/assets/upload-tTpgWLcH.js"
	},
	"/assets/users-3ZZQknvv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"128-+FgHmVXJlr1FOzPmaIOjc+AJ0nk\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 296,
		"path": "../public/assets/users-3ZZQknvv.js"
	},
	"/assets/useMatch-KJVpuKdT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"299-+djEVC/C8iE7VH1eUudWb532v8Y\"",
		"mtime": "2026-09-08T17:28:09.559Z",
		"size": 665,
		"path": "../public/assets/useMatch-KJVpuKdT.js"
	},
	"/assets/visitas.index-DjhLoKj5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d43-apzb/7M+wMXTlm8HFD7412tEeXM\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 7491,
		"path": "../public/assets/visitas.index-DjhLoKj5.js"
	},
	"/assets/visitas.nova-DJpFCfgP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31e1-AMM4eCYWiuZkUjrZBPkFOMRW03E\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 12769,
		"path": "../public/assets/visitas.nova-DJpFCfgP.js"
	},
	"/assets/xlsx-C8WN43MN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"67b05-hnbVNMlKih9ykm0V6S6Ujg3TNks\"",
		"mtime": "2026-09-08T17:28:09.560Z",
		"size": 424709,
		"path": "../public/assets/xlsx-C8WN43MN.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_xXl3x9 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_xXl3x9
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
