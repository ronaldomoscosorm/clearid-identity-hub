import{n as e,r as t}from"./rolldown-runtime-QTnfLwEv.js";import{$ as n,$a as r,$c as i,$i as a,$l as o,$n as s,$o as c,$r as l,$s as u,$t as d,A as f,Aa as p,Ac as m,Ai as h,Al as g,An as _,Ao as v,Ar as y,As as b,At as x,Au as S,B as C,Ba as w,Bc as T,Bi as E,Bl as ee,Bn as te,Bo as ne,Br as re,Bs as ie,Bt as ae,C as oe,Ca as se,Cc as ce,Ci as le,Cl as ue,Cn as de,Co as fe,Cr as pe,Cs as me,Ct as he,Cu as ge,D as _e,Da as D,Dc as ve,Di as ye,Dl as be,Dn as xe,Do as Se,Dr as Ce,Ds as we,Dt as Te,Du as Ee,E as De,Ea as Oe,Ec as ke,Ei as Ae,El as je,En as Me,Eo as Ne,Er as Pe,Es as Fe,Et as Ie,Eu as Le,F as Re,Fa as ze,Fc as Be,Fi as Ve,Fl as He,Fn as Ue,Fo as We,Fr as Ge,Fs as Ke,Ft as qe,G as Je,Ga as Ye,Gc as Xe,Gi as Ze,Gl as Qe,Gn as $e,Go as et,Gr as tt,Gs as nt,Gt as rt,H as it,Ha as at,Hc as ot,Hi as st,Hl as ct,Hn as lt,Ho as ut,Hr as dt,Hs as ft,Ht as pt,I as mt,Ia as ht,Ic as gt,Ii as _t,Il as vt,In as yt,Io as bt,Ir as xt,Is as St,It as Ct,J as wt,Ja as Tt,Jc as Et,Ji as Dt,Jl as Ot,Jn as kt,Jo as At,Jr as jt,Js as Mt,Jt as Nt,K as Pt,Ka as Ft,Kc as It,Ki as Lt,Kl as Rt,Kn as zt,Ko as Bt,Kr as Vt,Ks as Ht,Kt as Ut,L as Wt,La as Gt,Lc as Kt,Li as qt,Ll as Jt,Ln as Yt,Lo as Xt,Lr as Zt,Ls as Qt,Lt as $t,M as en,Ma as tn,Mc as nn,Mi as rn,Ml as an,Mn as on,Mo as sn,Mr as cn,Ms as ln,Mt as un,Mu as dn,N as fn,Na as pn,Nc as mn,Ni as hn,Nl as gn,Nn as _n,No as vn,Nr as yn,Ns as bn,Nt as xn,O as Sn,Oa as Cn,Oc as wn,Oi as Tn,Ol as En,On as Dn,Oo as On,Or as kn,Os as An,Ot as jn,Ou as Mn,P as Nn,Pa as Pn,Pc as Fn,Pi as In,Pl as Ln,Pn as Rn,Po as zn,Pr as Bn,Ps as Vn,Pt as Hn,Q as Un,Qa as Wn,Qc as Gn,Qi as Kn,Ql as qn,Qn as Jn,Qo as Yn,Qr as Xn,Qs as Zn,Qt as Qn,R as $n,Ra as er,Rc as tr,Ri as nr,Rl as rr,Rn as ir,Ro as ar,Rr as or,Rs as sr,Rt as cr,S as lr,Sa as ur,Sc as dr,Si as fr,Sl as pr,Sn as mr,So as hr,Sr as gr,Ss as _r,St as vr,Su as yr,T as br,Ta as xr,Tc as Sr,Ti as Cr,Tl as wr,Tn as Tr,To as Er,Tr as O,Ts as Dr,Tt as Or,Tu as k,U as kr,Ua as A,Uc as Ar,Ui as jr,Ul as Mr,Un as Nr,Uo as Pr,Ur as Fr,Us as Ir,Ut as Lr,V as Rr,Va as zr,Vc as Br,Vi as Vr,Vl as Hr,Vn as Ur,Vo as Wr,Vr as Gr,Vs as Kr,Vt as qr,W as Jr,Wa as Yr,Wc as Xr,Wi as Zr,Wl as Qr,Wn as $r,Wo as ei,Wr as ti,Ws as ni,Wt as ri,X as ii,Xa as ai,Xc as oi,Xi as si,Xl as ci,Xn as li,Xo as ui,Xr as di,Xs as fi,Xt as pi,Y as mi,Ya as hi,Yc as gi,Yi as _i,Yl as vi,Yn as yi,Yo as bi,Yr as xi,Ys as Si,Yt as Ci,Z as wi,Za as Ti,Zc as Ei,Zi as Di,Zl as j,Zn as Oi,Zo as ki,Zr as Ai,Zs as ji,Zt as Mi,_ as Ni,_a as M,_c as Pi,_i as Fi,_l as Ii,_n as Li,_o as Ri,_r as zi,_s as Bi,_t as Vi,_u as Hi,a as Ui,aa as Wi,ac as Gi,ai as Ki,al as qi,an as Ji,ao as Yi,ar as Xi,as as Zi,at as Qi,au as $i,b as ea,ba as ta,bc as na,bi as ra,bl as ia,bn as aa,bo as oa,br as sa,bs as ca,bt as la,bu as ua,c as da,ca as fa,cc as pa,ci as ma,cl as ha,cn as ga,co as _a,cr as va,cs as ya,ct as ba,cu as xa,d as Sa,da as N,dc as Ca,di as wa,dl as Ta,dn as Ea,do as Da,dr as Oa,ds as ka,dt as Aa,du as ja,ea as Ma,ec as Na,ei as Pa,el as Fa,en as Ia,eo as La,er as Ra,es as za,et as P,eu as Ba,f as Va,fa as Ha,fc as Ua,fi as Wa,fl as Ga,fn as Ka,fo as qa,fr as Ja,fs as Ya,ft as Xa,fu as Za,g as Qa,ga as F,gc as $a,gi as eo,gl as to,gn as no,go as ro,gr as io,gs as ao,gt as oo,gu as so,h as co,ha as lo,hc as uo,hi as fo,hl as po,hn as mo,ho,hr as go,hs as _o,ht as vo,hu as yo,i as bo,ia as xo,ic as So,ii as Co,il as wo,in as To,io as Eo,ir as Do,is as Oo,it as ko,iu as Ao,j as jo,ja as Mo,jc as No,ji as Po,jl as Fo,jn as Io,jo as Lo,jr as Ro,js as zo,jt as Bo,ju as Vo,k as Ho,ka as Uo,kc as Wo,ki as Go,kl as Ko,kn as qo,ko as Jo,kr as Yo,ks as Xo,kt as Zo,ku as Qo,l as $o,la as es,lc as ts,li as ns,ll as rs,ln as is,lo as as,lr as os,ls as ss,lt as cs,lu as ls,m as us,ma as ds,mc as fs,mi as ps,ml as ms,mn as hs,mo as gs,mr as _s,ms as vs,mt as ys,mu as bs,n as xs,na as Ss,nc as Cs,ni as ws,nl as Ts,nn as Es,no as Ds,nr as Os,ns as ks,nt as As,nu as js,o as Ms,oa as Ns,oc as Ps,oi as Fs,ol as Is,on as Ls,oo as Rs,or as zs,os as Bs,ot as Vs,ou as Hs,p as Us,pa as I,pc as Ws,pi as Gs,pl as Ks,pn as qs,po as Js,pr as Ys,ps as Xs,pt as Zs,pu as Qs,q as $s,qa as ec,qc as tc,qi as nc,ql as rc,qn as L,qo as ic,qr as ac,qs as oc,qt as sc,r as cc,ra as lc,rc as uc,ri as dc,rl as fc,rn as pc,ro as mc,rr as hc,rs as gc,rt as _c,ru as R,s as vc,sa as yc,sc as bc,si as xc,sl as Sc,sn as Cc,so as wc,sr as Tc,ss as Ec,st as Dc,su as Oc,t as kc,ta as Ac,tc as jc,ti as Mc,tl as Nc,tn as Pc,to as Fc,tr as Ic,ts as Lc,tt as Rc,tu as zc,u as Bc,ua as z,uc as Vc,ui as Hc,ul as Uc,un as Wc,uo as B,ur as Gc,us as Kc,ut as qc,uu as Jc,v as Yc,va as Xc,vc as Zc,vi as Qc,vl as $c,vn as el,vo as tl,vr as nl,vs as rl,vt as il,vu as al,w as ol,wa as sl,wc as cl,wi as ll,wl as ul,wn as dl,wo as fl,wr as pl,ws as ml,wt as hl,wu as gl,x as V,xa as _l,xc as vl,xi as yl,xl as bl,xn as xl,xo as Sl,xr as Cl,xs as wl,xt as Tl,xu as H,y as El,ya as Dl,yc as Ol,yi as kl,yl as Al,yn as jl,yo as Ml,yr as Nl,ys as Pl,yt as Fl,yu as Il,z as Ll,za as Rl,zc as zl,zi as U,zl as Bl,zn as Vl,zo as Hl,zr as Ul,zs as Wl,zt as Gl}from"./dist-CaQa9MMr.js";var Kl=e({TEST_EPSILON_FLOAT16:()=>Jl,createVideoElement:()=>au,encodeStrings:()=>iu,expectArrayBuffersEqual:()=>ru,expectArraysClose:()=>Yl,expectArraysEqual:()=>$l,expectNumbersClose:()=>eu,expectPromiseToFail:()=>Ql,expectValuesInRange:()=>nu,play:()=>ou,testEpsilon:()=>Xl}),ql=.001,Jl=.1;function Yl(e,t,n){return n??=Xl(),Zl(e,t,(e,t)=>tu(e,t,n))}function Xl(){return La.backend.floatPrecision()===32?ql:Jl}function Zl(e,t,n){let r=!0;if((ro(e)||ro(t))&&(r=!1),ro(e)&&ro(t)&&(r=!0),r){let n=e.constructor.name,r=t.constructor.name;if(n!==r)throw Error(`Arrays are of different type. Actual: ${n}. Expected: ${r}`)}if(Array.isArray(e)&&Array.isArray(t)){let n=ai(e),r=ai(t);if(!qn(n,r))throw Error(`Arrays have different shapes. Actual: [${n}]. Expected: [${r}]`)}let i=ro(e)?e:ho(e),a=ro(t)?t:ho(t);if(i.length!==a.length)throw Error(`Arrays have different lengths actual: ${i.length} vs expected: ${a.length}.\nActual:   ${i}.\nExpected: ${a}.`);for(let e=0;e<a.length;++e){let t=i[e],r=a[e];if(!n(t,r))throw Error(`Arrays differ: actual[${e}] = ${t}, expected[${e}] = ${r}.\nActual:   ${i}.\nExpected: ${a}.`)}typeof expect<`u`&&expect().nothing()}function Ql(e,t){e().then(()=>t.fail(),()=>t()),typeof expect<`u`&&expect().nothing()}function $l(e,t){let n=typeof t==`string`||typeof t==`number`||typeof t==`boolean`?[t]:t;return bs(e)||bs(e[0])||bs(t)||bs(t[0])?Zl(e,n,(e,t)=>e==t):Zl(e,t,(e,t)=>tu(e,t,0))}function eu(e,t,n){if(n??=Xl(),!tu(e,t,n))throw Error(`Numbers differ: actual === ${e}, expected === ${t}`);typeof expect<`u`&&expect().nothing()}function tu(e,t,n){return!isFinite(e)&&!isFinite(t)||!(isNaN(e)||isNaN(t)||Math.abs(e-t)>n)}function nu(e,t,n){for(let r=0;r<e.length;r++)if(e[r]<t||e[r]>n)throw Error(`Value out of range:${e[r]} low: ${t}, high: ${n}`)}function ru(e,t){let n=new Float32Array(e),r=new Float32Array(t);if(n.length!==r.length)throw Error(`Expected ArrayBuffer to be of length ${r.length}, but it was ${n.length}`);for(let e=0;e<r.length;e++)if(n[e]!==r[e])throw Error(`Expected ArrayBuffer value at ${e} to be ${r[e]} but got ${n[e]} instead`)}function iu(e){for(let t=0;t<e.length;t++){let n=e[t];Array.isArray(n)?iu(n):e[t]=Js(n)}return e}function au(e){let t=document.createElement(`video`);return`playsInline`in t&&(t.playsInline=!0),t.muted=!0,t.loop=!0,t.style.position=`fixed`,t.style.left=`0px`,t.style.top=`0px`,t.preload=`auto`,t.appendChild(e),new Promise(e=>{t.addEventListener(`loadeddata`,n=>e(t)),t.load()})}async function ou(e){await e.play(),`requestVideoFrameCallback`in e&&await new Promise(t=>{e.requestVideoFrameCallback(t)})}function su(e,t,n){let r=hi(e,`labels`,`confusionMatrix`),i=hi(t,`predictions`,`confusionMatrix`);o(n==null||n>0&&Number.isInteger(n),()=>`If provided, numClasses must be a positive integer, but got ${n}`),o(r.rank===1,()=>`Expected the rank of labels to be 1, but got ${r.rank}`),o(i.rank===1,()=>`Expected the rank of predictions to be 1, but got ${i.rank}`),o(r.shape[0]===i.shape[0],()=>`Mismatch in the number of examples: ${r.shape[0]} vs. ${i.shape[0]}. Labels and predictions should have the same number of elements.`),o(n>0&&Number.isInteger(n),()=>`numClasses is required to be a positive integer, but got ${n}`);let a=de(F(r,`int32`),n),s=de(F(i,`int32`),n);return F(Ve(P(a),s),`int32`)}var cu=Tt({confusionMatrix_:su}),lu=e({confusionMatrix:()=>cu}),uu=e({prepareAndValidate:()=>du});function du(e,t){let n=e.shape.length,r=t.shape.length;if(n<1)throw Error(`tf.gatherND() expects the input to be rank 1 or higher, but the rank was ${n}.`);if(r<1)throw Error(`tf.gatherND() expects the indices to be rank 1 or higher, but the rank was ${r}.`);if(t.dtype!==`int32`)throw Error(`tf.gatherND() expects the indices to be int32 type, but the dtype was ${t.dtype}.`);if(t.shape[r-1]>n)throw Error(`index innermost dimension length must be <= tensor rank; saw: ${t.shape[r-1]} vs. ${n}`);if(k(e.shape)===0)throw Error(`Requested more than 0 entries, but input is empty. Input shape: ${e.shape}.`);let i=t.shape,a=i[i.length-1],o=1;for(let e=0;e<i.length-1;++e)o*=i[e];let s=e.shape,c=i.slice();c.pop();let l=1;for(let e=a;e<n;++e)l*=s[e],c.push(s[e]);let u=[...R(e.shape).map(e=>e/l),1].slice(0,a);return[c,o,l,u]}var fu=e({assertParamsValid:()=>hu,computeFlatOffset:()=>Ou,computeOutShape:()=>_u,getNormalizedAxes:()=>xu,isSliceContinous:()=>Du,maskToAxes:()=>gu,parseSliceParams:()=>ku,sliceInfo:()=>Au,startForAxis:()=>Tu,startIndicesWithElidedDims:()=>Su,stopForAxis:()=>Eu,stopIndicesWithElidedDims:()=>Cu,stridesForAxis:()=>wu,stridesWithElidedDims:()=>vu}),pu=-2,mu=-1;function hu(e,t,n){let r=e.shape.length;o(r===t.length,()=>`Error in slice${r}D: Length of begin ${t} must match the rank of the array (${r}).`),o(r===n.length,()=>`Error in slice${r}D: Length of size ${n} must match the rank of the array (${r}).`);for(let i=0;i<r;++i)o(t[i]+n[i]<=e.shape[i],()=>`Error in slice${r}D: begin[${i}] + size[${i}] (${t[i]+n[i]}) would overflow input.shape[${i}] (${e.shape[i]})`)}function gu(e){let t=[],n=0;for(;e>0;)e&1&&t.push(n),e/=2,n++;return t}function _u(e,t,n){let r=[];for(let i=0;i<e.length;i++)r[i]=Math.ceil((t[i]-e[i])/n[i]);return r}function vu(e,t,n,r){let i=[...e];for(let e=i.length;e<r.length;e++)i.push(1);for(let e=0;e<n;e++)e===0?i[t]=1:(i.splice(t,0,1),i.pop());return i}function yu(e,t,n){return n<=e?n:n-(t-1)}function bu(e,t){let n=[];for(let r=0;r<e;r++)n.push(t+r);return n}function xu(e,t,n,r,i,a,o,s,c){let l=e.length,u=Array(l),d=Array(l),f=Array(l);if(t.length&&n>0){let c=t[0],l=n+1;u=Su(o,c,l,r,e),d=Cu(s,c,l,i,e),f=vu(a,c,l,e)}else for(let t=0;t<l;t++)u[t]=Tu(o,r,a,e,t,c),d[t]=Eu(s,i,a,e,t,c),f[t]=wu(a,t,c);return{begin:u,end:d,strides:f}}function Su(e,t,n,r,i){let a=[...i],o=bu(n,t);for(let i=0;i<a.length;i++)if(o.indexOf(i)>-1)a[i]=0;else{let o=yu(t,n,i),s=r[o];e&1<<o&&(s=0),a[i]=s}return a}function Cu(e,t,n,r,i){let a=[...i],o=bu(n,t);for(let i=0;i<a.length;i++)if(o.indexOf(i)>-1)a[i]=2**53-1;else{let o=yu(t,n,i),s=r[o];e&1<<o&&(s=2**53-1),a[i]=s}for(let e=0;e<a.length;e++){let t=i[e];a[e]<0&&(a[e]+=t),a[e]=js(0,a[e],i[e])}return a}function wu(e,t,n){let r=e[t];return(n&1<<t||r==null)&&(r=1),r}function Tu(e,t,n,r,i,a){let o=t[i],s=n[i]||1;(e&1<<i||a&1<<i||o==null)&&(o=s>0?-(2**53-1):2**53-1);let c=r[i];return o<0&&(o+=c),o=js(0,o,c-1),o}function Eu(e,t,n,r,i,a){let o=t[i],s=n[i]||1;(e&1<<i||a&1<<i||o==null)&&(o=s>0?2**53-1:-(2**53-1));let c=r[i];return o<0&&(o+=c),o=s>0?js(0,o,c):js(-1,o,c-1),o}function Du(e,t,n){let r=n.length;for(let e=0;e<n.length;e++)if(n[e]>1){r=e;break}for(let i=r+1;i<n.length;i++)if(t[i]>0||n[i]!==e[i])return!1;return!0}function Ou(e,t){let n=e.length>0?e[e.length-1]:1;for(let r=0;r<e.length-1;r++)n+=e[r]*t[r];return n}function ku(e,t,n){let r,i=e.shape.length;r=typeof t==`number`?[t,...Array(i-1).fill(0)]:t.length<i?t.concat(Array(i-t.length).fill(0)):t.slice(),r.forEach(e=>{o(e!==-1,()=>`slice() does not support negative begin indexing.`)});let a;return a=n==null?Array(i).fill(-1):typeof n==`number`?[n,...Array(i-1).fill(-1)]:n.length<i?n.concat(Array(i-n.length).fill(-1)):n,a=a.map((t,n)=>t>=0?t:(o(t===-1,()=>`Negative size values should be exactly -1 but got ${t} for the slice() size at index ${n}.`),e.shape[n]-r[n])),[r,a]}function Au(e,t,n,r,i,a,o,s,c){let l;if(r==null?(l=Array(t.length),l.fill(1)):l=r,o!=null&&o&o-1)throw Error(`Multiple ellipses in slice is not allowed.`);let u=!1,d={dims:l.length,numAddAxisAfterEllipsis:0,begin:t.slice(),end:n.slice(),strides:l.slice(),beginMask:i,endMask:a,ellipsisMask:o,newAxisMask:s,shrinkAxisMask:c};for(let e=0;e<d.dims;e++)u&&1<<e&s&&d.numAddAxisAfterEllipsis++,1<<e&o&&(u=!0);u||(d.ellipsisMask|=1<<d.dims,d.dims++);let f={dims:e.length,beginMask:0,endMask:0,beginValid:!1,endValid:!1};ju(d,f);let p=!0,m=!0,h=!0,g=[],_=[];for(let t=0;t<e.length;++t){if(f.strides[t]===0)throw Error(`strides[${t}] must be non-zero`);let n=!!(f.shrinkAxisMask&1<<t),r=e[t];if(r===-1){g.push(n?1:-1);continue}let i=[f.beginMask&1<<t,f.endMask&1<<t],a=[f.strides[t]>0?0:-1,f.strides[t]>0?r:r-1];if(n&&f.strides[t]<=0)throw Error(`only stride 1 allowed on non-range indexing.`);h&&=f.strides[t]===1;let o=!!(f.beginMask&1<<t&&f.endMask&1<<t);if(f.beginValid&&f.endValid){if(n){let e=f.begin[t]<0?r+f.begin[t]:f.begin[t];if(f.begin[t]=e,f.end[t]=f.begin[t]+1,e<0||e>=r)throw Error(`slice index ${f.begin[t]} of dimension ${t} out of bounds.`)}else f.begin[t]=Mu(f.begin[t],0,f.strides[t],r,i,a),f.end[t]=Mu(f.end[t],1,f.strides[t],r,i,a);let e=f.strides[t]===1&&f.begin[t]===0&&f.end[t]===r;p&&=e,m&&=t===0&&f.strides[t]===1||e}else p=p&&f.strides[t]===1&&o,m&&=t===0&&f.strides[t]===1||o;let s,c=!1;if(f.beginValid&&f.endValid?(s=f.end[t]-f.begin[t],c=!0):n?(s=1,c=!0):o&&r>=0&&(s=f.strides[t]<0?-r:r,c=!0),c){let e;e=s===0||s<0!=f.strides[t]<0?0:Math.trunc(s/f.strides[t])+(s%f.strides[t]===0?0:1),g.push(e)}else g.push(-1)}for(let e=0;e<f.finalShapeGatherIndices.length;++e){let t=f.finalShapeGatherIndices[e];t>=0?_.push(g[t]):t===pu&&_.push(1)}return{finalShapeSparse:_.filter((e,t)=>f.finalShapeGatherIndices[t]!==pu),finalShape:_,isIdentity:p,sliceDim0:m,isSimpleSlice:h,begin:f.begin,end:f.end,strides:f.strides}}function ju(e,t){t.beginMask=0,t.endMask=0,t.shrinkAxisMask=0;let n=0;t.beginValid=e.begin!=null,t.endValid=e.end!=null,t.begin=Array(t.dims),t.end=Array(t.dims),t.strides=Array(t.dims),t.finalShapeGatherIndices=[],t.finalShapeGatherIndicesSparse=[],t.inputShapeGatherIndicesSparse=Array(t.dims);for(let r=0;r<e.dims;r++)if(1<<r&e.ellipsisMask){let i=Math.min(t.dims-(e.dims-r)+1+e.numAddAxisAfterEllipsis,t.dims);for(;n<i;n++)t.begin[n]=0,t.end[n]=0,t.strides[n]=1,t.beginMask|=1<<n,t.endMask|=1<<n,t.finalShapeGatherIndices.push(n),t.finalShapeGatherIndicesSparse.push(-1),t.inputShapeGatherIndicesSparse[n]=r}else if(1<<r&e.newAxisMask)t.finalShapeGatherIndices.push(pu),t.finalShapeGatherIndicesSparse.push(-1);else{if(n===t.begin.length)throw Error(`Index out of range using input dim ${n}; input has only ${t.dims} dims, ${t.begin.length}.`);e.begin!=null&&(t.begin[n]=e.begin[r]),e.end!=null&&(t.end[n]=e.end[r]),t.strides[n]=e.strides[r],e.beginMask&1<<r&&(t.beginMask|=1<<n),e.endMask&1<<r&&(t.endMask|=1<<n),e.shrinkAxisMask&1<<r?(t.finalShapeGatherIndices.push(mu),t.finalShapeGatherIndicesSparse.push(-1),t.shrinkAxisMask|=1<<n):(t.finalShapeGatherIndices.push(n),t.finalShapeGatherIndicesSparse.push(r)),t.inputShapeGatherIndicesSparse[n]=r,n++}}function Mu(e,t,n,r,i,a){if(i[t])return n>0?a[t]:a[t+1&1];{let t=e<0?r+e:e;return t<a[0]?a[0]:t>a[1]?a[1]:t}}var Nu=`4.22.0`,Pu=class{static sgd(e){return new Us(e)}static momentum(e,t,n=!1){return new Va(e,t,n)}static rmsprop(e,t=.9,n=0,r=null,i=!1){return new Sa(e,t,n,r,i)}static adam(e=.001,t=.9,n=.999,r=null){return new co(e,t,n,r)}static adadelta(e=.001,t=.95,n=null){return new Ni(e,t,n)}static adamax(e=.002,t=.9,n=.999,r=null,i=0){return new us(e,t,n,r,i)}static adagrad(e,t=.1){return new Qa(e,t)}},Fu=Pu,Iu=typeof requestAnimationFrame<`u`?requestAnimationFrame:typeof setImmediate<`u`?setImmediate:e=>e();function Lu(){return new Promise(e=>Iu(()=>e()))}function Ru(e,t){let n=e[0].length;e.forEach((e,t)=>{o(e.length===n,()=>`Error in concat${n}D: rank of tensors[${t}] must be the same as the rank of the rest (${n})`)}),o(t>=0&&t<n,()=>`Error in concat${n}D: axis must be between 0 and ${n-1}.`);let r=e[0];e.forEach((e,i)=>{for(let a=0;a<n;a++)o(a===t||e[a]===r[a],()=>`Error in concat${n}D: Shape of tensors[${i}] (${e}) does not match the shape of the rest (${r}) along the non-concatenated axis ${i}.`)})}function zu(e,t){let n=e[0].slice();for(let r=1;r<e.length;r++)n[t]+=e[r][t];return n}var Bu;(function(e){e[e.FIRST_DIM_SIZE=0]=`FIRST_DIM_SIZE`,e[e.VALUE_ROWIDS=1]=`VALUE_ROWIDS`,e[e.ROW_LENGTHS=2]=`ROW_LENGTHS`,e[e.ROW_SPLITS=3]=`ROW_SPLITS`,e[e.ROW_LIMITS=4]=`ROW_LIMITS`,e[e.ROW_STARTS=5]=`ROW_STARTS`})(Bu||={});function Vu(e,t,n){let r=[];if(n==null&&t==null)return r;if(t==null)for(;r.length<e+n.length;)r.push(-1);else r=t.slice();if(n==null)return r;if(e+n.length!==r.length)throw Error(`rt input.shape and shape=${t} are incompatible: rt input.rank = ${e+n.length}, but shape.rank = ${r.length}`);for(let i=1;i<n.length;++i){let a=n[i],o=r[r.length-n.length+i],s=r[o];if(a>=0)if(s>=0){if(s!==a)throw Error(`rt input.shape and shape=${t} are incompatible: rt input.shape[${i+e}] = ${a} but shape[${i+e}] = ${s}`)}else r[o]=a}return r}function Hu(e){let t={FIRST_DIM_SIZE:Bu.FIRST_DIM_SIZE,VALUE_ROWIDS:Bu.VALUE_ROWIDS,ROW_LENGTHS:Bu.ROW_LENGTHS,ROW_SPLITS:Bu.ROW_SPLITS,ROW_LIMITS:Bu.ROW_LIMITS,ROW_STARTS:Bu.ROW_STARTS},n=[];for(let r of e)if(r in t)n.push(t[r]);else break;return n}function Uu(e){return e.length===0?0:e[0]===Bu.FIRST_DIM_SIZE?e.length-1:e.length}function Wu(e,t){if(e==null||t==null)return;let n=e.length,r=t.length;if(n>=r)throw Error(`defaultValue.shape=${e} and ragged tensor flatValues.shape=${t}, are incompatible: defaultValue.rank = ${n} must be less than ragged tensor input flatValues.rank = ${r})`);for(let i=0;i<Math.min(n,r-1);++i){let n=e[i],r=t[i+1];if(n>=0&&r>=0&&n!==1&&n!==r)throw Error(`defaultValue.shape=${e}, and ragged tensor input flatValues.shape=${t} are incompatible: defaultValue.shape[${i-e.length}] = ${n} but ragged tensor input.flatValues.shape[${i-e.length}] = ${r}`)}}function Gu(e){return e<=30?e:Il(e,Math.floor(Math.sqrt(e)))}function Ku(e,t,n){return[n*(typeof e==`number`?e:e[0]),t*(typeof e==`number`?e:e[1])]}function qu(e,t,n,r=!0){let i=[];if(r)i=i.concat(t.slice(0)),i.push(e[0]/n),i=i.concat(e.slice(1));else{i=i.concat(e[0]);let n=t.length;for(let r=0;r<n;++r)i=i.concat([e[r+1]/t[r],t[r]]);i=i.concat(e.slice(n+1))}return i}function Ju(e,t,n=!0){let r=[];if(n){r.push(t);for(let n=t+1;n<e;++n)n<=2*t?(r.push(n),r.push(n-(t+1))):r.push(n)}else{let n=[],i=[];for(let r=1;r<e;++r)r>=t*2+1||r%2==1?i.push(r):n.push(r);r.push(...n),r.push(0),r.push(...i)}return r}function Yu(e,t,n,r=!0){let i=[];r?i.push(e[0]/n):i.push(e[0]*n);for(let n=1;n<e.length;++n)n<=t.length?r?i.push(t[n-1]*e[n]):i.push(e[n]/t[n-1]):i.push(e[n]);return i}function Xu(e,t){let n=[0];for(let r=0;r<t;++r)n.push(e[r][0]);return n}function Zu(e,t,n){let r=e.slice(0,1);for(let i=0;i<n;++i)r.push(e[i+1]-t[i][0]-t[i][1]);return r}var Qu=1.7580993408473768,$u=1.0507009873554805,ed=.3275911,td=.254829592,nd=-.284496736,rd=1.421413741,id=-1.453152027,ad=1.061405429;function od(e,t){if(e.length!==t.length)throw Error(`Cannot merge real and imag arrays of different lengths. real:${e.length}, imag: ${t.length}.`);let n=new Float32Array(e.length*2);for(let r=0;r<n.length;r+=2)n[r]=e[r/2],n[r+1]=t[r/2];return n}function sd(e){let t=new Float32Array(e.length/2),n=new Float32Array(e.length/2);for(let r=0;r<e.length;r+=2)t[r/2]=e[r],n[r/2]=e[r+1];return{real:t,imag:n}}function cd(e){let t=Math.ceil(e.length/4),n=new Float32Array(t),r=new Float32Array(t);for(let t=0;t<e.length;t+=4)n[Math.floor(t/4)]=e[t],r[Math.floor(t/4)]=e[t+1];return{real:n,imag:r}}function ld(e){let t=Math.floor(e.length/4),n=new Float32Array(t),r=new Float32Array(t);for(let t=2;t<e.length;t+=4)n[Math.floor(t/4)]=e[t],r[Math.floor(t/4)]=e[t+1];return{real:n,imag:r}}function ud(e,t){return{real:e[t*2],imag:e[t*2+1]}}function dd(e,t,n,r){e[r*2]=t,e[r*2+1]=n}function fd(e,t){let n=new Float32Array(e/2),r=new Float32Array(e/2);for(let i=0;i<Math.ceil(e/2);i++){let a=(t?2:-2)*Math.PI*(i/e);n[i]=Math.cos(a),r[i]=Math.sin(a)}return{real:n,imag:r}}function pd(e,t,n){let r=(n?2:-2)*Math.PI*(e/t);return{real:Math.cos(r),imag:Math.sin(r)}}var md=`->`,hd=/->/g,gd=`,`,_d=`...`;function vd(e,t){e=e.replace(/\s/g,``);let n=(e.length-e.replace(hd,``).length)/2;if(n<1)throw Error(`Equations without an arrow are not supported.`);if(n>1)throw Error(`Equation must contain exactly one arrow ("${md}").`);let[r,i]=e.split(md);o(r.indexOf(_d)===-1,()=>`The ellipsis notation ("${_d}") is not supported yet.`);let a=r.split(gd),s=a.length;if(t!==s)throw Error(`Expected ${s} input tensors, received ${t}`);if(s>2)throw Error(`Support for more than 2 input tensors is not implemented yet.`);let c=[];for(let e=0;e<i.length;++e){let t=i[e];if(!a.some(e=>e.indexOf(t)!==-1))throw Error(`Output subscripts contain the label ${t} not present in the input subscripts.`);c.indexOf(t)===-1&&c.push(t)}for(let e=0;e<r.length;++e){let t=r[e];c.indexOf(t)===-1&&t!==gd&&c.push(t)}let l=Array(a.length);for(let e=0;e<s;++e){if(new Set(a[e].split(``)).size!==a[e].length)throw Error(`Found duplicate axes in input component ${a[e]}. Support for duplicate axes in input is not implemented yet.`);l[e]=[];for(let t=0;t<a[e].length;++t)l[e].push(c.indexOf(a[e][t]))}let u=c.length,d=i.length,f=[];for(let e=d;e<u;++e)f.push(e);return{allDims:c,summedDims:f,idDims:l}}function yd(e,t){let n=Array(e);n.fill(-1);for(let e=0;e<t.length;++e)n[t[e]]=e;let r=[];for(let t=0;t<e;++t)n[t]===-1&&r.push(t);return n=n.filter(e=>e!==-1),{permutationIndices:n,expandDims:r}}function bd(e,t,n){let r=Array(e);for(let e=0;e<n.length;++e){let i=n[e].shape;for(let n=0;n<t[e].length;++n)r[t[e][n]]===void 0?r[t[e][n]]=i[n]:o(r[t[e][n]]===i[n],()=>`Expected dimension ${r[t[e][n]]} at axis ${n} of input shaped ${JSON.stringify(i)}, but got dimension ${i[n]}`)}}function xd(e,t){let n=e,r=[],i=0;e.length===0&&n.push(-1),i=e.length+1;for(let e=0;e<i;++e)r.push([]);let a=[];for(let e=0;e<n.length;++e){let i=n[e],o=Cd(t,i);for(let t of o)a.indexOf(t)===-1&&(r[e].push(t),a.push(t))}return{path:n,steps:r}}function Sd(e){return e.every((e,t)=>e===t)}function Cd(e,t){let n=[];for(let r=0;r<e.length;++r)(e[r].length===0||e[r].indexOf(t)!==-1||t===-1)&&n.push(r);return n}function wd(e,t,n=0){let r=[];if(typeof t==`number`)o(e.shape[n]%t===0,()=>`Number of splits must evenly divide the axis.`),r=Array(t).fill(e.shape[n]/t);else{o(t.reduce((e,t)=>(t===-1&&(e+=1),e),0)<=1,()=>`There should be only one negative value in split array.`);let i=t.indexOf(-1);if(i!==-1){let r=t.reduce((e,t)=>t>0?e+t:e);t[i]=e.shape[n]-r}o(e.shape[n]===t.reduce((e,t)=>e+t),()=>`The sum of sizes must match the size of the axis dimension.`),r=t}return r}function Td(e){return`Received SparseTensor with denseShape[0] = 0 but
  indices.shape[0] = ${e}`}function Ed(e,t){return`indices(${e}, 0) is invalid: ${t} < 0`}function Dd(e,t,n){return`indices(${e}, 0) is invalid: ${t} >= ${n}`}function Od(e,t){return`only one output dimension may be -1, not both ${e} and ${t}`}function kd(e,t){return`size ${e} must be non-negative, not ${t}`}function Ad(){return`reshape cannot infer the missing input size for an empty tensor unless all specified input sizes are non-zero`}function jd(e,t){return`Input to reshape is a SparseTensor with ${k(e)}
  dense values, but the requested shape requires a multiple of ${k(t)}. inputShape=${e} outputShape= ${t}`}function Md(e,t){return`Input to reshape is a tensor with ${k(e)} dense values, but the requested shape has ${k(t)}. inputShape=${e} outputShape=${t}`}function Nd(){return`segment ids must be >= 0`}function Pd(){return`segment ids are not increasing`}function Fd(e,t){return`Segment id ${e} out of range [0, ${t}), possibly because segmentIds input is not sorted.`}function Id(e,t,n){return`Bad: indices[${e}] == ${t} out of range [0, ${n})`}var Ld=e({collectGatherOpShapeInfo:()=>Bd,computeOutShape:()=>zd,segOpComputeOptimalWindowSize:()=>Rd});function Rd(e,t){let n=!1,r;for(e<=30?(r=e,n=!0):r=Il(e,Math.floor(Math.sqrt(e)));!n;)r>t||r===e?n=!0:r=Il(e,r+1);return r}function zd(e,t,n){let r=[],i=e.length;for(let a=0;a<i;a++)a===t?r.push(n):r.push(e[a]);return r}function Bd(e,t,n,r){let i=t.shape.length,a=e.shape.length;if(r!==0&&(r<-i||r>i))throw Error(`Expect batchDims in the range of [-${i}, ${i}], but got ${r}`);if(r<0&&(r+=i),r>a)throw Error(`batchDims (${r}) must be less than rank(x) (
    ${a}).`);if(n<r)throw Error(`batchDims (${r}) must be less than or equal to axis (${n}).`);for(let n=0;n<r;++n)if(e.shape[n]!==t.shape[n])throw Error(`x.shape[${n}]: ${e.shape[n]} should be equal to indices.shape[${n}]: ${t.shape[n]}.`);let o=e.shape[n],s=[],c=1,l=1,u=1;for(let t=0;t<r;++t)s.push(e.shape[t]),c*=e.shape[t];for(let t=r;t<n;t++)s.push(e.shape[t]),l*=e.shape[t];for(let e=r;e<i;e++)s.push(t.shape[e]);for(let t=n+1;t<a;t++)s.push(e.shape[t]),u*=e.shape[t];return{batchSize:c,sliceSize:u,outerSize:l,dimSize:o,outputShape:s}}var Vd=e({ERF_A1:()=>td,ERF_A2:()=>nd,ERF_A3:()=>rd,ERF_A4:()=>id,ERF_A5:()=>ad,ERF_P:()=>ed,PARALLELIZE_THRESHOLD:()=>30,RowPartitionType:()=>Bu,SELU_SCALE:()=>$u,SELU_SCALEALPHA:()=>Qu,applyActivation:()=>Rr,assertAndGetBroadcastShape:()=>xi,assertAxesAreInnerMostDims:()=>cn,assertParamsConsistent:()=>Ru,assignToTypedArray:()=>dd,axesAreInnerMostDims:()=>yn,calculateShapes:()=>Xa,checkEinsumDimSizes:()=>bd,checkPadOnDimRoundingMode:()=>E,combineLocations:()=>Bn,combineRaggedTensorToTensorShapes:()=>Vu,complexWithEvenIndex:()=>cd,complexWithOddIndex:()=>ld,computeConv2DInfo:()=>Vr,computeConv3DInfo:()=>st,computeDefaultPad:()=>jr,computeDilation2DInfo:()=>Zr,computeOptimalWindowSize:()=>Gu,computeOutAndReduceShapes:()=>Ge,computeOutShape:()=>zu,computePool2DInfo:()=>Ze,computePool3DInfo:()=>Lt,convertConv2DDataFormat:()=>nc,decodeEinsumEquation:()=>vd,eitherStridesOrDilationsAreOne:()=>Dt,expandShapeToKeepDim:()=>xt,exponent:()=>pd,exponents:()=>fd,fromStringArrayToUint8:()=>Ud,fromUint8ToStringArray:()=>Hd,getAxesPermutation:()=>Zt,getBroadcastDims:()=>Ai,getComplexWithIndex:()=>ud,getEinsumComputePath:()=>xd,getEinsumPermutation:()=>yd,getFusedBiasGradient:()=>it,getFusedDyActivation:()=>kr,getImageCenter:()=>Ku,getInnerMostAxes:()=>or,getPermuted:()=>Ju,getRaggedRank:()=>Uu,getReductionAxes:()=>Xn,getReshaped:()=>qu,getReshapedPermuted:()=>Yu,getRowPartitionTypesHelper:()=>Hu,getSliceBeginCoords:()=>Xu,getSliceSize:()=>Zu,getSparseFillEmptyRowsIndicesDenseShapeMismatch:()=>Td,getSparseFillEmptyRowsNegativeIndexErrorMessage:()=>Ed,getSparseFillEmptyRowsOutOfRangeIndexErrorMessage:()=>Dd,getSparseReshapeEmptyTensorZeroOutputDimErrorMessage:()=>Ad,getSparseReshapeInputOutputMismatchErrorMessage:()=>Md,getSparseReshapeInputOutputMultipleErrorMessage:()=>jd,getSparseReshapeMultipleNegativeOneOutputDimErrorMessage:()=>Od,getSparseReshapeNegativeOutputDimErrorMessage:()=>kd,getSparseSegmentReductionIndicesOutOfRangeErrorMessage:()=>Id,getSparseSegmentReductionNegativeSegmentIdsErrorMessage:()=>Nd,getSparseSegmentReductionNonIncreasingSegmentIdsErrorMessage:()=>Pd,getSparseSegmentReductionSegmentIdOutOfRangeErrorMessage:()=>Fd,getUndoAxesPermutation:()=>Ul,isIdentityPermutation:()=>Sd,log:()=>Jo,mergeRealAndImagArrays:()=>od,prepareAndValidate:()=>du,prepareSplitSize:()=>wd,segment_util:()=>Ld,shouldFuse:()=>Jr,slice_util:()=>fu,splitRealAndImagArrays:()=>sd,stridesOrDilationsArePositive:()=>_i,tupleValuesAreOne:()=>si,upcastType:()=>Rs,validateDefaultValueShape:()=>Wu,validateInput:()=>ys,validateUpdateShape:()=>vo,warn:()=>v});function Hd(e){try{return e.map(e=>qa(e))}catch(e){throw Error(`Failed to decode encoded string bytes into utf-8, error: ${e}`)}}function Ud(e){return e.map(e=>Js(e))}var Wd=e({nonMaxSuppressionV3Impl:()=>fn,nonMaxSuppressionV4Impl:()=>Nn,nonMaxSuppressionV5Impl:()=>Re,whereImpl:()=>_c}),Gd=`4.22.0`,Kd={kernelName:`Abs`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,hl(F(n,`float32`),-1))}}},qd={kernelName:sn,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>{let t=Pe(F(n,`float32`));return li(N(e,Ce(L(kn(1),t))))}}}},Jd={kernelName:vn,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,Ce(L(Pe(F(n,`float32`)),1)))}}},Yd={kernelName:`Add`,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=e,r=Xn(n.shape,i);return r.length>0&&(t=O(t,r)),U(t,n.shape)},b:()=>{let t=e,n=Xn(r.shape,i);return n.length>0&&(t=O(t,n)),U(t,r.shape)}}}},Xd={kernelName:We,saveAllInputs:!0,gradFunc:(e,t)=>{let n={};return t.forEach((t,r)=>{n[r]=()=>e.clone()}),n}},Zd={kernelName:ar,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>Vt(n)}}},Qd={kernelName:Hl,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>Vt(n)}}},$d={kernelName:ne,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,Ce(L(kn(1),Pe(F(n,`float32`)))))}}},ef={kernelName:Wr,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,Ce(I(kn(1),Pe(F(n,`float32`)))))}}},tf={kernelName:Pr,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=I(Pe(n),Pe(r)),a=z(e,N(r,t)),o=Xn(n.shape,i);return o.length>0&&(a=O(a,o)),U(a,n.shape)},b:()=>{let t=I(Pe(n),Pe(r)),a=li(z(e,N(n,t))),o=Xn(r.shape,i);return o.length>0&&(a=O(a,o)),U(a,r.shape)}}}},nf={kernelName:ut,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,I(Pe(F(n,`float32`)),1))}}},rf={kernelName:ei,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,L(kn(1),Pe(F(n,`float32`))))}}};function af(e,t,n,r,i,a){let s=hi(e,`dy`,`avgPool3dGrad`),c=hi(t,`input`,`avgPool3dGrad`),l=s,u=c,d=!1;c.rank===4&&(d=!0,l=U(s,[1,s.shape[0],s.shape[1],s.shape[2],s.shape[3]]),u=U(c,[1,c.shape[0],c.shape[1],c.shape[2],c.shape[3]])),o(l.rank===5,()=>`Error in avgPool3dGrad: dy must be rank 5 but got rank ${l.rank}.`),o(u.rank===5,()=>`Error in avgPool3dGrad: input must be rank 5 but got rank ${u.rank}.`),E(`avgPool3dGrad`,i,a);let f={dy:l,input:u},p={filterSize:n,strides:r,pad:i,dimRoundingMode:a},m=La.runKernel(ic,f,p);return d?U(m,[m.shape[1],m.shape[2],m.shape[3],m.shape[4]]):m}var of=Tt({avgPool3dGrad_:af}),sf={kernelName:Bt,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{filterSize:i,strides:a,pad:o,dimRoundingMode:s}=n;return{x:()=>of(e,r,i,a,o,s)}}};function cf(e,t,n,r,i){let a=hi(e,`dy`,`avgPoolGrad`),s=hi(t,`input`,`avgPoolGrad`);o(s.rank===a.rank,()=>`Rank of input (${s.rank}) does not match rank of dy (${a.rank})`);let c=s,l=a,u=!1;s.rank===3&&(u=!0,c=U(s,[1,s.shape[0],s.shape[1],s.shape[2]]),l=U(a,[1,a.shape[0],a.shape[1],a.shape[2]])),o(l.rank===4,()=>`Error in avgPoolGrad: dy must be rank 4 but got rank ${l.rank}.`),o(c.rank===4,()=>`Error in avgPoolGrad: input must be rank 4 but got rank ${c.rank}.`);let d={dy:l,input:c},f={filterSize:n,strides:r,pad:i},p=La.runKernel(At,d,f);return u?U(p,[p.shape[1],p.shape[2],p.shape[3]]):p}var lf=Tt({avgPoolGrad_:cf}),uf={kernelName:et,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{filterSize:i,strides:a,pad:o}=n;return{x:()=>lf(e,r,i,a,o)}}},df={kernelName:bi,inputsToSave:[`a`,`b`],gradFunc:(e,t,n)=>{let[r,i]=t,{transposeA:a,transposeB:o}=n;return!a&&!o?{a:()=>Ve(e,i,!1,!0),b:()=>Ve(r,e,!0,!1)}:!a&&o?{a:()=>Ve(e,i,!1,!1),b:()=>Ve(e,r,!0,!1)}:a&&!o?{a:()=>Ve(i,e,!1,!0),b:()=>Ve(r,e,!1,!1)}:{a:()=>Ve(i,e,!0,!0),b:()=>Ve(e,r,!0,!0)}}},ff={kernelName:ui,gradFunc:(e,t,n)=>{let{blockShape:r,crops:i}=n;return{x:()=>mo(e,r,i)}}},pf={kernelName:za,gradFunc:(e,t,n)=>{let r=n,i=r.inputShape,a=r.shape,o=Array.from(a);for(let e=i.length-1;e>=0;e--)if(i[e]===a[e])o[e]=1;else if(i[e]!==1)throw Error(`broadcastTo(): [${i}] cannot be broadcast to [${a}].`);let s=[];for(let e=0;e<o.length;e++)o[e]>1&&s.push(e);return{x:()=>O(e,s,!0)}}},mf={kernelName:Lc,gradFunc:e=>({x:()=>e.clone()})},hf={kernelName:ks,gradFunc:e=>({x:()=>Vt(e)})},gf={kernelName:gc,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{clipValueMin:i,clipValueMax:a}=n;return{x:()=>ac($r(_s(r,i),Tc(r,a)),e,Vt(e))}}},_f={kernelName:Zi,inputsToSave:[`x`],gradFunc:Kd.gradFunc},vf={kernelName:Bs,saveAllInputs:!0,gradFunc:(e,t,n)=>{let r=t.map(e=>e.shape),{axis:i}=n,a=H(i,t[0].shape)[0];return Zo(e,r.map(e=>e[a]),a).map(e=>()=>e)}},yf={kernelName:Ec,inputsToSave:[`x`,`filter`],gradFunc:(e,t,n)=>{let[r,i]=t,{dilations:a,strides:s,pad:c,dataFormat:l}=n;return o(si(a),()=>`Error in gradient of conv2D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${a}'`),{x:()=>Wa(r.shape,e,i,s,c,l),filter:()=>Je(r,e,i.shape,s,c,l)}}},bf={kernelName:ss,inputsToSave:[`dy`,`filter`],gradFunc:(e,t,n)=>{let[r,i]=t,{strides:a,pad:o,dataFormat:s,dimRoundingMode:c}=n;return{dy:()=>ps(e,i,a,o,s,1,c),filter:()=>Je(e,r,i.shape,a,o,s,c)}}};function xf(e,t,n,r,i){let a=e;e.rank===4&&(a=U(e,[1,e.shape[0],e.shape[1],e.shape[2],e.shape[3]]));let s=t;s.rank===4&&(s=U(t,[1,t.shape[0],t.shape[1],t.shape[2],t.shape[3]])),o(a.rank===5,()=>`Error in conv3dDerFilter: input must be rank 5, but got shape ${a.shape}.`),o(s.rank===5,()=>`Error in conv3dDerFilter: dy must be rank 5, but got shape ${s.shape}.`),o(n.length===5,()=>`Error in conv3dDerFilter: filterShape must be length 5, but got ${n}.`),o(a.shape[4]===n[3],()=>`Error in conv3dDerFilter: depth of input ${a.shape[4]}) must match input depth in filter (${n[3]}.`),o(s.shape[4]===n[4],()=>`Error in conv3dDerFilter: depth of dy (${s.shape[4]}) must match output depth for filter (${n[4]}).`);let c={x:a,dy:s},l={strides:r,pad:i,filterShape:n};return La.runKernel(ka,c,l)}var Sf=Tt({conv3DBackpropFilter_:xf}),Cf={kernelName:Kc,inputsToSave:[`x`,`filter`],gradFunc:(e,t,n)=>{let{dilations:r,strides:i,pad:a}=n;o(si(r),()=>`Error in gradient of conv3D: dilation rates greater than 1 are not yet supported in gradients. Got dilations '${r}'`);let[s,c]=t;return{x:()=>ns(s.shape,e,c,i,a),filter:()=>Sf(s,e,c.shape,i,a)}}},wf={kernelName:`Cos`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(li(Gl(F(n,`float32`))),e)}}},Tf={kernelName:vs,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(cr(F(n,`float32`)),e)}}},Ef={kernelName:Bi,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{axis:i,exclusive:a,reverse:o}=n;return{x:()=>{let t=Zt([i],r.rank),n=Co(e,i,a,!o);return t!=null&&(n=P(n,t)),n}}}},Df={kernelName:ca,inputsToSave:[`x`,`filter`],gradFunc:(e,t,n)=>{let{dilations:r,strides:i,pad:a,dimRoundingMode:s}=n,c=r??[1,1];o(si(c),()=>`Error in gradient of depthwiseConv2dNative: dilation rates greater than 1 are not yet supported. Got dilations '${c}'`);let[l,u]=t;return o(l.rank===4,()=>`Error in gradient of depthwiseConv2dNative: input must be rank 4, but got rank ${l.rank}.`),o(u.rank===4,()=>`Error in gradient of depthwiseConv2dNative: filter must be rank 4, but got rank ${u.rank}.`),o(l.shape[3]===u.shape[2],()=>`Error in gradient of depthwiseConv2d: number of input channels (${l.shape[3]}) must match the inChannels dimension in filter ${u.shape[2]}.`),o(Dt(i,c),()=>`Error in gradient of depthwiseConv2d: Either strides or dilations must be  1. Got strides ${i} and dilations '${c}'.`),E(`depthwiseConv2d`,a,s),{x:()=>$n(l.shape,e,u,i,a,c,s),filter:()=>Ll(l,e,u.shape,i,a,c,s)}}},Of={kernelName:ml,inputsToSave:[`x`,`filter`],gradFunc:(e,t,n)=>{let[r,i]=t,a={x:r,filter:i,dy:e},o={x:r,filter:i,dy:e};return{x:()=>La.runKernel(Fe,a,n),filter:()=>La.runKernel(Dr,o,n)}}},kf={kernelName:`Elu`,outputsToSave:[!0],gradFunc:(e,t)=>{let[n]=t,r={dy:e,y:n};return{x:()=>La.runKernel(b,r)}}},Af={kernelName:`Erf`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t,r=z(gr(li(Pe(n))),2/Math.sqrt(Math.PI));return{x:()=>z(e,r)}}},jf={kernelName:`Exp`,outputsToSave:[!0],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,n)}}},Mf={kernelName:Vn,inputsToSave:[`input`],gradFunc:(e,t)=>{let[n]=t;return{input:()=>U(e,n.shape)}}},Nf={kernelName:Ke,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,gr(n))}}},Pf={kernelName:Wl,gradFunc:e=>({x:()=>Vt(e)})},Ff={kernelName:ie,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=N(e,F(r,`float32`)),a=Xn(n.shape,i);return a.length>0?U(O(t,a),n.shape):t},b:()=>{let t=z(e,F(n,`float32`)),a=Xn(r.shape,i);a.length>0&&(t=U(O(t,a),r.shape));let o=Pe(r);return li(N(t,F(o,`float32`)))}}}},If={kernelName:ft,inputsToSave:[`x`,`mean`,`variance`,`scale`],gradFunc:(e,t,n)=>{let{varianceEpsilon:r}=n,[i,a,o,s]=t,c=s??kn(1),l=Xn(a.shape,i.shape),u=[];if(a.rank===1){for(let e=0;e<i.shape.length-1;++e)u.push(i.shape[e]);u.push(1)}let d=L(i,a),f=z(e,c),p=ri(I(o,kn(r))),m=z(z(z(p,p),p),kn(-.5));return{x:()=>a.rank===1?U(z(z(e,Nl(U(p,[1,1,1,a.shape[0]]),u)),c),i.shape):U(z(z(e,p),c),i.shape),mean:()=>{let e=z(z(p,kn(-1)),f);return a.rank===1&&(e=O(e,l)),U(e,a.shape)},variance:()=>{let e=z(z(m,d),f);return a.rank===1&&(e=O(e,l)),U(e,a.shape)},scale:()=>{let t=z(e,z(d,p));return a.rank===1&&(t=O(t,l)),U(t,a.shape)},offset:()=>{let t=e;return a.rank===1&&(t=O(t,l)),U(t,a.shape)}}}},Lf={kernelName:Ht,inputsToSave:[`x`,`indices`],gradFunc:(e,t,n)=>{let[r,i]=t,{axis:a,batchDims:o}=n,s=H(a,r.shape)[0],c=(e,t,n)=>()=>{let r=e.shape,i=t.size,o=r.slice(0,s),c=o.length,l=r.slice(a,r.length).slice(1),u=l.length,d=Rf(0,c),f=Rf(c+1,c+1+u),p=U(n,zf([o,[i],l])),m=U(t,[i]),h=zf([[c],d,f]),g=Dc(P(p,h),m,e.shape[s]),_=Ul(h);return g=P(g,_),g};if(o===1){let t=r.shape[0],n=r.split(t,0);return{x:()=>Or(n.map((t,n)=>c(t,i.slice(n,1),e.slice(n,1))())).reshape(r.shape),indices:()=>i}}else return{x:c(r,i,e),indices:()=>i}}};function Rf(e,t){let n=[];for(let r=e;r<t;++r)n.push(r);return n}function zf(e){let t=[];for(let n=0;n<e.length;++n)for(let r=0;r<e[n].length;++r)t.push(e[n][r]);return t}var Bf={kernelName:Mt,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t;return{a:()=>Vt(n),b:()=>Vt(r)}}},Vf={kernelName:fi,gradFunc:e=>({x:()=>F(e,`float32`)})},Hf={kernelName:Zn,gradFunc:e=>({x:()=>Vt(e)})},Uf={kernelName:u,gradFunc:e=>({x:()=>Vt(e)})},Wf={kernelName:Na,gradFunc:e=>({x:()=>Vt(e)})},Gf={kernelName:uc,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{alpha:i}=n,a=go(r,0);return{x:()=>ac(a,e,z(e,i))}}},Kf={kernelName:pa,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,I(n,1))}}},qf={kernelName:`Log`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,F(n,`float32`))}}},Jf={kernelName:ts,inputsToSave:[],outputsToSave:[!0],gradFunc:(e,t,n)=>{let[r]=t,{axis:i}=n;return{logits:()=>{let t=gr(r);return L(e,z(O(e,i,!0),t))}}}};function Yf(e,t,n,r=5,i=1,a=1,o=.5){let s={x:e,y:t,dy:n},c={depthRadius:r,bias:i,alpha:a,beta:o};return La.runKernel(Cs,s,c)}var Xf=Tt({localResponseNormalizationBackprop_:Yf}),Zf={kernelName:`LRN`,inputsToSave:[`x`],outputsToSave:[!0],gradFunc:(e,t,n)=>{let[r,i]=t,{depthRadius:a,bias:o,alpha:s,beta:c}=n;return{x:()=>Xf(r,i,e,a,o,s,c)}}};function Qf(e,t,n,r){return t.rank<n.rank&&(t=U(t,xt(t.shape,r))),e.rank<n.rank&&(e=U(e,xt(e.shape,r))),{x:()=>z(e,F(jt(n,t),e.dtype))}}var $f={kernelName:`Max`,inputsToSave:[`x`],outputsToSave:[!0],gradFunc:(e,t,n)=>{let{reductionIndices:r}=n,i=t[0],a=t[1],o=Qf(e,a,i,H(r,i.shape));return{x:()=>o.x()}}},ep={kernelName:dr,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t;return{a:()=>z(e,F(_s(n,r),`float32`)),b:()=>z(e,F(va(n,r),`float32`))}}};function tp(e,t,n,r,i,a,s){let c=hi(e,`dy`,`maxPool3dGrad`),l=hi(t,`input`,`maxPool3dGrad`),u=hi(n,`output`,`maxPool3dGrad`),d=c,f=l,p=u,m=!1;l.rank===4&&(m=!0,d=U(c,[1,c.shape[0],c.shape[1],c.shape[2],c.shape[3]]),f=U(l,[1,l.shape[0],l.shape[1],l.shape[2],l.shape[3]]),p=U(u,[1,u.shape[0],u.shape[1],u.shape[2],u.shape[3]])),o(d.rank===5,()=>`Error in maxPool3dGrad: dy must be rank 5 but got rank ${d.rank}.`),o(f.rank===5,()=>`Error in maxPool3dGrad: input must be rank 5 but got rank ${f.rank}.`),o(p.rank===5,()=>`Error in maxPool3dGrad: output must be rank 5 but got rank ${p.rank}.`),E(`maxPool3dGrad`,a,s);let h={dy:d,input:f,output:p},g={filterSize:r,strides:i,pad:a,dimRoundingMode:s},_=La.runKernel(Ol,h,g);return m?U(_,[_.shape[1],_.shape[2],_.shape[3],_.shape[4]]):_}var np=Tt({maxPool3dGrad_:tp}),rp={kernelName:Zc,inputsToSave:[`x`],outputsToSave:[!0],gradFunc:(e,t,n)=>{let[r,i]=t,{filterSize:a,strides:o,pad:s,dimRoundingMode:c}=n;return{x:()=>np(e,r,i,a,o,s,c)}}};function ip(e,t,n,r,i,a,s){let c=hi(e,`dy`,`maxPoolGrad`),l=hi(t,`input`,`maxPoolGrad`),u=hi(n,`output`,`maxPoolGrad`);o(l.rank===c.rank,()=>`Rank of input (${l.rank}) does not match rank of dy (${c.rank})`),o(c.rank===4,()=>`Error in maxPoolGrad: dy must be rank 4 but got rank ${c.rank}.`),o(l.rank===4,()=>`Error in maxPoolGrad: input must be rank 4 but got rank ${l.rank}.`),E(`maxPoolGrad`,a,s);let d={dy:c,input:l,output:u},f={filterSize:r,strides:i,pad:a,dimRoundingMode:s};return La.runKernel(na,d,f)}var ap=Tt({maxPoolGrad_:ip}),op={kernelName:Pi,inputsToSave:[`x`],outputsToSave:[!0],gradFunc:(e,t,n)=>{let[r,i]=t,{filterSize:a,strides:o,pad:s}=n;return{x:()=>ap(e,r,i,a,o,s)}}},sp={kernelName:ce,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{axis:i}=n,a=H(i,r.shape),o=Ge(r.shape,a)[1],s=k(o);return{x:()=>{let t=r.shape.slice();return a.forEach(e=>{t[e]=1}),N(z(U(e,t),on(r.shape,`float32`)),s)}}}},cp={kernelName:`Min`,inputsToSave:[`x`],outputsToSave:[!0],gradFunc:(e,t,n)=>{let{axis:r}=n,[i,a]=t,o=Qf(e,a,i,H(r,i.shape));return{x:()=>o.x()}}},lp={kernelName:Sr,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t;return{a:()=>z(e,F(Tc(n,r),`float32`)),b:()=>z(e,F(go(n,r),`float32`))}}},up={kernelName:ke,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let r=t[0],{paddings:i}=n,a=i.map(e=>e[0]);return{x:()=>hn(e,a,r.shape)}}},dp={kernelName:`Mod`,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=Xn(n.shape,i);return t.length>0?U(O(e,t),n.shape):e},b:()=>{let t=z(e,li(zi(N(n,r)))),a=Xn(r.shape,i);return a.length>0?U(O(t,a),r.shape):t}}}},fp={kernelName:Wo,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=z(e,F(r,`float32`)),a=Xn(n.shape,i);return a.length>0?U(O(t,a),n.shape):t},b:()=>{let t=z(e,F(n,`float32`)),a=Xn(r.shape,i);return a.length>0?U(O(t,a),r.shape):t}}}},pp={kernelName:`Neg`,gradFunc:e=>({x:()=>li(e)})},mp={kernelName:Be,inputsToSave:[`indices`],gradFunc:(e,t)=>{let n=t[0];return{indices:()=>_n(n.shape,`float32`)}}},hp={kernelName:gt,gradFunc:e=>({x:()=>Vt(e)})},gp={kernelName:Kt,saveAllInputs:!0,gradFunc:(e,t,n)=>{let{axis:r}=n;return Vs(e,r).map(e=>()=>e)}},_p={kernelName:tr,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let r=t[0],{paddings:i}=n,a=i.map(e=>e[0]);return{x:()=>hn(e,a,r.shape)}}},vp={kernelName:`Pow`,inputsToSave:[`a`,`b`],outputsToSave:[!0],gradFunc:(e,t)=>{let[n,r,i]=t,a=n,o=r,s=xi(a.shape,o.shape);return{a:()=>{let t=F(o,`float32`),n=z(e,z(t,Yo(a,L(t,kn(1))))),r=Xn(a.shape,s);return r.length>0&&(n=O(n,r)),U(n,a.shape)},b:()=>{let t=ac(go(a,0),Do(a),Vt(a)),n=z(e,z(i,t)),r=Xn(o.shape,s);return r.length>0&&(n=O(n,r)),U(n,o.shape)}}}},yp={kernelName:Br,inputsToSave:[`x`,`alpha`],gradFunc:(e,t)=>{let[n,r]=t,i=go(n,0);return{x:()=>ac(i,e,z(e,r)),alpha:()=>{let t=ac(i,Vt(e),z(e,n)),a=Xn(r.shape,e.shape);return a.length>0&&(t=O(t,a)),U(t,r.shape)}}}};function bp(e,t,n){let r=e.shape.slice();return r[n]=1,z(U(t,r),z(Ki(e,n,!0,!1),Ki(e,n,!0,!0)))}function xp(e,t,n){let r=e.shape.length,i=r-n.length,a=Zt(n,r),o=e;a!=null&&(o=P(e,a));let s=o.shape.slice(),c=s.splice(r-n.length,n.length).reduce((e,t)=>e*t,1);s.push(c);let l=bp(o.reshape(s),t,i);if(l=l.reshape(o.shape),a!=null){let e=Ul(a);l=P(l,e)}return l}var Sp={kernelName:ot,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{axis:i}=n,a=[];return a=i==null?r.shape.map((e,t)=>t):typeof i==`number`?[i]:i,{x:()=>xp(r,e,a)}}},Cp={kernelName:Et,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=N(e,F(r,`float32`)),a=Xn(n.shape,i);return a.length>0?U(O(t,a),n.shape):t},b:()=>{let t=z(e,F(n,`float32`)),a=Xn(r.shape,i);a.length>0&&(t=U(O(t,a),r.shape));let o=Pe(r);return li(N(t,F(o,`float32`)))}}}},wp={kernelName:gi,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,li(Pe(n)))}}},Tp={kernelName:Ei,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t,r=z(Tc(n,6),hl(n));return{x:()=>z(e,F(r,`float32`))}}},Ep={kernelName:oi,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,F(hl(n),`float32`))}}},Dp={kernelName:Gn,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>U(e,n.shape)}}},Op={kernelName:i,inputsToSave:[`images`],gradFunc:(e,t,n)=>{let[r]=t,i={dy:e,images:r};return{images:()=>La.runKernel(Fa,i,n)}}},kp={kernelName:Nc,inputsToSave:[`images`],gradFunc:(e,t,n)=>{let[r]=t,i={dy:e,images:r};return{images:()=>La.runKernel(Ts,i,n)}}},Ap={kernelName:fc,gradFunc:(e,t,n)=>{let{dims:r}=n,i=H(r,e.shape);return{x:()=>pi(e,i)}}},jp={kernelName:qi,gradFunc:e=>({x:()=>Vt(e)})},Mp={kernelName:Is,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>li(N(e,z(Yo(n,1.5),2)))}}},Np={kernelName:rs,inputsToSave:[`condition`],gradFunc:(e,t)=>{let[n]=t;return{condition:()=>F(Vt(n),`float32`),t:()=>z(e,F(n,e.dtype)),e:()=>z(e,F(Nr(n),e.dtype))}}},Pp={kernelName:Uc,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>{let t=go(n,kn(0)),r=kn(Qu);return ac(t,z(e,kn($u)),z(z(e,r),gr(F(n,`float32`))))}}}},Fp={kernelName:Ta,outputsToSave:[!0],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,z(n,L(kn(1),n)))}}},Ip={kernelName:Ga,gradFunc:e=>({x:()=>Vt(e)})},Lp={kernelName:`Sin`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(xc(F(n,`float32`)),e)}}},Rp={kernelName:ms,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(Fs(F(n,`float32`)),e)}}},zp={kernelName:po,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{begin:i,size:a}=n,o=r.shape,[s,c]=ku(r,i,a),l=[];for(let t=0;t<e.rank;t++)l.push([s[t],o[t]-s[t]-c[t]]);return{x:()=>aa(e,l)}}},Bp={kernelName:to,outputsToSave:[!0],gradFunc:(e,t,n)=>{let[r]=t,{dim:i}=n,a=z(e,r);return{logits:()=>L(a,z(O(a,[i],!0),r))}}},Vp={kernelName:Ii,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,In(n))}}},Hp={kernelName:$c,gradFunc:(e,t,n)=>{let{blockShape:r,paddings:i}=n;return{x:()=>h(e,r,i)}}},Up={kernelName:ul,gradFunc:(e,t,n)=>{let{axis:r}=n;return{x:()=>_t(e,r)}}},Wp={kernelName:wr,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,z(Ce(F(n,`float32`)),2))}}},Gp={kernelName:je,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(e,z(F(n,`float32`),2))}}},Kp={kernelName:be,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=kn(2);return{a:()=>z(e,z(i,L(n,r))),b:()=>z(e,z(i,L(r,n)))}}},qp={kernelName:Ko,gradFunc:e=>({x:()=>Vt(e)})},Jp={kernelName:`Sub`,inputsToSave:[`a`,`b`],gradFunc:(e,t)=>{let[n,r]=t,i=xi(n.shape,r.shape);return{a:()=>{let t=e,r=Xn(n.shape,i);return r.length>0&&(t=O(t,r)),U(t,n.shape)},b:()=>{let t=e,n=Xn(r.shape,i);return n.length>0&&(t=O(t,n)),U(li(t),r.shape)}}}},Yp={kernelName:`Sum`,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,i=r.shape.slice(),{axis:a}=n;H(a,r.shape).forEach(e=>{i[e]=1});let o=z(U(e,i),on(r.shape,`float32`));return{x:()=>o}}},Xp={kernelName:`Tan`,inputsToSave:[`x`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>N(e,Pe(xc(n)))}}},Zp={kernelName:Jt,outputsToSave:[!0],gradFunc:(e,t)=>{let[n]=t;return{x:()=>z(L(kn(1),Pe(n)),e)}}},Qp={kernelName:Bl,inputsToSave:[`x`],gradFunc:(e,t,n)=>{let[r]=t,{reps:i}=n;return{x:()=>{let t=Vt(r);if(r.rank===1)for(let n=0;n<i[0];++n)t=I(t,hn(e,[n*r.shape[0]],[r.shape[0]]));else if(r.rank===2)for(let n=0;n<i[0];++n)for(let a=0;a<i[1];++a)t=I(t,hn(e,[n*r.shape[0],a*r.shape[1]],[r.shape[0],r.shape[1]]));else if(r.rank===3)for(let n=0;n<i[0];++n)for(let a=0;a<i[1];++a)for(let o=0;o<i[2];++o)t=I(t,hn(e,[n*r.shape[0],a*r.shape[1],o*r.shape[2]],[r.shape[0],r.shape[1],r.shape[2]]));else if(r.rank===4)for(let n=0;n<i[0];++n)for(let a=0;a<i[1];++a)for(let o=0;o<i[2];++o)for(let s=0;s<i[3];++s)t=I(t,hn(e,[n*r.shape[0],a*r.shape[1],o*r.shape[2],s*r.shape[3]],[r.shape[0],r.shape[1],r.shape[2],r.shape[3]]));else throw Error(`Gradient for tile operation is not implemented for rank-${r.rank} tensors yet.`);return t}}}},$p={kernelName:ct,gradFunc:(e,t,n)=>{let{perm:r}=n,i=Ul(r);return{x:()=>P(e,i)}}},em={kernelName:Qr,gradFunc:(e,t,n)=>{let{axis:r}=n;return{value:()=>Or(e,r)}}},tm={kernelName:Qe,inputsToSave:[`segmentIds`],gradFunc:(e,t)=>{let[n]=t;return{x:()=>nm(e,n)}}};function nm(e,t){let n=io(e,Ue(t,Vt(t))),r=_s(t,kn(0,`int32`)),i=n.rank-r.rank;for(let e=0;e<i;++e)r=Cl(r,e+1);r=$r(r,on(n.shape,`bool`));let a=Vt(n);return ac(r,n,a)}var rm=[Kd,qd,Jd,Yd,Xd,Zd,Qd,$d,ef,tf,nf,rf,sf,uf,df,ff,pf,mf,hf,gf,_f,vf,bf,yf,Cf,wf,Tf,Ef,Df,Of,Cp,kf,Af,jf,Mf,Nf,Ff,Pf,If,Lf,Bf,Vf,Hf,Uf,Wf,Gf,Kf,qf,Jf,Zf,$f,$f,ep,rp,op,sp,cp,lp,up,dp,fp,pp,mp,hp,gp,_p,_p,vp,yp,Sp,wp,Tp,Ep,Dp,Op,kp,Ap,jp,Mp,Np,Pp,Fp,Ip,Lp,Rp,zp,Bp,Vp,Hp,Hp,Up,Up,Wp,Kp,Gp,qp,Jp,Yp,Xp,Zp,Qp,$p,em,tm,{kernelName:rc,gradFunc:e=>({x:()=>Vt(e)})}];for(let e of rm)Er(e);B().prototype.abs=function(){return this.throwIfDisposed(),es(this)},B().prototype.acos=function(){return this.throwIfDisposed(),fa(this)},B().prototype.acosh=function(){return this.throwIfDisposed(),yc(this)},B().prototype.add=function(e){return this.throwIfDisposed(),I(this,e)},B().prototype.all=function(e,t){return this.throwIfDisposed(),Wi(this,e,t)},B().prototype.any=function(e,t){return this.throwIfDisposed(),xo(this,e,t)},B().prototype.argMax=function(e){return this.throwIfDisposed(),lc(this,e)},B().prototype.argMin=function(e){return this.throwIfDisposed(),Ss(this,e)},B().prototype.asScalar=function(){return this.throwIfDisposed(),o(this.size===1,()=>`The array must have only 1 element.`),U(this,[])},B().prototype.asType=function(e){return this.throwIfDisposed(),F(this,e)},B().prototype.as1D=function(){return this.throwIfDisposed(),U(this,[this.size])},B().prototype.as2D=function(e,t){return this.throwIfDisposed(),U(this,[e,t])},B().prototype.as3D=function(e,t,n){return this.throwIfDisposed(),U(this,[e,t,n])},B().prototype.as4D=function(e,t,n,r){return this.throwIfDisposed(),U(this,[e,t,n,r])},B().prototype.as5D=function(e,t,n,r,i){return this.throwIfDisposed(),U(this,[e,t,n,r,i])},B().prototype.asin=function(){return this.throwIfDisposed(),Ac(this)},B().prototype.asinh=function(){return this.throwIfDisposed(),Ma(this)},B().prototype.atan=function(){return this.throwIfDisposed(),a(this)},B().prototype.atan2=function(e){return this.throwIfDisposed(),Kn(this,e)},B().prototype.atanh=function(){return this.throwIfDisposed(),Di(this)},B().prototype.avgPool=function(e,t,n,r){return this.throwIfDisposed(),nr(this,e,t,n,r)},B().prototype.batchToSpaceND=function(e,t){return this.throwIfDisposed(),h(this,e,t)},B().prototype.batchNorm=function(e,t,n,r,i){return this.throwIfDisposed(),Go(this,e,t,n,r,i)},B().prototype.broadcastTo=function(e){return this.throwIfDisposed(),fr(this,e)},B().prototype.cast=function(e){return this.throwIfDisposed(),F(this,e)},B().prototype.ceil=function(){return this.throwIfDisposed(),yl(this)},B().prototype.clipByValue=function(e,t){return this.throwIfDisposed(),kl(this,e,t)},B().prototype.concat=function(e,t){return this.throwIfDisposed(),e instanceof wc&&(e=[e]),_t([this,...e],t)},B().prototype.conv1d=function(e,t,n,r,i,a){return this.throwIfDisposed(),Gs(this,e,t,n,r,i,a)},B().prototype.conv2dTranspose=function(e,t,n,r,i){return this.throwIfDisposed(),wa(this,e,t,n,r,i)},B().prototype.conv2d=function(e,t,n,r,i,a){return this.throwIfDisposed(),ps(this,e,t,n,r,i,a)},B().prototype.cos=function(){return this.throwIfDisposed(),xc(this)},B().prototype.cosh=function(){return this.throwIfDisposed(),Fs(this)},B().prototype.cumprod=function(e,t,n){return this.throwIfDisposed(),Ki(this,e,t,n)},B().prototype.cumsum=function(e,t,n){return this.throwIfDisposed(),Co(this,e,t,n)},B().prototype.depthToSpace=function(e,t){return this.throwIfDisposed(),ws(this,e,t)},B().prototype.depthwiseConv2d=function(e,t,n,r,i,a){return this.throwIfDisposed(),Mc(this,e,t,n,r,i,a)},B().prototype.dilation2d=function(e,t,n,r,i){return this.throwIfDisposed(),l(this,e,t,n,r,i)},B().prototype.divNoNan=function(e){return this.throwIfDisposed(),tt(this,e)},B().prototype.div=function(e){return this.throwIfDisposed(),N(this,e)},B().prototype.dot=function(e){return this.throwIfDisposed(),ti(this,e)},B().prototype.elu=function(){return this.throwIfDisposed(),dt(this)},B().prototype.equal=function(e){return this.throwIfDisposed(),jt(this,e)},B().prototype.erf=function(){return this.throwIfDisposed(),re(this)},B().prototype.euclideanNorm=function(e,t){return this.throwIfDisposed(),pe(this,e,t)},B().prototype.exp=function(){return this.throwIfDisposed(),gr(this)},B().prototype.expandDims=function(e){return this.throwIfDisposed(),Cl(this,e)},B().prototype.expm1=function(){return this.throwIfDisposed(),sa(this)},B().prototype.fft=function(){return this.throwIfDisposed(),un(this)},B().prototype.flatten=function(){return this.throwIfDisposed(),U(this,[this.size])},B().prototype.floor=function(){return this.throwIfDisposed(),zi(this)},B().prototype.floorDiv=function(e){return this.throwIfDisposed(),Ha(this,e)},B().prototype.gather=function(e,t,n){return this.throwIfDisposed(),io(this,e,t,n)},B().prototype.greaterEqual=function(e){return this.throwIfDisposed(),_s(this,e)},B().prototype.greater=function(e){return this.throwIfDisposed(),go(this,e)},B().prototype.ifft=function(){return this.throwIfDisposed(),Bo(this)},B().prototype.irfft=function(){return this.throwIfDisposed(),x(this)},B().prototype.isFinite=function(){return this.throwIfDisposed(),Ja(this)},B().prototype.isInf=function(){return this.throwIfDisposed(),Oa(this)},B().prototype.isNaN=function(){return this.throwIfDisposed(),Gc(this)},B().prototype.leakyRelu=function(e){return this.throwIfDisposed(),os(this,e)},B().prototype.lessEqual=function(e){return this.throwIfDisposed(),Tc(this,e)},B().prototype.less=function(e){return this.throwIfDisposed(),va(this,e)},B().prototype.localResponseNormalization=function(e,t,n,r){return this.throwIfDisposed(),Xi(this,e,t,n,r)},B().prototype.logSigmoid=function(){return this.throwIfDisposed(),kt(this)},B().prototype.logSoftmax=function(e){return this.throwIfDisposed(),zt(this,e)},B().prototype.logSumExp=function(e,t){return this.throwIfDisposed(),$e(this,e,t)},B().prototype.log=function(){return this.throwIfDisposed(),Do(this)},B().prototype.log1p=function(){return this.throwIfDisposed(),hc(this)},B().prototype.logicalAnd=function(e){return this.throwIfDisposed(),$r(this,e)},B().prototype.logicalNot=function(){return this.throwIfDisposed(),Nr(this)},B().prototype.logicalOr=function(e){return this.throwIfDisposed(),lt(this,e)},B().prototype.logicalXor=function(e){return this.throwIfDisposed(),Ur(this,e)},B().prototype.matMul=function(e,t,n){return this.throwIfDisposed(),Ve(this,e,t,n)},B().prototype.maxPool=function(e,t,n,r){return this.throwIfDisposed(),ir(this,e,t,n,r)},B().prototype.max=function(e,t){return this.throwIfDisposed(),Ro(this,e,t)},B().prototype.maximum=function(e){return this.throwIfDisposed(),Ue(this,e)},B().prototype.mean=function(e,t){return this.throwIfDisposed(),Rn(this,e,t)},B().prototype.min=function(e,t){return this.throwIfDisposed(),y(this,e,t)},B().prototype.minimum=function(e){return this.throwIfDisposed(),_(this,e)},B().prototype.mirrorPad=function(e,t){return this.throwIfDisposed(),qo(this,e,t)},B().prototype.mod=function(e){return this.throwIfDisposed(),Dn(this,e)},B().prototype.mul=function(e){return this.throwIfDisposed(),z(this,e)},B().prototype.neg=function(){return this.throwIfDisposed(),li(this)},B().prototype.norm=function(e,t,n){return this.throwIfDisposed(),pl(this,e,t,n)},B().prototype.notEqual=function(e){return this.throwIfDisposed(),dl(this,e)},B().prototype.oneHot=function(e,t=1,n=0){return this.throwIfDisposed(),de(this,e,t,n)},B().prototype.onesLike=function(){return this.throwIfDisposed(),mr(this)},B().prototype.pad=function(e,t){return this.throwIfDisposed(),aa(this,e,t)},B().prototype.pool=function(e,t,n,r,i,a){return this.throwIfDisposed(),hs(this,e,t,n,r,i,a)},B().prototype.pow=function(e){return this.throwIfDisposed(),Yo(this,e)},B().prototype.prelu=function(e){return this.throwIfDisposed(),qs(this,e)},B().prototype.prod=function(e,t){return this.throwIfDisposed(),Ka(this,e,t)},B().prototype.reciprocal=function(){return this.throwIfDisposed(),d(this)},B().prototype.relu=function(){return this.throwIfDisposed(),Qn(this)},B().prototype.relu6=function(){return this.throwIfDisposed(),Mi(this)},B().prototype.reshapeAs=function(e){return this.throwIfDisposed(),U(this,e.shape)},B().prototype.reshape=function(e){return this.throwIfDisposed(),U(this,e)},B().prototype.resizeBilinear=function(e,t,n){return this.throwIfDisposed(),en(this,e,t,n)},B().prototype.resizeNearestNeighbor=function(e,t,n){return this.throwIfDisposed(),jo(this,e,t,n)},B().prototype.reverse=function(e){return this.throwIfDisposed(),pi(this,e)},B().prototype.rfft=function(){return this.throwIfDisposed(),jn(this)},B().prototype.round=function(){return this.throwIfDisposed(),rt(this)},B().prototype.rsqrt=function(){return this.throwIfDisposed(),ri(this)},B().prototype.selu=function(){return this.throwIfDisposed(),Lr(this)},B().prototype.separableConv2d=function(e,t,n,r,i,a){return this.throwIfDisposed(),pt(this,e,t,n,r,i,a)},B().prototype.sigmoid=function(){return this.throwIfDisposed(),In(this)},B().prototype.sign=function(){return this.throwIfDisposed(),ae(this)},B().prototype.sin=function(){return this.throwIfDisposed(),Gl(this)},B().prototype.sinh=function(){return this.throwIfDisposed(),cr(this)},B().prototype.slice=function(e,t){return this.throwIfDisposed(),hn(this,e,t)},B().prototype.softmax=function(e){return this.throwIfDisposed(),xn(this,e)},B().prototype.softplus=function(){return this.throwIfDisposed(),yi(this)},B().prototype.spaceToBatchND=function(e,t){return this.throwIfDisposed(),mo(this,e,t)},B().prototype.split=function(e,t){return this.throwIfDisposed(),Zo(this,e,t)},B().prototype.sqrt=function(){return this.throwIfDisposed(),Ce(this)},B().prototype.square=function(){return this.throwIfDisposed(),Pe(this)},B().prototype.squaredDifference=function(e){return this.throwIfDisposed(),Te(this,e)},B().prototype.squeeze=function(e){return this.throwIfDisposed(),Ie(this,e)},B().prototype.stack=function(e,t){return this.throwIfDisposed(),Or(e instanceof wc?[this,e]:[this,...e],t)},B().prototype.step=function(e){return this.throwIfDisposed(),hl(this,e)},B().prototype.stridedSlice=function(e,t,n,r,i,a,o,s){return this.throwIfDisposed(),he(this,e,t,n,r,i,a,o,s)},B().prototype.sub=function(e){return this.throwIfDisposed(),L(this,e)},B().prototype.sum=function(e,t){return this.throwIfDisposed(),O(this,e,t)},B().prototype.tan=function(){return this.throwIfDisposed(),vr(this)},B().prototype.tanh=function(){return this.throwIfDisposed(),rn(this)},B().prototype.tile=function(e){return this.throwIfDisposed(),Nl(this,e)},B().prototype.toBool=function(){return this.throwIfDisposed(),F(this,`bool`)},B().prototype.toFloat=function(){return this.throwIfDisposed(),F(this,`float32`)},B().prototype.toInt=function(){return this.throwIfDisposed(),F(this,`int32`)},B().prototype.topk=function(e,t){return this.throwIfDisposed(),qc(this,e,t)},B().prototype.transpose=function(e){return this.throwIfDisposed(),P(this,e)},B().prototype.unique=function(e){return this.throwIfDisposed(),ba(this,e)},B().prototype.unsortedSegmentSum=function(e,t){return this.throwIfDisposed(),Dc(this,e,t)},B().prototype.unstack=function(e){return this.throwIfDisposed(),Vs(this,e)},B().prototype.where=function(e,t){return this.throwIfDisposed(),ac(e,this,t)},B().prototype.zerosLike=function(){return this.throwIfDisposed(),Vt(this)};var im=class e extends Error{constructor(t){super(t),Object.setPrototypeOf(this,e.prototype)}},am=class e extends Error{constructor(t){super(t),Object.setPrototypeOf(this,e.prototype)}},W=class e extends Error{constructor(t){super(t),Object.setPrototypeOf(this,e.prototype)}},G=class e extends Error{constructor(t){super(t),Object.setPrototypeOf(this,e.prototype)}},om=class e extends Error{constructor(t){super(t),Object.setPrototypeOf(this,e.prototype)}},sm=class{constructor(e){this.maxEntries=e||100,this.cache=new Map}get(e){let t;return this.cache.has(e)&&(t=this.cache.get(e),this.cache.delete(e),this.cache.set(e,t)),t}put(e,t){if(this.cache.has(e))this.cache.delete(e);else if(this.cache.size>=this.maxEntries){let e=this.cache.keys().next().value;this.cache.delete(e)}this.cache.set(e,t)}getMaxEntries(){return this.maxEntries}setMaxEntries(e){if(e<0)throw Error(`The maxEntries of LRU caches must be at least 0, but got ${e}.`);if(this.maxEntries>e)for(let t=0;t<this.maxEntries-e;t++){let e=this.cache.keys().next().value;this.cache.delete(e)}this.maxEntries=e}};function cm(e,t){if(Array.isArray(e)){let n=[];for(let r=0;r<t;r++)n=n.concat(e);return n}else{let n=Array(t);return n.fill(e),n}}function lm(e,t){if(!e)throw new om(t)}function um(e,t){let n=0;for(let r of e)r===t&&n++;return n}function dm(e){return e.length===1?e[0]:e}function fm(e){return Array.isArray(e)?e:[e]}function pm(e){let t=e.replace(/(.)([A-Z][a-z0-9]+)/g,`$1_$2`).replace(/([a-z])([A-Z])/g,`$1_$2`).toLowerCase();return t[0]===`_`?`private`+t:t}function mm(e){return e.length<=1||e.indexOf(`_`)===-1?e:e.replace(/[_]+(\w|$)/g,(e,t)=>t.toUpperCase())}var hm={};function gm(e){if(e==null)return null;let t={};return t.className=e.getClassName(),t.config=e.getConfig(),t}function _m(e){if(!(typeof e!=`object`||!e))if(Array.isArray(e))e.forEach(e=>_m(e));else{let t=Object.keys(e);for(let n of t){let t=e[n];typeof t==`object`&&t&&(!Array.isArray(t)&&t.type===`ndarray`&&typeof t.value==`number`?e[n]=t.value:_m(t))}}}function vm(e,t={},n={},r=`object`,i=!1){if(typeof e==`string`){let i=e,a;if(i in n)a=n[i];else if(i in hm)a=hm[i];else if(a=t[i],a==null)throw new W(`Unknown ${r}: ${e}. This may be due to one of the following reasons:\n1. The ${r} is defined in Python, in which case it needs to be ported to TensorFlow.js or your JavaScript code.\n2. The custom ${r} is defined in JavaScript, but is not registered properly with tf.serialization.registerClass().`);return a}else{let a=e;if(a.className==null||a.config==null)throw new W(`${r}: Improper config format: ${JSON.stringify(a)}.\n'className' and 'config' must set.`);let o=a.className,s,c;if(o in n?[s,c]=n[o]:o in hm?[s,c]=hm.className:o in t&&([s,c]=t[o]),s==null)throw new W(`Unknown ${r}: ${o}. This may be due to one of the following reasons:\n1. The ${r} is defined in Python, in which case it needs to be ported to TensorFlow.js or your JavaScript code.\n2. The custom ${r} is defined in JavaScript, but is not registered properly with tf.serialization.registerClass().`);if(c!=null){let e={};for(let t of Object.keys(hm))e[t]=hm[t];for(let t of Object.keys(n))e[t]=n[t];let t=a.config;t.customObjects=e;let r=Object.assign({},hm);for(let e of Object.keys(n))hm[e]=n[e];_m(a.config);let o=c(s,a.config,n,i);return hm=Object.assign({},r),o}else{let e=Object.assign({},hm);for(let e of Object.keys(n))hm[e]=n[e];let t=new s(a.config);return hm=Object.assign({},e),t}}}function ym(e,t){return e<t?-1:+(e>t)}function bm(e,t){return-1*ym(e,t)}function xm(e){if(e==null)return e;let t=[];for(let n of e)t.indexOf(n)===-1&&t.push(n);return t}function Sm(e){if(e==null)throw new W(`Invalid value in obj: ${JSON.stringify(e)}`);for(let t in e)if(e.hasOwnProperty(t))return!1;return!0}function Cm(e,t,n){if(n!=null&&e.indexOf(n)<0)throw new W(`${n} is not a valid ${t}.  Valid values are ${e} or null/undefined.`)}function wm(e,t,n=0,r=1/0){return lm(n>=0),lm(r>=n),Array.isArray(e)&&e.length>=n&&e.length<=r&&e.every(e=>typeof e===t)}function Tm(e,t){Array.isArray(e)?(o(e.length>0,()=>`${t} is unexpectedly an empty array.`),e.forEach((e,n)=>Tm(e,`element ${n+1} of ${t}`))):o(Number.isInteger(e)&&e>0,()=>`Expected ${t} to be a positive integer, but got ${Em(e)}.`)}function Em(e){return e===null?`null`:Array.isArray(e)?`[`+e.map(e=>Em(e)).join(`,`)+`]`:typeof e==`string`?`"${e}"`:`${e}`}function Dm(e,t,n){let r=n==null?Ri():n(),i;return(...a)=>{let o=n==null?Ri():n();return o-r<t?i:(r=o,i=e(...a),i)}}function Om(e){return e===`relu`?`relu`:e===`linear`?`linear`:e===`elu`?`elu`:null}var km=0;function Am(){return km++}var jm={};function Mm(e=``){return e in jm||(jm[e]=0),jm[e]+=1,e+jm[e].toString()}var Nm=[`channelsFirst`,`channelsLast`],Pm=[`nearest`,`bilinear`],Fm=[`valid`,`same`,`causal`],Im=[`max`,`avg`],Lm=[`sum`,`mul`,`concat`,`ave`],Rm=new Map;function zm(e){Cm(Nm,`DataFormat`,e)}function Bm(e){Cm(Pm,`InterpolationFormat`,e)}function Vm(e){Cm(Fm,`PaddingMode`,e)}function Hm(e){Cm(Im,`PoolMode`,e)}var Um=[],Wm=`/`;function Gm(e,t){Um.push(e);try{let e=t();return Um.pop(),e}catch(e){throw Um.pop(),e}}function Km(){return Um.length===0?``:Um.join(Wm)+Wm}function qm(e){if(!Xm(e))throw Error(`Not a valid tensor name: '`+e+`'`);return Km()+e}function Jm(e){if(!Xm(e))throw Error(`Not a valid tensor name: '`+e+`'`);Rm.has(e)||Rm.set(e,0);let t=Rm.get(e);if(Rm.set(e,Rm.get(e)+1),t>0){let n=`${e}_${t}`;return Rm.set(n,1),n}else return e}var Ym=new RegExp(/^[A-Za-z0-9][-A-Za-z0-9\._\/]*$/);function Xm(e){return!!e.match(Ym)}function Zm(e){return e===parseInt(e.toString(),10)}function Qm(e,t,n){t??=0,n??=e.length;let r=1;for(let i=t;i<n;++i)r*=e[i];return r}function $m(e){if(e.length===0)return NaN;let t=1/0;for(let n=0;n<e.length;n++){let r=e[n];r<t&&(t=r)}return t}function eh(e){if(e.length===0)return NaN;let t=-1/0;for(let n=0;n<e.length;n++){let r=e[n];r>t&&(t=r)}return t}function th(e,t){if(t<e)throw new W(`end (${t}) < begin (${e}) is forbidden.`);let n=[];for(let r=e;r<t;++r)n.push(r);return n}var nh;function rh(){return nh??=sl().epsilon(),nh}function ih(){return`channelsLast`}function ah(e,t){return F(e,t)}function oh(e,t=-1){let n=e.shape.slice();return t<0&&(t=n.length+t+1),n.splice(t,0,1),U(e,n)}function sh(e,t){return A(()=>{if(e.shape.length!==2)throw new W(`repeat() expects a rank-2 tensor, but received a rank-${e.shape.length} tensor.`);return hh(oh(e,1),[1,t,1])})}function ch(e){return U(e,[Qm(e.shape)])}function lh(e){if(e.rank<=1)throw new W(`batchFlatten requires a minimum rank of 2. Got rank: ${e.rank}.`);return U(e,[e.shape[0],Qm(e.shape,1)])}function uh(e,t,n){return A(()=>{switch(e.rank){case 1:return $t(e,t,n);case 2:return Ct(e,[t,0],[n,e.shape[1]]);case 3:return qe(e,[t,0,0],[n,e.shape[1],e.shape[2]]);case 4:return Hn(e,[t,0,0,0],[n,e.shape[1],e.shape[2],e.shape[3]]);case 5:return hn(e,[t,0,0,0,0],[n,e.shape[1],e.shape[2],e.shape[3],e.shape[4]]);case 6:return hn(e,[t,0,0,0,0,0],[n,e.shape[1],e.shape[2],e.shape[3],e.shape[4],e.shape[5]]);default:throw new W(`sliceAlongFirstAxis() received an unsupported tensor rank: ${e.rank}`)}})}function dh(e,t,n){return A(()=>{switch(e.rank){case 1:return $t(e,t,n);case 2:return Ct(e,[0,t],[e.shape[0],n]);case 3:return qe(e,[0,0,t],[e.shape[0],e.shape[1],n]);case 4:return Hn(e,[0,0,0,t],[e.shape[0],e.shape[1],e.shape[2],n]);default:throw new W(`sliceAlongLastAxis() received an unsupported tensor rank: ${e.rank}`)}})}function fh(e,t,n,r){return A(()=>{switch(e.rank){case 1:return $t(e,t,n);case 2:switch(r){case 1:return uh(e,t,n);case 2:return dh(e,t,n);default:throw new W(`The axis is not within the rank of the tensor ${r}`)}case 3:switch(r){case 1:return uh(e,t,n);case 2:return qe(e,[0,t,0],[e.shape[0],n,e.shape[2]]);case 3:return dh(e,t,n);default:throw new W(`The axis is not within the rank of the tensor ${r}`)}case 4:switch(r){case 1:return uh(e,t,n);case 2:return Hn(e,[0,t,0,0],[e.shape[0],n,e.shape[2],e.shape[3]]);case 3:return Hn(e,[0,0,t,0],[e.shape[0],e.shape[1],n,e.shape[3]]);case 4:return dh(e,t,n);default:throw new W(`The axis is not within the rank of the tensor ${r}`)}default:throw new W(`sliceAlongLastAxis() received an unsupported tensor rank: ${e.rank}`)}})}function ph(e,t=-1){let n;return t<0&&(n=e[0].rank,t=n===0?0:n),t===e[0].rank&&(t=-1),_t(e,t)}function mh(e,t){switch(e.rank){case 1:return Qc([e,t]);case 2:return Fi([e,t],0);case 3:return eo([e,t],0);case 4:return fo([e,t],0);default:throw new W(`concatAlongFirstAxis() received an unsupported tensor rank: ${e.rank}`)}}function hh(e,t){if(Array.isArray(t)||(t=[t]),e.rank!==t.length)throw new W(`The length of input n (${t.length}) does not match the number of dimensions in input x (${e.rank})`);return Nl(e,t)}function gh(e,t=0,n=1,r,i){return Ji(e,t,n,r,i)}function _h(e,t,n,r){if(e.rank<2||t.rank<2)throw new G(`dot requires both inputs to be rank >= 2 but got x shape = ${e.shape} and y shape = ${t.shape}`);if(t.rank>=3&&e.shape.slice(-1)[0]!==t.shape.slice(-2)[0])throw new G(`If rank y >= 3, then the second last dim of y must equal the last dim of x but got x shape = ${e.shape} and  y shape = ${t.shape}`);if(e.rank===2&&t.rank===2)return Wt({a:e,b:t,transposeA:!1,transposeB:!1,bias:r?bh(e.rank,r,ih()):null,activation:n});{let i=e.shape.slice(),a=i.pop();e=U(e,[-1,a]);let o=t.shape.slice(),s=o.pop(),c=o.pop(),l=[...o,s],u=Array.from({length:t.rank},(e,n)=>n===0?t.rank-2:n<=t.rank-2?n-1:n);t=U(P(t,u),[c,-1]);let d=[...i,...l];return U(Wt({a:e,b:t,transposeA:!1,transposeB:!1,bias:r?bh(e.rank,r,ih()):null,activation:n}),d)}}function vh(e,t,n){return A(()=>(t=Array.isArray(t)?Tl(t,`int32`):F(t,`int32`),io(e,t,n)))}function yh(e){return z(e,e)}function bh(e,t,n){let r=t.shape;if(t.rank!==1&&t.rank!==e)throw new W(`Unexpected bias dimensions: ${t.rank}; expected it to be 1 or ${e}`);if(e===5){if(n===`channelsFirst`)return r.length===1?U(t,[1,r[0],1,1,1]):U(t,[1,r[3],r[0],r[1],r[2]]);if(n===`channelsLast`)return r.length===1?U(t,[1,1,1,1,r[0]]):U(t,[1].concat(r))}else if(e===4){if(n===`channelsFirst`)return r.length===1?U(t,[1,r[0],1,1]):U(t,[1,r[2],r[0],r[1]]);if(n===`channelsLast`)return r.length===1?U(t,[1,1,1,r[0]]):U(t,[1].concat(r))}else if(e===3){if(n===`channelsFirst`)return r.length===1?U(t,[1,r[0],1]):U(t,[1,r[1],r[0]]);if(n===`channelsLast`)return r.length===1?U(t,[1,1,r[0]]):U(t,[1].concat(r))}else if(e<3)return t;throw new W(`Unsupported input rank by biasAdd: ${t.rank}`)}function xh(e,t,n){return A(()=>(n??=ih(),zm(n),I(e,bh(e.rank,t,n))))}function Sh(e,t=1){if(t!==1)throw new G(`Support for alpha values other than 1 (${t}) is not implemented yet.`);return dt(e)}function Ch(e){return A(()=>N(e,I(es(e),1)))}function wh(e,t,n,r){return A(()=>mi(e,t,n,r))}function Th(e){return A(()=>kl(I(.5,z(.2,e)),0,1))}function Eh(e,t,n=!1){return n?e():t()}var Dh=[`fanIn`,`fanOut`,`fanAvg`],Oh=[`normal`,`uniform`,`truncatedNormal`];function kh(e){Cm(Dh,`FanMode`,e)}function Ah(e){Cm(Oh,`Distribution`,e)}var jh=class extends El{fromConfigUsesCustomObjects(){return!1}getConfig(){return{}}},Mh=class extends jh{apply(e,t){return _n(e,t)}};Mh.className=`Zeros`,V(Mh);var Nh=class extends jh{apply(e,t){return on(e,t)}};Nh.className=`Ones`,V(Nh);var Ph=class extends jh{constructor(e){if(super(),typeof e!=`object`)throw new W(`Expected argument of type ConstantConfig but got ${e}`);if(e.value===void 0)throw new W(`config must have value set but got ${e}`);this.value=e.value}apply(e,t){return A(()=>z(kn(this.value),on(e,t)))}getConfig(){return{value:this.value}}};Ph.className=`Constant`,V(Ph);var Fh=class extends jh{constructor(e){super(),this.DEFAULT_MINVAL=-.05,this.DEFAULT_MAXVAL=.05,this.minval=e.minval||this.DEFAULT_MINVAL,this.maxval=e.maxval||this.DEFAULT_MAXVAL,this.seed=e.seed}apply(e,t){return pc(e,this.minval,this.maxval,t,this.seed)}getConfig(){return{minval:this.minval,maxval:this.maxval,seed:this.seed}}};Fh.className=`RandomUniform`,V(Fh);var Ih=class extends jh{constructor(e){super(),this.DEFAULT_MEAN=0,this.DEFAULT_STDDEV=.05,this.mean=e.mean||this.DEFAULT_MEAN,this.stddev=e.stddev||this.DEFAULT_STDDEV,this.seed=e.seed}apply(e,t){if(t||=`float32`,t!==`float32`&&t!==`int32`)throw new G(`randomNormal does not support dType ${t}.`);return gh(e,this.mean,this.stddev,t,this.seed)}getConfig(){return{mean:this.mean,stddev:this.stddev,seed:this.seed}}};Ih.className=`RandomNormal`,V(Ih);var Lh=class extends jh{constructor(e){super(),this.DEFAULT_MEAN=0,this.DEFAULT_STDDEV=.05,this.mean=e.mean||this.DEFAULT_MEAN,this.stddev=e.stddev||this.DEFAULT_STDDEV,this.seed=e.seed}apply(e,t){if(t||=`float32`,t!==`float32`&&t!==`int32`)throw new G(`truncatedNormal does not support dType ${t}.`);return cs(e,this.mean,this.stddev,t,this.seed)}getConfig(){return{mean:this.mean,stddev:this.stddev,seed:this.seed}}};Lh.className=`TruncatedNormal`,V(Lh);var Rh=class extends jh{constructor(e){super(),this.gain=e.gain==null?1:e.gain}apply(e,t){return A(()=>{if(e.length!==2||e[0]!==e[1])throw new W(`Identity matrix initializer can only be used for 2D square matrices.`);return z(this.gain,nl(e[0]))})}getConfig(){return{gain:this.gain}}};Rh.className=`Identity`,V(Rh);function zh(e,t=`channelsLast`){let n,r;if(zm(t),e.length===2)n=e[0],r=e[1];else if([3,4,5].indexOf(e.length)!==-1){if(t===`channelsFirst`){let t=Qm(e,2);n=e[1]*t,r=e[0]*t}else if(t===`channelsLast`){let t=Qm(e,0,e.length-2);n=e[e.length-2]*t,r=e[e.length-1]*t}}else{let t=Qm(e);n=Math.sqrt(t),r=Math.sqrt(t)}return[n,r]}var Bh=class extends jh{constructor(e){if(super(),e.scale<0)throw new W(`scale must be a positive float. Got: ${e.scale}`);this.scale=e.scale==null?1:e.scale,this.mode=e.mode==null?`fanIn`:e.mode,kh(this.mode),this.distribution=e.distribution==null?`normal`:e.distribution,Ah(this.distribution),this.seed=e.seed}apply(e,t){let n=zh(e),r=n[0],i=n[1],a=this.scale;if(this.mode===`fanIn`?a/=Math.max(1,r):this.mode===`fanOut`?a/=Math.max(1,i):a/=Math.max(1,(r+i)/2),this.distribution===`normal`){let n=Math.sqrt(a);if(t||=`float32`,t!==`float32`&&t!==`int32`)throw new G(`${this.getClassName()} does not support dType ${t}.`);return cs(e,0,n,t,this.seed)}else{let n=Math.sqrt(3*a);return pc(e,-n,n,t,this.seed)}}getConfig(){return{scale:this.scale,mode:this.mode,distribution:this.distribution,seed:this.seed}}};Bh.className=`VarianceScaling`,V(Bh);var Vh=class extends Bh{constructor(e){super({scale:1,mode:`fanAvg`,distribution:`uniform`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Vh.className=`GlorotUniform`,V(Vh);var Hh=class extends Bh{constructor(e){super({scale:1,mode:`fanAvg`,distribution:`normal`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Hh.className=`GlorotNormal`,V(Hh);var Uh=class extends Bh{constructor(e){super({scale:2,mode:`fanIn`,distribution:`normal`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Uh.className=`HeNormal`,V(Uh);var Wh=class extends Bh{constructor(e){super({scale:2,mode:`fanIn`,distribution:`uniform`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Wh.className=`HeUniform`,V(Wh);var Gh=class extends Bh{constructor(e){super({scale:1,mode:`fanIn`,distribution:`normal`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Gh.className=`LeCunNormal`,V(Gh);var Kh=class extends Bh{constructor(e){super({scale:1,mode:`fanIn`,distribution:`uniform`,seed:e==null?null:e.seed})}getClassName(){return Bh.className}};Kh.className=`LeCunUniform`,V(Kh);var qh=class extends jh{constructor(e){super(),this.DEFAULT_GAIN=1,this.ELEMENTS_WARN_SLOW=2e3,this.gain=e.gain==null?this.DEFAULT_GAIN:e.gain,this.seed=e.seed}apply(e,t){return A(()=>{if(e.length<2)throw new G(`Shape must be at least 2D.`);if(t!==`int32`&&t!==`float32`&&t!==void 0)throw TypeError(`Unsupported data type ${t}.`);t=t;let n=k(e.slice(0,-1)),r=e[e.length-1],i=n*r;i>this.ELEMENTS_WARN_SLOW&&console.warn(`Orthogonal initializer is being called on a matrix with more than ${this.ELEMENTS_WARN_SLOW} (${i}) elements: Slowness may result.`);let a=gh([Math.max(r,n),Math.min(r,n)],0,1,t,this.seed),o=ol.qr(a,!1),s=o[0],c=o[1].flatten().stridedSlice([0],[Math.min(r,n)*Math.min(r,n)],[Math.min(r,n)+1]);return s=z(s,c.sign()),n<r&&(s=s.transpose()),z(kn(this.gain),s.reshape(e))})}getConfig(){return{gain:this.gain,seed:this.seed}}};qh.className=`Orthogonal`,V(qh);var Jh={constant:`Constant`,glorotNormal:`GlorotNormal`,glorotUniform:`GlorotUniform`,heNormal:`HeNormal`,heUniform:`HeUniform`,identity:`Identity`,leCunNormal:`LeCunNormal`,leCunUniform:`LeCunUniform`,ones:`Ones`,orthogonal:`Orthogonal`,randomNormal:`RandomNormal`,randomUniform:`RandomUniform`,truncatedNormal:`TruncatedNormal`,varianceScaling:`VarianceScaling`,zeros:`Zeros`};function Yh(e,t={}){return vm(e,ea.getMap().classNameMap,t,`initializer`)}function Xh(e){return gm(e)}function Zh(e){if(typeof e==`string`){let t=e in Jh?Jh[e]:e;if(t===`GlorotNormal`)return new Hh;if(t===`GlorotUniform`)return new Vh;if(t===`HeNormal`)return new Uh;if(t===`HeUniform`)return new Wh;if(t===`LeCunNormal`)return new Gh;if(t===`LeCunUniform`)return new Kh;{let e={};return e.className=t,e.config={},Yh(e)}}else if(e instanceof jh)return e;else return Yh(e)}function Qh(e){return Array.isArray(e)&&Array.isArray(e[0])}function $h(e){return e.length===0?[]:Array.isArray(e[0])?e:[e]}function K(e){let t;if(Array.isArray(e)){if(e.length!==1)throw new W(`Expected Tensor length to be 1; got ${e.length}`);t=e[0]}else t=e;return t}function q(e){if(Array.isArray(e)&&Array.isArray(e[0])){if(e.length===1)return e=e,e[0];throw new W(`Expected exactly 1 Shape; got ${e.length}`)}else return e}function eg(e){let t=0;for(let n of e)n.shape.length===0?t+=1:t+=n.shape.reduce((e,t)=>e*t);return t}var tg=`Variable`,ng=class{constructor(e,t=`float32`,n=tg,r=!0,i=null){this.dtype=t??`float32`,this.shape=e.shape,this.id=Am(),n??=tg,this.originalName=qm(n),this.name=Jm(this.originalName),this.trainable_=r,this.constraint=i,this.val=ko(e,this.trainable_,this.name,this.dtype)}read(){return this.assertNotDisposed(),this.val}write(e){return this.assertNotDisposed(),rg(this.val,e),this.val.id!==e.id&&(this.val.assign(e),this.constraint!=null&&this.val.assign(this.constraint.apply(this.val))),this}dispose(){this.assertNotDisposed(),this.val.dispose()}assertNotDisposed(){if(this.val.isDisposed)throw Error(`LayersVariable ${this.name} is already disposed.`)}get trainable(){return this.trainable_}set trainable(e){this.trainable_=e,this.val.trainable=e}};function rg(e,t){if(e.shape.toString()!==t.shape.toString())throw Error(`Shape mismatch: `+JSON.stringify(e.shape)+` vs. `+JSON.stringify(t.shape))}function ig(e){return e.map(e=>e.read())}function ag(e){e.forEach(e=>{e[0].write(e[1])})}var og=class{constructor(e){this.dtype=e.dtype,this.shape=e.shape,e.shape==null?this.ndim=e.ndim:this.ndim=e.shape.length,this.maxNDim=e.maxNDim,this.minNDim=e.minNDim,this.axes=e.axes||{}}},sg=class{constructor(e,t,n,r,i,a,o){this.dtype=e,this.shape=t,this.sourceLayer=n,this.inputs=r,this.callArgs=i,this.outputTensorIndex=o,this.id=Am(),a!=null&&(this.originalName=qm(a),this.name=Jm(this.originalName)),this.rank=t.length}},cg=0,lg=class{constructor(e,t){this.callArgs=t,this.id=cg++,this.outboundLayer=e.outboundLayer,this.inboundLayers=e.inboundLayers,this.nodeIndices=e.nodeIndices,this.tensorIndices=e.tensorIndices,this.inputTensors=e.inputTensors,this.outputTensors=e.outputTensors,this.inputMasks=e.inputMasks,this.outputMasks=e.outputMasks,this.inputShapes=e.inputShapes,this.outputShapes=e.outputShapes;for(let t of e.inboundLayers)t?.outboundNodes.push(this);e.outboundLayer.inboundNodes.push(this)}getConfig(){let e=[];for(let t of this.inboundLayers)t==null?e.push(null):e.push(t.name);return{outboundLayer:this.outboundLayer?this.outboundLayer.name:null,inboundLayers:e,nodeIndices:this.nodeIndices,tensorIndices:this.tensorIndices}}},ug=0,J=class extends El{constructor(e={}){super(),this._callHook=null,this._addedWeightNames=[],this._stateful=!1,this.id=ug++,this.activityRegularizer=null,this.inputSpec=null,this.supportsMasking=!1,this._trainableWeights=[],this._nonTrainableWeights=[],this._losses=[],this._updates=[],this._built=!1,this.inboundNodes=[],this.outboundNodes=[];let t=e.name;if(!t){let e=this.getClassName();t=pm(e)+`_`+Mm(e)}if(this.name=t,this.trainable_=e.trainable==null||e.trainable,e.inputShape!=null||e.batchInputShape!=null){let t;if(e.batchInputShape!=null)t=e.batchInputShape;else if(e.inputShape!=null){let n=null;e.batchSize!=null&&(n=e.batchSize),t=[n].concat(e.inputShape)}this.batchInputShape=t;let n=e.dtype;n??=e.inputDType,n??=`float32`,this.dtype=n}e.weights==null?this.initialWeights=null:this.initialWeights=e.weights,this._refCount=null,this.fastWeightInitDuringBuild=!1}static nodeKey(e,t){return e.name+`_ib-`+t.toString()}getNodeAtIndex(e,t){if(this.inboundNodes.length===0)throw new am(`The layer has never been called and thus has no defined ${t}.`);if(this.inboundNodes.length<=e)throw new W(`Asked to get ${t} at node ${e}, but the layer has only ${this.inboundNodes.length} inbound nodes.`);return this.inboundNodes[e]}getInputAt(e){return dm(this.getNodeAtIndex(e,`input`).inputTensors)}getOutputAt(e){return dm(this.getNodeAtIndex(e,`output`).outputTensors)}get input(){if(this.inboundNodes.length>1)throw new im(`Layer ${this.name} has multiple inbound nodes, hence the notion of "layer input" is ill-defined. Use \`getInputAt(nodeIndex)\` instead.`);if(this.inboundNodes.length===0)throw new im(`Layer ${this.name} is not connected, no input to return.`);return dm(this.getNodeAtIndex(0,`input`).inputTensors)}get output(){if(this.inboundNodes.length===0)throw new im(`Layer ${this.name} has no inbound nodes.`);if(this.inboundNodes.length>1)throw new im(`Layer ${this.name} has multiple inbound nodes, hence the notion of "layer output" is ill-defined. Use \`getOutputAt(nodeIndex)\` instead.`);return dm(this.getNodeAtIndex(0,`output`).outputTensors)}get losses(){return this._losses}calculateLosses(){return this.losses.map(e=>e())}get updates(){return this._updates}get built(){return this._built}set built(e){this._built=e}get trainable(){return this.trainable_}set trainable(e){this._trainableWeights.forEach(t=>t.trainable=e),this.trainable_=e}get trainableWeights(){return this.trainable_?this._trainableWeights.filter(e=>e.trainable):[]}set trainableWeights(e){this._trainableWeights=e}get nonTrainableWeights(){return this.trainable?this._trainableWeights.filter(e=>!e.trainable).concat(this._nonTrainableWeights):this._trainableWeights.concat(this._nonTrainableWeights)}set nonTrainableWeights(e){this._nonTrainableWeights=e}get weights(){return this.trainableWeights.concat(this.nonTrainableWeights)}get stateful(){return this._stateful}resetStates(){if(!this.stateful)throw Error(`Cannot call the resetStates() method of a non-stateful Layer object.`)}assertInputCompatibility(e){let t=fm(e);if(this.inputSpec==null||this.inputSpec.length===0)return;let n=fm(this.inputSpec);if(t.length!==n.length)throw new W(`Layer ${this.name} expects ${n.length} inputs, but it received ${t.length} input tensors. Input received: ${e}`);for(let e=0;e<t.length;e++){let r=t[e],i=n[e];if(i==null)continue;let a=r.rank;if(i.ndim!=null&&a!==i.ndim)throw new W(`Input ${e} is incompatible with layer ${this.name}: expected ndim=${i.ndim}, found ndim=${a}`);if(i.maxNDim!=null&&a>i.maxNDim)throw new W(`Input ${e} is incompatible with layer ${this.name}: expected max_ndim=${i.maxNDim}, found ndim=${a}`);if(i.minNDim!=null&&a<i.minNDim)throw new W(`Input ${e} is incompatible with layer ${this.name}: expected min_ndim=${i.minNDim}, found ndim=${a}.`);if(i.dtype!=null&&r.dtype!==i.dtype)throw new W(`Input ${e} is incompatible with layer ${this.name} : expected dtype=${i.dtype}, found dtype=${r.dtype}.`);if(i.axes){let t=r.shape;for(let n in i.axes){let r=Number(n),a=i.axes[n],o=r>=0?t[r]:t[t.length+r];if(a!=null&&[a,null].indexOf(o)===-1)throw new W(`Input ${e} is incompatible with layer ${this.name}: expected axis ${r} of input shape to have value ${a} but got shape ${t}.`)}}if(i.shape!=null)for(let t=0;t<i.shape.length;++t){let n=i.shape[t],a=r.shape[t];if(n!=null&&a!=null&&n!==a)throw new W(`Input ${e} is incompatible with layer ${this.name}: expected shape=${i.shape}, found shape=${r.shape}.`)}}}call(e,t){return e}invokeCallHook(e,t){this._callHook!=null&&this._callHook(e,t)}setCallHook(e){this._callHook=e}clearCallHook(){this._callHook=null}apply(e,t){t||={},this.assertNotDisposed();let n=fm(e),r=mg(e),i=hg(e);if(r===i)throw new W(`Arguments to apply() must be all SymbolicTensors or all Tensors`);return Gm(this.name,()=>{if(!this.built){this.assertInputCompatibility(e);let t=[];for(let n of fm(e))t.push(n.shape);this.build(dm(t)),this.built=!0,this.initialWeights&&this.setWeights(this.initialWeights),this._refCount===null&&i&&(this._refCount=1)}if(this.assertInputCompatibility(e),i){let r=this.call(e,t);this.supportsMasking&&this.setMaskMetadata(e,r);let i=fm(r),a=[];for(let e of i)n.indexOf(e)!==-1&&(e=e.clone()),a.push(e);if(r=dm(a),this.activityRegularizer!=null)throw new G(`Layer invocation in the presence of activity regularizer(s) is not supported yet.`);return r}else{let n=dg(e),r=this.computeOutputShape(n),i,a=fg(e);if(this.warnOnIncompatibleInputShape(Array.isArray(e)?n[0]:n),i=r!=null&&r.length>0&&Array.isArray(r[0])?r.map((n,r)=>new sg(a,n,this,fm(e),t,this.name,r)):new sg(a,r,this,fm(e),t,this.name),this.addInboundNode(e,i,null,null,n,r,t),this._refCount++,this.activityRegularizer!=null)throw new G(`Layer invocation in the presence of activity regularizer(s) is not supported yet.`);return i}})}warnOnIncompatibleInputShape(e){if(this.batchInputShape!=null)if(e.length!==this.batchInputShape.length)console.warn(`The rank of the input tensor provided (shape: ${JSON.stringify(e)}) does not match that of the batchInputShape (${JSON.stringify(this.batchInputShape)}) of the layer ${this.name}`);else{let t=!1;this.batchInputShape.forEach((n,r)=>{n!=null&&e[r]!=null&&e[r]!==n&&(t=!0)}),t&&console.warn(`The shape of the input tensor (${JSON.stringify(e)}) does not match the expectation of layer ${this.name}: ${JSON.stringify(this.batchInputShape)}`)}}get outputShape(){if(this.inboundNodes==null||this.inboundNodes.length===0)throw new im(`The layer ${this.name} has never been called and thus has no defined output shape.`);let e=[];for(let t of this.inboundNodes){let n=JSON.stringify(t.outputShapes);e.indexOf(n)===-1&&e.push(n)}if(e.length===1){let e=this.inboundNodes[0].outputShapes;return Array.isArray(e)&&Array.isArray(e[0])&&e.length===1?e[0]:e}else throw new im(`The layer ${this.name} has multiple inbound nodes with different output shapes. Hence the notion of "output shape" is ill-defined for the layer.`)}countParams(){if(!this.built)throw new am(`You tried to call countParams() on ${this.name}, but the layer is not built yet. Build it first by calling build(batchInputShape).`);return eg(this.weights)}build(e){this.built=!0}getWeights(e=!1){return ig(e?this.trainableWeights:this.weights)}setWeights(e){A(()=>{let t=this.weights;if(t.length!==e.length)throw new W(`You called setWeights(weights) on layer "${this.name}" with a weight list of length ${e.length}, but the layer was expecting ${t.length} weights. Provided weights: ${e}...`);if(t.length===0)return;let n=[],r=ig(t);for(let i=0;i<r.length;++i){let a=r[i],o=t[i],s=e[i];if(!qn(a.shape,s.shape))throw new W(`Layer weight shape ${a.shape} not compatible with provided weight shape ${s.shape}`);n.push([o,s])}ag(n)})}addWeight(e,t,n,r,i,a,o,s){if(this._addedWeightNames.indexOf(e)!==-1)throw new W(`Duplicate weight name ${e} for layer ${this.name}`);this._addedWeightNames.push(e),n??=`float32`,this.fastWeightInitDuringBuild&&(r=s==null?Zh(`zeros`):s());let c=r.apply(t,n),l=new ng(c,n,e,a,o);return c.dispose(),i!=null&&this.addLoss(()=>i.apply(l.read())),a??=!0,a?this._trainableWeights.push(l):this._nonTrainableWeights.push(l),l}setFastWeightInitDuringBuild(e){this.fastWeightInitDuringBuild=e}addLoss(e){e==null||Array.isArray(e)&&e.length===0||(e=fm(e),this._losses!==void 0&&this._losses!==null&&this.losses.push(...e))}computeOutputShape(e){return e}computeMask(e,t){if(!this.supportsMasking){if(t!=null)if(Array.isArray(t))t.forEach(e=>{if(e!=null)throw TypeError(`Layer ${this.name} does not support masking, but was passed an inputMask.`)});else throw TypeError(`Layer ${this.name} does not support masking, but was passed an inputMask.`);return null}return t}setMaskMetadata(e,t,n){if(!this.supportsMasking)return;let r=this.computeMask(e,n),i=fm(t),a=fm(r);if(i.length!==a.length)throw Error(`${this.name} outputs ${i.length} tensors but ${i.length} masks for those tensors`);for(let e=0;e<i.length;e++)i[e].kerasMask=a[e]}addInboundNode(e,t,n,r,i,a,o=null){let s=fm(e);t=fm(t),n=fm(n),r=fm(r),i=$h(i),a=$h(a);let c=[],l=[],u=[];for(let e of s)c.push(e.sourceLayer),l.push(e.nodeIndex),u.push(e.tensorIndex);new lg({outboundLayer:this,inboundLayers:c,nodeIndices:l,tensorIndices:u,inputTensors:s,outputTensors:t,inputMasks:n,outputMasks:r,inputShapes:i,outputShapes:a},o);for(let e=0;e<t.length;e++)t[e].sourceLayer=this,t[e].nodeIndex=this.inboundNodes.length-1,t[e].tensorIndex=e}getConfig(){let e={name:this.name,trainable:this.trainable};return this.batchInputShape!=null&&(e.batchInputShape=this.batchInputShape),this.dtype!=null&&(e.dtype=this.dtype),e}disposeWeights(){return this.weights.forEach(e=>e.dispose()),this.weights.length}assertNotDisposed(){if(this._refCount===0)throw Error(`Layer '${this.name}' is already disposed.`)}dispose(){if(!this.built)throw Error(`Cannot dispose Layer ${this.name} because it has not been built yet.`);if(this._refCount===null)throw Error(`Cannot dispose Layer ${this.name} because it has not been used yet.`);this.assertNotDisposed();let e=0;return--this._refCount===0&&(e=this.disposeWeights()),{refCountAfterDispose:this._refCount,numDisposedVariables:e}}};function dg(e){e=fm(e);let t=[];for(let n of e)t.push(n.shape);return dm(t)}function fg(e){return`float32`}function pg(e,t,n){if((t==null||n!=null&&n>0)&&(t=e.sourceLayer,n=e.nodeIndex),t.inboundNodes.length===0)return[e];{let e=t.inboundNodes[n];if(e.inboundLayers.length===0)return e.inputTensors;{let t=[];for(let n=0;n<e.inboundLayers.length;n++){let r=e.inputTensors[n],i=e.inboundLayers[n],a=e.nodeIndices[n],o=pg(r,i,a);for(let e of o)t.indexOf(e)===-1&&t.push(e)}return t}}}function mg(e){let t=!0;for(let n of fm(e))if(!(n instanceof sg)){t=!1;break}return t}function hg(e){let t=!0;for(let n of fm(e))if(n instanceof sg){t=!1;break}return t}var gg=class extends J{constructor(e){if(super({dtype:e.dtype,name:e.name==null?Mm(`input`).toString():e.name}),e.batchSize??=null,e.sparse??=!1,this.trainable=!1,this.built=!0,this.sparse=e.sparse,e.inputShape!=null&&e.batchInputShape!=null)throw new W(`Only provide the inputShape OR batchInputShape argument to inputLayer, not both at the same time.`);let t=e.batchInputShape;if(t==null){if(e.inputShape==null)throw new W("An InputLayer should be passed either a `batchInputShape` or an `inputShape`.");t=[e.batchSize].concat(e.inputShape)}else if(e.batchSize!=null)throw new W(`Cannot specify batchSize if batchInputShape is specified when creating an InputLayer.`);let n=e.dtype||`float32`;this.batchInputShape=t,this.dtype=n,this.inputSpec=[{shape:t}];let r=new sg(this.dtype,this.batchInputShape,this,[],{},this.name);r.nodeIndex=0,r.tensorIndex=0,new lg({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:[r],outputTensors:[r],inputMasks:[null],outputMasks:[null],inputShapes:[t],outputShapes:[t]})}apply(e,t){throw new W(`Cannot pass any input to an InputLayer's apply() method. InputLayer name: ${this.name}`)}dispose(){return{refCountAfterDispose:this._refCount,numDisposedVariables:0}}getConfig(){return{batchInputShape:this.batchInputShape,dtype:this.dtype,sparse:this.sparse,name:this.name}}};gg.className=`InputLayer`,V(gg);function _g(e){if(e.batchShape==null&&e.shape==null)throw Error("Please provide to Input either a `shape` or a `batchShape` argument. Note that `shape` does not include the batch dimension.");if(e.batchShape!=null&&e.shape!=null)throw new W("Please provide either a `shape` or `batchShape` argument to Input, but not both.");let t=e.batchShape;e.shape!=null&&t==null&&(t=[null].concat(e.shape));let n=e.dtype;return n??=`float32`,new gg({batchInputShape:t,name:e.name,dtype:n,sparse:e.sparse}).inboundNodes[0].outputTensors[0]}function vg(e,t){if(e.dtype==null||e.dtype===t.dtype)return t;try{return F(t,e.dtype)}catch{throw new W(`The dtype of the feed (${t.dtype}) can not be cast to the dtype of the key '${e.name}' (${e.dtype}).`)}}var yg=class e{constructor(t){if(this.id2Value={},this.id2Mask={},this.name2Id={},t instanceof e)for(let e in t.id2Value)this.id2Value[e]=t.id2Value[e],e in t.id2Mask&&(this.id2Mask[e]=t.id2Mask[e]);else{if(t==null)return;for(let e of t)this.add(e.key,e.value)}}add(e,t,n){if(this.id2Value[e.id]==null)this.id2Value[e.id]=vg(e,t),this.name2Id[e.name]=e.id,n!=null&&(this.id2Mask[e.id]=n);else throw new W(`Duplicate key: name=${e.name}, id=${e.id}`);return this}addFeed(e){this.add(e.key,e.value)}hasKey(e){return this.id2Value[e.id]!=null}names(){return Object.keys(this.name2Id)}getValue(e){if(e instanceof sg){if(this.id2Value[e.id]==null)throw new W(`Nonexistent key: ${e.name}`);return this.id2Value[e.id]}else{let t=this.name2Id[e];if(t==null)throw new W(`Feed dict has no SymbolicTensor name: ${e}`);return this.id2Value[t]}}getMask(e){if(e instanceof sg){if(this.id2Value[e.id]==null)throw new W(`Nonexistent key: ${e.name}`);return this.id2Mask[e.id]}else{let t=this.name2Id[e];if(t==null)throw new W(`Feed dict has no SymbolicTensor name: ${e}`);return this.id2Mask[t]}}disposeMasks(){this.id2Mask!=null&&D(this.id2Mask)}},bg=new sm,xg=new sm;function Sg(e){bg?.setMaxEntries(e),xg?.setMaxEntries(e)}function Cg(e,t,n,r){let i=n!=null&&n.training,a=Array.isArray(e),o=a?e:[e],s=o.map(e=>e.name),c=[],l=t.names();for(let e of s)l.indexOf(e)===-1?c.push(null):c.push(t.getValue(e));r!=null&&(r.maxNumTensors=-1/0,r.minNumTensors=1/0);let u=s.join(`,`)+`|`+t.names().sort().join(`,`),d=bg.get(u),f;if(d==null){let e=wg(o,t);d=e.sorted,f=e.recipientCounts,bg.put(u,d),xg.put(u,f)}f={},i||Object.assign(f,xg.get(u));let p=new yg(t);for(let e=0;e<d.length;++e){if(r!=null){let e=ht().numTensors;e>r.maxNumTensors&&(r.maxNumTensors=e),e<r.minNumTensors&&(r.minNumTensors=e)}let a=d[e],o=a.sourceLayer;if(o instanceof gg)continue;let l=[],u=[],m=[],h=!1;for(let e of a.inputs){let n=p.getValue(e),r=p.getMask(e);l.push(n),u.push(r),r!=null&&(h=!0),i||(f[e.name]--,f[e.name]===0&&!t.hasKey(e)&&s.indexOf(e.name)===-1&&!n.isDisposed&&e.sourceLayer.stateful!==!0&&m.push(n))}h&&(n||={},n.mask=u[0]);let g=fm(o.apply(l,n)),_=null;o.supportsMasking&&(_=o.computeMask(l,u));let v=Dg(a),y=Array.isArray(v)?v:[v];for(let e=0;e<y.length;++e){p.hasKey(y[e])||p.add(y[e],g[e],Array.isArray(_)?_[0]:_);let t=s.indexOf(y[e].name);t!==-1&&(c[t]=g[e])}i||D(m)}return p.disposeMasks(),a?c:c[0]}function wg(e,t){o(e!=null&&e.length>0,()=>`Expected at least one fetch, got none`);let n=[],r={};if(e.length===1){let i=Eg(e[0],t);n=i.sorted,r=i.recipientMap}else{let i=new Set;for(let a of e){let{sorted:e,recipientMap:o}=Eg(a,t);for(let t of e)i.has(t.name)||(n.push(t),i.add(t.name));for(let e in o)r[e]??(r[e]=new Set),o[e].forEach(t=>r[e].add(t))}}return{sorted:n,recipientCounts:Tg(r)}}function Tg(e){let t={};for(let n in e)t[n]=e[n].size;return t}function Eg(e,t){let n=new Set,r=[],i={};for(let e of t.names())n.add(e);let a=[],o=[];for(a.push(e);a.length>0;){let e=a[a.length-1];if(n.has(e.name)){a.pop();continue}let t=o[o.length-1]===a.length-1;if(e.inputs.length===0||t)a.pop(),r.push(e),n.add(e.name),t&&o.pop();else{o.push(a.length-1);for(let t of e.inputs)i[t.name]??(i[t.name]=new Set),i[t.name].add(e.name),!n.has(t.name)&&a.push(t)}}return{sorted:r,recipientMap:i}}function Dg(e){let t;if(e.sourceLayer.inboundNodes.length===1)t=e.sourceLayer.output;else{let n=null;for(let t=0;t<e.sourceLayer.inboundNodes.length;++t)for(let r of e.sourceLayer.inboundNodes[t].outputTensors)if(r.id===e.id){n=t;break}t=e.sourceLayer.getOutputAt(n)}return t}j().registerFlag(`TOPOLOGICAL_SORT_CACHE_MAX_ENTRIES`,()=>100,Sg);function Og(e,t){return A(()=>Ce(O(z(e,e),t,!0)))}var kg=class extends El{getConfig(){return{}}},Ag=class extends kg{constructor(e){super(),this.defaultMaxValue=2,this.defaultAxis=0,this.maxValue=e.maxValue==null?this.defaultMaxValue:e.maxValue,this.axis=e.axis==null?this.defaultAxis:e.axis}apply(e){return A(()=>{let t=Og(e,this.axis);return z(e,N(kl(t,0,this.maxValue),I(rh(),t)))})}getConfig(){return{maxValue:this.maxValue,axis:this.axis}}};Ag.className=`MaxNorm`,V(Ag);var jg=class extends kg{constructor(e){super(),this.defaultAxis=0,this.axis=e.axis==null?this.defaultAxis:e.axis}apply(e){return A(()=>N(e,I(rh(),Og(e,this.axis))))}getConfig(){return{axis:this.axis}}};jg.className=`UnitNorm`,V(jg);var Mg=class extends kg{apply(e){return Qn(e)}};Mg.className=`NonNeg`,V(Mg);var Ng=class extends kg{constructor(e){super(),this.defaultMinValue=0,this.defaultMaxValue=1,this.defaultRate=1,this.defaultAxis=0,this.minValue=e.minValue==null?this.defaultMinValue:e.minValue,this.maxValue=e.maxValue==null?this.defaultMaxValue:e.maxValue,this.rate=e.rate==null?this.defaultRate:e.rate,this.axis=e.axis==null?this.defaultAxis:e.axis}apply(e){return A(()=>{let t=Og(e,this.axis);return z(e,N(I(z(this.rate,kl(t,this.minValue,this.maxValue)),z(1-this.rate,t)),I(rh(),t)))})}getConfig(){return{minValue:this.minValue,maxValue:this.maxValue,rate:this.rate,axis:this.axis}}};Ng.className=`MinMaxNorm`,V(Ng);var Pg={maxNorm:`MaxNorm`,minMaxNorm:`MinMaxNorm`,nonNeg:`NonNeg`,unitNorm:`UnitNorm`};function Fg(e){return gm(e)}function Ig(e,t={}){return vm(e,ea.getMap().classNameMap,t,`constraint`)}function Lg(e){return e==null?null:typeof e==`string`?Ig({className:e in Pg?Pg[e]:e,config:{}}):e instanceof kg?e:Ig(e)}var Rg=e({maxNorm:()=>zg,minMaxNorm:()=>Hg,nonNeg:()=>Vg,unitNorm:()=>Bg});function zg(e){return new Ag(e)}function Bg(e){return new jg(e)}function Vg(){return new Mg}function Hg(e){return new Ng(e)}var Ug=e({constant:()=>Kg,glorotNormal:()=>$g,glorotUniform:()=>Qg,heNormal:()=>e_,heUniform:()=>t_,identity:()=>Xg,leCunNormal:()=>n_,leCunUniform:()=>r_,ones:()=>Gg,orthogonal:()=>i_,randomNormal:()=>Jg,randomUniform:()=>qg,truncatedNormal:()=>Yg,varianceScaling:()=>Zg,zeros:()=>Wg});function Wg(){return new Mh}function Gg(){return new Nh}function Kg(e){return new Ph(e)}function qg(e){return new Fh(e)}function Jg(e){return new Ih(e)}function Yg(e){return new Lh(e)}function Xg(e){return new Rh(e)}function Zg(e){return new Bh(e)}function Qg(e){return new Vh(e)}function $g(e){return new Hh(e)}function e_(e){return new Uh(e)}function t_(e){return new Wh(e)}function n_(e){return new Gh(e)}function r_(e){return new Kh(e)}function i_(e){return new qh(e)}async function a_(e){if(e==null)return;let t=[],n=[],r=[];for(let i in e){let a=e[i];if(typeof a!=`number`){let e=a;t.push(e.data()),n.push(i),r.push(e)}}if(t.length>0){let i=await Promise.all(t);for(let t=0;t<i.length;++t)e[n[t]]=i[t][0];D(r)}}function o_(e){if(e!=null)for(let t in e){let n=e[t];typeof n!=`number`&&n.dispose()}}var s_;(function(e){e[e.SILENT=0]=`SILENT`,e[e.VERBOSE=1]=`VERBOSE`})(s_||={});var c_=class{constructor(){this.validationData=null}setParams(e){this.params=e}async onEpochBegin(e,t){}async onEpochEnd(e,t){}async onBatchBegin(e,t){}async onBatchEnd(e,t){}async onTrainBegin(e){}async onTrainEnd(e){}setModel(e){}},l_=class{constructor(e,t=10){e??=[],this.callbacks=e,this.queueLength=t}append(e){this.callbacks.push(e)}setParams(e){for(let t of this.callbacks)t.setParams(e)}setModel(e){for(let t of this.callbacks)t.setModel(e)}async onEpochBegin(e,t){t??={};for(let n of this.callbacks)await n.onEpochBegin(e,t)}async onEpochEnd(e,t){t??={};for(let n of this.callbacks)await n.onEpochEnd(e,t)}async onBatchBegin(e,t){t??={};for(let n of this.callbacks)await n.onBatchBegin(e,t)}async onBatchEnd(e,t){t??={};for(let n of this.callbacks)await n.onBatchEnd(e,t)}async onTrainBegin(e){e??={};for(let t of this.callbacks)await t.onTrainBegin(e)}async onTrainEnd(e){e??={};for(let t of this.callbacks)await t.onTrainEnd(e)}},u_=class extends c_{constructor(){super()}async onEpochBegin(e){this.seen=0,this.totals={}}async onBatchEnd(e,t){t??={};let n=t.size==null?0:t.size;this.seen+=n;for(let e in t){let r=t[e];if(typeof r==`number`)this.totals.hasOwnProperty(e)||(this.totals[e]=0),this.totals[e]=this.totals[e]+r*n;else{let t;e in this.totals?t=this.totals[e]:this.totals[e]=0;let i=A(()=>I(this.totals[e],z(r,n)));this.totals[e]=i,t?.dispose()}}}async onEpochEnd(e,t){if(t!=null)for(let e of this.params.metrics)this.totals[e]!=null&&(typeof this.totals[e]==`number`?t[e]=this.totals[e]/this.seen:A(()=>{t[e]=z(N(1,this.seen),this.totals[e]),this.totals[e].dispose(),ze(t[e])}))}},d_=class extends c_{async onTrainBegin(e){this.epoch=[],this.history={}}async onEpochEnd(e,t){t??={},this.epoch.push(e);for(let e in t)this.history[e]??(this.history[e]=[]),this.history[e].push(t[e])}async syncData(){let e=[],t=[],n=[];for(let r in this.history){let i=this.history[r];for(let a=0;a<i.length;++a)if(typeof i[a]!=`number`){let o=i[a];e.push(o.data()),t.push(r),n.push(a)}}let r=await Promise.all(e);for(let e=0;e<r.length;++e)this.history[t[e]][n[e]].dispose(),this.history[t[e]][n[e]]=r[e][0]}},f_=class extends c_{constructor(e,t){if(super(),this.currentEpoch=0,this.nowFunc=e.nowFunc,this.nextFrameFunc=e.nextFrameFunc||Lu,this.yieldEvery=t||`auto`,this.yieldEvery===`auto`&&(this.yieldEvery=125),this.yieldEvery===`never`&&e.onYield!=null)throw Error("yieldEvery is `never` but you provided an `onYield` callback. Either change `yieldEvery` or remove the callback");Za(this.yieldEvery)&&(this.maybeWait=Dm(this.maybeWait.bind(this),this.yieldEvery,this.nowFunc)),this.trainBegin=e.onTrainBegin,this.trainEnd=e.onTrainEnd,this.epochBegin=e.onEpochBegin,this.epochEnd=e.onEpochEnd,this.batchBegin=e.onBatchBegin,this.batchEnd=e.onBatchEnd,this.yield=e.onYield}async maybeWait(e,t,n){let r=[];this.yield!=null&&(await a_(n),r.push(this.yield(e,t,n))),r.push(this.nextFrameFunc()),await Promise.all(r)}async onEpochBegin(e,t){this.currentEpoch=e,this.epochBegin!=null&&(await a_(t),await this.epochBegin(e,t))}async onEpochEnd(e,t){let n=[];this.epochEnd!=null&&(await a_(t),n.push(this.epochEnd(e,t))),this.yieldEvery===`epoch`&&n.push(this.nextFrameFunc()),await Promise.all(n)}async onBatchBegin(e,t){this.batchBegin!=null&&(await a_(t),await this.batchBegin(e,t))}async onBatchEnd(e,t){let n=[];this.batchEnd!=null&&(await a_(t),n.push(this.batchEnd(e,t))),this.yieldEvery===`batch`?n.push(this.nextFrameFunc()):Za(this.yieldEvery)&&n.push(this.maybeWait(this.currentEpoch,e,t)),await Promise.all(n)}async onTrainBegin(e){this.trainBegin!=null&&(await a_(e),await this.trainBegin(e))}async onTrainEnd(e){this.trainEnd!=null&&(await a_(e),await this.trainEnd(e))}};function p_(e,t){return e??={},e instanceof c_?[e]:Array.isArray(e)&&e[0]instanceof c_?e:fm(e).map(e=>new f_(e,t))}var m_=class e{constructor(){}static registerCallbackConstructor(t,n){o(t>=0&&Number.isInteger(t),()=>`Verbosity level is expected to be an integer >= 0, but got ${t}`),e.checkForDuplicate(n),e.constructors[t]??(e.constructors[t]=[]),e.constructors[t].push(n)}static checkForDuplicate(t){for(let n in e.constructors)e.constructors[+n].forEach(e=>{if(e===t)throw new W(`Duplicate callback constructor.`)})}static clear(){e.constructors={}}static createCallbacks(t){let n=[];for(let r in e.constructors){let i=+r;t>=i&&n.push(...e.constructors[i])}return n.map(e=>new e)}};m_.constructors={};function h_(e,t,n,r,i,a,o,s,c){let l=new d_,u=[new u_,...m_.createCallbacks(t)];e!=null&&u.push(...e),u.push(l);let d=new l_(u);return d.setParams({epochs:n,initialEpoch:r,samples:i,steps:a,batchSize:o,verbose:t,doValidation:s,metrics:c}),{callbackList:d,history:l}}function g_(e,t={},n=!1){return vm(e,ea.getMap().classNameMap,t,`layer`,n)}function __(e,t){return A(()=>{e.dtype!==`float32`&&(e=F(e,`float32`));let n=O(yh(e),t,!0),r=Ce(Ue(n,ra(n.shape,rh())));return N(e,r)})}function v_(e,t){return A(()=>Rn(yh(L(t,e)),-1))}function y_(e,t){return A(()=>Rn(es(L(t,e)),-1))}function b_(e,t){return A(()=>z(100,Rn(es(N(L(e,t),kl(es(e),rh(),Number.MAX_VALUE))),-1)))}function x_(e,t){return A(()=>Rn(yh(L(Do(I(1,kl(t,rh(),Number.MAX_VALUE))),Do(I(1,kl(e,rh(),Number.MAX_VALUE))))),-1))}function S_(e,t){return A(()=>Rn(yh(Ue(0,L(1,z(e,t)))),-1))}function C_(e,t){return A(()=>Rn(Ue(0,L(1,z(e,t))),-1))}function w_(e,t){return A(()=>{let n=O(z(e,t),-1);return Ue(0,I(1,L(Ro(z(L(1,e),t),-1),n)))})}function T_(e,t){return A(()=>{let n=Math.log(2),r=L(t,e);return Rn(L(I(r,yi(z(-2,r))),n),-1)})}function E_(e,t,n=!1){return A(()=>{if(n)t=xn(t);else{let e=O(t,t.shape.length-1,!0);t=N(t,e)}return t=kl(t,rh(),1-rh()),li(O(z(F(e,`float32`),Do(t)),t.shape.length-1))})}function D_(e,t,n=!1){return A(()=>{let r=F(zi(ch(e)),`int32`);t=kl(t,rh(),1-rh());let i=t.shape;return E_(U(de(r,i[i.length-1]),i),t,n)})}function O_(e,t){if(!qn(e.shape,t.shape))throw new W(`logits and labels must have the same shape, but got shapes ${JSON.stringify(e.shape)} and ${JSON.stringify(t.shape)}`);return A(()=>{let n=Qn(t),r=li(es(t));return I(L(n,z(t,e)),hc(gr(r)))})}function k_(e,t){return A(()=>{let n;return n=kl(t,rh(),1-rh()),n=Do(N(n,L(1,n))),Rn(O_(e,n),-1)})}function A_(e,t){return A(()=>O(z(e,Do(N(kl(e,rh(),1),kl(t,rh(),1)))),-1))}function j_(e,t){return A(()=>Rn(L(t,z(e,Do(I(rh(),t)))),-1))}function M_(e,t){return A(()=>li(O(z(__(e,-1),__(t,-1)),-1)))}var N_={meanSquaredError:v_,meanAbsoluteError:y_,meanAbsolutePercentageError:b_,meanSquaredLogarithmicError:x_,squaredHinge:S_,hinge:C_,categoricalHinge:w_,logcosh:T_,categoricalCrossentropy:E_,sparseCategoricalCrossentropy:D_,binaryCrossentropy:k_,kullbackLeiblerDivergence:A_,poisson:j_,cosineProximity:M_};function P_(e){if(typeof e==`string`){if(e in N_)return N_[e];let t=`Unknown loss ${e}`;throw e.toLowerCase().includes(`softmaxcrossentropy`)&&(t=`Unknown loss ${e}. Use "categoricalCrossentropy" as the string name for tf.losses.softmaxCrossEntropy`),new W(t)}else return e}function F_(e,t){return A(()=>Rn(jt(e,ah(go(t,z(.5,mr(t))),e.dtype)),-1))}function I_(e,t){return A(()=>ah(jt(lc(e,-1),lc(t,-1)),`float32`))}function L_(e,t){return A(()=>F(O($r(jt(e,1),jt(t,1))),`float32`))}function R_(e,t){return A(()=>F(O($r(jt(e,1),jt(t,0))),`float32`))}function z_(e,t){return A(()=>F(O($r(jt(e,0),jt(t,1))),`float32`))}function B_(e,t){return A(()=>{let n=L_(e,t),r=I(n,z_(e,t));return F(ac(go(r,0),N(n,r),0),`float32`)})}function V_(e,t){return A(()=>{let n=L_(e,t),r=I(n,R_(e,t));return F(ac(go(r,0),N(n,r),0),`float32`)})}function H_(e,t){return k_(e,t)}function U_(e,t){return e.rank===t.rank&&(e=Ie(e,[e.rank-1])),t=lc(t,-1),t.dtype!==e.dtype&&(t=F(t,e.dtype)),F(jt(e,t),`float32`)}function W_(e,t){return A(()=>{let n=e.sub(t).square().sum(),r=e.sub(e.mean()).square().sum();return kn(1).sub(n.div(r))})}var G_=v_,K_=v_,q_=y_,J_=y_,Y_=b_,X_=b_,Z_=E_,Q_=M_,$_=D_,ev={binaryAccuracy:F_,categoricalAccuracy:I_,precision:B_,categoricalCrossentropy:Z_,sparseCategoricalCrossentropy:$_,mse:G_,MSE:K_,mae:q_,MAE:J_,mape:Y_,MAPE:X_,cosine:Q_};function tv(e){if(typeof e==`string`&&e in ev)return ev[e];if(typeof e!=`string`&&e!=null)return e;throw new W(`Unknown metric ${e}`)}function nv(e){if(lm(e!==null,`Unknown LossOrMetricFn ${e}`),typeof e==`string`)return e;{let t;for(let n of Object.keys(N_))if(N_[n]===e){t=n;break}if(t!==void 0)return t;for(let n of Object.keys(ev))if(ev[n]===e){t=n;break}return t===void 0?e.name:t}}function rv(e){let t={Adagrad:()=>Fu.adagrad(.01),Adadelta:()=>Fu.adadelta(1,.95,rh()),Adam:()=>Fu.adam(.001,.9,.999,rh()),Adamax:()=>Fu.adamax(.002,.9,.999,rh(),0),RMSProp:()=>Fu.rmsprop(.001,.9,0,rh()),SGD:()=>Fu.sgd(.01)};if(t.adagrad=t.Adagrad,t.adadelta=t.Adadelta,t.adam=t.Adam,t.adamax=t.Adamax,t.rmsprop=t.RMSProp,t.sgd=t.SGD,e in t)return t[e]();throw new W(`Unknown Optimizer ${e}`)}var iv=1*1024*1024;function av(e,t,n=!1){if(typeof e!=`object`||!e||Object.getPrototypeOf(e)!==Object.prototype||!ov(e))throw Error(`User-defined metadata is expected to be a JSON object, but is not.`);if(n){let n=JSON.stringify(e);n.length>1048576&&console.warn(`User-defined metadata of model "${t}" is too large in size (length=${n.length} when serialized). It is not recommended to store such large objects in user-defined metadata. Please make sure its serialized length is <= ${iv}.`)}}function ov(e){if(e===null)return!0;if(typeof e==`object`)if(Object.getPrototypeOf(e)===Object.prototype){let t=Object.keys(e);for(let n of t)if(typeof n!=`string`||!ov(e[n]))return!1;return!0}else if(Array.isArray(e)){for(let t of e)if(!ov(t))return!1;return!0}else return!1;else{let t=typeof e;return t===`string`||t===`number`||t===`boolean`}}function sv(e,t,n,r=console.log){let i=lv(e),a=[`Layer (type)`,`Input Shape`,`Output shape`,`Param #`];i?(t||=90,n||=[.32,.61,.89,1]):(t||=115,n||=[.24,.48,.7,.8,1]),n[n.length-1]<=1&&(n=n.map(e=>Math.floor(t*e)));let o;if(!i){a.push(`Receives inputs`),o=[];for(let t in e.nodesByDepth)o.push(...e.nodesByDepth[t])}r(`_`.repeat(t)),uv(a,n,r),r(`=`.repeat(t));let s=e.layers;for(let e=0;e<s.length;++e)i?dv(s[e],n,r):fv(s[e],n,o,r),r((e===s.length-1?`=`:`_`).repeat(t));e.checkTrainableWeightsConsistency();let c=cv(e),l=eg(e.nonTrainableWeights);r(`Total params: ${c+l}`),r(`Trainable params: ${c}`),r(`Non-trainable params: ${l}`),r(`_`.repeat(t))}function cv(e){let t;return t=e.collectedTrainableWeights==null?eg(e.trainableWeights):eg(e.collectedTrainableWeights),t}function lv(e){let t=!0,n=[],r=[];for(let t in e.nodesByDepth)n.push(e.nodesByDepth[t]);for(let e of n){if(e.length>1||e.length===1&&e[0].inboundLayers.length>1){t=!1;break}r.push(...e)}if(t)for(let n of e.layers){let e=!1;for(let i of n.inboundNodes)if(r.indexOf(i)!==-1)if(e){t=!1;break}else e=!0;if(!t)break}return t}function uv(e,t,n=console.log){let r=``;for(let n=0;n<e.length;++n)n>0&&(r=r.slice(0,r.length-1)+` `),r+=e[n],r=r.slice(0,t[n]),r+=` `.repeat(t[n]-r.length);n(r)}function dv(e,t,n){let r,i;try{i=e.inboundNodes.map(e=>JSON.stringify(e.inputShapes)).join(`,`)}catch{i=`multiple`}try{r=JSON.stringify(e.outputShape)}catch{r=`multiple`}uv([`${e.name} (${e.getClassName()})`,i,r,e.countParams().toString()],t,n)}function fv(e,t,n,r){let i,a;try{a=e.inboundNodes.map(e=>JSON.stringify(e.inputShapes)).join(`,`)}catch{a=`multiple`}try{i=JSON.stringify(e.outputShape)}catch{i=`multiple`}let o=[];for(let t of e.inboundNodes)if(!(n!=null&&n.length>0&&n.indexOf(t)===-1))for(let e=0;e<t.inboundLayers.length;++e){let n=t.inboundLayers[e].name,r=t.nodeIndices[e],i=t.tensorIndices[e];o.push(`${n}[${r}][${i}]`)}let s=e.name,c=e.getClassName(),l=o.length===0?``:o[0];uv([`${s} (${c})`,a,i,e.countParams().toString(),l],t,r);for(let e=1;e<o.length;++e)uv([``,``,``,``,o[e]],t,r)}function pv(e,t,n){return(e===`inboundNodes`||e===`outputLayers`||e===`inputLayers`)&&t===0&&typeof n==`string`}function mv(e,t){if(e===null)return null;if(typeof e==`string`)return mm(e);if(typeof e==`number`||typeof e==`boolean`)return e;if(e instanceof Array){let n=[],r=e.length;for(let i=0;i<r;++i){let r=e[i];pv(t,i,r)?n.push(r):n.push(mv(r,t))}return n}else{let t={};for(let n of Object.keys(e)){let r=e[n];if(n===`name`&&typeof r==`string`)t[n]=r;else{let e=mm(n);t[e]=mv(r,e)}}return t}}function hv(e,t){if(e==null)return null;if(typeof e==`string`)return pm(e);if(typeof e==`number`||typeof e==`boolean`)return e;if(e instanceof Array){let n=[],r=e.length;for(let i=0;i<r;++i){let r=e[i];pv(t,i,r)?n.push(r):n.push(hv(r,t))}return n}else{let t={};for(let n of Object.keys(e)){let r=e[n],i=pm(n);(n===`name`||n===`className`)&&typeof r==`string`?t[i]=r:t[i]=hv(r,n)}return t}}var gv=`4.22.0`,_v=e=>{let t=Object.keys(e);if(t.length===0)return!1;let n=t[0].split(`/`);return!isNaN(parseInt(n[n.length-1],10))},vv=class e extends J{constructor(t){if(super({}),this.containerNodes=new Set,this.name=t.name,this.name==null){let e=this.getClassName().toLowerCase();this.name=Mm(e)}if(this.supportsMasking=!1,this.trainable_=!0,Array.isArray(t.inputs)?this.inputs=t.inputs.slice():this.inputs=[t.inputs],Array.isArray(t.outputs)?this.outputs=t.outputs.slice():this.outputs=[t.outputs],xm(this.inputs).length!==this.inputs.length)throw new W(`The list of inputs passed to the model is redundant. All inputs should only appear once. Found: ${this.inputs.map(e=>e.name)}`);xm(this.outputs).length!==this.outputs.length&&console.warn(`The list of outputs passed to the model is redundant. All outputs should only appear once. Found: ${this.outputs.map(e=>e.name)}`),this.inputLayers=[],this.inputLayersNodeIndices=[],this.inputLayersTensorIndices=[],this.outputLayers=[],this.outputLayersNodeIndices=[],this.outputLayersTensorIndices=[],this.layers=[],this.internalContainerRefs=[];for(let e of this.outputs){let t=e.sourceLayer,n=e.nodeIndex,r=e.tensorIndex;this.outputLayers.push(t),this.outputLayersNodeIndices.push(n),this.outputLayersTensorIndices.push(r)}for(let e of this.inputs){let t=e.sourceLayer,n=e.nodeIndex,r=e.tensorIndex;lm(n===0,`input layer has >1 nodes`),lm(r===0,`input layer has >1 tensors`),this.inputLayers.push(t),this.inputLayersNodeIndices.push(n),this.inputLayersTensorIndices.push(r)}this.inputNames=[],this.outputNames=[],this.feedInputShapes=[],this.feedInputNames=[],this.feedOutputNames=[];for(let e=0;e<this.inputLayers.length;e++){let n=this.inputLayers[e];if(!(n instanceof gg))throw TypeError(`Input layers to a LayersModel must be InputLayer objects. Received inputs: ${t.inputs}. Input ${e} (0-based) originates from layer type ${n.getClassName()}.`);this.inputNames.push(n.name),this.feedInputShapes.push(n.batchInputShape),this.feedInputNames.push(n.name)}for(let e of this.outputLayers)this.outputNames.push(e.name);this.internalInputShapes=this.inputs.map(e=>e.shape),this.internalOutputShapes=this.outputs.map(e=>e.shape);let n={},r={},i={},a={},o={},s=[],c=(t,n,r,i,a,l)=>{(i==null||a==null||l==null)&&(i=t.sourceLayer,a=t.nodeIndex,l=t.tensorIndex);let u=i.inboundNodes[a];if(r.indexOf(u)!==-1)throw new am(`The tensor ${t.name} at layer "${i.name}" is part of a cycle.`);if(n.indexOf(u)!==-1)return;this.containerNodes.add(e.nodeKey(i,a)),i.id in o||(o[i.id]=Object.keys(o).length),r.indexOf(u)===-1&&r.push(u);let d=u.inboundLayers.length;for(let e=0;e<d;e++){let t=u.inputTensors[e],i=u.inboundLayers[e],a=u.nodeIndices[e],o=u.tensorIndices[e];c(t,n,r,i,a,o)}for(n.push(u);r.indexOf(u)>=0;)r.splice(r.indexOf(u),1);s.push(u)},l=[],u=[];for(let e of this.outputs)c(e,l,u);let d=s.slice().reverse();for(let e of d){r[e.id]=e,e.id in n||(n[e.id]=0);let t=n[e.id],o=i[e.outboundLayer.id]==null?0:i[e.outboundLayer.id];t=Math.max(t,o),i[e.outboundLayer.id]=t,a[e.outboundLayer.id]=e.outboundLayer,n[e.id]=t;for(let i=0;i<e.inboundLayers.length;i++){let a=e.inboundLayers[i],o=e.nodeIndices[i],s=a.inboundNodes[o],c=n[s.id]==null?0:n[s.id];n[s.id]=Math.max(t+1,c),r[s.id]=s}}let f={};for(let e in n){let t=n[e];t in f||(f[t]=[]),f[t].push(r[e])}let p={};for(let e in i){let t=i[e];t in p||(p[t]=[]),p[t].push(a[e])}let m=Object.keys(p).map(e=>parseInt(e,10)).sort(bm);this.layers=[];for(let t of m){let n=p[t];n.sort((e,t)=>{let n=o[e.id],r=o[t.id];return n<r?-1:+(n>r)});for(let t of n)t instanceof e&&this.internalContainerRefs.push(t),this.layers.push(t)}this.layersByDepth=p,m=Object.keys(f).map(e=>parseInt(e,10)).sort(bm);let h=this.inputs.slice(),g=[];for(let e of m)for(let t of f[e]){let e=t.outboundLayer;if(e!=null){for(let n of t.inputTensors)if(h.indexOf(n)===-1)throw new am(`Graph disconnected: cannot obtain value for tensor ${n} at layer "${e.name}". The following previous layers were accessed without issue: ${g}`);for(let e of t.outputTensors)h.push(e);g.push(e.name)}}this.nodesByDepth=f;let _=this.layers.map(e=>e.name);for(let e of _){let t=_.filter(t=>t===e).length;if(t!==1)throw new am(`The name "${e}" is used ${t} times in the model. All layer names should be unique. Layer names: `+JSON.stringify(_))}this.outboundNodes=[],this.inboundNodes=[],new lg({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:this.inputs,outputTensors:this.outputs,inputMasks:this.inputs.map(e=>null),outputMasks:this.outputs.map(e=>null),inputShapes:this.inputs.map(e=>e.shape),outputShapes:this.outputs.map(e=>e.shape)}),this.built=!0,this._refCount=1}assertNotDisposed(){if(this._refCount===0)throw Error(`Container '${this.name}' is already disposed.`)}dispose(){this.assertNotDisposed();let e={refCountAfterDispose:null,numDisposedVariables:0};if(--this._refCount===0){for(let t of this.layers)e.numDisposedVariables+=t.dispose().numDisposedVariables;for(let t of this.internalContainerRefs)e.numDisposedVariables+=t.dispose().numDisposedVariables}return e.refCountAfterDispose=this._refCount,e}get trainable(){return this.trainable_}set trainable(e){this.layers.forEach(t=>{t._trainableWeights.forEach(t=>t.trainable=e)}),this.trainable_=e}get trainableWeights(){if(this._trainableWeights.length>0)throw new W(`Container instance unexpectedly contains _trainableWeights.The trainable weights of a Container are a union of the trainable weights of its consituent Layers. Its own _trainableWeights must remain an empty Array.`);if(!this.trainable)return[];let e=[];for(let t of this.layers)e=e.concat(t.trainableWeights);return e}get nonTrainableWeights(){let e=[];for(let t of this.layers)e.push(...t.nonTrainableWeights);if(!this.trainable){let t=[];for(let e of this.layers)t.push(...e.trainableWeights);return t.concat(e)}return e}get weights(){return this.trainableWeights.concat(this.nonTrainableWeights)}loadWeights(e,t=!0){let n={},r=0,i=_v(e);i&&this.parseWeights(e);for(let e of this.layers)for(let[t,a]of e.weights.entries()){let e=i?`${a.name.split(`/`).slice(0,-1).join(`/`)+`/`}${t}`:a.originalName;if(n[e]!=null)throw new W(`Duplicate weight name: ${e}`);n[e]=a,r++}let a=[];for(let r in e){let i=r;if(n[r]==null){let e=r.split(`/`);i=e.slice(0,-2).concat([e[e.length-1]]).join(`/`)}if(n[i]!=null)a.push([n[i],e[r]]);else if(t)throw new W(`Provided weight data has no target variable: ${r}`);delete n[i]}if(t){let e=[];for(let t in n)e.push(t);if(e.length>0)throw new W(`${e.length} of ${r} weights are not set: ${e}`)}ag(a)}parseWeights(e){for(let t in Object.keys(e)){let n=t.split(`/`),r=[`vars`,`layer_checkpoint_dependencies`],i=n.map(e=>e.startsWith(`_`)?e.slice(1):e).filter(e=>!r.includes(e)).join(`/`);i!==t&&(e[i]=e[t],delete e[t])}}updatedConfig(){let e=this.getConfig(),t={};return t.className=this.getClassName(),t.config=e,t.kerasVersion=`tfjs-layers ${gv}`,t.backend=`TensorFlow.js`,t}toJSON(e,t=!0){let n=hv(this.updatedConfig());return t?JSON.stringify(n):n}call(e,t){return A(()=>{e=fm(e);let n=new yg;for(let t=0;t<this.inputs.length;++t)n.add(this.inputs[t],e[t]);return Cg(this.outputs,n,t)})}computeMask(e,t){return A(()=>{e=fm(e);let n;return n=t==null?cm(null,e.length):fm(t),this.runInternalGraph(e,n)[1]})}computeOutputShape(e){let t=$h(e);if(t.length!==this.inputLayers.length)throw new W(`Invalid inputShape argument ${e}: model has ${this.inputLayers.length} tensor inputs.`);let n={};for(let e=0;e<t.length;e++){let r=this.inputLayers[e],i=t[e],a=r.name+`_0_0`;n[a]=i}let r=Object.keys(this.nodesByDepth).map(e=>parseInt(e,10)).sort(bm);if(r.length>1)for(let e of r){let t=this.nodesByDepth[e];for(let e of t){let t=e.outboundLayer;if(this.inputLayers.map(e=>e.id).indexOf(t.id)!==-1)continue;let r=[];for(let t=0;t<e.inboundLayers.length;t++){let i=e.inboundLayers[t],a=e.nodeIndices[t],o=e.tensorIndices[t],s=n[`${i.name}_${a}_${o}`];r.push(s)}let i=$h(t.computeOutputShape(dm(r))),a=t.inboundNodes.indexOf(e);for(let e=0;e<i.length;e++){let r=`${t.name}_${a}_${e}`;n[r]=i[e]}}}let i=[],a=[];for(let e=0;e<this.outputLayers.length;e++){let t=this.outputLayers[e],n=this.outputLayersNodeIndices[e],r=this.outputLayersTensorIndices[e],i=`${t.name}_${n}_${r}`;a.push(i)}for(let e=0;e<a.length;e++){let t=a[e];lm(t in n),i.push(n[t])}return dm(i)}runInternalGraph(e,t){t??=cm(null,e.length);let n={};for(let r=0;r<this.inputs.length;++r){let i=this.inputs[r],a=e[r],o=t[r];n[i.id]=[a,o]}let r=Object.keys(this.nodesByDepth).map(e=>parseInt(e,10)).sort(bm);for(let e of r){let t=this.nodesByDepth[e];for(let e of t){let t=e.outboundLayer,r=e.inputTensors,i=e.outputTensors,a=[];for(let e of r)e.id in n&&a.push(n[e.id]);if(a.length===r.length){let r={},o,s,c,l;if(e.callArgs!=null&&(r=e.callArgs),a.length===1){let[e,n]=a[0];r.mask??=n,c=fm(t.call(e,r)),l=fm(t.computeMask(e,n)),o=[e],s=[n]}else o=a.map(e=>e[0]),s=a.map(e=>e[1]),r.mask??=s,c=fm(t.call(o,r)),l=fm(t.computeMask(o,s));if(t.activityRegularizer)throw new G(`LayersModel invocation with concrete Tensor value(s) in the presence of activity regularizer(s) is not supported yet.`);for(let e=0;e<i.length;++e){let t=i[e],r=c[e],a=l[e];n[t.id]=[r,a]}}}}let i=[],a=[],o=[];for(let e of this.outputs){lm(e.id in n,`Could not compute output ${e.name} : ${e.id}`);let[t,r]=n[e.id];o.push(t.shape),i.push(t),a.push(r)}return[i,a,o]}buildNodeConversionMap(t){let n={},r;for(let t of this.layers){r=+(t instanceof e);for(let i=0;i<t.inboundNodes.length;i++){let a=e.nodeKey(t,i);this.containerNodes.has(a)&&(n[a]=r,r+=1)}}return n}getLayer(e,t){if(t!=null)return this.findLayer(t);if(e==null)throw new W(`Provide either a layer name or layer index`);if(typeof e==`number`)return this.findLayer(e);for(let t of this.layers)if(t.name===e)return t;throw new W(`No such layer: ${e}`)}findLayer(e){if(this.layers.length<=e)throw new W(`Was asked to retrieve layer at index ${e}, but model only has ${this.layers.length} layer(s).`);return this.layers[e]}calculateLosses(){return A(()=>{let t=[];for(let n of this.layers)for(let r=0;r<n.inboundNodes.length;++r){let i=e.nodeKey(n,r);this.containerNodes.has(i)&&t.push(...n.calculateLosses())}return t})}getConfig(){let t={name:this.name},n=this.buildNodeConversionMap(this.layers),r=[];for(let t of this.layers){let i=t.getClassName(),a=t.getConfig(),o=[];for(let r=0;r<t.inboundNodes.length;r++){let i=t.inboundNodes[r],a=e.nodeKey(t,r),s={};if(this.containerNodes.has(a)){if(i.callArgs)try{JSON.stringify(i.callArgs),s=i.callArgs}catch{console.warn(`Layer ${t.name} was passed non-serializable keyword arguments: ${i.callArgs}. They will not be included in the serialized model (and thus will be missing at deserialization time).`),s={}}if(i.inboundLayers.length>0){let t=[];for(let r=0;r<i.inboundLayers.length;r++){let a=i.inboundLayers[r],o=i.nodeIndices[r],c=i.tensorIndices[r],l=n[e.nodeKey(a,o)];l??=0,t.push([a.name,l,c,s])}o.push(t)}}}let s={};s.name=t.name,s.className=i,s.config=a,s.inboundNodes=o,r.push(s)}t.layers=r;let i=[];for(let t=0;t<this.inputLayers.length;t++){let r=this.inputLayers[t],a=this.inputLayersNodeIndices[t],o=e.nodeKey(r,a);if(!this.containerNodes.has(o))continue;let s=n[o];s??=0;let c=this.inputLayersTensorIndices[t];i.push([r.name,s,c])}t.inputLayers=i;let a=[];for(let t=0;t<this.outputLayers.length;t++){let r=this.outputLayers[t],i=this.outputLayersNodeIndices[t],o=e.nodeKey(r,i);if(!this.containerNodes.has(o))continue;let s=n[o];s??=0;let c=this.outputLayersTensorIndices[t];a.push([r.name,s,c])}return t.outputLayers=a,t}static fromConfig(e,t,n={},r=!1){let i={},a={};function o(e,t){e.name in a?a[e.name].push(t):a[e.name]=[t]}function s(e,t){let n=[],r;for(let a of t){let s=a[0],c=a[1],l=a[2];if(r=a[3]==null?{}:a[3],!(s in i)){o(e,t);return}let u=i[s];if(u.inboundNodes.length<=c){o(e,t);return}let d=u.inboundNodes[c];n.push(d.outputTensors[l])}n.length>0&&e.apply(dm(n),r)}function c(e){let n=e.name,a=g_(e,t.customObjects==null?{}:t.customObjects);a.setFastWeightInitDuringBuild(r),i[n]=a,e.inboundNodes.forEach(e=>{if(!(e instanceof Array))throw new W(`Corrupted configuration, expected array for nodeData: ${e}`);o(a,e)})}let l=t.name,u=t.layers;for(let e of u)c(e);for(;!Sm(a);)for(let e of u){let t=i[e.name];if(t.name in a){let e=a[t.name];delete a[t.name];for(let n of e)s(t,n)}}let d=[],f=[],p=t.inputLayers;for(let e of p){let t=e[0],n=e[1],r=e[2];lm(t in i);let a=i[t].inboundNodes[n].outputTensors;d.push(a[r])}let m=t.outputLayers;for(let e of m){let t=e[0],n=e[1],r=e[2];lm(t in i);let a=i[t].inboundNodes[n].outputTensors;f.push(a[r])}return new e({inputs:d,outputs:f,name:l})}get stateful(){if(this._stateful)throw new W(`Container instance unexpectedly has _stateful = true. The statefulness of a Container is determined by the Layers it contains. Its _stateful property must remain the default false.`);for(let e of this.layers)if(e.stateful)return!0;return!1}resetStates(){A(()=>{this.layers.forEach(e=>{e.stateful&&e.resetStates()})})}};function yv(e,t,n){let r=t.length;if(e==null||Array.isArray(e)&&e.length===0)return t.map(e=>null);if(r===1)return Array.isArray(e)&&e.length===1?e:typeof e==`object`&&t[0]in e?[e[t[0]]]:[e];if(Array.isArray(e)){if(e.length!==r)throw Error(`Provided ${n} is an array of ${e.length} element(s), but the model has ${r} outputs. Make sure a set of weights is provided for each model output.`);return e}else if(typeof e==`object`&&Object.keys(e).length>0&&typeof e[Object.keys(e)[0]]==`object`){let n=[];return t.forEach(t=>{t in e?n.push(e[t]):n.push(null)}),n}else throw Error(`The model has multiple (${r}) outputs, so ${n} must be either an array with ${r} elements or an object with ${t} keys. Provided ${n} not understood: ${JSON.stringify(e)}`)}function bv(e,t){return yv(e,t,`classWeight`)}async function xv(e,t,n,r){if(t!=null||r!=null)throw Error(`Support sampleWeight is not implemented yet`);if(n!=null){let t=A(()=>{if(e.shape.length===1)return lo(e);if(e.shape.length===2){if(e.shape[1]>1)return lc(e,1);if(e.shape[1]===1)return U(e,[e.shape[0]]);throw Error(`Encountered unexpected last-dimension size (${e.shape[1]}) during handling of class weights. The size is expected to be >= 1.`)}else throw Error(`Unexpected rank of target (y) tensor (${e.rank}) during handling of class weights. The rank is expected to be 1 or 2.`)}),r=Array.from(await t.data());D(t);let i=[];return r.forEach(e=>{if(n[e]==null)throw Error(`classWeight must contain all classes in the training data. The class ${e} exists in the data but not in classWeight`);i.push(n[e])}),Tl(i,`float32`)}else return null}function Sv(e,t){return z(e,t)}var Cv=32;function wv(e,t){let n,r,i=t;n=i.xs,r=i.ys,o(n!=null&&r!=null,()=>`A Dataset iterator for fitDataset() is expected to generate objects of the form \`{xs: xVal, ys: yVal}\`, where the two values may be \`tf.Tensor\`, an array of Tensors, or a map of string to Tensor.  The provided Dataset instead generates ${t}`);let a=Tv(`input`,e.inputNames,n),s=Tv(`output`,e.outputNames,r),c=a[0].shape[0];o(a.length===e.inputs.length,()=>`LayersModel has ${e.inputs.length} inputs, but the dataset provides ${a.length} inputs.  (Expected input keys: ${JSON.stringify(e.inputNames)})`),o(s.length===e.outputs.length,()=>`LayersModel has ${e.outputs.length} outputs, but the dataset provides ${s.length} outputs.  (Expected output keys: ${JSON.stringify(e.outputNames)})`);for(let t=0;t<a.length;t++)o(a[t].shape[0]===c,()=>`Batch size mismatch: input ${e.inputNames[t]} has ${a[t].shape[0]}; expected  ${c} based on input ${e.inputNames[0]}.`);for(let t=0;t<s.length;t++)o(s[t].shape[0]===c,()=>`Batch size mismatch: output ${e.outputNames[t]} has ${s[t].shape[0]}; expected  ${c} based on input ${e.inputNames[0]}.`);return{xs:a,ys:s}}function Tv(e,t,n){if(n instanceof wc)return[n];if(Array.isArray(n))return o(n.length===t.length,()=>`Received an array of ${n.length} Tensors, but expected ${t.length} to match the ${e} keys ${t}.`),n;{let r=[];for(let i of t){if(n[i]==null)throw new W(`The feature data generated by the dataset lacks the required ${e} key '${i}'.`);r.push(n[i])}return r}}function Ev(e){if(e.length===3)throw new G(`Validation with sample weights is not implemented yet.`);return{xs:e[0],ys:e[1]}}async function Dv(e,t,n){let r=n.batchesPerEpoch!=null;if(o(e.optimizer!=null,()=>`You must compile a model before training/testing. Use LayersModel.compile(modelCompileConfig).`),o(n!=null,()=>`For fitDataset(), the 2nd argument (config) is required, but it is not provided in this call.`),o(n.epochs!=null&&n.epochs>0&&Number.isInteger(n.epochs),()=>`For fitDataset(), config.epochs is expected to be a positive integer, but got ${n.epochs}`),o(!r||n.batchesPerEpoch>0&&Number.isInteger(n.batchesPerEpoch),()=>`For fitDataset(), config.batchesPerEpoch is expected to be a positive integer if specified, but got ${n.batchesPerEpoch}`),o(n.validationSplit==null,()=>"`validationSplit` is not supported by `fitDataset()`. Use validationData instead."),e.isTraining)throw Error(`Cannot start training because another fit() call is ongoing.`);e.isTraining=!0;try{let i=n.validationData!=null,a,s;if(i)if(kv(n.validationData))o(n.validationBatches==null||n.validationBatches>0&&Number.isInteger(n.validationBatches),()=>`For fitDataset() with dataset-based validation, config.validationBatches is expected not to be provided, or to be a positive integer, but got ${n.validationBatches}`);else{let e=Ev(n.validationData);a=e.xs,s=e.ys}let c=e.makeTrainFunction(),l=e.getDedupedMetricsNames(),u;u=i?l.slice().concat(l.map(e=>`val_`+e)):l.slice();let{callbackList:d,history:f}=h_(p_(n.callbacks,n.yieldEvery),n.verbose==null?1:n.verbose,n.epochs,null,null,Ov(t,n),null,i,u);d.setModel(e),e.history=f,await d.onTrainBegin(),e.stopTraining_=!1;let p=n.initialEpoch==null?0:n.initialEpoch,m=await t.iterator();for(;p<n.epochs;){let o={};await d.onEpochBegin(p);let u=0,f=0;for(r||(m=await t.iterator());!r||u<n.batchesPerEpoch;){let t=await m.next();if(r&&t.done){console.warn(`You provided \`batchesPerEpoch\` as ${n.batchesPerEpoch}, but your dataset iterator ran out of data after ${u} batches; interrupting training. Make sure that your dataset can generate at least \`batchesPerEpoch * epochs\` batches (in this case, ${n.batchesPerEpoch*n.epochs} batches). You may need to use the repeat() function when building your dataset.`);break}if(t.value!=null){let{xs:r,ys:i}=wv(e,t.value),a={};a.batch=f,a.size=r[0].shape[0],await d.onBatchBegin(f,a);let o=[];if(n.classWeight!=null){let t=bv(n.classWeight,e.outputNames);for(let e=0;e<t.length;++e)o.push(await xv(i[e],null,t[e]))}let s=r.concat(i).concat(o),p=c(s);D(s);for(let e=0;e<l.length;++e){let t=l[e],n=p[e];a[t]=n,ze(n)}await d.onBatchEnd(f,a),o_(a),f++,u++}if(r?u>=n.batchesPerEpoch:t.done){if(i){let t;t=kv(n.validationData)?fm(await e.evaluateDataset(n.validationData,{batches:n.validationBatches})):fm(e.evaluate(a,s,{batchSize:n.validationBatchSize==null?Cv:n.validationBatchSize,verbose:0}));for(let n=0;n<e.metricsNames.length;++n)o[`val_${e.metricsNames[n]}`]=t[n]}break}if(e.stopTraining_)break}if(await d.onEpochEnd(p,o),p++,e.stopTraining_)break}return await d.onTrainEnd(),await e.history.syncData(),e.history}finally{e.isTraining=!1}}function Ov(e,t){let n=null;return t.batchesPerEpoch==null?Number.isFinite(e.size)&&(n=e.size):n=t.batchesPerEpoch,n}function kv(e){return typeof e.iterator==`function`}function Av(e){return typeof e.next==`function`}async function jv(e,t,n){n||={};let r=n.batches!=null,i=e.testFunction,a=[];if(n.verbose>0)throw new G(`Verbose mode is not implemented yet.`);o(!r||n.batches>0&&Number.isInteger(n.batches),()=>`Test loop expects \`batches\` to be a positive integer, but received ${JSON.stringify(n.batches)}`);let s=Av(t)?t:await t.iterator(),c=0,l=0;for(;!r||l<n.batches;){let t=await s.next();if(a=A(()=>{if(t.value){let{xs:n,ys:r}=wv(e,t.value),o=n.concat(r),s=A(()=>i(o));if(D(o),l===0)for(let e=0;e<s.length;++e)a.push(kn(0));let u=o[0].shape[0];for(let e=0;e<s.length;++e){let t=s[e],n=a[e];a[e]=A(()=>I(a[e],z(u,t))),l>0&&D(n)}D(s),c+=u,++l}return a}),t.done){r&&console.warn(`Your dataset iterator ran out of data during evaluateDataset(). Interrupting evalution. Make sure that your dataset can generate at least \`batches\` batches (in this case, ${n.batches} batches). You may need to use the repeat() function when building your dataset.`);break}}for(let e=0;e<a.length;++e){let t=a[e];a[e]=N(a[e],c),D(t)}return dm(a)}function Mv(e){o(e>0&&Number.isInteger(e),()=>`batchSize is required to be a positive integer, but got ${e}`)}function Nv(e,t,n){return e==null?[null]:Array.isArray(e)?e.map(e=>uh(e,t,n-t)):uh(e,t,n-t)}function Pv(e,t){return A(()=>e==null?null:Array.isArray(e)?e.map(e=>Pv(e,t)):vh(e,t.dtype===`int32`?t:F(t,`int32`)))}function Fv(e,t){let n=[],r=0,i=null;for(;r<e;)i=r+t,i>=e&&(i=e),n.push([r,i]),r=i;return n}function Iv(e){let t=[];e instanceof wc&&(e=[e]);for(let n=0;n<e.length;++n){let r=e[n];if(r.rank===1)t.push(oh(r,1));else if(r.rank===0)throw Error(`Expected tensor to be at least 1D, but received a 0D tensor (scalar).`);else t.push(r)}return t}function Lv(e,t){if(e==null)return;let n=[];if(t instanceof wc)n.push(t.id);else if(Array.isArray(t))t.forEach(e=>n.push(e.id));else if(t!=null)for(let e in t){let r=t[e];n.push(r.id)}let r=[];if(e instanceof wc)n.indexOf(e.id)===-1&&r.push(e);else if(Array.isArray(e))e.forEach(e=>{n.indexOf(e.id)===-1&&r.push(e)});else if(e!=null)for(let t in e){let i=e[t];n.indexOf(i.id)===-1&&r.push(i)}r.forEach(e=>{e.isDisposed||e.dispose()})}function Rv(e){return e instanceof wc}function zv(e){return Array.isArray(e)}function Bv(e){return!Rv(e)&&!zv(e)}function Vv(e,t,n,r=!0,i=``){if(t==null||t.length===0){if(e!=null){let t=!1;if(zv(e)&&e.length>0)t=!0;else if(Bv(e)){for(let n in e)if(e.hasOwnProperty(n)){t=!0;break}}else t=!0;if(t)throw new W(`Error when checking model ${i} expected no data, but got ${e}`)}return[]}if(e==null)return t.map(e=>null);let a;if(Bv(e)){e=e,a=[];for(let n of t){if(e[n]==null)throw new W(`No data provided for "${n}". Need data for each key in: ${t}`);a.push(e[n])}}else if(zv(e)){if(e=e,e.length!==t.length)throw new W(`Error when checking model ${i}: the Array of Tensors that you are passing to your model is not the size the model expected. Expected to see ${t.length} Tensor(s), but instead got the following list of Tensor(s): ${e}`);a=e}else{if(e=e,t.length>1)throw new W(`The model ${i} expects ${t.length} Tensor(s), but only received one Tensor. Found: Tensor with shape ${e.shape}`);a=[e]}if(a=Iv(a),n!=null)for(let e=0;e<t.length;++e){if(n[e]==null)continue;let o=a[e];if(o.shape.length!==n[e].length)throw new W(`Error when checking ${i}: expected ${t[e]} to have ${n[e].length} dimension(s). but got array with shape ${o.shape}`);for(let t=0;t<n[e].length;++t){if(t===0&&!r)continue;let a=o.shape[t],s=n[e][t];if(s!=null&&s>=0&&a!==s)throw new W(`${i} expected a batch of elements where each example has shape [${n[e].slice(1,n[e].length)}] (i.e.,tensor shape [*,${n[e].slice(1,n[e].length)}]) but the ${i} received an input with ${o.shape[0]} examples, each with shape [${o.shape.slice(1,o.shape.length)}] (tensor shape [${o.shape}])`)}}return a}function Hv(e,t,n){let r=xm(e.map(e=>e.shape[0]));r.sort();let i=xm(t.map(e=>e.shape[0]));if(i.sort(),r.length>1)throw new W(`All input Tensors (x) should have the same number of samples. Got array shapes: ${JSON.stringify(e.map(e=>e.shape))}`);if(i.length>1)throw new W(`All target Tensors (y) should have the same number of samples. Got array shapes: ${JSON.stringify(t.map(e=>e.shape))}`);if(r.length>0&&i.length>0&&!qn(r,i))throw new W(`Input Tensors should have the same number of samples as target Tensors. Found ${r[0]} input sample(s) and ${i[0]} target sample(s).`)}function Uv(e,t,n){let r=[v_,k_,E_];for(let i=0;i<e.length;++i){let a=e[i],o=t[i],s=n[i];if(o!=null){if(o===E_&&a.shape[a.shape.length-1]===1)throw new W(`You are passing a target array of shape ${a.shape} while using a loss 'categorical_crossentropy'. 'categorical_crossentropy'expects targets to be binary matrices (1s and 0s) of shape [samples, classes].`);if(r.indexOf(o)!==-1){let e=a.shape.slice(1),t=s.slice(1);for(let n=0;n<e.length;++n){let r=e[n],i=t[n];if(i!=null&&r!==i)throw new W(`A target Tensor with shape ${a.shape} was passed for an output of shape ${s}, while using a loss function that expects targets to have the same shape as the output.`)}}}}}function Wv(e,t,n,r=!0,i=``){let a;if(Array.isArray(e)){if(e.length!==t.length)throw new W(`Error when checking model ${i}: the Array of Tensors that you are passing to your model is not the size the the model expected. Expected to see ${t.length} Tensor(s), but instead got ${e.length} Tensors(s).`);a=e}else{if(t.length>1)throw new W(`The model expects ${t.length} ${i} Tensors, but only received one Tensor. Found: array with shape ${JSON.stringify(e.shape)}.`);a=[e]}if(n!=null)for(let e=0;e<t.length;++e){if(n[e]==null)continue;let o=a[e];if(o.shape.length!==n[e].length)throw new W(`Error when checking ${i}: expected ${t[e]} to have ${n[e].length} dimension(s), but got array with shape ${JSON.stringify(o.shape)}`);for(let a=0;a<n[e].length;++a){if(a===0&&!r)continue;let s=o.shape[a],c=n[e][a];if(c!=null&&c!==s)throw new W(`Error when checking ${i}: expected ${t[e]} to have shape ${JSON.stringify(n[e])} but got array with shape ${JSON.stringify(o.shape)}.`)}}}function Gv(e,t){if(e==null||Array.isArray(e)&&e.length===0)return t.map(e=>[]);let n;if(typeof e==`string`||typeof e==`function`)n=[e];else if(Array.isArray(e)||typeof e==`object`)n=e;else throw TypeError(`Type of metrics argument not understood. Expected an string,function, Array, or Object, found: ${e}`);if(Array.isArray(n))return t.map(e=>n);{let e=[];for(let r of t){let t=n.hasOwnProperty(r)?n[r]:[];Array.isArray(t)||(t=[t]),e.push(t)}return e}}var Kv=`layers-model`,qv=class extends vv{constructor(e){super(e),this.isTraining=!1}summary(e,t,n=console.log){if(!this.built)throw new W(`This model has never been called, thus its weights have not been created yet. So no summary can be displayed. Build the model first (e.g., by calling it on some test data).`);sv(this,e,t,n)}compile(e){if(e.loss??=[],this.loss=e.loss,typeof e.optimizer==`string`)this.optimizer_=rv(e.optimizer),this.isOptimizerOwned=!0;else{if(!(e.optimizer instanceof Yc))throw new W(`User-defined optimizer must be an instance of tf.Optimizer.`);this.optimizer_=e.optimizer,this.isOptimizerOwned=!1}let t=[];if(!Array.isArray(e.loss)&&typeof e.loss!=`string`&&typeof e.loss!=`function`){e.loss=e.loss;for(let t in e.loss)if(this.outputNames.indexOf(t)===-1)throw new W(`Unknown entry in loss dictionary: "${t}". Only expected the following keys: ${this.outputNames}`);for(let n of this.outputNames)e.loss[n]??console.warn(`Output "${n}" is missing from loss dictionary. We assume this was done on purpose, and we will not be expecting data to be passed to ${n} during training`),t.push(P_(e.loss[n]))}else if(Array.isArray(e.loss)){if(e.loss.length!==this.outputs.length)throw new W(`When passing an Array as loss, it should have one entry per model output. The model has ${this.outputs.length} output(s), but you passed loss=${e.loss}.`);t=e.loss.map(e=>P_(e))}else{let n=P_(e.loss);this.outputs.forEach(e=>{t.push(n)})}this.lossFunctions=t,this.feedOutputNames=[],this.feedOutputShapes=[],this.feedLossFns=[];for(let e=0;e<this.outputs.length;++e){let t=this.internalOutputShapes[e],n=this.outputNames[e];this.feedOutputNames.push(n),this.feedOutputShapes.push(t),this.feedLossFns.push(this.lossFunctions[e])}let n=[];this.metrics=e.metrics,this.metricsNames=[`loss`],this.metricsTensors=[],Gm(`loss`,()=>{for(let e=0;e<this.outputs.length;++e){if(n.indexOf(e)!==-1)continue;let t=this.lossFunctions[e];this.outputs.length>1&&(this.metricsTensors.push([t,e]),this.metricsNames.push(this.outputNames[e]+`_loss`))}});let r=Gv(e.metrics,this.outputNames),i=(e,t,n)=>{this.outputNames.length>1&&(t=this.outputNames[e]+`_`+t),this.metricsNames.push(t),this.metricsTensors.push([n,e])};Gm(`metric`,()=>{for(let e=0;e<this.outputs.length;++e)n.indexOf(e)===-1&&(t=>{let n,r,a;for(let o of t){if(typeof o==`string`&&[`accuracy`,`acc`,`crossentropy`,`ce`].indexOf(o)!==-1){let t=this.internalOutputShapes[e];t[t.length-1]===1||this.lossFunctions[e]===k_?[`accuracy`,`acc`].indexOf(o)===-1?[`crossentropy`,`ce`].indexOf(o)!==-1&&(r=H_):r=F_:this.lossFunctions[e]===D_?[`accuracy`,`acc`].indexOf(o)===-1?[`crossentropy`,`ce`].indexOf(o)!==-1&&(r=$_):r=U_:[`accuracy`,`acc`].indexOf(o)===-1?[`crossentropy`,`ce`].indexOf(o)!==-1&&(r=Z_):r=I_;let i;[`accuracy`,`acc`].indexOf(o)===-1?[`crossentropy`,`ce`].indexOf(o)!==-1&&(i=`ce`):i=`acc`,a=r,n=``+i}else a=tv(o),n=``+nv(o);let t;Gm(n,()=>{t=a}),i(e,n,t)}})(r[e])}),this.collectedTrainableWeights=this.trainableWeights}checkTrainableWeightsConsistency(){this.collectedTrainableWeights!=null&&this.trainableWeights.length!==this.collectedTrainableWeights.length&&console.warn("Discrepancy between trainableweights and collected trainable weights. Did you set `model.trainable` without calling `model.compile()` afterwards?")}evaluate(e,t,n={}){let r=n.batchSize==null?32:n.batchSize;Mv(r);let i=this.standardizeUserDataXY(e,t,!0,r);try{let e=i[0].concat(i[1]);this.makeTestFunction();let t=this.testFunction;return dm(this.testLoop(t,e,r,n.verbose,n.steps))}finally{Lv(i[0],e),Lv(i[1],t)}}async evaluateDataset(e,t){return this.makeTestFunction(),jv(this,e,t)}checkNumSamples(e,t,n,r=`steps`){let i;if(n!=null){if(i=null,t!=null)throw new W(`If ${r} is set, batchSize must be null or undefined.Got batchSize = ${t}`)}else if(e!=null)i=Array.isArray(e)?e[0].shape[0]:e.shape[0];else throw new W(`Either the input data should have a defined shape, or ${r} shoud be specified.`);return i}execute(e,t){if(Array.isArray(t)&&t.length===0)throw new W("`outputs` is an empty Array, which is not allowed.");let n=Array.isArray(t),r=n?t:[t],i=this.retrieveSymbolicTensors(r),a=new yg;if(e instanceof wc&&(e=[e]),Array.isArray(e)){if(e.length!==this.inputs.length)throw new W(`The number of inputs provided (${e.length}) does not match the number of inputs of this model (${this.inputs.length}).`);for(let t=0;t<this.inputs.length;++t)a.add(this.inputs[t],e[t])}else for(let t of this.inputs){let n=e[t.name];if(n==null)throw new W(`No value is provided for the model's input ${t.name}`);a.add(t,n)}let o=Cg(i,a);return n?o:o[0]}retrieveSymbolicTensors(e){let t=cm(null,e.length),n=e.length;for(let r of this.layers){let i=Array.isArray(r.output)?r.output:[r.output],a=i.map(e=>e.name);for(let r=0;r<e.length;++r){let o=a.indexOf(e[r]);if(o!==-1&&(t[r]=i[o],n--),n===0)break}if(n===0)break}if(n>0){let n=[];throw t.forEach((t,r)=>{t??n.push(e[r])}),new W(`Cannot find SymbolicTensors for output name(s): ${JSON.stringify(n)}`)}return t}predictLoop(e,t=32,n=!1){return A(()=>{let r=this.checkNumSamples(e);if(n)throw new G(`Verbose predictLoop() is not implemented yet.`);let i=Fv(r,t),a=this.outputs.map(e=>[]);for(let t=0;t<i.length;++t)A(()=>{let n=i[t][0],r=i[t][1],a=Nv(e,n,r),o=[];if(Array.isArray(a))for(let e=0;e<a.length;++e)o.push({key:this.inputs[e],value:a[e]});else o.push({key:this.inputs[0],value:a});let s=new yg(o);return Cg(this.outputs,s)}).forEach((e,t)=>a[t].push(e));return dm(a.map(e=>_t(e,0)))})}predict(e,t={}){let n=Iv(e);Wv(n,this.inputNames,this.feedInputShapes,!1);try{let e=t.batchSize==null?32:t.batchSize;return Mv(e),this.predictLoop(n,e)}finally{Lv(n,e)}}predictOnBatch(e){Wv(e,this.inputNames,this.feedInputShapes,!0);let t=(Array.isArray(e)?e[0]:e).shape[0];return this.predictLoop(e,t)}standardizeUserDataXY(e,t,n=!0,r){if(this.optimizer_==null)throw new am(`You must compile a model before training/testing. Use LayersModel.compile(modelCompileArgs).`);let i=[];for(let e=0;e<this.feedOutputShapes.length;++e){let t=this.feedOutputShapes[e];this.feedLossFns[e]===D_?i.push(t.slice(0,t.length-1).concat([1])):i.push(t)}if(e=Vv(e,this.feedInputNames,this.feedInputShapes,!1,`input`),t=Vv(t,this.feedOutputNames,i,!1,`target`),Hv(e,t,null),Uv(t,this.feedLossFns,this.feedOutputShapes),this.stateful&&r!=null&&r>0&&e[0].shape[0]%r!==0)throw new W(`In a stateful network, you should only pass inputs with a number of samples that is divisible by the batch size ${r}. Found: ${e[0].shape[0]} sample(s).`);return[e,t]}async standardizeUserData(e,t,n,r,i=!0,a){let[o,s]=this.standardizeUserDataXY(e,t,i,a);if(n!=null)throw Error(`sample weight is not supported yet.`);let c=null;if(r!=null){let e=bv(r,this.outputNames);c=[];for(let t=0;t<e.length;++t)c.push(await xv(s[t],null,e[t]))}return[o,s,c]}testLoop(e,t,n,r=0,i){return A(()=>{let a=this.checkNumSamples(t,n,i,`steps`),o=[];if(r>0)throw new G(`Verbose mode is not implemented yet.`);if(i!=null)throw new G(`steps mode in testLoop() is not implemented yet`);{let r=Fv(a,n),i=Tl(th(0,a));for(let n=0;n<r.length;++n){let a=r[n][0],s=r[n][1],c=e(Pv(t,uh(i,a,s-a)));if(n===0)for(let e=0;e<c.length;++e)o.push(kn(0));for(let e=0;e<c.length;++e){let t=c[e];o[e]=I(o[e],z(s-a,t))}}for(let e=0;e<o.length;++e)o[e]=N(o[e],a)}return o})}getDedupedMetricsNames(){let e=this.metricsNames,t=[];for(let n=0;n<e.length;++n){let r=e[n],i=r;if(um(e,r)>1){let t=um(e.slice(0,n),r);i+=`_${t}`}t.push(i)}return t}makeTrainFunction(){return e=>{let t=[],n=e.slice(0,this.inputs.length),r=e.slice(this.inputs.length,this.inputs.length+this.outputs.length),i=e.slice(this.inputs.length+this.outputs.length,this.inputs.length+this.outputs.length*2),a=[],o=()=>{let e=[];for(let t=0;t<this.inputs.length;++t)e.push({key:this.inputs[t],value:n[t]});let o=new yg(e),s=Cg(this.outputs,o,{training:!0}),c;for(let e=0;e<this.lossFunctions.length;++e){let n=this.lossFunctions[e],a=n(r[e],s[e]);i[e]!=null&&(a=Sv(a,i[e]));let o=Rn(a);t.push(o),c=e===0?a:I(c,a)}for(let e=0;e<this.metricsTensors.length;++e){let n;if(this.outputs.length>1&&e<this.outputs.length)n=t[e];else{let t=this.metricsTensors[e][0],i=this.metricsTensors[e][1];n=Rn(t(r[i],s[i]))}ze(n),a.push(n)}return c=Rn(c),this.calculateLosses().forEach(e=>{c=I(c,e)}),c},s=this.collectedTrainableWeights.map(e=>e.read());return[this.optimizer_.minimize(o,!0,s)].concat(a)}}makeTestFunction(){this.testFunction=e=>A(()=>{let t=[],n,r=e.slice(0,this.inputs.length),i=e.slice(this.inputs.length,this.inputs.length+this.outputs.length),a=[];for(let e=0;e<this.inputs.length;++e)a.push({key:this.inputs[e],value:r[e]});let o=new yg(a),s=Cg(this.outputs,o);for(let e=0;e<this.lossFunctions.length;++e){let r=this.lossFunctions[e],a=Rn(r(i[e],s[e]));n=e===0?a:I(n,a),t.push(n)}for(let e=0;e<this.metricsTensors.length;++e){let n=this.metricsTensors[e][0],r=this.metricsTensors[e][1],a=Rn(n(i[r],s[r]));t.push(a)}return t})}async fit(e,t,n={}){if(this.isTraining)throw Error(`Cannot start training because another fit() call is ongoing.`);this.isTraining=!0;let r,i,a,o,s,c,l,u,d;try{let f=n.batchSize==null?32:n.batchSize;Mv(f);let p=await this.standardizeUserData(e,t,n.sampleWeight,n.classWeight,!1,f);r=p[0],i=p[1],d=p[2];let m=!1,h;if(n.validationData!=null&&n.validationData.length>0){if(m=!0,n.validationData.length===2)s=n.validationData[0],c=n.validationData[1];else if(n.validationData.length===3)throw new G(`validationData including sample weights is not supported yet.`);else throw new W(`When passing validation data, it must contain 2 (valX, valY) or 3 (valX, valY, valSampleWeight) items; ${n.validationData} is invalid.`);let e=await this.standardizeUserData(s,c,null,null,!0,f);l=e[0],u=e[1],h=l.concat(u)}else if(n.validationSplit!=null&&n.validationSplit>0&&n.validationSplit<1){m=!0;let e=Math.floor(r[0].shape[0]*(1-n.validationSplit)),t=r[0].shape[0];l=Nv(r,e,t),a=r,r=Nv(r,0,e),u=Nv(i,e,t),o=i,i=Nv(i,0,e),h=l.concat(u)}else n.validationSteps!=null&&(m=!0);let g=r.concat(i).concat(d);this.checkTrainableWeightsConsistency();let _=this.makeTrainFunction(),v=this.getDedupedMetricsNames(),y,b;m?(this.makeTestFunction(),y=this.testFunction,b=v.slice().concat(v.map(e=>`val_`+e))):(y=null,h=[],b=v.slice());let x=p_(n.callbacks,n.yieldEvery);return await this.fitLoop(_,g,v,f,n.epochs,n.verbose,x,y,h,n.shuffle,b,n.initialEpoch,null,null)}finally{this.isTraining=!1,Lv(r,e),Lv(i,t),Lv(a,e),Lv(o,t),Lv(l,s),Lv(u,c),d!=null&&D(d)}}async fitLoop(e,t,n,r,i,a,o,s,c,l,u,d,f,p){r??=32,i??=1,l??=!0,d??=0;let m=!1;if(s!=null&&c!=null&&(m=!0),p!=null&&(m=!0,f==null))throw new W("Can only use `validationSteps` when doing step-wise training, i.e., `stepsPerEpoch` must be set.");let h=this.checkNumSamples(t,r,f,`steps_per_epoch`),g;h!=null&&(g=th(0,h)),a??=1;let{callbackList:_,history:v}=h_(o,a,i,d,h,f,r,m,u);_.setModel(this),this.history=v,await _.onTrainBegin(),this.stopTraining_=!1;for(let a=d;a<i;++a){await _.onEpochBegin(a);let i={};if(f!=null)throw new G(`stepsPerEpoch mode is not implemented yet.`);{if(l===`batch`)throw new G(`batch shuffling is not implemneted yet`);l&&gl(g);let a=Tl(g),o=Fv(h,r);for(let l=0;l<o.length;++l){let u={};if(await _.onBatchBegin(l,u),A(()=>{let d=o[l][0],f=o[l][1],p=uh(a,d,f-d);u.batch=l,u.size=f-d;let h=e(Pv(t,p));for(let e=0;e<n.length;++e){let t=n[e],r=h[e];u[t]=r,ze(r)}if(l===o.length-1&&m){let e=this.testLoop(s,c,r);for(let t=0;t<n.length;++t){let r=n[t],a=e[t];ze(a),i[`val_`+r]=a}}}),await _.onBatchEnd(l,u),o_(u),this.stopTraining_)break}a.dispose()}if(await _.onEpochEnd(a,i),this.stopTraining_)break}return await _.onTrainEnd(),await this.history.syncData(),this.history}async fitDataset(e,t){return Dv(this,e,t)}async trainOnBatch(e,t){let n=await this.standardizeUserData(e,t),r=n[0],i=n[1],a=this.makeTrainFunction()(r.concat(i)),o=[];for(let e of a){let t=await e.data();o.push(t[0])}return D(a),Lv(n[0],e),Lv(n[1],t),dm(o)}getNamedWeights(e){let t=[],n=e!=null&&e.trainableOnly,r=n?this.trainableWeights:this.weights,i=this.getWeights(n);for(let e=0;e<r.length;++e)n&&!r[e].trainable||t.push({name:r[e].originalName,tensor:i[e]});return t}set stopTraining(e){this.stopTraining_=e}get stopTraining(){return this.stopTraining_}get optimizer(){return this.optimizer_}set optimizer(e){this.optimizer_!==e&&(this.optimizer_=e,this.isOptimizerOwned=!1)}dispose(){let e=super.dispose();if(e.refCountAfterDispose===0&&this.optimizer!=null&&this.isOptimizerOwned){let t=ht().numTensors;this.optimizer_.dispose(),e.numDisposedVariables+=t-ht().numTensors}return e}getLossIdentifiers(){let e;if(typeof this.loss==`string`)e=pm(this.loss);else if(Array.isArray(this.loss)){for(let e of this.loss)if(typeof e!=`string`)throw Error(`Serialization of non-string loss is not supported.`);e=this.loss.map(e=>pm(e))}else{let t=Object.keys(this.loss);e={};let n=this.loss;for(let r of t)if(typeof n[r]==`string`)e[r]=pm(n[r]);else throw Error(`Serialization of non-string loss is not supported.`)}return e}getMetricIdentifiers(){if(typeof this.metrics==`string`||typeof this.metrics==`function`)return[pm(nv(this.metrics))];if(Array.isArray(this.metrics))return this.metrics.map(e=>pm(nv(e)));{let e={};for(let t in this.metrics)e[t]=pm(nv(this.metrics[t]));return e}}getTrainingConfig(){return{loss:this.getLossIdentifiers(),metrics:this.getMetricIdentifiers(),optimizer_config:{class_name:this.optimizer.getClassName(),config:this.optimizer.getConfig()}}}loadTrainingConfig(e){if(e.weighted_metrics!=null)throw Error(`Loading weight_metrics is not supported yet.`);if(e.loss_weights!=null)throw Error(`Loading loss_weights is not supported yet.`);if(e.sample_weight_mode!=null)throw Error(`Loading sample_weight_mode is not supported yet.`);let t=g_(mv(e.optimizer_config)),n;if(typeof e.loss==`string`)n=mm(e.loss);else if(Array.isArray(e.loss))n=e.loss.map(e=>mm(e));else if(e.loss!=null){n={};for(let t in e.loss)n[t]=mm(e.loss[t])}let r;if(Array.isArray(e.metrics))r=e.metrics.map(e=>mm(e));else if(e.metrics!=null){r={};for(let t in e.metrics)r[t]=mm(e.metrics[t])}this.compile({loss:n,metrics:r,optimizer:t})}async save(e,t){if(typeof e==`string`){let t=ta(e);if(t.length===0)throw new W(`Cannot find any save handlers for URL '${e}'`);if(t.length>1)throw new W(`Found more than one (${t.length}) save handlers for URL '${e}'`);e=t[0]}if(e.save==null)throw new W("LayersModel.save() cannot proceed because the IOHandler provided does not have the `save` attribute defined.");let n=await se(this.getNamedWeights(t)),r={modelTopology:this.toJSON(null,!1),format:Kv,generatedBy:`TensorFlow.js tfjs-layers v${gv}`,convertedBy:null};if(t!=null&&t.includeOptimizer&&this.optimizer!=null){r.trainingConfig=this.getTrainingConfig();let{data:e,specs:t}=await se(await this.optimizer.getWeights(),`optimizer`);n.specs.push(...t),n.data=_l([n.data,e])}return this.userDefinedMetadata!=null&&(av(this.userDefinedMetadata,this.name,!0),r.userDefinedMetadata=this.userDefinedMetadata),r.weightData=n.data,r.weightSpecs=n.specs,e.save(r)}setUserDefinedMetadata(e){av(e,this.name),this.userDefinedMetadata=e}getUserDefinedMetadata(){return this.userDefinedMetadata}};qv.className=`Model`,V(qv);var Jv=class extends qv{};Jv.className=`Functional`,V(Jv);async function Yv(e,t){`modelTopology`in e||(e={modelTopology:e}),e=e;let n=e.modelTopology;n.model_config!=null&&(n=n.model_config);let r=g_(mv(n),t);if(e.weightsManifest!=null){let t=await Bc(e.weightsManifest,e.pathPrefix,r.weights.map(e=>e.originalName)),n={};for(let e of r.weights)n[e.originalName]=t[e.originalName];r.loadWeights(n),D(t)}return r}async function Xv(e,t){if(t??={},typeof e==`string`){let n=Dl(e,t);if(n.length===0)n.push($o(e,t));else if(n.length>1)throw new W(`Found more than one (${n.length}) load handlers for URL '${e}'`);e=n[0]}return Zv(e,void 0,t)}async function Zv(e,t,n){if(n??={},e.load==null)throw new W("Cannot proceed with model loading because the IOHandler provided does not have the `load` method implemented.");let r=await e.load(),i=r.modelTopology;i.model_config!=null&&(i=i.model_config);let a=n.strict==null||n.strict,o=r.weightData!=null&&r.weightSpecs!=null&&a,s=g_(mv(i),t,o),c=r.trainingConfig;if(c!=null&&s.loadTrainingConfig(c),r.userDefinedMetadata!=null&&s.setUserDefinedMetadata(r.userDefinedMetadata),r.weightData!=null){if(r.weightSpecs==null)throw new W(`LayersModel artifacts contains weight data, but not weight specs. Therefore loading of weights cannot proceed.`);let{modelWeights:e,optimizerWeights:t}=Qv(r.weightData,r.weightSpecs);s.loadWeights(e,a),s.optimizer!=null&&t.length>0&&await s.optimizer.setWeights(t),D(e),D(t.map(e=>e.tensor))}return s}function Qv(e,t){let n=ur(e,t),r={},i=[];return t.forEach(e=>{e.group===`optimizer`?i.push({name:e.name,tensor:n[e.name]}):r[e.name]=n[e.name]}),{modelWeights:r,optimizerWeights:i}}var $v=class e extends qv{constructor(e){if(super({inputs:[],outputs:[]}),e||={},this.trainable=!0,this.built=!1,this.name=e.name==null?Mm(`sequential_`):e.name,e.layers!=null)for(let t of e.layers)this.add(t)}checkShape(e){if(e.inboundNodes[0].outputTensors[0].shape.some(e=>e<0))throw new W(`Negative dimension size caused by adding layer ${e.name} with input shape [${e.inboundNodes[0].inputTensors[0].shape}]`)}add(t){let n=t instanceof e||t instanceof qv,r;if(n){if(r=t,r.outputs.length!==1)throw new W(`All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.`);if(r.inputs.length!==1)throw new W(`All layers in a Sequential model should have a single input tensor. For multi-input layers, use the functional API.`)}if(this.outputs.length===0){if(t.inboundNodes.length===0){if(t.batchInputShape==null)throw new W("The first layer in a Sequential model must get an `inputShape` or `batchInputShape` argument.");let e=_g({batchShape:t.batchInputShape,dtype:t.dtype,name:t.name+`_input`});t.apply(e)}if(n)this.outputs=r.outputs,this.inputs=r.inputs;else{if(t.inboundNodes.length!==1)throw new W(`A layer added to a Sequential model must not already be connected somewhere else. LayersModel received layer ${t.name} which has ${t.inboundNodes.length} pre-existing inbound connections.`);if(t.inboundNodes[0].outputTensors.length!==1)throw new W(`All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.`);this.checkShape(t),this.outputs=[t.inboundNodes[0].outputTensors[0]],this.inputs=pg(this.outputs[0])}this.inboundNodes=[],new lg({outboundLayer:this,inboundLayers:[],nodeIndices:[],tensorIndices:[],inputTensors:this.inputs,outputTensors:this.outputs,inputMasks:cm(null,this.inputs.length),outputMasks:[null],inputShapes:this.inputs.map(e=>e.shape),outputShapes:this.outputs[0].shape})}else{let e=t.apply(this.outputs[0]);if(Array.isArray(e))throw TypeError(`All layers in a Sequential model should have a single output tensor. For multi-output layers, use the functional API.`);this.checkShape(t),this.outputs=[e],this.inboundNodes[0].outputTensors=this.outputs,this.inboundNodes[0].outputShapes=[this.outputs[0].shape]}this.layers.push(t),this.built=!1}pop(){if(this.layers.length===0)throw TypeError(`There are no layers in the model.`);if(this.layers.pop(),this.layers.length===0)this.outputs=[],this.inboundNodes=[],this.outboundNodes=[];else{let e=this.layers.length-1;this.layers[e].outboundNodes=[],this.outputs=[this.layers[e].output],this.inboundNodes[0].outputTensors=this.outputs,this.inboundNodes[0].outputShapes=[this.outputs[0].shape]}}call(e,t){return this.model??this.build(),this.model.call(e,t)}build(e){if(q(e),this.inputs.length===0||this.outputs.length===0)throw TypeError(`Sequential model cannot be built: model is empty. Add some layers first.`);this.model=new qv({inputs:this.inputs,outputs:this.outputs[0],name:this.name+`_model`}),this.model.trainable=this.trainable,this.supportsMasking=this.model.supportsMasking,this.inputLayers=this.model.inputLayers,this.inputLayersNodeIndices=this.model.inputLayersNodeIndices,this.inputLayersTensorIndices=this.model.inputLayersTensorIndices,this.outputLayers=this.model.outputLayers,this.outputLayersNodeIndices=this.model.outputLayersNodeIndices,this.outputLayersTensorIndices=this.model.outputLayersTensorIndices,this.nodesByDepth=this.model.nodesByDepth,this.containerNodes=this.model.containerNodes,this.outputNames=this.model.outputNames,this.inputNames=this.model.inputNames,this.built=!0}countParams(){return this.built||this.build(),super.countParams()}summary(e,t,n=console.log){this.built||this.build(),super.summary(e,t,n)}setWeights(e){this.model??this.build(),this.model.setWeights(e)}evaluate(e,t,n={}){if(!this.built)throw new am(`The model needs to be compiled before being used.`);return this.model.evaluate(e,t,n)}async evaluateDataset(e,t){if(!this.built)throw new am(`The model needs to be compiled before being used.`);return this.model.evaluateDataset(e,t)}predict(e,t={}){return this.model??this.build(),this.model.predict(e,t)}predictOnBatch(e){return this.model??this.build(),this.model.predictOnBatch(e)}compile(e){this.build(),this.model.compile(e),this.optimizer_=this.model.optimizer,this.isOptimizerOwned=this.model.isOptimizerOwned,this.loss=this.model.loss,this.metrics=this.model.metrics,this.metricsTensors=this.model.metricsTensors,this.metricsNames=this.model.metricsNames}get optimizer(){return this.model==null?void 0:this.model.optimizer}set optimizer(e){this.model.optimizer=e}async fit(e,t,n={}){if(!this.built)throw new am(`The model needs to be compiled before being used.`);return this.model.fit(e,t,n)}async fitDataset(e,t){if(!this.built)throw new am(`The model needs to be compiled before being used.`);return this.model.fitDataset(e,t)}async trainOnBatch(e,t){return this.model.trainOnBatch(e,t)}static fromConfig(t,n,r={},i=!1){let a,s={};if(n instanceof Array){if(n[0].className==null||n[0].className===`Merge`)throw new W(`Legacy serialization format not supported yet.`);a=n}else o(n.layers!=null,()=>`When the config data for a Sequential model is not an Array, it must be an Object that contains the 'layers' field.`),a=n.layers,delete n.layers,s=n;let c=new t(s);if(!(c instanceof e))throw new G(`Sequential.fromConfig called on non-Sequential input: ${c}`);for(let e of a){let t=g_(e,void 0,i);i&&t.setFastWeightInitDuringBuild(!0),c.add(t)}return c}set stopTraining(e){if(this.model==null)throw new W(`Cannot set the stopTraining property of a sequential model before it is compiled.`);this.model.stopTraining=e}get stopTraining(){if(this.model==null)throw new W(`Cannot get the stopTraining property of a sequential model before it is compiled.`);return this.model.stopTraining}getConfig(){let e=[];for(let t of this.layers){let n={};n.className=t.getClassName(),n.config=t.getConfig(),e.push(n)}return{name:this.name,layers:e}}};$v.className=`Sequential`,V($v);function ey(e){return new qv(e)}function ty(e){return new $v(e)}function ny(e){return _g(e)}function ry(e,t){m_.registerCallbackConstructor(e,t)}var iy=class extends El{getConfig(){return{}}},ay=class extends iy{apply(e,t=1){return Sh(e,t)}};ay.className=`elu`,V(ay);var oy=class extends iy{apply(e){return Lr(e)}};oy.className=`selu`,V(oy);var sy=class extends iy{apply(e){return Qn(e)}};sy.className=`relu`,V(sy);var cy=class extends iy{apply(e){return A(()=>_(6,Qn(e)))}};cy.className=`relu6`,V(cy);var ly=class extends iy{apply(e){return e}};ly.className=`linear`,V(ly);var uy=class extends iy{apply(e){return In(e)}};uy.className=`sigmoid`,V(uy);var dy=class extends iy{apply(e){return Th(e)}};dy.className=`hardSigmoid`,V(dy);var fy=class extends iy{apply(e){return yi(e)}};fy.className=`softplus`,V(fy);var py=class extends iy{apply(e){return Ch(e)}};py.className=`softsign`,V(py);var my=class extends iy{apply(e){return rn(e)}};my.className=`tanh`,V(my);var hy=class extends iy{apply(e,t=-1){return xn(e,t)}};hy.className=`softmax`,V(hy);var gy=class extends iy{apply(e,t=-1){return zt(e,t)}};gy.className=`logSoftmax`,V(gy);var _y=class extends iy{apply(e){return A(()=>A(()=>z(e,z(.5,I(1,re(N(e,Math.sqrt(2))))))))}};_y.className=`gelu`,V(_y);var vy=class extends iy{apply(e){return A(()=>z(.5,z(e,I(1,rn(z(Ce(N(2,Math.PI)),I(e,z(.044715,Yo(e,3)))))))))}};vy.className=`gelu_new`,V(vy);var yy=class extends iy{apply(e){return A(()=>z(e,rn(yi(e))))}};yy.className=`mish`,V(yy);var by=class extends iy{apply(e,t=1){return A(()=>z(In(z(e,t)),e))}};by.className=`swish`,V(by);function xy(e){return e.getClassName()}function Sy(e,t={}){return vm(e,ea.getMap().classNameMap,t,`activation`)}function Cy(e){if(e==null){let e={};return e.className=`linear`,e.config={},Sy(e)}if(typeof e==`string`){let t={};return t.className=e,t.config={},Sy(t)}else if(e instanceof iy)return e;else return Sy(e)}function wy(e){if(e!=null&&typeof e!=`object`)throw Error(`Argument to L1L2 regularizer's constructor is expected to be an object, but received: ${e}`)}var Ty=class extends El{},Ey=class extends Ty{constructor(e){super(),wy(e),this.l1=e==null||e.l1==null?.01:e.l1,this.l2=e==null||e.l2==null?.01:e.l2,this.hasL1=this.l1!==0,this.hasL2=this.l2!==0}apply(e){return A(()=>{let t=_n([1]);return this.hasL1&&(t=I(t,O(z(this.l1,es(e))))),this.hasL2&&(t=I(t,O(z(this.l2,yh(e))))),U(t,[])})}getConfig(){return{l1:this.l1,l2:this.l2}}static fromConfig(e,t){return new e({l1:t.l1,l2:t.l2})}};Ey.className=`L1L2`,V(Ey);function Dy(e){return wy(e),new Ey({l1:e==null?null:e.l1,l2:0})}function Oy(e){return wy(e),new Ey({l2:e==null?null:e.l2,l1:0})}var ky={l1l2:`L1L2`};function Ay(e){return gm(e)}function jy(e,t={}){return vm(e,ea.getMap().classNameMap,t,`regularizer`)}function My(e){return e==null?null:typeof e==`string`?jy({className:e in ky?ky[e]:e,config:{}}):e instanceof Ty?e:jy(e)}var Ny=class extends J{constructor(e){super(e??{}),this.supportsMasking=!0,e!=null&&(this.maxValue=e.maxValue)}call(e,t){e=K(e);let n=Qn(e);return this.maxValue!=null&&(n=kl(n,0,this.maxValue)),n}computeOutputShape(e){return e}getConfig(){let e={maxValue:this.maxValue},t=super.getConfig();return Object.assign(e,t),e}};Ny.className=`ReLU`,V(Ny);var Py=class extends J{constructor(e){super(e??{}),this.DEFAULT_ALPHA=.3,e??={},this.alpha=e.alpha==null?this.DEFAULT_ALPHA:e.alpha}call(e,t){return os(K(e),this.alpha)}computeOutputShape(e){return e}getConfig(){let e={alpha:this.alpha},t=super.getConfig();return Object.assign(e,t),e}};Py.className=`LeakyReLU`,V(Py);var Fy=class extends J{constructor(e){if(super(e??{}),this.DEFAULT_ALPHA_INITIALIZER=`zeros`,e??={},this.supportsMasking=!0,this.alphaInitializer=Zh(e.alphaInitializer||this.DEFAULT_ALPHA_INITIALIZER),this.alphaRegularizer=My(e.alphaRegularizer),this.alphaConstraint=Lg(e.alphaConstraint),e.sharedAxes==null)this.sharedAxes=null;else if(Array.isArray(e.sharedAxes))this.sharedAxes=e.sharedAxes;else if(typeof e.sharedAxes==`number`)this.sharedAxes=[e.sharedAxes];else throw new W(`Expected sharedAxes to be a number or an array of numbers, but got ${e.sharedAxes}`)}build(e){e=q(e);let t=e.slice(1);if(this.sharedAxes!=null)for(let e of this.sharedAxes)t[e-1]=1;this.alpha=this.addWeight(`alpha`,t,`float32`,this.alphaInitializer,this.alphaRegularizer,!0,this.alphaConstraint);let n={};if(this.sharedAxes!=null)for(let t=1;t<e.length;++t)n[t]=e[t];this.inputSpec=[new og({ndim:e.length,axes:n})],this.built=!0}call(e,t){return e=K(e),qs(e,this.alpha.read())}getConfig(){let e={alphaInitializer:Xh(this.alphaInitializer),alphaRegularizer:Ay(this.alphaRegularizer),alphaConstraint:Fg(this.alphaConstraint),sharedAxes:this.sharedAxes},t=super.getConfig();return Object.assign(e,t),e}};Fy.className=`PReLU`,V(Fy);var Iy=class extends J{constructor(e){if(super(e??{}),this.DEFAULT_ALPHA=1,e??={},e.alpha!=null&&e.alpha!==this.DEFAULT_ALPHA)throw new G(`Non-default alpha value (${e.alpha}) is not supported by the ELU layer yet.`);this.alpha=e.alpha==null?this.DEFAULT_ALPHA:e.alpha}call(e,t){return dt(K(e))}computeOutputShape(e){return e}getConfig(){let e={alpha:this.alpha},t=super.getConfig();return Object.assign(e,t),e}};Iy.className=`ELU`,V(Iy);var Ly=class extends J{constructor(e){super(e??{}),this.DEFAULT_THETA=1,e??={},this.theta=e.theta==null?this.DEFAULT_THETA:e.theta}call(e,t){let n=K(e);return z(n,F(go(n,this.theta),`float32`))}computeOutputShape(e){return e}getConfig(){let e={theta:this.theta},t=super.getConfig();return Object.assign(e,t),e}};Ly.className=`ThresholdedReLU`,V(Ly);var Ry=class extends J{constructor(e){super(e??{}),this.DEFAULT_AXIS=1,e??={},this.softmax=new hy().apply,this.axis=e.axis==null?this.DEFAULT_AXIS:e.axis}call(e,t){return A(()=>{let n=K(e),r=t.mask;if(r!=null){let e=z(L(on(n.shape),F(r,n.dtype)),kn(-1e9));n=I(n,e)}return this.axis instanceof Array?this.axis.length>1?gr(L(n,$e(n,this.axis,!0))):this.softmax(n,this.axis[0]):this.softmax(n,this.axis)})}computeOutputShape(e){return e}getConfig(){let e={axis:this.axis},t=super.getConfig();return Object.assign(e,t),e}};Ry.className=`Softmax`,V(Ry);function zy(e,t,n){if(typeof e==`number`)return cm(e,t);if(e.length!==t)throw new W(`The ${n} argument must be an integer or tuple of ${t} integers. Received: ${e.length} elements.`);for(let r=0;r<t;++r){let i=e[r];if(!Zm(i))throw new W(`The ${n} argument must be an integer or tuple of ${t} integers. Received: ${JSON.stringify(e)} including a non-integer number ${i}`)}return e}function By(e,t,n,r,i=1){if(e==null)return e;let a=t+(t-1)*(i-1),o;return o=n===`same`?e:e-a+1,Math.floor((o+r-1)/r)}function Vy(e,t,n,r){if(e==null)return null;if(r===`valid`)e=e*t+eh([n-t,0]);else if(r===`same`)e*=t;else throw new W(`Unsupport padding mode: ${r}.`);return e}function Hy(e,t){return A(()=>(zm(t),t===`channelsFirst`?P(e,[0,2,3,1]):e))}function Uy(e,t){return A(()=>(zm(t),t===`channelsFirst`?P(e,[0,2,3,4,1]):e))}function Wy(e,t,n,r=1,i=`valid`,a,o=1){return A(()=>{if(a??=ih(),zm(a),e.shape.length!==3)throw new W(`The input of a conv1dWithBias operation should be 3, but is ${e.shape.length} instead.`);if(t.shape.length!==3)throw new W(`The kernel for a conv1dWithBias operation should be 3, but is ${t.shape.length} instead`);if(n!=null&&n.shape.length!==1)throw new W(`The bias for a conv1dWithBias operation should be 1, but is ${n.shape.length} instead`);if(a===`channelsFirst`&&(e=P(e,[0,2,1])),i===`causal`)throw new G(`The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.`);let s=Gs(e,t,r,i===`same`?`same`:`valid`,`NWC`,o);return n!=null&&(s=xh(s,n)),s})}function Gy(e,t,n,r=[1,1],i=`valid`,a,o,s=null){return A(()=>{if(a??=ih(),zm(a),e.rank!==3&&e.rank!==4)throw new W(`conv2dWithBiasActivation expects input to be of rank 3 or 4, but received ${e.rank}.`);if(t.rank!==3&&t.rank!==4)throw new W(`conv2dWithBiasActivation expects kernel to be of rank 3 or 4, but received ${e.rank}.`);let c=Hy(e,a);if(i===`causal`)throw new G(`The support for CAUSAL padding mode in conv1dWithBias is not implemented yet.`);return c=C({x:c,filter:t,strides:r,pad:i===`same`?`same`:`valid`,dilations:o,dataFormat:`NHWC`,bias:n,activation:s}),a===`channelsFirst`&&(c=P(c,[0,3,1,2])),c})}function Ky(e,t,n,r=[1,1,1],i=`valid`,a,o){return A(()=>{if(a??=ih(),zm(a),e.rank!==4&&e.rank!==5)throw new W(`conv3dWithBias expects input to be of rank 4 or 5, but received ${e.rank}.`);if(t.rank!==4&&t.rank!==5)throw new W(`conv3dWithBias expects kernel to be of rank 4 or 5, but received ${e.rank}.`);let s=Uy(e,a);if(i===`causal`)throw new G(`The support for CAUSAL padding mode in conv3dWithBias is not implemented yet.`);return s=Hc(s,t,r,i===`same`?`same`:`valid`,`NDHWC`,o),n!=null&&(s=xh(s,n)),a===`channelsFirst`&&(s=P(s,[0,4,1,2,3])),s})}var qy=class e extends J{constructor(t,n){if(super(n),this.bias=null,this.DEFAULT_KERNEL_INITIALIZER=`glorotNormal`,this.DEFAULT_BIAS_INITIALIZER=`zeros`,e.verifyArgs(n),this.rank=t,Tm(this.rank,`rank`),this.rank!==1&&this.rank!==2&&this.rank!==3)throw new G(`Convolution layer for rank other than 1, 2, or 3 (${this.rank}) is not implemented yet.`);if(this.kernelSize=zy(n.kernelSize,t,`kernelSize`),this.strides=zy(n.strides==null?1:n.strides,t,`strides`),this.padding=n.padding==null?`valid`:n.padding,Vm(this.padding),this.dataFormat=n.dataFormat==null?`channelsLast`:n.dataFormat,zm(this.dataFormat),this.activation=Cy(n.activation),this.useBias=n.useBias==null||n.useBias,this.biasInitializer=Zh(n.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.biasConstraint=Lg(n.biasConstraint),this.biasRegularizer=My(n.biasRegularizer),this.activityRegularizer=My(n.activityRegularizer),this.dilationRate=zy(n.dilationRate==null?1:n.dilationRate,t,`dilationRate`),this.rank===1&&Array.isArray(this.dilationRate)&&this.dilationRate.length!==1)throw new W(`dilationRate must be a number or an array of a single number for 1D convolution, but received ${JSON.stringify(this.dilationRate)}`);if(this.rank===2){if(typeof this.dilationRate==`number`)this.dilationRate=[this.dilationRate,this.dilationRate];else if(this.dilationRate.length!==2)throw new W(`dilationRate must be a number or array of two numbers for 2D convolution, but received ${JSON.stringify(this.dilationRate)}`)}else if(this.rank===3){if(typeof this.dilationRate==`number`)this.dilationRate=[this.dilationRate,this.dilationRate,this.dilationRate];else if(this.dilationRate.length!==3)throw new W(`dilationRate must be a number or array of three numbers for 3D convolution, but received ${JSON.stringify(this.dilationRate)}`)}}static verifyArgs(e){if(lm(`kernelSize`in e,`required key 'kernelSize' not in config`),typeof e.kernelSize!=`number`&&!wm(e.kernelSize,`number`,1,3))throw new W(`BaseConv expects config.kernelSize to be number or number[] with length 1, 2, or 3, but received ${JSON.stringify(e.kernelSize)}.`)}getConfig(){let e={kernelSize:this.kernelSize,strides:this.strides,padding:this.padding,dataFormat:this.dataFormat,dilationRate:this.dilationRate,activation:xy(this.activation),useBias:this.useBias,biasInitializer:Xh(this.biasInitializer),biasRegularizer:Ay(this.biasRegularizer),activityRegularizer:Ay(this.activityRegularizer),biasConstraint:Fg(this.biasConstraint)},t=super.getConfig();return Object.assign(e,t),e}},Jy=class e extends qy{constructor(t,n){super(t,n),this.kernel=null,e.verifyArgs(n),this.filters=n.filters,Tm(this.filters,`filters`),this.kernelInitializer=Zh(n.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.kernelConstraint=Lg(n.kernelConstraint),this.kernelRegularizer=My(n.kernelRegularizer)}build(e){e=q(e);let t=this.dataFormat===`channelsFirst`?1:e.length-1;if(e[t]==null)throw new W(`The channel dimension of the input should be defined. Found ${e[t]}`);let n=e[t],r=this.kernelSize.concat([n,this.filters]);this.kernel=this.addWeight(`kernel`,r,null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight(`bias`,[this.filters],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[{ndim:this.rank+2,axes:{[t]:n}}],this.built=!0}call(e,t){return A(()=>{e=K(e);let t,n=this.bias==null?null:this.bias.read(),r=Om(this.activation.getClassName());if(r!=null&&this.rank===2)t=Gy(e,this.kernel.read(),n,this.strides,this.padding,this.dataFormat,this.dilationRate,r);else{if(this.rank===1)t=Wy(e,this.kernel.read(),n,this.strides[0],this.padding,this.dataFormat,this.dilationRate[0]);else if(this.rank===2)t=Gy(e,this.kernel.read(),n,this.strides,this.padding,this.dataFormat,this.dilationRate);else if(this.rank===3)t=Ky(e,this.kernel.read(),n,this.strides,this.padding,this.dataFormat,this.dilationRate);else throw new G(`convolutions greater than 3D are not implemented yet.`);this.activation!=null&&(t=this.activation.apply(t))}return t})}computeOutputShape(e){e=q(e);let t=[],n=this.dataFormat===`channelsLast`?e.slice(1,e.length-1):e.slice(2);for(let e=0;e<n.length;++e){let r=By(n[e],this.kernelSize[e],this.padding,this.strides[e],typeof this.dilationRate==`number`?this.dilationRate:this.dilationRate[e]);t.push(r)}let r=[e[0]];return this.dataFormat===`channelsLast`?(r=r.concat(t),r.push(this.filters)):(r.push(this.filters),r=r.concat(t)),r}getConfig(){let e={filters:this.filters,kernelInitializer:Xh(this.kernelInitializer),kernelRegularizer:Ay(this.kernelRegularizer),kernelConstraint:Fg(this.kernelConstraint)},t=super.getConfig();return Object.assign(e,t),e}static verifyArgs(e){if(!(`filters`in e)||typeof e.filters!=`number`||e.filters<1)throw new W(`Convolution layer expected config.filters to be a 'number' > 0 but got ${JSON.stringify(e.filters)}`)}},Yy=class e extends Jy{constructor(t){super(2,t),e.verifyArgs(t)}getConfig(){let e=super.getConfig();return delete e.rank,e}static verifyArgs(e){if(typeof e.kernelSize!=`number`&&!wm(e.kernelSize,`number`,1,2))throw new W(`Conv2D expects config.kernelSize to be number or number[] with length 1 or 2, but received ${JSON.stringify(e.kernelSize)}.`)}};Yy.className=`Conv2D`,V(Yy);var Xy=class e extends Jy{constructor(t){super(3,t),e.verifyArgs(t)}getConfig(){let e=super.getConfig();return delete e.rank,e}static verifyArgs(e){if(typeof e.kernelSize!=`number`&&!(Array.isArray(e.kernelSize)&&(e.kernelSize.length===1||e.kernelSize.length===3)))throw new W(`Conv3D expects config.kernelSize to be number or [number, number, number], but received ${JSON.stringify(e.kernelSize)}.`)}};Xy.className=`Conv3D`,V(Xy);var Zy=class extends Yy{constructor(e){if(super(e),this.inputSpec=[new og({ndim:4})],this.padding!==`same`&&this.padding!==`valid`)throw new W(`Conv2DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)}build(e){if(e=q(e),e.length!==4)throw new W(`Input should have rank 4; Received input shape: `+JSON.stringify(e));let t=this.dataFormat===`channelsFirst`?1:e.length-1;if(e[t]==null)throw new W("The channel dimension of the inputs should be defined. Found `None`.");let n=e[t],r=this.kernelSize.concat([this.filters,n]);this.kernel=this.addWeight(`kernel`,r,`float32`,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight(`bias`,[this.filters],`float32`,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[new og({ndim:4,axes:{[t]:n}})],this.built=!0}call(e,t){return A(()=>{let t=K(e);if(t.shape.length!==4)throw new W(`Conv2DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${t.shape.length}`);let n=t.shape,r=n[0],i,a;this.dataFormat===`channelsFirst`?(i=2,a=3):(i=1,a=2);let o=n[i],s=n[a],c=this.kernelSize[0],l=this.kernelSize[1],u=this.strides[0],d=this.strides[1],f=[r,Vy(o,u,c,this.padding),Vy(s,d,l,this.padding),this.filters];this.dataFormat!==`channelsLast`&&(t=P(t,[0,2,3,1]));let p=wa(t,this.kernel.read(),f,this.strides,this.padding);return this.dataFormat!==`channelsLast`&&(p=P(p,[0,3,1,2])),this.bias!=null&&(p=xh(p,this.bias.read(),this.dataFormat)),this.activation!=null&&(p=this.activation.apply(p)),p})}computeOutputShape(e){e=q(e);let t=e.slice(),n,r,i;this.dataFormat===`channelsFirst`?(n=1,r=2,i=3):(n=3,r=1,i=2);let a=this.kernelSize[0],o=this.kernelSize[1],s=this.strides[0],c=this.strides[1];return t[n]=this.filters,t[r]=Vy(t[r],s,a,this.padding),t[i]=Vy(t[i],c,o,this.padding),t}getConfig(){let e=super.getConfig();return delete e.dilationRate,e}};Zy.className=`Conv2DTranspose`,V(Zy);var Qy=class extends Xy{constructor(e){if(super(e),this.inputSpec=[new og({ndim:5})],this.padding!==`same`&&this.padding!==`valid`)throw new W(`Conv3DTranspose currently supports only padding modes 'same' and 'valid', but received padding mode ${this.padding}`)}build(e){if(e=q(e),e.length!==5)throw new W(`Input should have rank 5; Received input shape: `+JSON.stringify(e));let t=this.dataFormat===`channelsFirst`?1:e.length-1;if(e[t]==null)throw new W("The channel dimension of the inputs should be defined. Found `None`.");let n=e[t],r=this.kernelSize.concat([this.filters,n]);this.kernel=this.addWeight(`kernel`,r,`float32`,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight(`bias`,[this.filters],`float32`,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint)),this.inputSpec=[new og({ndim:5,axes:{[t]:n}})],this.built=!0}call(e,t){return A(()=>{let t=K(e);if(t.shape.length!==5)throw new W(`Conv3DTranspose.call() expects input tensor to be rank-4, but received a tensor of rank-${t.shape.length}`);let n=t.shape,r=n[0],i,a,o;this.dataFormat===`channelsFirst`?(o=2,i=3,a=4):(o=1,i=2,a=3);let s=n[o],c=n[i],l=n[a],u=this.kernelSize[0],d=this.kernelSize[1],f=this.kernelSize[2],p=this.strides[0],m=this.strides[1],h=this.strides[2],g=[r,Vy(s,p,u,this.padding),Vy(c,m,d,this.padding),Vy(l,h,f,this.padding),this.filters];this.dataFormat!==`channelsLast`&&(t=P(t,[0,2,3,4,1]));let _=ma(t,this.kernel.read(),g,this.strides,this.padding);return this.dataFormat!==`channelsLast`&&(_=P(_,[0,4,1,2,3])),this.bias!==null&&(_=xh(_,this.bias.read(),this.dataFormat)),this.activation!==null&&(_=this.activation.apply(_)),_})}computeOutputShape(e){e=q(e);let t=e.slice(),n,r,i,a;this.dataFormat===`channelsFirst`?(n=1,r=2,i=3,a=4):(n=4,r=1,i=2,a=3);let o=this.kernelSize[0],s=this.kernelSize[1],c=this.kernelSize[2],l=this.strides[0],u=this.strides[1],d=this.strides[2];return t[n]=this.filters,t[r]=Vy(t[r],l,o,this.padding),t[i]=Vy(t[i],u,s,this.padding),t[a]=Vy(t[a],d,c,this.padding),t}getConfig(){let e=super.getConfig();return delete e.dilationRate,e}};Qy.className=`Conv3DTranspose`,V(Qy);var $y=class extends Jy{constructor(e,t){if(super(e,t),this.DEFAULT_DEPTHWISE_INITIALIZER=`glorotUniform`,this.DEFAULT_POINTWISE_INITIALIZER=`glorotUniform`,this.depthwiseKernel=null,this.pointwiseKernel=null,t.filters==null)throw new W("The `filters` configuration field is required by SeparableConv, but is unspecified.");if(t.kernelInitializer!=null||t.kernelRegularizer!=null||t.kernelConstraint!=null)throw new W(`Fields kernelInitializer, kernelRegularizer and kernelConstraint are invalid for SeparableConv2D. Use depthwiseInitializer, depthwiseRegularizer, depthwiseConstraint, pointwiseInitializer, pointwiseRegularizer and pointwiseConstraint instead.`);if(t.padding!=null&&t.padding!==`same`&&t.padding!==`valid`)throw new W(`SeparableConv${this.rank}D supports only padding modes: 'same' and 'valid', but received ${JSON.stringify(t.padding)}`);this.depthMultiplier=t.depthMultiplier==null?1:t.depthMultiplier,this.depthwiseInitializer=Zh(t.depthwiseInitializer||this.DEFAULT_DEPTHWISE_INITIALIZER),this.depthwiseRegularizer=My(t.depthwiseRegularizer),this.depthwiseConstraint=Lg(t.depthwiseConstraint),this.pointwiseInitializer=Zh(t.depthwiseInitializer||this.DEFAULT_POINTWISE_INITIALIZER),this.pointwiseRegularizer=My(t.pointwiseRegularizer),this.pointwiseConstraint=Lg(t.pointwiseConstraint)}build(e){if(e=q(e),e.length<this.rank+2)throw new W(`Inputs to SeparableConv${this.rank}D should have rank ${this.rank+2}, but received input shape: ${JSON.stringify(e)}`);let t=this.dataFormat===`channelsFirst`?1:e.length-1;if(e[t]==null||e[t]<0)throw new W(`The channel dimension of the inputs should be defined, but found ${JSON.stringify(e[t])}`);let n=e[t],r=this.kernelSize.concat([n,this.depthMultiplier]),i=[];for(let e=0;e<this.rank;++e)i.push(1);i.push(n*this.depthMultiplier,this.filters),this.depthwiseKernel=this.addWeight(`depthwise_kernel`,r,`float32`,this.depthwiseInitializer,this.depthwiseRegularizer,!0,this.depthwiseConstraint),this.pointwiseKernel=this.addWeight(`pointwise_kernel`,i,`float32`,this.pointwiseInitializer,this.pointwiseRegularizer,!0,this.pointwiseConstraint),this.useBias?this.bias=this.addWeight(`bias`,[this.filters],`float32`,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.inputSpec=[new og({ndim:this.rank+2,axes:{[t]:n}})],this.built=!0}call(e,t){return A(()=>{e=K(e);let t;if(this.rank===1)throw new G(`1D separable convolution is not implemented yet.`);return this.rank===2&&(this.dataFormat===`channelsFirst`&&(e=P(e,[0,2,3,1])),t=pt(e,this.depthwiseKernel.read(),this.pointwiseKernel.read(),this.strides,this.padding,this.dilationRate,`NHWC`)),this.useBias&&(t=xh(t,this.bias.read(),this.dataFormat)),this.activation!=null&&(t=this.activation.apply(t)),this.dataFormat===`channelsFirst`&&(t=P(t,[0,3,1,2])),t})}getConfig(){let e=super.getConfig();return delete e.rank,delete e.kernelInitializer,delete e.kernelRegularizer,delete e.kernelConstraint,e.depthwiseInitializer=Xh(this.depthwiseInitializer),e.pointwiseInitializer=Xh(this.pointwiseInitializer),e.depthwiseRegularizer=Ay(this.depthwiseRegularizer),e.pointwiseRegularizer=Ay(this.pointwiseRegularizer),e.depthwiseConstraint=Fg(this.depthwiseConstraint),e.pointwiseConstraint=Fg(this.pointwiseConstraint),e}};$y.className=`SeparableConv`;var eb=class extends $y{constructor(e){super(2,e)}};eb.className=`SeparableConv2D`,V(eb);var tb=class e extends Jy{constructor(t){super(1,t),e.verifyArgs(t),this.inputSpec=[{ndim:3}]}getConfig(){let e=super.getConfig();return delete e.rank,delete e.dataFormat,e}static verifyArgs(e){if(typeof e.kernelSize!=`number`&&!wm(e.kernelSize,`number`,1,1))throw new W(`Conv1D expects config.kernelSize to be number or number[] with length 1, but received ${JSON.stringify(e.kernelSize)}.`)}};tb.className=`Conv1D`,V(tb);var nb=class extends J{constructor(e){super(e),typeof e.cropping==`number`?this.cropping=[[e.cropping,e.cropping],[e.cropping,e.cropping]]:typeof e.cropping[0]==`number`?this.cropping=[[e.cropping[0],e.cropping[0]],[e.cropping[1],e.cropping[1]]]:this.cropping=e.cropping,this.dataFormat=e.dataFormat===void 0?`channelsLast`:e.dataFormat,this.inputSpec=[{ndim:4}]}computeOutputShape(e){return this.dataFormat===`channelsFirst`?[e[0],e[1],e[2]-this.cropping[0][0]-this.cropping[0][1],e[3]-this.cropping[1][0]-this.cropping[1][1]]:[e[0],e[1]-this.cropping[0][0]-this.cropping[0][1],e[2]-this.cropping[1][0]-this.cropping[1][1],e[3]]}call(e,t){return A(()=>(e=K(e),this.dataFormat===`channelsLast`?fh(fh(e,this.cropping[0][0],e.shape[1]-this.cropping[0][0]-this.cropping[0][1],2),this.cropping[1][0],e.shape[2]-this.cropping[1][1]-this.cropping[1][0],3):fh(fh(e,this.cropping[0][0],e.shape[2]-this.cropping[0][0]-this.cropping[0][1],3),this.cropping[1][0],e.shape[3]-this.cropping[1][1]-this.cropping[1][0],4)))}getConfig(){let e={cropping:this.cropping,dataFormat:this.dataFormat},t=super.getConfig();return Object.assign(e,t),e}};nb.className=`Cropping2D`,V(nb);var rb=class extends J{constructor(e){super(e),this.DEFAULT_SIZE=[2,2],this.inputSpec=[{ndim:4}],this.size=e.size==null?this.DEFAULT_SIZE:e.size,this.dataFormat=e.dataFormat==null?`channelsLast`:e.dataFormat,zm(this.dataFormat),this.interpolation=e.interpolation==null?`nearest`:e.interpolation,Bm(this.interpolation)}computeOutputShape(e){if(this.dataFormat===`channelsFirst`){let t=e[2]==null?null:this.size[0]*e[2],n=e[3]==null?null:this.size[1]*e[3];return[e[0],e[1],t,n]}else{let t=e[1]==null?null:this.size[0]*e[1],n=e[2]==null?null:this.size[1]*e[2];return[e[0],t,n,e[3]]}}call(e,t){return A(()=>{let t=K(e),n=t.shape;if(this.dataFormat===`channelsFirst`){t=P(t,[0,2,3,1]);let e=this.size[0]*n[2],r=this.size[1]*n[3];return P(this.interpolation===`nearest`?oe.resizeNearestNeighbor(t,[e,r]):oe.resizeBilinear(t,[e,r]),[0,3,1,2])}else{let e=this.size[0]*n[1],r=this.size[1]*n[2];return this.interpolation===`nearest`?oe.resizeNearestNeighbor(t,[e,r]):oe.resizeBilinear(t,[e,r])}})}getConfig(){let e={size:this.size,dataFormat:this.dataFormat,interpolation:this.interpolation},t=super.getConfig();return Object.assign(e,t),e}};rb.className=`UpSampling2D`,V(rb);function ib(e,t,n=[1,1],r=`valid`,i,a){return A(()=>{i??=ih(),zm(i);let o=Hy(e,i);if(e.rank!==4)throw new W(`Input for depthwiseConv2d is required to be 4-D, but is instead ${e.rank}-D`);if(t.rank!==4)throw new W(`depthwiseKernel is required to be 4-D, but is instead ${t.rank}-D`);return o=Mc(o,t,n,r===`same`?`same`:`valid`,`NHWC`,a),i===`channelsFirst`&&(o=P(o,[0,3,1,2])),o})}var ab=class extends qy{constructor(e){super(2,e),this.depthwiseKernel=null,this.depthMultiplier=e.depthMultiplier==null?1:e.depthMultiplier,this.depthwiseInitializer=Zh(e.depthwiseInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.depthwiseConstraint=Lg(e.depthwiseConstraint),this.depthwiseRegularizer=My(e.depthwiseRegularizer)}build(e){if(e=q(e),e.length<4)throw new W(`Inputs to DepthwiseConv2D should have rank 4. Received input shape: ${JSON.stringify(e)}.`);let t=this.dataFormat===`channelsFirst`?1:3;if(e[t]==null||e[t]<0)throw new W(`The channel dimension of the inputs to DepthwiseConv2D should be defined, but is not (${e[t]}).`);let n=e[t],r=[this.kernelSize[0],this.kernelSize[1],n,this.depthMultiplier];this.depthwiseKernel=this.addWeight(`depthwise_kernel`,r,null,this.depthwiseInitializer,this.depthwiseRegularizer,!0,this.depthwiseConstraint),this.useBias?this.bias=this.addWeight(`bias`,[n*this.depthMultiplier],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(e,t){return A(()=>{e=K(e);let t=ib(e,this.depthwiseKernel.read(),this.strides,this.padding,this.dataFormat,null);return this.useBias&&(t=xh(t,this.bias.read(),this.dataFormat)),this.activation!=null&&(t=this.activation.apply(t)),t})}computeOutputShape(e){e=q(e);let t=this.dataFormat===`channelsFirst`?e[2]:e[1],n=this.dataFormat===`channelsFirst`?e[3]:e[2],r=this.dataFormat===`channelsFirst`?e[1]*this.depthMultiplier:e[3]*this.depthMultiplier,i=By(t,this.kernelSize[0],this.padding,this.strides[0]),a=By(n,this.kernelSize[1],this.padding,this.strides[1]);return this.dataFormat===`channelsFirst`?[e[0],r,i,a]:[e[0],i,a,r]}getConfig(){let e=super.getConfig();return e.depthMultiplier=this.depthMultiplier,e.depthwiseInitializer=Xh(this.depthwiseInitializer),e.depthwiseRegularizer=Ay(this.depthwiseRegularizer),e.depthwiseConstraint=Fg(this.depthwiseRegularizer),e}};ab.className=`DepthwiseConv2D`,V(ab);function ob(e,t,n,r){if(Array.isArray(e)){if(t!=null||n!=null)throw new W(`When inputs is an array, neither initialState or constants should be provided`);r!=null&&(n=e.slice(e.length-r,e.length),e=e.slice(0,e.length-r)),e.length>1&&(t=e.slice(1,e.length)),e=e[0]}function i(e){return e==null||Array.isArray(e)?e:[e]}return t=i(t),n=i(n),{inputs:e,initialState:t,constants:n}}function sb(e,t,n,r=!1,i,a,o=!1,s=!1){return A(()=>{let c=t.shape.length;if(c<3)throw new W(`Input should be at least 3D, but is ${c}D.`);let l=[1,0].concat(th(2,c));if(t=P(t,l),a!=null)throw new G(`The rnn() functoin of the deeplearn.js backend does not support constants yet.`);o&&console.warn(`Backend rnn(): the unroll = true option is not applicable to the imperative deeplearn.js backend.`),i!=null&&(i=F(F(i,`bool`),`float32`),i.rank===c-1&&(i=Cl(i,-1)),i=P(i,l)),r&&(t=pi(t,0),i!=null&&(i=pi(i,0)));let u=[],d,f=n,p=t.shape[0],m=Vs(t),h;i!=null&&(h=Vs(i));for(let t=0;t<p;++t){let n=m[t],r=A(()=>e(n,f));if(i==null)d=r[0],f=r[1];else{let e=A(()=>{let e=h[t],n=L(mr(e),e);return{output:I(z(r[0],e),z(f[0],n)),newStates:f.map((t,i)=>I(z(r[1][i],e),z(t,n)))}});d=e.output,f=e.newStates}s&&u.push(d)}let g;return s&&(g=Or(u,1)),[d,g,f]})}var cb=class e extends J{constructor(e){super(e);let t;if(e.cell==null)throw new W(`cell property is missing for the constructor of RNN.`);if(t=Array.isArray(e.cell)?new gb({cells:e.cell}):e.cell,t.stateSize==null)throw new W("The RNN cell should have an attribute `stateSize` (tuple of integers, one integer per RNN state).");this.cell=t,this.returnSequences=e.returnSequences!=null&&e.returnSequences,this.returnState=e.returnState!=null&&e.returnState,this.goBackwards=e.goBackwards!=null&&e.goBackwards,this._stateful=e.stateful!=null&&e.stateful,this.unroll=e.unroll!=null&&e.unroll,this.supportsMasking=!0,this.inputSpec=[new og({ndim:3})],this.stateSpec=null,this.states_=null,this.numConstants=null,this.keptStates=[]}getStates(){return this.states_==null?th(0,Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1).map(e=>null):this.states_}setStates(e){this.states_=e}computeOutputShape(e){Qh(e)&&(e=e[0]),e=e;let t=this.cell.stateSize;Array.isArray(t)||(t=[t]);let n=t[0],r;if(r=this.returnSequences?[e[0],e[1],n]:[e[0],n],this.returnState){let n=[];for(let r of t)n.push([e[0],r]);return[r].concat(n)}else return r}computeMask(e,t){return A(()=>{Array.isArray(t)&&(t=t[0]);let e=this.returnSequences?t:null;if(this.returnState){let t=this.states.map(e=>null);return[e].concat(t)}else return e})}get states(){if(this.states_==null){let e=Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1,t=[];for(let n=0;n<e;++n)t.push(null);return t}else return this.states_}set states(e){this.states_=e}build(e){if(this.numConstants!=null)throw new G(`Constants support is not implemented in RNN yet.`);Qh(e)&&(e=e[0]),e=e;let t=this.stateful?e[0]:null,n=e.slice(2);this.inputSpec[0]=new og({shape:[t,null,...n]});let r=[e[0]].concat(e.slice(2));this.cell.build(r);let i;if(i=Array.isArray(this.cell.stateSize)?this.cell.stateSize:[this.cell.stateSize],this.stateSpec!=null){if(!qn(this.stateSpec.map(e=>e.shape[e.shape.length-1]),i))throw new W(`An initialState was passed that is not compatible with cell.stateSize. Received stateSpec=${this.stateSpec}; However cell.stateSize is ${this.cell.stateSize}`)}else this.stateSpec=i.map(e=>new og({shape:[null,e]}));this.stateful&&this.resetStates()}resetStates(e,t=!1){A(()=>{if(!this.stateful)throw new im(`Cannot call resetStates() on an RNN Layer that is not stateful.`);let n=this.inputSpec[0].shape[0];if(n==null)throw new W("If an RNN is stateful, it needs to know its batch size. Specify the batch size of your input tensors: \n- If using a Sequential model, specify the batch size by passing a `batchInputShape` option to your first layer.\n- If using the functional API, specify the batch size by passing a `batchShape` option to your Input layer.");if(this.states_==null)Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(e=>_n([n,e])):this.states_=[_n([n,this.cell.stateSize])];else if(e==null)D(this.states_),this.keptStates!=null&&(D(this.keptStates),this.keptStates=[]),Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(e=>_n([n,e])):this.states_[0]=_n([n,this.cell.stateSize]);else{if(Array.isArray(e)||(e=[e]),e.length!==this.states_.length)throw new W(`Layer ${this.name} expects ${this.states_.length} state(s), but it received ${e.length} state value(s). Input received: ${e}`);t===!0?this.keptStates.push(this.states_.slice()):D(this.states_);for(let t=0;t<this.states_.length;++t){let r=e[t],i=[n,Array.isArray(this.cell.stateSize)?this.cell.stateSize[t]:this.cell.stateSize];if(!qn(r.shape,i))throw new W(`State ${t} is incompatible with layer ${this.name}: expected shape=${i}, received shape=${r.shape}`);this.states_[t]=r}}this.states_=this.states_.map(e=>ze(e.clone()))})}apply(e,t){let n=t==null?null:t.initialState,r=t==null?null:t.constants;t??={};let i=ob(e,n,r,this.numConstants);e=i.inputs,n=i.initialState,r=i.constants;let a=[],o=[];if(n!=null){t.initialState=n,a=a.concat(n),this.stateSpec=[];for(let e of n)this.stateSpec.push(new og({shape:e.shape}));o=o.concat(this.stateSpec)}if(r!=null&&(t.constants=r,a=a.concat(r),this.numConstants=r.length),a[0]instanceof sg){let n=[e].concat(a),r=this.inputSpec.concat(o),i=this.inputSpec;this.inputSpec=r;let s=super.apply(n,t);return this.inputSpec=i,s}else return super.apply(e,t)}call(e,t){return A(()=>{let n=t==null?null:t.mask,r=t==null?null:t.training,i=t==null?null:t.initialState;e=K(e),i??=this.stateful?this.states_:this.getInitialState(e);let a=Array.isArray(this.cell.stateSize)?this.cell.stateSize.length:1;if(i.length!==a)throw new W(`RNN Layer has ${a} state(s) but was passed ${i.length} initial state(s).`);this.unroll&&console.warn(`Ignoring unroll = true for RNN layer, due to imperative backend.`);let o={training:r},s=sb((e,t)=>{let n=this.cell.call([e].concat(t),o);return[n[0],n.slice(1)]},e,i,this.goBackwards,n,null,this.unroll,this.returnSequences),c=s[0],l=s[1],u=s[2];this.stateful&&this.resetStates(u,r);let d=this.returnSequences?l:c;return this.returnState?[d].concat(u):d})}getInitialState(e){return A(()=>{let t=_n(e.shape);return t=O(t,[1,2]),t=oh(t),Array.isArray(this.cell.stateSize)?this.cell.stateSize.map(e=>e>1?hh(t,[1,e]):t):this.cell.stateSize>1?[hh(t,[1,this.cell.stateSize])]:[t]})}get trainableWeights(){return this.trainable?this.cell.trainableWeights:[]}get nonTrainableWeights(){return this.trainable?this.cell.nonTrainableWeights:this.cell.weights}setFastWeightInitDuringBuild(e){super.setFastWeightInitDuringBuild(e),this.cell!=null&&this.cell.setFastWeightInitDuringBuild(e)}getConfig(){let t=super.getConfig(),n={returnSequences:this.returnSequences,returnState:this.returnState,goBackwards:this.goBackwards,stateful:this.stateful,unroll:this.unroll};this.numConstants!=null&&(n.numConstants=this.numConstants);let r=this.cell.getConfig();return this.getClassName()===e.className&&(n.cell={className:this.cell.getClassName(),config:r}),Object.assign(Object.assign(Object.assign({},r),t),n)}static fromConfig(e,t,n={}){let r=t.cell,i=g_(r,n);return new e(Object.assign(t,{cell:i}))}};cb.className=`RNN`,V(cb);var lb=class extends J{},ub=class extends lb{constructor(e){super(e),this.DEFAULT_ACTIVATION=`tanh`,this.DEFAULT_KERNEL_INITIALIZER=`glorotNormal`,this.DEFAULT_RECURRENT_INITIALIZER=`orthogonal`,this.DEFAULT_BIAS_INITIALIZER=`zeros`,this.units=e.units,Tm(this.units,`units`),this.activation=Cy(e.activation==null?this.DEFAULT_ACTIVATION:e.activation),this.useBias=e.useBias==null||e.useBias,this.kernelInitializer=Zh(e.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Zh(e.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Zh(e.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelRegularizer=My(e.kernelRegularizer),this.recurrentRegularizer=My(e.recurrentRegularizer),this.biasRegularizer=My(e.biasRegularizer),this.kernelConstraint=Lg(e.kernelConstraint),this.recurrentConstraint=Lg(e.recurrentConstraint),this.biasConstraint=Lg(e.biasConstraint),this.dropout=$m([1,eh([0,e.dropout==null?0:e.dropout])]),this.recurrentDropout=$m([1,eh([0,e.recurrentDropout==null?0:e.recurrentDropout])]),this.dropoutFunc=e.dropoutFunc,this.stateSize=this.units,this.dropoutMask=null,this.recurrentDropoutMask=null}build(e){e=q(e),this.kernel=this.addWeight(`kernel`,[e[e.length-1],this.units],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight(`recurrent_kernel`,[this.units,this.units],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias?this.bias=this.addWeight(`bias`,[this.units],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(e,t){return A(()=>{if(e=e,e.length!==2)throw new W(`SimpleRNNCell expects 2 input Tensors, got ${e.length}.`);let n=e[1];e=e[0];let r=t.training!=null&&t.training;0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=_b({ones:()=>mr(e),rate:this.dropout,training:r,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=_b({ones:()=>mr(n),rate:this.recurrentDropout,training:r,dropoutFunc:this.dropoutFunc}));let i,a=this.dropoutMask,o=this.recurrentDropoutMask;i=_h(a==null?e:z(e,a),this.kernel.read()),this.bias!=null&&(i=xh(i,this.bias.read())),o!=null&&(n=z(n,o));let s=I(i,_h(n,this.recurrentKernel.read()));return this.activation!=null&&(s=this.activation.apply(s)),[s,s]})}getConfig(){let e=super.getConfig(),t={units:this.units,activation:xy(this.activation),useBias:this.useBias,kernelInitializer:Xh(this.kernelInitializer),recurrentInitializer:Xh(this.recurrentInitializer),biasInitializer:Xh(this.biasInitializer),kernelRegularizer:Ay(this.kernelRegularizer),recurrentRegularizer:Ay(this.recurrentRegularizer),biasRegularizer:Ay(this.biasRegularizer),activityRegularizer:Ay(this.activityRegularizer),kernelConstraint:Fg(this.kernelConstraint),recurrentConstraint:Fg(this.recurrentConstraint),biasConstraint:Fg(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout};return Object.assign(Object.assign({},e),t)}};ub.className=`SimpleRNNCell`,V(ub);var db=class extends cb{constructor(e){e.cell=new ub(e),super(e)}call(e,t){return A(()=>{this.cell.dropoutMask!=null&&(D(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(D(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);let n=t==null?null:t.mask,r=t==null?null:t.training,i=t==null?null:t.initialState;return super.call(e,{mask:n,training:r,initialState:i})})}static fromConfig(e,t){return new e(t)}};db.className=`SimpleRNN`,V(db);var fb=class extends lb{constructor(e){if(super(e),this.DEFAULT_ACTIVATION=`tanh`,this.DEFAULT_RECURRENT_ACTIVATION=`hardSigmoid`,this.DEFAULT_KERNEL_INITIALIZER=`glorotNormal`,this.DEFAULT_RECURRENT_INITIALIZER=`orthogonal`,this.DEFAULT_BIAS_INITIALIZER=`zeros`,e.resetAfter)throw new W(`GRUCell does not support reset_after parameter set to true.`);this.units=e.units,Tm(this.units,`units`),this.activation=Cy(e.activation===void 0?this.DEFAULT_ACTIVATION:e.activation),this.recurrentActivation=Cy(e.recurrentActivation===void 0?this.DEFAULT_RECURRENT_ACTIVATION:e.recurrentActivation),this.useBias=e.useBias==null||e.useBias,this.kernelInitializer=Zh(e.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Zh(e.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Zh(e.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelRegularizer=My(e.kernelRegularizer),this.recurrentRegularizer=My(e.recurrentRegularizer),this.biasRegularizer=My(e.biasRegularizer),this.kernelConstraint=Lg(e.kernelConstraint),this.recurrentConstraint=Lg(e.recurrentConstraint),this.biasConstraint=Lg(e.biasConstraint),this.dropout=$m([1,eh([0,e.dropout==null?0:e.dropout])]),this.recurrentDropout=$m([1,eh([0,e.recurrentDropout==null?0:e.recurrentDropout])]),this.dropoutFunc=e.dropoutFunc,this.implementation=e.implementation,this.stateSize=this.units,this.dropoutMask=null,this.recurrentDropoutMask=null}build(e){e=q(e);let t=e[e.length-1];this.kernel=this.addWeight(`kernel`,[t,this.units*3],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight(`recurrent_kernel`,[this.units,this.units*3],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias?this.bias=this.addWeight(`bias`,[this.units*3],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint):this.bias=null,this.built=!0}call(e,t){return A(()=>{if(e=e,e.length!==2)throw new W(`GRUCell expects 2 input Tensors (inputs, h, c), got ${e.length}.`);let n=t.training!=null&&t.training,r=e[1];e=e[0],0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=_b({ones:()=>mr(e),rate:this.dropout,training:n,count:3,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=_b({ones:()=>mr(r),rate:this.recurrentDropout,training:n,count:3,dropoutFunc:this.dropoutFunc}));let i=this.dropoutMask,a=this.recurrentDropoutMask,o,s,c;0<this.dropout&&this.dropout<1&&(e=z(e,i[0]));let l=_h(e,this.kernel.read());this.useBias&&(l=xh(l,this.bias.read())),0<this.recurrentDropout&&this.recurrentDropout<1&&(r=z(r,a[0]));let u=this.recurrentKernel.read(),[d,f]=Zo(u,[2*this.units,this.units],u.rank-1),p=_h(r,d),[m,h,g]=Zo(l,3,l.rank-1),[_,v]=Zo(p,2,p.rank-1);o=this.recurrentActivation.apply(I(m,_)),s=this.recurrentActivation.apply(I(h,v));let y=_h(z(s,r),f);c=this.activation.apply(I(g,y));let b=I(z(o,r),z(I(1,li(o)),c));return[b,b]})}getConfig(){let e=super.getConfig(),t={units:this.units,activation:xy(this.activation),recurrentActivation:xy(this.recurrentActivation),useBias:this.useBias,kernelInitializer:Xh(this.kernelInitializer),recurrentInitializer:Xh(this.recurrentInitializer),biasInitializer:Xh(this.biasInitializer),kernelRegularizer:Ay(this.kernelRegularizer),recurrentRegularizer:Ay(this.recurrentRegularizer),biasRegularizer:Ay(this.biasRegularizer),activityRegularizer:Ay(this.activityRegularizer),kernelConstraint:Fg(this.kernelConstraint),recurrentConstraint:Fg(this.recurrentConstraint),biasConstraint:Fg(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout,implementation:this.implementation,resetAfter:!1};return Object.assign(Object.assign({},e),t)}};fb.className=`GRUCell`,V(fb);var pb=class extends cb{constructor(e){e.implementation===0&&console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."),e.cell=new fb(e),super(e)}call(e,t){return A(()=>{this.cell.dropoutMask!=null&&(D(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(D(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);let n=t==null?null:t.mask,r=t==null?null:t.training,i=t==null?null:t.initialState;return super.call(e,{mask:n,training:r,initialState:i})})}static fromConfig(e,t){return t.implmentation===0&&(t.implementation=1),new e(t)}};pb.className=`GRU`,V(pb);var mb=class extends lb{constructor(e){super(e),this.DEFAULT_ACTIVATION=`tanh`,this.DEFAULT_RECURRENT_ACTIVATION=`hardSigmoid`,this.DEFAULT_KERNEL_INITIALIZER=`glorotNormal`,this.DEFAULT_RECURRENT_INITIALIZER=`orthogonal`,this.DEFAULT_BIAS_INITIALIZER=`zeros`,this.units=e.units,Tm(this.units,`units`),this.activation=Cy(e.activation===void 0?this.DEFAULT_ACTIVATION:e.activation),this.recurrentActivation=Cy(e.recurrentActivation===void 0?this.DEFAULT_RECURRENT_ACTIVATION:e.recurrentActivation),this.useBias=e.useBias==null||e.useBias,this.kernelInitializer=Zh(e.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.recurrentInitializer=Zh(e.recurrentInitializer||this.DEFAULT_RECURRENT_INITIALIZER),this.biasInitializer=Zh(e.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.unitForgetBias=e.unitForgetBias,this.kernelRegularizer=My(e.kernelRegularizer),this.recurrentRegularizer=My(e.recurrentRegularizer),this.biasRegularizer=My(e.biasRegularizer),this.kernelConstraint=Lg(e.kernelConstraint),this.recurrentConstraint=Lg(e.recurrentConstraint),this.biasConstraint=Lg(e.biasConstraint),this.dropout=$m([1,eh([0,e.dropout==null?0:e.dropout])]),this.recurrentDropout=$m([1,eh([0,e.recurrentDropout==null?0:e.recurrentDropout])]),this.dropoutFunc=e.dropoutFunc,this.implementation=e.implementation,this.stateSize=[this.units,this.units],this.dropoutMask=null,this.recurrentDropoutMask=null}build(e){var t;e=q(e);let n=e[e.length-1];this.kernel=this.addWeight(`kernel`,[n,this.units*4],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.recurrentKernel=this.addWeight(`recurrent_kernel`,[this.units,this.units*4],null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint);let r;if(this.useBias){if(this.unitForgetBias){let e=this.biasInitializer,n=this.units;r=new(t=class extends jh{apply(t,r){let i=e.apply([n]),a=new Nh().apply([n]),o=e.apply([n*2]);return mh(mh(i,a),o)}},t.className=`CustomInit`,t)}else r=this.biasInitializer;this.bias=this.addWeight(`bias`,[this.units*4],null,r,this.biasRegularizer,!0,this.biasConstraint)}else this.bias=null;this.built=!0}call(e,t){return A(()=>{let n=t.training!=null&&t.training;if(e=e,e.length!==3)throw new W(`LSTMCell expects 3 input Tensors (inputs, h, c), got ${e.length}.`);let r=e[1],i=e[2];e=e[0],0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=_b({ones:()=>mr(e),rate:this.dropout,training:n,count:4,dropoutFunc:this.dropoutFunc})),0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=_b({ones:()=>mr(r),rate:this.recurrentDropout,training:n,count:4,dropoutFunc:this.dropoutFunc}));let a=this.dropoutMask,o=this.recurrentDropoutMask,s,c,l,u;0<this.dropout&&this.dropout<1&&(e=z(e,a[0]));let d=_h(e,this.kernel.read());0<this.recurrentDropout&&this.recurrentDropout<1&&(r=z(r,o[0])),d=I(d,_h(r,this.recurrentKernel.read())),this.useBias&&(d=xh(d,this.bias.read()));let[f,p,m,h]=Zo(d,4,d.rank-1);s=this.recurrentActivation.apply(f),c=this.recurrentActivation.apply(p),l=I(z(c,i),z(s,this.activation.apply(m))),u=this.recurrentActivation.apply(h);let g=z(u,this.activation.apply(l));return[g,g,l]})}getConfig(){let e=super.getConfig(),t={units:this.units,activation:xy(this.activation),recurrentActivation:xy(this.recurrentActivation),useBias:this.useBias,kernelInitializer:Xh(this.kernelInitializer),recurrentInitializer:Xh(this.recurrentInitializer),biasInitializer:Xh(this.biasInitializer),unitForgetBias:this.unitForgetBias,kernelRegularizer:Ay(this.kernelRegularizer),recurrentRegularizer:Ay(this.recurrentRegularizer),biasRegularizer:Ay(this.biasRegularizer),activityRegularizer:Ay(this.activityRegularizer),kernelConstraint:Fg(this.kernelConstraint),recurrentConstraint:Fg(this.recurrentConstraint),biasConstraint:Fg(this.biasConstraint),dropout:this.dropout,recurrentDropout:this.recurrentDropout,implementation:this.implementation};return Object.assign(Object.assign({},e),t)}};mb.className=`LSTMCell`,V(mb);var hb=class extends cb{constructor(e){e.implementation===0&&console.warn("`implementation=0` has been deprecated, and now defaults to `implementation=1`. Please update your layer call."),e.cell=new mb(e),super(e)}call(e,t){return A(()=>{this.cell.dropoutMask!=null&&(D(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(D(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null);let n=t==null?null:t.mask,r=t==null?null:t.training,i=t==null?null:t.initialState;return super.call(e,{mask:n,training:r,initialState:i})})}static fromConfig(e,t){return t.implmentation===0&&(t.implementation=1),new e(t)}};hb.className=`LSTM`,V(hb);var gb=class extends lb{constructor(e){super(e),this.cells=e.cells}get stateSize(){let e=[];for(let t of this.cells.slice().reverse())Array.isArray(t.stateSize)?e.push(...t.stateSize):e.push(t.stateSize);return e}call(e,t){return A(()=>{e=e;let n=e.slice(1),r=[];for(let e of this.cells.slice().reverse())Array.isArray(e.stateSize)?r.push(n.splice(0,e.stateSize.length)):r.push(n.splice(0,1));r.reverse();let i=[],a;for(let o=0;o<this.cells.length;++o){let s=this.cells[o];n=r[o],a=o===0?[e[0]].concat(n):[a[0]].concat(n),a=s.call(a,t),i.push(a.slice(1))}n=[];for(let e of i.slice().reverse())n.push(...e);return[a[0]].concat(n)})}build(e){Qh(e)&&(e=e[0]),e=e;let t;this.cells.forEach((n,r)=>{Gm(`RNNCell_${r}`,()=>{n.build(e),t=Array.isArray(n.stateSize)?n.stateSize[0]:n.stateSize,e=[e[0],t]})}),this.built=!0}getConfig(){let e=super.getConfig(),t={cells:this.cells.map(e=>({className:e.getClassName(),config:e.getConfig()}))};return Object.assign(Object.assign({},e),t)}static fromConfig(e,t,n={}){let r=[];for(let e of t.cells)r.push(g_(e,n));return new e({cells:r})}get trainableWeights(){if(!this.trainable)return[];let e=[];for(let t of this.cells)e.push(...t.trainableWeights);return e}get nonTrainableWeights(){let e=[];for(let t of this.cells)e.push(...t.nonTrainableWeights);if(!this.trainable){let t=[];for(let e of this.cells)t.push(...e.trainableWeights);return t.concat(e)}return e}getWeights(){let e=[];for(let t of this.cells)e.push(...t.weights);return ig(e)}setWeights(e){let t=[];for(let n of this.cells){let r=n.weights.length,i=e.splice(r);for(let e=0;e<n.weights.length;++e)t.push([n.weights[e],i[e]])}ag(t)}};gb.className=`StackedRNNCells`,V(gb);function _b(e){let{ones:t,rate:n,training:r=!1,count:i=1,dropoutFunc:a}=e,o=()=>a==null?wh(t(),n):a(t(),n),s=()=>Eh(o,t,r);return!i||i<=1?ze(s().clone()):Array(i).fill(void 0).map(s).map(e=>ze(e.clone()))}var vb=function(e,t){var n={};for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(e!=null&&typeof Object.getOwnPropertySymbols==`function`)for(var i=0,r=Object.getOwnPropertySymbols(e);i<r.length;i++)t.indexOf(r[i])<0&&Object.prototype.propertyIsEnumerable.call(e,r[i])&&(n[r[i]]=e[r[i]]);return n},yb=class extends cb{constructor(e){if(e.unroll)throw new G(`Unrolling is not possible with convolutional RNNs.`);if(Array.isArray(e.cell))throw new G(`It is not possible at the moment to stack convolutional cells.`);super(e),this.inputSpec=[new og({ndim:5})]}call(e,t){return A(()=>{if(this.cell.dropoutMask!=null&&(D(this.cell.dropoutMask),this.cell.dropoutMask=null),this.cell.recurrentDropoutMask!=null&&(D(this.cell.recurrentDropoutMask),this.cell.recurrentDropoutMask=null),t&&t.constants)throw new W(`ConvRNN2D cell does not support constants`);let n=t==null?null:t.mask,r=t==null?null:t.training,i=t==null?null:t.initialState;return super.call(e,{mask:n,training:r,initialState:i})})}computeOutputShape(e){let t=this.computeSingleOutputShape(e);return this.returnSequences||(t=[t[0],...t.slice(2)]),this.returnState&&(t=[t,...[,,].fill([e[0],...t.slice(-3)])]),t}getInitialState(e){return A(()=>{let{stateSize:t}=this.cell,n=e.shape,r=this.computeSingleOutputShape(n),i=_n([r[0],...r.slice(2)]);return Array.isArray(t)?Array(t.length).fill(i):[i]})}resetStates(e,t=!1){A(()=>{if(!this.stateful)throw new im(`Cannot call resetStates() on an RNN Layer that is not stateful.`);let n=this.inputSpec[0].shape,r=this.computeSingleOutputShape(n),i=[r[0],...r.slice(2)];if(n[0]==null)throw new W("If an RNN is stateful, it needs to know its batch size. Specify the batch size of your input tensors: \n- If using a Sequential model, specify the batch size by passing a `batchInputShape` option to your first layer.\n- If using the functional API, specify the batch size by passing a `batchShape` option to your Input layer.");if(this.getStates()==null)Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(()=>_n(i)):this.states_=[_n(i)];else if(e==null)D(this.states_),this.keptStates!=null&&(D(this.keptStates),this.keptStates=[]),Array.isArray(this.cell.stateSize)?this.states_=this.cell.stateSize.map(()=>_n(i)):this.states_[0]=_n(i);else{if(Array.isArray(e)||(e=[e]),e.length!==this.states_.length)throw new W(`Layer ${this.name} expects ${this.states_.length} state(s), but it received ${e.length} state value(s). Input received: ${e}`);t?this.keptStates.push(this.states_.slice()):D(this.states_);for(let t=0;t<this.states_.length;++t){let n=e[t],r=i;if(!qn(n.shape,r))throw new W(`State ${t} is incompatible with layer ${this.name}: expected shape=${r}, received shape=${n.shape}`);this.states_[t]=n}}this.states_=this.states_.map(e=>ze(e.clone()))})}computeSingleOutputShape(e){let{dataFormat:t,filters:n,kernelSize:r,padding:i,strides:a,dilationRate:o}=this.cell,s=t===`channelsFirst`,c=e[s?3:2],l=e[s?4:3],u=By(c,r[0],i,a[0],o[0]),d=By(l,r[1],i,a[1],o[1]);return[...e.slice(0,2),...s?[n,u,d]:[u,d,n]]}};yb.className=`ConvRNN2D`;var bb=class extends mb{constructor(e){let{filters:t,kernelSize:n,strides:r,padding:i,dataFormat:a,dilationRate:o}=e;super(Object.assign(Object.assign({},e),{units:t})),this.filters=t,Tm(this.filters,`filters`),this.kernelSize=zy(n,2,`kernelSize`),this.kernelSize.forEach(e=>Tm(e,`kernelSize`)),this.strides=zy(r||1,2,`strides`),this.strides.forEach(e=>Tm(e,`strides`)),this.padding=i||`valid`,Vm(this.padding),this.dataFormat=a||`channelsLast`,zm(this.dataFormat),this.dilationRate=zy(o||1,2,`dilationRate`),this.dilationRate.forEach(e=>Tm(e,`dilationRate`))}build(e){var t;e=q(e);let n=this.dataFormat===`channelsFirst`?1:e.length-1;if(e[n]==null)throw new W(`The channel dimension of the input should be defined. Found ${e[n]}`);let r=e[n],i=this.kernelSize.concat([r,this.filters*4]);this.kernel=this.addWeight(`kernel`,i,null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint);let a=this.kernelSize.concat([this.filters,this.filters*4]);if(this.recurrentKernel=this.addWeight(`recurrent_kernel`,a,null,this.recurrentInitializer,this.recurrentRegularizer,!0,this.recurrentConstraint),this.useBias){let e;if(this.unitForgetBias){let n=this.biasInitializer,r=this.filters;e=new(t=class extends jh{apply(e,t){return ph([n.apply([r]),on([r]),n.apply([r*2])])}},t.className=`CustomInit`,t)}else e=this.biasInitializer;this.bias=this.addWeight(`bias`,[this.filters*4],null,e,this.biasRegularizer,!0,this.biasConstraint)}this.built=!0}call(e,t){return A(()=>{if(e.length!==3)throw new W(`ConvLSTM2DCell expects 3 input Tensors (inputs, h, c), got ${e.length}.`);let n=t.training||!1,r=e[0],i=e[1],a=e[2];0<this.dropout&&this.dropout<1&&this.dropoutMask==null&&(this.dropoutMask=_b({ones:()=>mr(r),rate:this.dropout,training:n,count:4,dropoutFunc:this.dropoutFunc}));let o=this.dropoutMask,s=(e,t,n)=>!t||!t[n]?e:z(t[n],e),c=s(r,o,0),l=s(r,o,1),u=s(r,o,2),d=s(r,o,3);0<this.recurrentDropout&&this.recurrentDropout<1&&this.recurrentDropoutMask==null&&(this.recurrentDropoutMask=_b({ones:()=>mr(i),rate:this.recurrentDropout,training:n,count:4,dropoutFunc:this.dropoutFunc}));let f=this.recurrentDropoutMask,p=s(i,f,0),m=s(i,f,1),h=s(i,f,2),g=s(i,f,3),[_,v,y,b]=Zo(this.kernel.read(),4,3),[x,S,C,w]=this.useBias?Zo(this.bias.read(),4):[null,null,null,null];c=this.inputConv(c,_,x,this.padding),l=this.inputConv(l,v,S,this.padding),u=this.inputConv(u,y,C,this.padding),d=this.inputConv(d,b,w,this.padding);let[T,E,ee,te]=Zo(this.recurrentKernel.read(),4,3);p=this.recurrentConv(p,T),m=this.recurrentConv(m,E),h=this.recurrentConv(h,ee),g=this.recurrentConv(g,te);let ne=this.recurrentActivation.apply(I(c,p)),re=I(z(this.recurrentActivation.apply(I(l,m)),a),z(ne,this.activation.apply(I(u,h)))),ie=z(this.recurrentActivation.apply(I(d,g)),this.activation.apply(re));return[ie,ie,re]})}getConfig(){let e=super.getConfig(),{units:t}=e,n=vb(e,[`units`]),r={filters:this.filters,kernelSize:this.kernelSize,padding:this.padding,dataFormat:this.dataFormat,dilationRate:this.dilationRate,strides:this.strides};return Object.assign(Object.assign({},n),r)}inputConv(e,t,n,r){let i=ps(e,t,this.strides,r||`valid`,this.dataFormat===`channelsFirst`?`NCHW`:`NHWC`,this.dilationRate);return n?xh(i,n,this.dataFormat):i}recurrentConv(e,t){return ps(e,t,1,`same`,this.dataFormat===`channelsFirst`?`NCHW`:`NHWC`)}};bb.className=`ConvLSTM2DCell`,V(bb);var xb=class extends yb{constructor(e){let t=new bb(e);super(Object.assign(Object.assign({},e),{cell:t}))}static fromConfig(e,t){return new e(t)}};xb.className=`ConvLSTM2D`,V(xb);var Sb=class extends J{constructor(e){super(e),this.rate=Math.max(Math.min(e.rate,1),0),this.noiseShape=e.noiseShape,this.seed=e.seed,this.supportsMasking=!0}getNoiseShape(e){if(this.noiseShape==null)return this.noiseShape;let t=e.shape,n=[];for(let e=0;e<this.noiseShape.length;++e)n.push(this.noiseShape[e]==null?t[e]:this.noiseShape[e]);return n}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);if(0<this.rate&&this.rate<1){let e=t.training!=null&&t.training,r=this.getNoiseShape(n);return Eh(()=>wh(n,this.rate,r,this.seed),()=>n,e)}return e})}getConfig(){let e={rate:this.rate,noiseShape:this.noiseShape,seed:this.seed},t=super.getConfig();return Object.assign(e,t),e}dispose(){return super.dispose()}};Sb.className=`Dropout`,V(Sb);var Cb=class extends Sb{constructor(e){super(e),this.inputSpec=[{ndim:3}]}getNoiseShape(e){let t=e.shape;return[t[0],1,t[2]]}};Cb.className=`SpatialDropout1D`,V(Cb);var wb=class extends J{constructor(e){if(super(e),this.activation=null,this.useBias=!0,this.kernel=null,this.bias=null,this.DEFAULT_KERNEL_INITIALIZER=`glorotNormal`,this.DEFAULT_BIAS_INITIALIZER=`zeros`,e.batchInputShape==null&&e.inputShape==null&&e.inputDim!=null){let t=null;e.batchSize!=null&&(t=e.batchSize),this.batchInputShape=[t,e.inputDim]}this.units=e.units,Tm(this.units,`units`),this.activation=Cy(e.activation),e.useBias!=null&&(this.useBias=e.useBias),this.kernelInitializer=Zh(e.kernelInitializer||this.DEFAULT_KERNEL_INITIALIZER),this.biasInitializer=Zh(e.biasInitializer||this.DEFAULT_BIAS_INITIALIZER),this.kernelConstraint=Lg(e.kernelConstraint),this.biasConstraint=Lg(e.biasConstraint),this.kernelRegularizer=My(e.kernelRegularizer),this.biasRegularizer=My(e.biasRegularizer),this.activityRegularizer=My(e.activityRegularizer),this.supportsMasking=!0,this.inputSpec=[{minNDim:2}]}build(e){e=q(e);let t=e[e.length-1];this.kernel??(this.kernel=this.addWeight(`kernel`,[t,this.units],null,this.kernelInitializer,this.kernelRegularizer,!0,this.kernelConstraint),this.useBias&&(this.bias=this.addWeight(`bias`,[this.units],null,this.biasInitializer,this.biasRegularizer,!0,this.biasConstraint))),this.inputSpec=[{minNDim:2,axes:{[-1]:t}}],this.built=!0}computeOutputShape(e){e=q(e);let t=e.slice();return t[t.length-1]=this.units,t}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e),r=Om(this.activation.getClassName()),i;return r==null?(i=_h(n,this.kernel.read()),this.bias!=null&&(i=xh(i,this.bias.read())),this.activation!=null&&(i=this.activation.apply(i))):i=_h(n,this.kernel.read(),r,this.bias?this.bias.read():null),i})}getConfig(){let e={units:this.units,activation:xy(this.activation),useBias:this.useBias,kernelInitializer:Xh(this.kernelInitializer),biasInitializer:Xh(this.biasInitializer),kernelRegularizer:Ay(this.kernelRegularizer),biasRegularizer:Ay(this.biasRegularizer),activityRegularizer:Ay(this.activityRegularizer),kernelConstraint:Fg(this.kernelConstraint),biasConstraint:Fg(this.biasConstraint)},t=super.getConfig();return Object.assign(e,t),e}};wb.className=`Dense`,V(wb);var Tb=class extends J{constructor(e){e||={},super(e),this.inputSpec=[{minNDim:3}],this.dataFormat=e.dataFormat}computeOutputShape(e){e=q(e);for(let t of e.slice(1))if(t==null)throw new W(`The shape of the input to "Flatten" is not fully defined (got ${e.slice(1)}). Make sure to pass a complete "input_shape" or "batch_input_shape" argument to the first layer in your model.`);return[e[0],Qm(e,1)]}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);if(this.dataFormat===`channelsFirst`&&n.rank>1){let e=[0];for(let t=2;t<n.rank;++t)e.push(t);e.push(1),n=P(n,e)}return lh(n)})}getConfig(){let e={};this.dataFormat!=null&&(e.dataFormat=this.dataFormat);let t=super.getConfig();return Object.assign(e,t),e}};Tb.className=`Flatten`,V(Tb);var Eb=class extends J{constructor(e){super(e),this.supportsMasking=!0,this.activation=Cy(e.activation)}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);return this.activation.apply(n)})}getConfig(){let e={activation:xy(this.activation)},t=super.getConfig();return Object.assign(e,t),e}};Eb.className=`Activation`,V(Eb);var Db=class extends J{constructor(e){super(e),this.n=e.n,this.inputSpec=[{ndim:2}]}computeOutputShape(e){return[e[0],this.n,e[1]]}call(e,t){return A(()=>(e=K(e),sh(e,this.n)))}getConfig(){let e={n:this.n},t=super.getConfig();return Object.assign(e,t),e}};Db.className=`RepeatVector`,V(Db);var Ob=class extends J{constructor(e){super(e),this.targetShape=e.targetShape;for(let e=0;e<this.targetShape.length;++e)this.isUnknown(this.targetShape[e])&&(this.targetShape[e]=null)}isUnknown(e){return e<0||e==null}fixUnknownDimension(e,t){let n=`Total size of new array must be unchanged.`,r=t.slice(),i=1,a=null;for(let e=0;e<r.length;++e){let t=r[e];if(this.isUnknown(t))if(a===null)a=e;else throw new W(`Can only specifiy one unknown dimension.`);else i*=t}let o=Qm(e);if(a!==null){if(i===0||o%i!==0)throw new W(n);r[a]=o/i}else if(o!==i)throw new W(n);return r}computeOutputShape(e){let t=!1;for(let n=0;n<e.length;++n)if(this.isUnknown(e[n])){t=!0;break}return t?e.slice(0,1).concat(this.targetShape):e.slice(0,1).concat(this.fixUnknownDimension(e.slice(1),this.targetShape))}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e),r=n.shape;return U(n,r.slice(0,1).concat(this.fixUnknownDimension(r.slice(1),this.targetShape)))})}getConfig(){let e={targetShape:this.targetShape},t=super.getConfig();return Object.assign(e,t),e}};Ob.className=`Reshape`,V(Ob);var kb=class extends J{constructor(e){if(super(e),e.dims==null)throw Error("Required configuration field `dims` is missing during Permute constructor call.");if(!Array.isArray(e.dims))throw Error(`Permute constructor requires \`dims\` to be an Array, but received ${e.dims} instead.`);let t=th(1,e.dims.length+1);if(!qn(e.dims.slice().sort(),t))throw Error("Invalid permutation `dims`: "+JSON.stringify(e.dims)+" `dims` must contain consecutive integers starting from 1.");this.dims=e.dims,this.dimsIncludingBatch=[0].concat(this.dims),this.inputSpec=[new og({ndim:this.dims.length+1})]}computeOutputShape(e){e=q(e);let t=e.slice();return this.dims.forEach((n,r)=>{t[r+1]=e[n]}),t}call(e,t){return P(K(e),this.dimsIncludingBatch)}getConfig(){let e={dims:this.dims},t=super.getConfig();return Object.assign(e,t),e}};kb.className=`Permute`,V(kb);var Ab=class extends J{constructor(e){super(e??{}),this.supportsMasking=!0,e==null?this.maskValue=0:this.maskValue=e.maskValue==null?0:e.maskValue}computeOutputShape(e){return e}getConfig(){let e=super.getConfig(),t={maskValue:this.maskValue};return Object.assign(t,e),t}computeMask(e,t){return xo(dl(K(e),this.maskValue),-1)}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);return z(n,F(xo(dl(n,this.maskValue),-1,!0),n.dtype))})}};Ab.className=`Masking`,V(Ab);var jb=class extends J{constructor(e){if(super(e),this.embeddings=null,this.DEFAULT_EMBEDDINGS_INITIALIZER=`randomUniform`,e.batchInputShape==null&&e.inputShape==null){let t=null;e.batchSize!=null&&(t=e.batchSize),e.inputLength==null?this.batchInputShape=[t,null]:this.batchInputShape=[t].concat(fm(e.inputLength))}this.inputDim=e.inputDim,Tm(this.inputDim,`inputDim`),this.outputDim=e.outputDim,Tm(this.outputDim,`outputDim`),this.embeddingsInitializer=Zh(e.embeddingsInitializer||this.DEFAULT_EMBEDDINGS_INITIALIZER),this.embeddingsRegularizer=My(e.embeddingsRegularizer),this.activityRegularizer=My(e.activityRegularizer),this.embeddingsConstraint=Lg(e.embeddingsConstraint),this.maskZero=e.maskZero,this.supportsMasking=e.maskZero,this.inputLength=e.inputLength}build(e){this.embeddings=this.addWeight(`embeddings`,[this.inputDim,this.outputDim],this.dtype,this.embeddingsInitializer,this.embeddingsRegularizer,!0,this.embeddingsConstraint),this.built=!0}warnOnIncompatibleInputShape(e){}computeMask(e,t){return A(()=>this.maskZero?(e=K(e),dl(e,Vt(e))):null)}computeOutputShape(e){if(e=q(e),this.inputLength==null)return[...e,this.outputDim];let t=fm(this.inputLength);if(t.length!==e.length-1)throw new W(`"inputLength" is ${this.inputLength}, but received input shape has shape ${e}`);{let n=0;for(let r=0;r<t.length;++r){let i=t[r],a=e[r+1];if(i!=null&&a!=null&&i!==a)throw new W(`"inputLength" is ${this.inputLength}, but received input shape has shape ${e}`);i??(t[n]=a),n++}}return[e[0],...t,this.outputDim]}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);return n.dtype!==`int32`&&(n=ah(n,`int32`)),U(vh(this.embeddings.read(),U(n,[n.size])),q(this.computeOutputShape(n.shape)))})}getConfig(){let e={inputDim:this.inputDim,outputDim:this.outputDim,embeddingsInitializer:Xh(this.embeddingsInitializer),embeddingsRegularizer:Ay(this.embeddingsRegularizer),activityRegularizer:Ay(this.activityRegularizer),embeddingsConstraint:Fg(this.embeddingsConstraint),maskZero:this.maskZero,inputLength:this.inputLength},t=super.getConfig();return Object.assign(e,t),e}};jb.className=`Embedding`,V(jb);var Mb=class extends J{constructor(e){super(e||{}),this.supportsMasking=!0}mergeFunction(e){throw new G}computeElementwiseOpOutputShape(e,t){if(e==null||t==null)return null;if(e.length<t.length)return this.computeElementwiseOpOutputShape(t,e);if(t.length===0)return e;let n=e.slice(0,e.length-t.length);for(let r=0;r<t.length;++r){let i=e[e.length-t.length+r],a=t[r];if(i==null||a==null||i<0||a<0)n.push(null);else if(i===1)n.push(a);else if(a===1)n.push(i);else{if(i!==a)throw new W(`Operands could not be broadcast together with shapes `+JSON.stringify(e)+` `+JSON.stringify(t));n.push(i)}}return n}build(e){if(Array.isArray(e)&&!Array.isArray(e[0])&&(e=[q(e)]),e=e,e.length<2)throw new W(`A merge layer should be called on an Array of at least 2 inputs. Got ${e.length} input(s).`);let t=[];for(let n of e)n!=null&&n[0]!==null&&t.push(n[0]);if(t=xm(t),t.length>1)throw new W(`Can not merge tensors with different batch sizes. Got tensors with shapes: ${JSON.stringify(e)}.`);let n=e[0]==null?null:e[0].slice(1);for(let t=1;t<e.length;++t){let r=e[t]==null?null:e[t].slice(1);n=this.computeElementwiseOpOutputShape(n,r)}let r=e.map(e=>e.length);e.indexOf(null)===-1&&xm(r).length===1?this.reshapeRequired=!1:this.reshapeRequired=!0}call(e,t){return A(()=>{if(e=e,this.reshapeRequired){let t=[],n=e.map(e=>e.rank);if(n.indexOf(null)===-1){let r=eh(n);for(let n of e){let e=n.rank;for(let t=0;t<r-e;++t)n=oh(n,1);t.push(n)}return this.mergeFunction(t)}else{let n=!1;for(let r of e){let e=r.rank;if(e==null){let e=r.shape,i=e[0],a=e.slice(1).concat([i]),o=U(r,[i].concat(Qm(e.slice(1))));o=P(o,[1,0]),o=U(o,a),t.push(o),n=!0}else if(e>1){let i=th(1,e).concat([0]);t.push(P(r,i)),n=!0}else t.push(r)}let r=this.mergeFunction(t),i=r.rank;if(n){if(i==null){let e=r.shape,t=e[e.length-1],n=[t].concat(e.slice(0,e.length-1));r=U(P(U(r,[-1,t]),[1,0]),n)}else if(i>1){let e=[i-1].concat(th(0,i-1));r=P(r,e)}}return r}}else return this.mergeFunction(e)})}computeOutputShape(e){e=e;let t;t=e[0]==null?null:e[0].slice(1);for(let n=1;n<e.length;++n){let r=e[n]==null?null:e[n].slice(1);t=this.computeElementwiseOpOutputShape(t,r)}let n=[];for(let t of e)t!=null&&t[0]!==null&&n.push(t[0]);return n=xm(n),t=n.length===1?n.concat(t):[null].concat(t),t}computeMask(e,t){return A(()=>{if(t==null)return null;if(!Array.isArray(t))throw new W("`mask` should be an Array");if(!Array.isArray(e))throw new W("`inputs` should be an Array");if(t.length!==e.length)throw new W(`The Array 'inputs' and 'mask' are expected to have the same length, but have different lengths (${e.length} vs ${t.length})`);if(t.every(e=>e==null))return null;t=t.map(e=>e==null?e:Cl(e,0));let n=t[0];for(let e=1;e<t.length-1;++e)n=$r(n,t[e]);return n})}},Nb=class extends Mb{constructor(e){super(e)}mergeFunction(e){return A(()=>{let t=e[0].clone();for(let n=1;n<e.length;++n)t=I(t,e[n]);return t})}};Nb.className=`Add`,V(Nb);var Pb=class extends Mb{constructor(e){super(e)}mergeFunction(e){return A(()=>{let t=e[0].clone();for(let n=1;n<e.length;++n)t=z(t,e[n]);return t})}};Pb.className=`Multiply`,V(Pb);var Fb=class extends Mb{constructor(e){super(e)}mergeFunction(e){return A(()=>{let t=e[0].clone();for(let n=1;n<e.length;++n)t=I(t,e[n]);return z(1/e.length,t)})}};Fb.className=`Average`,V(Fb);var Ib=class extends Mb{constructor(e){super(e)}mergeFunction(e){return A(()=>{let t=e[0];for(let n=1;n<e.length;++n)t=Ue(t,e[n]);return t})}};Ib.className=`Maximum`,V(Ib);var Lb=class extends Mb{constructor(e){super(e)}mergeFunction(e){return A(()=>{let t=e[0];for(let n=1;n<e.length;++n)t=_(t,e[n]);return t})}};Lb.className=`Minimum`,V(Lb);var Rb=class extends Mb{constructor(e){super(e),this.DEFAULT_AXIS=-1,e??={},this.axis=e.axis==null?this.DEFAULT_AXIS:e.axis,this.supportsMasking=!0,this.reshapeRequired=!1}build(e){if(!(Array.isArray(e)&&Array.isArray(e[0]))||e.length===1)throw new W("A `Concatenate` layer should be called on a list of at least 2 inputs");e=e;let t=!0;for(let n of e)if(n!=null){t=!1;break}if(t)return;let n=[];for(let t=0;t<e.length;++t){let r=e[t].slice();r.splice(this.axis,1);let i=!1;for(let e of n)if(qn(e,r)){i=!0;break}i||n.push(r)}if(n.length>1)throw new W("A `Concatenate` layer requires inputs with matching shapes except for the concat axis. Got input shapes: "+JSON.stringify(e))}mergeFunction(e){return A(()=>ph(e,this.axis))}computeOutputShape(e){if(!(Array.isArray(e)&&Array.isArray(e[0])))throw new W("A `Concatenate` layer should be called on a list of inputs.");let t=e,n=t[0].slice(),r=this.axis<0?n.length+this.axis:this.axis;for(let e of t.slice(1)){if(n[r]==null||e[r]==null){n[r]=null;break}n[r]+=e[r]}return n}computeMask(e,t){if(t==null)return null;if(!Array.isArray(t))throw new W("`mask` should be an array for Concatenate");if(!Array.isArray(e))throw new W("`inputs` should be an array for Concatenate");if(t.length!==e.length)throw new W(`Mismatch in the length of mask (${t.length}) and the legnth of inputs (${e.length})`);return A(()=>{let n=!0;if(t.forEach(e=>{if(e!=null){n=!1;return}}),n)return null;let r=[];for(let n=0;n<e.length;++n)t[n]==null?r.push(F(mr(e[n]),`bool`)):t[n].rank<e[n].rank?r.push(Cl(t[n],-1)):r.push(t[n]);return Wi(_t(r,this.axis),-1,!1)})}getConfig(){let e={axis:this.axis},t=super.getConfig();return Object.assign(e,t),e}};Rb.className=`Concatenate`,V(Rb);function zb(e,t){for(;e<0;)e+=t;return e}function Bb(e,t,n){if(e.shape.length>3||t.shape.length>3)throw new G(`batchDot is not implemented for tensors of 4D or higher rank yet`);if(o(e.shape.length>=2,()=>`batchDot requires the rank of x to be >= 2, but got ${e.shape.length}`),o(e.shape.length>=2,()=>`batchDot requires the rank of y to be >= 2, but got ${t.shape.length}`),typeof n==`number`&&(n=[n,n]),e.dtype===`complex64`||t.dtype===`complex64`)throw new G(`batchDot is not implemented for complex64-type Tensors yet.`);let r=e.shape.length,i=t.shape.length;n??=[r-1,i-2];let a=n;return A(()=>{let n;if(r>i){n=r-i;let e=[];for(let t=0;t<n;++t)e.push(1);t=U(t,t.shape.concat(e))}else if(i>r){n=i-r;let t=[];for(let e=0;e<n;++e)t.push(1);e=U(e,e.shape.concat(t))}else n=0;let o;if(e.shape.length===2&&t.shape.length===2)o=a[0]===a[1]?O(z(e,t),a[0]):O(z(P(e,[1,0]),t),a[1]);else{let n=a[0]!==e.shape.length-1,r=a[1]===t.shape.length-1;o=Ve(e,t,n,r)}if(n>0){let e;e=r>i?r+i-3:r-1;let t=[];for(let r=e;r<e+n;++r)t.push(r);o=Ie(o,t)}return o.shape.length===1&&(o=Cl(o,1)),o})}var Vb=class extends Mb{constructor(e){super(e),this.axes=e.axes,this.normalize=e.normalize!=null&&e.normalize,this.supportsMasking=!0,this.reshapeRequired=!1}build(e){o(Array.isArray(e)&&e.length===2&&Array.isArray(e[0])&&Array.isArray(e[1]),()=>"A `Dot` layer should be called on a list of exactly 2 inputs.");let t=e[0],n=e[1];if(t.length>3||n.length>3)throw new G(`Dot layer does not support tensors of 4D or higher rank yet.`);let r=this.interpretAxes(t,n);if(t[r[0]]!==n[r[1]])throw new W(`Dimension incompatibility: ${t[r[0]]} !== ${n[r[1]]}`)}mergeFunction(e){if(e.length!==2)throw new W(`A \`Dot\` layer must be called on exactly 2 inputs, but received ${e.length} input(s).`);let t=e[0],n=e[1],r;return r=Array.isArray(this.axes)?this.axes.map((t,n)=>zb(t,e[n].shape.length)):[zb(this.axes,t.shape.length),zb(this.axes,n.shape.length)],this.normalize&&(t=__(t,r[0]),n=__(n,r[1])),Bb(t,n,r)}interpretAxes(e,t){let n;return n=Array.isArray(this.axes)?this.axes:[zb(this.axes,e.length),zb(this.axes,t.length)],n}computeOutputShape(e){o(Array.isArray(e)&&e.length===2&&Array.isArray(e[0])&&Array.isArray(e[1]),()=>"A `Dot` layer should be called on a list of exactly 2 inputs.");let t=e[0].slice(),n=e[1].slice();if(t.length>3||n.length>3)throw new G(`Dot layer does not support tensors of 4D or higher rank yet.`);let r=this.interpretAxes(t,n);t.splice(r[0],1),n.splice(r[1],1),n.splice(0,1);let i=t.concat(n);return i.length===1&&i.push(1),i}computeMask(e,t){return null}getConfig(){let e={axes:this.axes,normalize:this.normalize},t=super.getConfig();return Object.assign(e,t),e}};Vb.className=`Dot`,V(Vb);var Hb=class extends J{constructor(e){super(e),this.supportsMasking=!0,this.stddev=e.stddev}computeOutputShape(e){return e}getConfig(){let e=super.getConfig(),t={stddev:this.stddev};return Object.assign(t,e),t}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);return Eh(()=>I(gh(n.shape,0,this.stddev),n),()=>n,t.training||!1)})}};Hb.className=`GaussianNoise`,V(Hb);var Ub=class extends J{constructor(e){super(e),this.supportsMasking=!0,this.rate=e.rate}computeOutputShape(e){return e}getConfig(){let e=super.getConfig(),t={rate:this.rate};return Object.assign(t,e),t}call(e,t){return A(()=>{this.invokeCallHook(e,t);let n=K(e);return this.rate>0&&this.rate<1?Eh(()=>{let e=Math.sqrt(this.rate/(1-this.rate));return z(n,gh(n.shape,1,e))},()=>n,t.training||!1):n})}};Ub.className=`GaussianDropout`,V(Ub);var Wb=class extends J{constructor(e){super(e),this.supportsMasking=!0,this.rate=e.rate,this.noiseShape=e.noiseShape}_getNoiseShape(e){return this.noiseShape||K(e).shape}computeOutputShape(e){return e}getConfig(){let e=super.getConfig(),t={rate:this.rate};return Object.assign(t,e),t}call(e,t){return A(()=>{if(this.rate<1&&this.rate>0){let n=this._getNoiseShape(e);return Eh(()=>{let t=K(e),r=-1.6732632423543772*1.0507009873554805,i=_s(pc(n),this.rate);i=ah(i,`float32`);let a=((1-this.rate)*(1+this.rate*r**2))**-.5,o=-a*r*this.rate;return I(z(I(z(t,i),z(I(i,-1),r)),a),o)},()=>K(e),t.training||!1)}return e})}};Wb.className=`AlphaDropout`,V(Wb);function Gb(e,t,n,r,i,a=.001){let o;if(e.rank===2)o=Tn(e,t,n,r,i,a);else if(e.rank===3)o=ye(e,t,n,r,i,a);else if(e.rank===4)o=Ae(e,t,n,r,i,a);else throw new G(`batchNormalization is not implemented for array of rank ${e.rank} yet`);return o}function Kb(e,t,n,r,i=.001){return A(()=>{let a=xe(e,r),o=a.mean,s=a.variance;return[Gb(e,o,s,n,t,i),o,s]})}function qb(e,t,n,r,i=.001){return A(()=>{let a=xe(e,r),o=a.mean,s=a.variance,c=[];for(let t of th(0,e.rank))r.indexOf(t)===-1?c.push(e.shape[t]):c.push(1);let l=U(o,c),u=U(s,c),d=t==null?null:U(t,c);return[Gb(e,l,u,n==null?null:U(n,c),d,i),o,s]})}function Jb(e,t,n,r,i=.001){return qn(r.slice().sort(),th(0,e.rank-1))?Kb(e,t,n,r,i):qb(e,t,n,r,i)}var Yb=class extends J{constructor(e){e??={},super(e),this.supportsMasking=!0,this.axis=e.axis==null?-1:e.axis,this.momentum=e.momentum==null?.99:e.momentum,this.epsilon=e.epsilon==null?.001:e.epsilon,this.center=e.center==null||e.center,this.scale=e.scale==null||e.scale,this.betaInitializer=Zh(e.betaInitializer||`zeros`),this.gammaInitializer=Zh(e.gammaInitializer||`ones`),this.movingMeanInitializer=Zh(e.movingMeanInitializer||`zeros`),this.movingVarianceInitializer=Zh(e.movingVarianceInitializer||`ones`),this.betaConstraint=Lg(e.betaConstraint),this.gammaConstraint=Lg(e.gammaConstraint),this.betaRegularizer=My(e.betaRegularizer),this.gammaRegularizer=My(e.gammaRegularizer)}build(e){e=q(e);let t=this.axis>=0?this.axis:this.axis+e.length,n=e[t];if(n==null)throw new W(`Axis ${t} of input tensor should have a defined dimension but the layer received an input with shape ${JSON.stringify(e)}.`);this.inputSpec=[new og({ndim:e.length,axes:{[t]:n}})];let r=[n];this.scale&&(this.gamma=this.addWeight(`gamma`,r,null,this.gammaInitializer,this.gammaRegularizer,!0,this.gammaConstraint)),this.center&&(this.beta=this.addWeight(`beta`,r,null,this.betaInitializer,this.betaRegularizer,!0,this.betaConstraint)),this.movingMean=this.addWeight(`moving_mean`,r,null,this.movingMeanInitializer,null,!1),this.movingVariance=this.addWeight(`moving_variance`,r,null,this.movingVarianceInitializer,null,!1),this.built=!0}call(e,t){return A(()=>{let n=t.training!=null&&t.training,r=K(e),i=r.shape,a=i.length,o=th(0,a),s=this.axis>=0?this.axis:this.axis+a;o.splice(s,1);let c=cm(1,a);c[s]=i[s];let l=o.slice();l.sort();let u=!qn(l,th(0,a).slice(0,a-1)),d=()=>{if(u){let e=U(this.movingMean.read(),c),t=U(this.movingVariance.read(),c),n=this.center?U(this.beta.read(),c):null,i=this.scale?U(this.gamma.read(),c):null;return Gb(r,e,t,n,i,this.epsilon)}else return Gb(r,this.movingMean.read(),this.movingVariance.read(),this.beta==null?null:this.beta.read(),this.gamma==null?null:this.gamma.read(),this.epsilon)};if(!n)return d();let[f,p,m]=Jb(r,this.gamma.read(),this.beta.read(),o,this.epsilon),h=(e,t,n)=>{A(()=>{let r=1-n,i=e.read(),a=z(L(i,t),r);e.write(L(i,a))})};return h(this.movingMean,p,this.momentum),h(this.movingVariance,m,this.momentum),f})}getConfig(){let e={axis:this.axis,momentum:this.momentum,epsilon:this.epsilon,center:this.center,scale:this.scale,betaInitializer:Xh(this.betaInitializer),gammaInitializer:Xh(this.gammaInitializer),movingMeanInitializer:Xh(this.movingMeanInitializer),movingVarianceInitializer:Xh(this.movingVarianceInitializer),betaRegularizer:Ay(this.betaRegularizer),gammaRegularizer:Ay(this.gammaRegularizer),betaConstraint:Fg(this.betaConstraint),gammaConstraint:Fg(this.gammaConstraint)},t=super.getConfig();return Object.assign(e,t),e}};Yb.className=`BatchNormalization`,V(Yb);var Xb=class extends J{constructor(e){if(e??={},super(e),this.axis=e.axis==null?-1:e.axis,typeof this.axis==`number`){if(!Number.isInteger(this.axis))throw Error(`Expected axis to be an integer, but received ${this.axis}`)}else if(Array.isArray(this.axis)){for(let e of this.axis)if(!Number.isInteger(e))throw Error(`Expected axis to be an array of integers, but received ${JSON.stringify(this.axis)}`)}else throw Error(`Expected axis to be an integer or an array of integers, but received ${JSON.stringify(this.axis)}`);this.epsilon=e.epsilon==null?.001:e.epsilon,this.center=e.center==null||e.center,this.scale=e.scale==null||e.scale,this.betaInitializer=Zh(e.betaInitializer||`zeros`),this.gammaInitializer=Zh(e.gammaInitializer||`ones`),this.betaRegularizer=My(e.betaRegularizer),this.gammaRegularizer=My(e.gammaRegularizer),this.supportsMasking=!0}build(e){e=q(e);let t=e.length;typeof this.axis==`number`&&(this.axis=[this.axis]);for(let e=0;e<this.axis.length;++e)this.axis[e]<0&&(this.axis[e]+=t);for(let e of this.axis)if(e<0||e>=t)throw Error(`Invalid axis: ${e}`);if(this.axis.length!==xm(this.axis).length)throw Error(`Found duplicate axes in: ${this.axis}`);let n=this.axis.map(t=>e[t]);this.scale?this.gamma=this.addWeight(`gamma`,n,`float32`,this.gammaInitializer,this.gammaRegularizer,!0):this.gamma=null,this.center?this.beta=this.addWeight(`beta`,n,`float32`,this.betaInitializer,this.betaRegularizer,!0):this.beta=null,this.built=!0}call(e,t){let n=K(e),r=n.shape,i=r.length;return A(()=>{let{mean:e,variance:t}=xe(n,this.axis,!0),a=cm(1,i);for(let e of this.axis)a[e]=r[e];let o=e=>e!=null&&e.shape.length!==i?U(e,a):e,s=this.scale?o(this.gamma.read()):null,c=this.center?o(this.beta.read()):null,l=[],u=[];for(let e=0;e<i;++e)this.axis.indexOf(e)===-1?(l.push(1),u.push(r[e])):(l.push(r[e]),u.push(1));return e=Nl(e,l),t=Nl(t,l),s!=null&&(s=Nl(s,u)),c!=null&&(c=Nl(c,u)),Gb(n,e,t,c,s,this.epsilon)})}getConfig(){let e={axis:this.axis,epsilon:this.epsilon,center:this.center,scale:this.scale,betaInitializer:Xh(this.betaInitializer),gammaInitializer:Xh(this.gammaInitializer),betaRegularizer:Ay(this.betaRegularizer),gammaRegularizer:Ay(this.gammaRegularizer)},t=super.getConfig();return Object.assign(e,t),e}};Xb.className=`LayerNormalization`,V(Xb);function Zb(e,t,n){return A(()=>{if(e.rank!==4)throw new W(`temporalPadding expects input tensor to be 4-D, but received a ${e.rank}-D tensor.`);if(t??=[[1,1],[1,1]],t.length!==2||t[0].length!==2||t[1].length!==2)throw new W("spatial2dPadding expects `padding` to be an Array of two Arrays, each of which is an Array of two integers.");if(n??=ih(),n!==`channelsLast`&&n!==`channelsFirst`)throw new W(`Unknown data format: ${n}. Supported data formats are 'channelsLast' and 'channelsFirst.`);let r;return r=n===`channelsFirst`?[[0,0],[0,0],t[0],t[1]]:[[0,0],t[0],t[1],[0,0]],aa(e,r)})}var Qb=class extends J{constructor(e){if(e??={},super(e),this.dataFormat=e.dataFormat==null?ih():e.dataFormat,e.padding==null)this.padding=[[1,1],[1,1]];else if(typeof e.padding==`number`)this.padding=[[e.padding,e.padding],[e.padding,e.padding]];else{if(e.padding=e.padding,e.padding.length!==2)throw new W(`ZeroPadding2D expects padding to be a length-2 array, but received a length-${e.padding.length} array.`);let t,n;if(typeof e.padding[0]==`number`)t=[e.padding[0],e.padding[0]],n=[e.padding[1],e.padding[1]];else{if(e.padding=e.padding,e.padding[0].length!==2)throw new W(`ZeroPadding2D expects height padding to be a length-2 array, but received a length-${e.padding[0].length} array.`);if(t=e.padding[0],e.padding[1].length!==2)throw new W(`ZeroPadding2D expects width padding to be a length-2 array, but received a length-${e.padding[1].length} array.`);n=e.padding[1]}this.padding=[t,n]}this.inputSpec=[new og({ndim:4})]}computeOutputShape(e){e=q(e);let t,n;return this.dataFormat===`channelsFirst`?(t=e[2]!=null&&e[2]>=0?e[2]+this.padding[0][0]+this.padding[0][1]:null,n=e[3]!=null&&e[3]>=0?e[3]+this.padding[1][0]+this.padding[1][1]:null,[e[0],e[1],t,n]):(t=e[1]!=null&&e[1]>=0?e[1]+this.padding[0][0]+this.padding[0][1]:null,n=e[2]!=null&&e[2]>=0?e[2]+this.padding[1][0]+this.padding[1][1]:null,[e[0],t,n,e[3]])}call(e,t){return A(()=>Zb(K(e),this.padding,this.dataFormat))}getConfig(){let e={padding:this.padding,dataFormat:this.dataFormat},t=super.getConfig();return Object.assign(e,t),e}};Qb.className=`ZeroPadding2D`,V(Qb);function $b(e,t,n,r,i,a){return A(()=>{zm(i),Hm(a),Vm(r),n??=[1,1],r??=`valid`,i??=ih(),a??=`max`,e=Hy(e,i);let o,s=r===`same`?`same`:`valid`;return o=a===`max`?ir(e,t,n,s):nr(e,t,n,s),i===`channelsFirst`&&(o=P(o,[0,3,1,2])),o})}function ex(e,t,n,r,i,a){return A(()=>{zm(i),Hm(a),Vm(r),n??=[1,1,1],r??=`valid`,i??=ih(),a??=`max`,e=Uy(e,i);let o,s=r===`same`?`same`:`valid`;return o=a===`max`?Yt(e,t,n,s):qt(e,t,n,s),i===`channelsFirst`&&(o=P(o,[0,4,1,2,3])),o})}var tx=class extends J{constructor(e){if(e.poolSize??=2,super(e),typeof e.poolSize==`number`)this.poolSize=[e.poolSize];else if(Array.isArray(e.poolSize)&&e.poolSize.length===1&&typeof e.poolSize[0]==`number`)this.poolSize=e.poolSize;else throw new W(`poolSize for 1D convolutional layer must be a number or an Array of a single number, but received ${JSON.stringify(e.poolSize)}`);if(Tm(this.poolSize,`poolSize`),e.strides==null)this.strides=this.poolSize;else if(typeof e.strides==`number`)this.strides=[e.strides];else if(Array.isArray(e.strides)&&e.strides.length===1&&typeof e.strides[0]==`number`)this.strides=e.strides;else throw new W(`strides for 1D convolutional layer must be a number or an Array of a single number, but received ${JSON.stringify(e.strides)}`);Tm(this.strides,`strides`),this.padding=e.padding==null?`valid`:e.padding,Vm(this.padding),this.inputSpec=[new og({ndim:3})]}computeOutputShape(e){e=q(e);let t=By(e[1],this.poolSize[0],this.padding,this.strides[0]);return[e[0],t,e[2]]}call(e,t){return A(()=>(this.invokeCallHook(e,t),e=oh(K(e),2),Ie(this.poolingFunction(K(e),[this.poolSize[0],1],[this.strides[0],1],this.padding,`channelsLast`),[2])))}getConfig(){let e={poolSize:this.poolSize,padding:this.padding,strides:this.strides},t=super.getConfig();return Object.assign(e,t),e}},nx=class extends tx{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),$b(e,t,n,r,i,`max`)}};nx.className=`MaxPooling1D`,V(nx);var rx=class extends tx{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),$b(e,t,n,r,i,`avg`)}};rx.className=`AveragePooling1D`,V(rx);var ix=class extends J{constructor(e){if(e.poolSize??=[2,2],super(e),this.poolSize=Array.isArray(e.poolSize)?e.poolSize:[e.poolSize,e.poolSize],e.strides==null)this.strides=this.poolSize;else if(Array.isArray(e.strides)){if(e.strides.length!==2)throw new W(`If the strides property of a 2D pooling layer is an Array, it is expected to have a length of 2, but received length ${e.strides.length}.`);this.strides=e.strides}else this.strides=[e.strides,e.strides];Tm(this.poolSize,`poolSize`),Tm(this.strides,`strides`),this.padding=e.padding==null?`valid`:e.padding,this.dataFormat=e.dataFormat==null?`channelsLast`:e.dataFormat,zm(this.dataFormat),Vm(this.padding),this.inputSpec=[new og({ndim:4})]}computeOutputShape(e){e=q(e);let t=this.dataFormat===`channelsFirst`?e[2]:e[1],n=this.dataFormat===`channelsFirst`?e[3]:e[2];return t=By(t,this.poolSize[0],this.padding,this.strides[0]),n=By(n,this.poolSize[1],this.padding,this.strides[1]),this.dataFormat===`channelsFirst`?[e[0],e[1],t,n]:[e[0],t,n,e[3]]}call(e,t){return A(()=>(this.invokeCallHook(e,t),this.poolingFunction(K(e),this.poolSize,this.strides,this.padding,this.dataFormat)))}getConfig(){let e={poolSize:this.poolSize,padding:this.padding,strides:this.strides,dataFormat:this.dataFormat},t=super.getConfig();return Object.assign(e,t),e}},ax=class extends ix{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),$b(e,t,n,r,i,`max`)}};ax.className=`MaxPooling2D`,V(ax);var ox=class extends ix{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),$b(e,t,n,r,i,`avg`)}};ox.className=`AveragePooling2D`,V(ox);var sx=class extends J{constructor(e){if(e.poolSize??=[2,2,2],super(e),this.poolSize=Array.isArray(e.poolSize)?e.poolSize:[e.poolSize,e.poolSize,e.poolSize],e.strides==null)this.strides=this.poolSize;else if(Array.isArray(e.strides)){if(e.strides.length!==3)throw new W(`If the strides property of a 3D pooling layer is an Array, it is expected to have a length of 3, but received length ${e.strides.length}.`);this.strides=e.strides}else this.strides=[e.strides,e.strides,e.strides];Tm(this.poolSize,`poolSize`),Tm(this.strides,`strides`),this.padding=e.padding==null?`valid`:e.padding,this.dataFormat=e.dataFormat==null?`channelsLast`:e.dataFormat,zm(this.dataFormat),Vm(this.padding),this.inputSpec=[new og({ndim:5})]}computeOutputShape(e){e=q(e);let t=this.dataFormat===`channelsFirst`?e[2]:e[1],n=this.dataFormat===`channelsFirst`?e[3]:e[2],r=this.dataFormat===`channelsFirst`?e[4]:e[3];return t=By(t,this.poolSize[0],this.padding,this.strides[0]),n=By(n,this.poolSize[1],this.padding,this.strides[1]),r=By(r,this.poolSize[2],this.padding,this.strides[2]),this.dataFormat===`channelsFirst`?[e[0],e[1],t,n,r]:[e[0],t,n,r,e[4]]}call(e,t){return A(()=>(this.invokeCallHook(e,t),this.poolingFunction(K(e),this.poolSize,this.strides,this.padding,this.dataFormat)))}getConfig(){let e={poolSize:this.poolSize,padding:this.padding,strides:this.strides,dataFormat:this.dataFormat},t=super.getConfig();return Object.assign(e,t),e}},cx=class extends sx{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),ex(e,t,n,r,i,`max`)}};cx.className=`MaxPooling3D`,V(cx);var lx=class extends sx{constructor(e){super(e)}poolingFunction(e,t,n,r,i){return zm(i),Vm(r),ex(e,t,n,r,i,`avg`)}};lx.className=`AveragePooling3D`,V(lx);var ux=class extends J{constructor(e){super(e),this.inputSpec=[new og({ndim:3})]}computeOutputShape(e){return[e[0],e[2]]}call(e,t){throw new G}},dx=class extends ux{constructor(e){super(e||{})}call(e,t){return A(()=>Rn(K(e),1))}};dx.className=`GlobalAveragePooling1D`,V(dx);var fx=class extends ux{constructor(e){super(e||{})}call(e,t){return A(()=>Ro(K(e),1))}};fx.className=`GlobalMaxPooling1D`,V(fx);var px=class extends J{constructor(e){super(e),this.dataFormat=e.dataFormat==null?`channelsLast`:e.dataFormat,zm(this.dataFormat),this.inputSpec=[new og({ndim:4})]}computeOutputShape(e){return e=e,this.dataFormat===`channelsLast`?[e[0],e[3]]:[e[0],e[1]]}call(e,t){throw new G}getConfig(){let e={dataFormat:this.dataFormat},t=super.getConfig();return Object.assign(e,t),e}},mx=class extends px{call(e,t){return A(()=>{let t=K(e);return this.dataFormat===`channelsLast`?Rn(t,[1,2]):Rn(t,[2,3])})}};mx.className=`GlobalAveragePooling2D`,V(mx);var hx=class extends px{call(e,t){return A(()=>{let t=K(e);return this.dataFormat===`channelsLast`?Ro(t,[1,2]):Ro(t,[2,3])})}};hx.className=`GlobalMaxPooling2D`,V(hx);var gx=class extends J{constructor(e){super(e),this.layer=e.layer}build(e){this.built=!0}get trainable(){return this.layer!=null&&this.layer.trainable}set trainable(e){this.layer!=null&&(this.layer.trainable=e)}get trainableWeights(){return this.layer.trainableWeights}get nonTrainableWeights(){return this.layer.nonTrainableWeights}get updates(){return this.layer._updates}get losses(){return this.layer.losses}getWeights(){return this.layer.getWeights()}setWeights(e){this.layer.setWeights(e)}getConfig(){let e={layer:{className:this.layer.getClassName(),config:this.layer.getConfig()}},t=super.getConfig();return Object.assign(e,t),e}setFastWeightInitDuringBuild(e){super.setFastWeightInitDuringBuild(e),this.layer!=null&&this.layer.setFastWeightInitDuringBuild(e)}static fromConfig(e,t,n={}){let r=t.layer,i=g_(r,n);delete t.layer;let a={layer:i};return Object.assign(a,t),new e(a)}},_x=class extends gx{constructor(e){super(e),this.supportsMasking=!0}build(e){if(e=q(e),e.length<3)throw new W(`TimeDistributed layer expects an input shape >= 3D, but received input shape ${JSON.stringify(e)}`);this.inputSpec=[{shape:e}];let t=[e[0]].concat(e.slice(2));this.layer.built||(this.layer.build(t),this.layer.built=!0),super.build(e)}computeOutputShape(e){e=q(e);let t=[e[0]].concat(e.slice(2)),n=this.layer.computeOutputShape(t),r=e[1];return[n[0],r].concat(n.slice(1))}call(e,t){return A(()=>(e=K(e),sb((e,n)=>[K(this.layer.call(e,t)),[]],e,[],!1,null,null,!1,!0)[1]))}};_x.className=`TimeDistributed`,V(_x);function vx(e){Cm(Lm,`BidirectionalMergeMode`,e)}var yx=`concat`,bx=class extends gx{constructor(e){super(e);let t=e.layer.getConfig(),n={};n.className=e.layer.getClassName(),n.config=t,this.forwardLayer=g_(n),t.goBackwards=t.goBackwards!==!0;let r={};if(r.className=e.layer.getClassName(),r.config=t,this.backwardLayer=g_(r),this.forwardLayer.name=`forward_`+this.forwardLayer.name,this.backwardLayer.name=`backward_`+this.backwardLayer.name,this.mergeMode=e.mergeMode===void 0?yx:e.mergeMode,vx(this.mergeMode),e.weights)throw new G(`weights support is not implemented for Bidirectional layer yet.`);this._stateful=e.layer.stateful,this.returnSequences=e.layer.returnSequences,this.returnState=e.layer.returnState,this.supportsMasking=!0,this._trainable=!0,this.inputSpec=e.layer.inputSpec,this.numConstants=null}get trainable(){return this._trainable}set trainable(e){this._trainable=e,this.forwardLayer!=null&&(this.forwardLayer.trainable=e),this.backwardLayer!=null&&(this.backwardLayer.trainable=e)}getWeights(){return this.forwardLayer.getWeights().concat(this.backwardLayer.getWeights())}setWeights(e){let t=e.length,n=Math.floor(t/2);this.forwardLayer.setWeights(e.slice(0,n)),this.backwardLayer.setWeights(e.slice(n))}computeOutputShape(e){let t=this.forwardLayer.computeOutputShape(e);Array.isArray(t)&&Array.isArray(t[0])||(t=[t]),t=t;let n,r,i;return this.returnState&&(i=t.slice(1)),n=t[0],n=n,this.mergeMode===`concat`?(n[n.length-1]*=2,r=[n]):r=this.mergeMode==null?[n,n.slice()]:[n],this.returnState?this.mergeMode==null?r.concat(i).concat(i.slice()):[n].concat(i,i.slice()):dm(r)}apply(e,t){let n=t==null?null:t.initialState,r=t==null?null:t.constants;t??={};let i=ob(e,n,r,this.numConstants);if(e=i.inputs,n=i.initialState,r=i.constants,Array.isArray(e)&&(n=e.slice(1),e=e[0]),(n==null||n.length===0)&&r==null)return super.apply(e,t);let a=[],o=[];if(n!=null){let e=n.length;if(e%2>0)throw new W("When passing `initialState` to a Bidrectional RNN, the state should be an Array containing the states of the underlying RNNs.");t.initialState=n,a.push(...n);let r=n.map(e=>new og({shape:e.shape}));this.forwardLayer.stateSpec=r.slice(0,e/2),this.backwardLayer.stateSpec=r.slice(e/2),o.push(...r)}if(r!=null)throw new G(`Support for constants in Bidirectional layers is not implemented yet.`);let s=a[0]instanceof sg;for(let e of a)if(e instanceof sg!==s)throw new W(`The initial state of a Bidirectional layer cannot be specified as a mix of symbolic and non-symbolic tensors`);if(s){let n=[e].concat(a),r=this.inputSpec.concat(o),i=this.inputSpec;this.inputSpec=r;let s=super.apply(n,t);return this.inputSpec=i,s}else return super.apply(e,t)}call(e,t){return A(()=>{let n=t.initialState,r,i;if(n==null)r=this.forwardLayer.call(e,t),i=this.backwardLayer.call(e,t);else{let a=n.slice(0,n.length/2),o=n.slice(n.length/2);r=this.forwardLayer.call(e,Object.assign(t,{initialState:a})),i=this.backwardLayer.call(e,Object.assign(t,{initialState:o}))}let a;this.returnState&&(Array.isArray(r)&&(a=r.slice(1).concat(i.slice(1))),r=r[0],i=i[0]),this.returnSequences&&(i=pi(i,1));let o;return this.mergeMode===`concat`?o=ph([r,i]):this.mergeMode===`sum`?o=I(r,i):this.mergeMode===`ave`?o=z(.5,I(r,i)):this.mergeMode===`mul`?o=z(r,i):this.mergeMode??(o=[r,i]),this.returnState?this.mergeMode==null?o.concat(a):[o].concat(a):o})}resetStates(e){this.forwardLayer.resetStates(),this.backwardLayer.resetStates()}build(e){Gm(this.forwardLayer.name,()=>{this.forwardLayer.build(e)}),Gm(this.backwardLayer.name,()=>{this.backwardLayer.build(e)}),this.built=!0}computeMask(e,t){Array.isArray(t)&&(t=t[0]);let n;if(n=this.returnSequences?this.mergeMode==null?[t,t]:t:this.mergeMode==null?[null,null]:null,this.returnState){let e=this.forwardLayer.states.map(e=>null);return Array.isArray(n)?n.concat(e).concat(e):[n].concat(e,e)}else return n}get trainableWeights(){return this.forwardLayer.trainableWeights.concat(this.backwardLayer.trainableWeights)}get nonTrainableWeights(){return this.forwardLayer.nonTrainableWeights.concat(this.backwardLayer.nonTrainableWeights)}setFastWeightInitDuringBuild(e){super.setFastWeightInitDuringBuild(e),this.forwardLayer!=null&&this.forwardLayer.setFastWeightInitDuringBuild(e),this.backwardLayer!=null&&this.backwardLayer.setFastWeightInitDuringBuild(e)}getConfig(){let e={mergeMode:this.mergeMode},t=super.getConfig();return Object.assign(e,t),e}static fromConfig(e,t){let n=g_(t.layer);if(delete t.layer,t.numConstants!=null)throw new G(`Deserialization of a Bidirectional layer with numConstants present is not supported yet.`);let r=t;return r.layer=n,new e(r)}};bx.className=`Bidirectional`,V(bx);var xx=class extends J{constructor(e){super(e),this.scale=e.scale,e.offset?this.offset=e.offset:this.offset=0}getConfig(){let e={scale:this.scale,offset:this.offset},t=super.getConfig();return Object.assign(e,t),e}call(e,t){return A(()=>(e=K(e),e.dtype!==`float32`&&(e=ah(e,`float32`)),I(z(e,this.scale),this.offset)))}};xx.className=`Rescaling`,V(xx);var{resizeBilinear:Sx,cropAndResize:Cx}=oe,wx=class extends J{constructor(e){super(e),this.height=e.height,this.width=e.width}centerCrop(e,t,n,r,i,a,o,s){return A(()=>{let c,l=!1,u=[t/a,n/o,(r+t)/a,(i+n)/o],d=[];e.rank===3?(l=!0,c=Or([e])):c=e;for(let e=0;e<c.shape[0];e++)d.push(u);let f=Ye(d,[d.length,4]),p=Pc(0,d.length,1,`int32`),m=Cx(c,f,p,[r,i],`nearest`);return ah(l?K(Vs(m)):m,s)})}upsize(e,t,n,r){return A(()=>ah(Sx(e,[t,n]),r))}call(e,t){return A(()=>{let t=K(e),n=t.dtype,r=t.shape,i=r[r.length-3],a=r[r.length-2],o=0;i!==this.height&&(o=Math.floor((i-this.height)/2));let s=0;return a!==this.width&&(s=Math.floor((a-this.width)/2),s===0&&(s=1)),o>=0&&s>=0?this.centerCrop(t,o,s,this.height,this.width,i,a,n):this.upsize(e,this.height,this.width,n)})}getConfig(){let e={height:this.height,width:this.width},t=super.getConfig();return Object.assign(e,t),e}computeOutputShape(e){e=q(e);let t=e.length-3,n=e.length-2;return e[t]=this.height,e[n]=this.width,e}};wx.className=`CenterCrop`,V(wx);function Tx(e,t,n,r){let i=K(e);if(i.dtype!==`int32`&&(i=ah(i,`int32`)),t===`int`)return i;let a=i.shape;if(i.rank===0&&(i=Cl(i,-1)),t===`oneHot`&&i.shape[i.shape.length-1]!==1&&(i=Cl(i,-1)),i.rank>2)throw new W(`When outputMode is not int, maximum output rank is 2 Received outputMode ${t} and input shape ${a} which would result in output rank ${i.rank}.`);let o=[`multiHot`,`oneHot`].includes(t),s=i,c;if(c=r!==void 0&&t===`count`?dc(s,r,n,o):dc(s,[],n,o),t!==`tfIdf`)return c;if(r)return z(c,r);throw new W(`When outputMode is 'tfIdf', weights must be provided.`)}var Ex=class extends J{constructor(e){super(e),this.numTokens=e.numTokens,e.outputMode?this.outputMode=e.outputMode:this.outputMode=`multiHot`}getConfig(){let e={numTokens:this.numTokens,outputMode:this.outputMode},t=super.getConfig();return Object.assign(e,t),e}computeOutputShape(e){return e=q(e),e==null?[this.numTokens]:this.outputMode===`oneHot`&&e[e.length-1]!==1?(e.push(this.numTokens),e):(e[e.length-1]=this.numTokens,e)}call(e,t){return A(()=>{e=K(e),e.dtype!==`int32`&&(e=ah(e,`int32`));let n;if(t.countWeights!==void 0){if(this.outputMode!==`count`)throw new W(`countWeights is not used when outputMode !== count.
              Received countWeights=${t.countWeights}`);n=K(t.countWeights)}let r=Ro(e),i=y(e),a=go(this.numTokens,r).bufferSync().get(0),o=_s(i,0).bufferSync().get(0);if(!(a&&o))throw new W(`Input values must be between 0 < values <= numTokens with numTokens=${this.numTokens}`);return Tx(e,this.outputMode,this.numTokens,n)})}};Ex.className=`CategoryEncoding`,V(Ex);var Dx=new Set([`bilinear`,`nearest`]),Ox=class extends J{constructor(e){if(super(e),this.height=e.height,this.width=e.width,e.interpolation)if(Dx.has(e.interpolation))this.interpolation=e.interpolation;else throw new W(`Invalid interpolation parameter: ${e.interpolation} is not implemented`);else this.interpolation=`bilinear`;this.cropToAspectRatio=!!e.cropToAspectRatio}computeOutputShape(e){e=q(e);let t=e[2];return[this.height,this.width,t]}getConfig(){let e={height:this.height,width:this.width,interpolation:this.interpolation,cropToAspectRatio:this.cropToAspectRatio},t=super.getConfig();return Object.assign(e,t),e}call(e,t){return A(()=>{let t=[this.height,this.width];if(this.interpolation===`bilinear`)return oe.resizeBilinear(e,t,!this.cropToAspectRatio);if(this.interpolation===`nearest`)return oe.resizeNearestNeighbor(e,t,!this.cropToAspectRatio);throw Error(`Interpolation is ${this.interpolation} but only ${[...Dx]} are supported`)})}};Ox.className=`Resizing`,V(Ox);var kx=class{constructor(e){this.seed=e}next(){if(this.seed!==void 0)return this.seed++}};kx.className=`RandomSeed`;var Ax=class extends J{constructor(e){super(e),this.randomGenerator=new kx(e.seed)}getConfig(){let e={seed:this.randomGenerator.seed},t=super.getConfig();return Object.assign(e,t),e}};Ax.className=`BaseRandomLayer`;var jx=new Set([`bilinear`,`nearest`]),Mx=class extends Ax{constructor(e){super(e);let{factor:t,interpolation:n=`bilinear`}=e;if(this.factor=t,Array.isArray(this.factor)&&this.factor.length===2)this.widthLower=this.factor[0],this.widthUpper=this.factor[1];else if(!Array.isArray(this.factor)&&this.factor>0)this.widthLower=-this.factor,this.widthUpper=this.factor;else throw new W(`Invalid factor: ${this.factor}. Must be positive number or tuple of 2 numbers`);if(this.widthLower<-1||this.widthUpper<-1)throw new W(`factor must have values larger than -1. Got: ${this.factor}`);if(this.widthUpper<this.widthLower)throw new W(`factor cannot have upper bound less than lower bound.
        Got upper bound: ${this.widthUpper}.
        Got lower bound: ${this.widthLower}
      `);if(n)if(jx.has(n))this.interpolation=n;else throw new W(`Invalid interpolation parameter: ${n} is not implemented`)}getConfig(){let e={factor:this.factor,interpolation:this.interpolation},t=super.getConfig();return Object.assign(e,t),e}computeOutputShape(e){e=q(e);let t=e[2];return[this.imgHeight,-1,t]}call(e,t){return A(()=>{let t=K(e);this.imgHeight=t.shape[t.shape.length-3];let n=t.shape[t.shape.length-2];this.widthFactor=pc([1],1+this.widthLower,1+this.widthUpper,`float32`,this.randomGenerator.next());let r=this.widthFactor.dataSync()[0]*n;r=Math.round(r);let i=[this.imgHeight,r];switch(this.interpolation){case`bilinear`:return oe.resizeBilinear(e,i);case`nearest`:return oe.resizeNearestNeighbor(e,i);default:throw Error(`Interpolation is ${this.interpolation}
          but only ${[...jx]} are supported`)}})}};Mx.className=`RandomWidth`,V(Mx);var Nx=e({Layer:()=>J,RNN:()=>cb,RNNCell:()=>lb,activation:()=>Xx,add:()=>aS,alphaDropout:()=>YS,average:()=>oS,averagePooling1d:()=>hS,averagePooling2d:()=>vS,averagePooling3d:()=>xS,avgPool1d:()=>gS,avgPool2d:()=>yS,avgPool3d:()=>SS,avgPooling1d:()=>_S,avgPooling2d:()=>bS,avgPooling3d:()=>CS,batchNormalization:()=>fS,bidirectional:()=>VS,categoryEncoding:()=>eC,centerCrop:()=>QS,concatenate:()=>sS,conv1d:()=>Vx,conv2d:()=>Hx,conv2dTranspose:()=>Ux,conv3d:()=>Wx,conv3dTranspose:()=>Gx,convLstm2d:()=>LS,convLstm2dCell:()=>RS,cropping2D:()=>qx,dense:()=>Zx,depthwiseConv2d:()=>Yx,dot:()=>dS,dropout:()=>Qx,elu:()=>Fx,embedding:()=>iS,flatten:()=>eS,gaussianDropout:()=>JS,gaussianNoise:()=>qS,globalAveragePooling1d:()=>wS,globalAveragePooling2d:()=>TS,globalMaxPool1d:()=>US,globalMaxPool2d:()=>WS,globalMaxPooling1d:()=>ES,globalMaxPooling2d:()=>DS,gru:()=>jS,gruCell:()=>MS,input:()=>ny,inputLayer:()=>Px,layerNormalization:()=>pS,leakyReLU:()=>Lx,lstm:()=>NS,lstmCell:()=>PS,masking:()=>XS,maxPool1d:()=>GS,maxPool2d:()=>KS,maxPooling1d:()=>OS,maxPooling2d:()=>kS,maxPooling3d:()=>AS,maximum:()=>cS,minimum:()=>lS,multiply:()=>uS,permute:()=>rS,prelu:()=>Rx,randomWidth:()=>tC,reLU:()=>Ix,repeatVector:()=>tS,rescaling:()=>ZS,reshape:()=>nS,resizing:()=>$S,rnn:()=>zS,separableConv2d:()=>Kx,simpleRNN:()=>FS,simpleRNNCell:()=>IS,softmax:()=>zx,spatialDropout1d:()=>$x,stackedRNNCells:()=>BS,thresholdedReLU:()=>Bx,timeDistributed:()=>HS,upSampling2d:()=>Jx,zeroPadding2d:()=>mS});function Px(e){return new gg(e)}function Fx(e){return new Iy(e)}function Ix(e){return new Ny(e)}function Lx(e){return new Py(e)}function Rx(e){return new Fy(e)}function zx(e){return new Ry(e)}function Bx(e){return new Ly(e)}function Vx(e){return new tb(e)}function Hx(e){return new Yy(e)}function Ux(e){return new Zy(e)}function Wx(e){return new Xy(e)}function Gx(e){return new Qy(e)}function Kx(e){return new eb(e)}function qx(e){return new nb(e)}function Jx(e){return new rb(e)}function Yx(e){return new ab(e)}function Xx(e){return new Eb(e)}function Zx(e){return new wb(e)}function Qx(e){return new Sb(e)}function $x(e){return new Cb(e)}function eS(e){return new Tb(e)}function tS(e){return new Db(e)}function nS(e){return new Ob(e)}function rS(e){return new kb(e)}function iS(e){return new jb(e)}function aS(e){return new Nb(e)}function oS(e){return new Fb(e)}function sS(e){return new Rb(e)}function cS(e){return new Ib(e)}function lS(e){return new Lb(e)}function uS(e){return new Pb(e)}function dS(e){return new Vb(e)}function fS(e){return new Yb(e)}function pS(e){return new Xb(e)}function mS(e){return new Qb(e)}function hS(e){return new rx(e)}function gS(e){return hS(e)}function _S(e){return hS(e)}function vS(e){return new ox(e)}function yS(e){return vS(e)}function bS(e){return vS(e)}function xS(e){return new lx(e)}function SS(e){return xS(e)}function CS(e){return xS(e)}function wS(e){return new dx(e)}function TS(e){return new mx(e)}function ES(e){return new fx(e)}function DS(e){return new hx(e)}function OS(e){return new nx(e)}function kS(e){return new ax(e)}function AS(e){return new cx(e)}function jS(e){return new pb(e)}function MS(e){return new fb(e)}function NS(e){return new hb(e)}function PS(e){return new mb(e)}function FS(e){return new db(e)}function IS(e){return new ub(e)}function LS(e){return new xb(e)}function RS(e){return new bb(e)}function zS(e){return new cb(e)}function BS(e){return new gb(e)}function VS(e){return new bx(e)}function HS(e){return new _x(e)}var US=ES,WS=DS,GS=OS,KS=kS;function qS(e){return new Hb(e)}function JS(e){return new Ub(e)}function YS(e){return new Wb(e)}function XS(e){return new Ab(e)}function ZS(e){return new xx(e)}function QS(e){return new wx(e)}function $S(e){return new Ox(e)}function eC(e){return new Ex(e)}function tC(e){return new Mx(e)}var nC=e({MAPE:()=>pC,MSE:()=>gC,binaryAccuracy:()=>rC,binaryCrossentropy:()=>iC,categoricalAccuracy:()=>oC,categoricalCrossentropy:()=>sC,cosineProximity:()=>uC,mape:()=>mC,meanAbsoluteError:()=>dC,meanAbsolutePercentageError:()=>fC,meanSquaredError:()=>hC,mse:()=>_C,precision:()=>cC,r2Score:()=>vC,recall:()=>lC,sparseCategoricalAccuracy:()=>aC});function rC(e,t){return F_(e,t)}function iC(e,t){return H_(e,t)}function aC(e,t){return U_(e,t)}function oC(e,t){return I_(e,t)}function sC(e,t){return Z_(e,t)}function cC(e,t){return B_(e,t)}function lC(e,t){return V_(e,t)}function uC(e,t){return M_(e,t)}function dC(e,t){return y_(e,t)}function fC(e,t){return b_(e,t)}function pC(e,t){return b_(e,t)}function mC(e,t){return b_(e,t)}function hC(e,t){return v_(e,t)}function gC(e,t){return v_(e,t)}function _C(e,t){return v_(e,t)}function vC(e,t){return W_(e,t)}var yC=e({modelFromJSON:()=>Yv}),bC=e({l1:()=>SC,l1l2:()=>xC,l2:()=>CC});function xC(e){return new Ey(e)}function SC(e){return Dy(e)}function CC(e){return Oy(e)}var wC=class extends c_{constructor(){super(...arguments),this.model=null}setModel(e){if(!(e instanceof qv))throw Error(`model must be a LayersModel, not some other Container`);this.model=e}};function TC(e,t){return e<t}function EC(e,t){return e>t}var DC=class extends wC{constructor(e){if(super(),e??={},e.restoreBestWeights)throw new G(`restoreBestWeights = True is not implemented in EarlyStopping yet.`);this.monitor=e.monitor||`val_loss`,this.minDelta=Math.abs(e.minDelta||0),this.patience=e.patience||0,this.verbose=e.verbose||0,this.mode=e.mode||`auto`,this.baseline=e.baseline,[`auto`,`min`,`max`].indexOf(this.mode)===-1&&(console.warn(`EarlyStopping mode '${this.mode}' is invalid. Falling back to mode 'auto'.`),this.mode=`auto`),this.mode===`min`?this.monitorFunc=TC:this.mode===`max`?this.monitorFunc=EC:this.monitor.indexOf(`acc`)===-1?this.monitorFunc=TC:this.monitorFunc=EC,this.monitorFunc===TC&&(this.minDelta*=-1)}async onTrainBegin(e){this.wait=0,this.stoppedEpoch=0,this.baseline==null?this.best=this.monitorFunc===TC?1/0:-1/0:this.best=this.baseline}async onEpochEnd(e,t){await a_(t);let n=this.getMonitorValue(t);n!=null&&(this.monitorFunc(n-this.minDelta,this.best)?(this.best=n,this.wait=0):(this.wait++,this.wait>=this.patience&&(this.stoppedEpoch=e,this.model.stopTraining=!0)))}async onTrainEnd(e){this.stoppedEpoch>0&&this.verbose&&console.log(`Epoch ${this.stoppedEpoch}: early stopping.`)}getMonitorValue(e){e??={};let t=e[this.monitor];return t??console.warn(`Metric for EarlyStopping ${this.monitor} is not available. Available metrics are: ${Object.keys(e)}`),t}};function OC(e){return new DC(e)}var kC={earlyStopping:OC},AC=t(Cc());function jC(e,t){return MC(e,t)}function MC(e,t,n=new Map,r=new Set){if(e==null)return null;if(typeof Blob==`function`&&e instanceof Blob)return e.slice();if(r.has(e))throw Error(`Circular references are not supported.`);if(n.has(e))return n.get(e);let i=t(e);if(i.recurse&&i.value!==null)throw Error(`A deep map function may not return both a value and recurse=true.`);if(!i.recurse)return n.set(e,i.value),i.value;if(LC(e)){let i=Array.isArray(e)?[]:{};r.add(e);for(let a in e){let o=e[a];i[a]=MC(o,t,n,r)}return r.delete(e),e.__proto__&&(i.__proto__=e.__proto__),i}else throw Error(`Can't recurse into non-iterable type: ${e}`)}function NC(e,t=FC){return PC(e,t)}function PC(e,t,n=new Set){let r=e[0];if(n.has(r))throw Error(`Circular references are not supported.`);let i=t(e);if(i.recurse&&i.value!==null)throw Error(`A deep zip function may not return both a value and recurse=true.`);if(!i.recurse)return i.value;if(LC(r)){let i=Array.isArray(r)?[]:{};n.add(r);for(let a in r)i[a]=PC(e.map(e=>e[a]),t,n);return n.delete(r),i}else throw Error(`Can't recurse into non-iterable type: ${r}`)}function FC(e){return e===null?null:LC(e[0])?{value:null,recurse:!0}:{value:e,recurse:!1}}async function IC(e,t){let n=new Map;MC(e,t,n);for(let e of Array.from(n.keys())){let t=n.get(e);if(Qs(t)){let r=await t;n.set(e,r)}}return MC(e,t,n)}function LC(e){let t=!1;if(j().get(`IS_BROWSER`))t=e instanceof TextDecoder;else{let{StringDecoder:n}=Xc();t=e instanceof n}return e!=null&&!ArrayBuffer.isView(e)&&(Array.isArray(e)||typeof e==`object`&&!(e instanceof wc)&&!(e instanceof Promise)&&!t)}function RC(e){return e==null||zC(e)||Array.isArray(e)||typeof e==`object`&&e instanceof wc||ro(e)}function zC(e){return e===null||typeof e!=`object`&&typeof e!=`function`}function BC(e){return jC(e,VC)}function VC(e){return e instanceof wc?{value:e.clone(),recurse:!1}:LC(e)?{value:null,recurse:!0}:{value:e,recurse:!1}}var HC=class{constructor(e){if(this.capacity=e,this.begin=0,this.end=0,e==null)throw RangeError(`Can't create a ring buffer of unknown capacity.`);if(e<1)throw RangeError(`Can't create ring buffer of capacity < 1.`);this.data=Array(e),this.doubledCapacity=2*e}wrap(e){for(;e<0;)e+=this.doubledCapacity;return e%this.doubledCapacity}get(e){if(e<0)throw RangeError(`Can't get item at a negative index.`);return this.data[e%this.capacity]}set(e,t){if(e<0)throw RangeError(`Can't set item at a negative index.`);this.data[e%this.capacity]=t}length(){let e=this.end-this.begin;return e<0&&(e=this.doubledCapacity+e),e}isFull(){return this.length()===this.capacity}isEmpty(){return this.length()===0}push(e){if(this.isFull())throw RangeError(`Ring buffer is full.`);this.set(this.end,e),this.end=this.wrap(this.end+1)}pushAll(e){for(let t of e)this.push(t)}pop(){if(this.isEmpty())throw RangeError(`Ring buffer is empty.`);this.end=this.wrap(this.end-1);let e=this.get(this.end);return this.set(this.end,void 0),e}unshift(e){if(this.isFull())throw RangeError(`Ring buffer is full.`);this.begin=this.wrap(this.begin-1),this.set(this.begin,e)}shift(){if(this.isEmpty())throw RangeError(`Ring buffer is empty.`);let e=this.get(this.begin);return this.set(this.begin,void 0),this.begin=this.wrap(this.begin+1),e}shuffleExcise(e){if(this.isEmpty())throw RangeError(`Ring buffer is empty.`);let t=this.wrap(this.begin+e),n=this.get(t);return this.set(t,this.pop()),n}},UC=class e extends HC{constructor(){super(e.INITIAL_CAPACITY)}isFull(){return!1}push(e){super.isFull()&&this.expand(),super.push(e)}unshift(e){super.isFull()&&this.expand(),super.unshift(e)}expand(){let e=this.capacity*2,t=Array(e),n=this.length();for(let e=0;e<n;e++)t[e]=this.get(this.wrap(this.begin+e));this.data=t,this.capacity=e,this.doubledCapacity=2*this.capacity,this.begin=0,this.end=n}};UC.INITIAL_CAPACITY=32;function WC(e){return new YC(e)}function GC(e){return new XC(e)}function KC(e,t){return new sw(e,t)}function qC(e,t=cw.FAIL){return new lw(e,t)}var JC=class{async toArray(){let e=[],t=await this.next();for(;!t.done;)e.push(t.value),t=await this.next();return e}async toArrayForTest(){let e=this.prefetch(100),t=[],n=await e.next();for(;!n.done;)t.push(n.value),n=await e.next();return t}async resolveFully(){let e=await this.next();for(;!e.done;)e=await this.next()}async resolveWhile(e){let t=await this.next(),n=e(t.value);for(;!t.done&&n;)t=await this.next(),n=e(t.value)}handleErrors(e){return new rw(this,e)}filter(e){return new tw(this,e)}map(e){return new nw(this,e)}mapAsync(e){return new iw(this,e)}serialMapAsync(e){return new iw(this,e).serial()}flatmap(e){return new ow(this,e)}async forEachAsync(e){return this.map(e).resolveFully()}async serialForEach(e){return this.serialMapAsync(e).resolveWhile(e=>e===!0)}rowMajorBatch(e,t=!0){return new ew(this,e,t)}columnMajorBatch(e,t=!0,n=FC){return this.rowMajorBatch(e,t).map(e=>NC(e,n))}concatenate(e,t){return new sw(WC([this,e]),t)}take(e){return e<0||e==null?this:new $C(this,e)}skip(e){return e<0||e==null?this:new QC(this,e)}prefetch(e){return new uw(this,e)}shuffle(e,t){return new dw(this,e,t)}serial(){return new ZC(this)}},YC=class extends JC{constructor(e){super(),this.items=e,this.trav=0}summary(){return`Array of ${this.items.length} items`}async next(){if(this.trav>=this.items.length)return{value:null,done:!0};let e=this.items[this.trav];return this.trav++,{value:BC(e),done:!1}}},XC=class extends JC{constructor(e){super(),this.nextFn=e}summary(){return`Function call`}async next(){try{return this.nextFn()}catch(e){throw e.message=`Error thrown while iterating through a dataset: ${e.message}`,e}}},ZC=class extends JC{constructor(e){super(),this.upstream=e,this.lastRead=Promise.resolve({value:null,done:!1})}summary(){return`${this.upstream.summary()} -> Serial`}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){return this.upstream.next()}},QC=class extends JC{constructor(e,t){super(),this.upstream=e,this.maxCount=t,this.count=0,this.lastRead=Promise.resolve({value:null,done:!1})}summary(){return`${this.upstream.summary()} -> Skip`}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){for(;this.count++<this.maxCount;){let e=await this.upstream.next();if(e.done)return e;D(e.value)}return this.upstream.next()}},$C=class extends JC{constructor(e,t){super(),this.upstream=e,this.maxCount=t,this.count=0}summary(){return`${this.upstream.summary()} -> Take`}async next(){return this.count++>=this.maxCount?{value:null,done:!0}:this.upstream.next()}},ew=class extends JC{constructor(e,t,n=!0){super(),this.upstream=e,this.batchSize=t,this.enableSmallLastBatch=n,this.lastRead=Promise.resolve({value:null,done:!1})}summary(){return`${this.upstream.summary()} -> RowMajorBatch`}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){let e=[];for(;e.length<this.batchSize;){let t=await this.upstream.next();if(t.done)return this.enableSmallLastBatch&&e.length>0?{value:e,done:!1}:{value:null,done:!0};e.push(t.value)}return{value:e,done:!1}}},tw=class extends JC{constructor(e,t){super(),this.upstream=e,this.predicate=t,this.lastRead=Promise.resolve({value:null,done:!1})}summary(){return`${this.upstream.summary()} -> Filter`}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){for(;;){let e=await this.upstream.next();if(e.done||this.predicate(e.value))return e;D(e.value)}}},nw=class extends JC{constructor(e,t){super(),this.upstream=e,this.transform=t}summary(){return`${this.upstream.summary()} -> Map`}async next(){let e=await this.upstream.next();if(e.done)return{value:null,done:!0};let t=Fc(e.value),n=this.transform(e.value),r=Fc(n);for(let e of t)Ds(e,r)||e.dispose();return{value:n,done:!1}}},rw=class extends JC{constructor(e,t){super(),this.upstream=e,this.handler=t,this.count=0,this.lastRead=Promise.resolve({value:null,done:!1})}summary(){return`${this.upstream.summary()} -> handleErrors`}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){for(;;)try{return await this.upstream.next()}catch(e){if(!this.handler(e))return{value:null,done:!0}}}},iw=class extends JC{constructor(e,t){super(),this.upstream=e,this.transform=t}summary(){return`${this.upstream.summary()} -> AsyncMap`}async next(){let e=await this.upstream.next();if(e.done)return{value:null,done:!0};let t=Fc(e.value),n=await this.transform(e.value),r=Fc(n);for(let e of t)Ds(e,r)||e.dispose();return{value:n,done:!1}}},aw=class extends JC{constructor(){super(),this.outputQueue=new UC,this.lastRead=Promise.resolve({value:null,done:!1})}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}async serialNext(){for(;this.outputQueue.length()===0;)if(!await this.pump())return{value:null,done:!0};return{value:this.outputQueue.shift(),done:!1}}},ow=class extends aw{constructor(e,t){super(),this.upstream=e,this.transform=t}summary(){return`${this.upstream.summary()} -> Flatmap`}async pump(){let e=await this.upstream.next();if(e.done)return!1;let t=Fc(e.value),n=this.transform(e.value),r=Fc(n);this.outputQueue.pushAll(n);for(let e of t)Ds(e,r)||e.dispose();return!0}},sw=class extends JC{constructor(e,t){super(),this.baseErrorHandler=t,this.lastRead=null,this.iterator=null,this.moreIterators=e}summary(){return`TODO: fill in upstream of chained summaries -> Chained`}async next(){return this.lastRead=this.readFromChain(this.lastRead),this.lastRead}async readFromChain(e){if(await e,this.iterator==null){let e=await this.moreIterators.next();if(e.done)return{value:null,done:!0};this.iterator=e.value,this.baseErrorHandler!=null&&(this.iterator=this.iterator.handleErrors(this.baseErrorHandler))}let t=await this.iterator.next();return t.done?(this.iterator=null,this.readFromChain(e)):t}},cw;(function(e){e[e.FAIL=0]=`FAIL`,e[e.SHORTEST=1]=`SHORTEST`,e[e.LONGEST=2]=`LONGEST`})(cw||={});var lw=class extends JC{constructor(e,t=cw.FAIL){super(),this.iterators=e,this.mismatchMode=t,this.count=0,this.currentPromise=null}summary(){return`{TODO: fill in upstream of zip summaries} -> Zip`}async nextState(e){await e;let t=0,n=0;function r(e){return e instanceof JC?{value:e.next().then(e=>(t++,e.done&&n++,e.value)),recurse:!1}:{value:null,recurse:!0}}let i=await IC(this.iterators,r);if(t===n)return{value:null,done:!0};if(n>0)switch(this.mismatchMode){case cw.FAIL:throw Error(`Zipped streams should have the same length. Mismatched at element ${this.count}.`);case cw.SHORTEST:return{value:null,done:!0};case cw.LONGEST:default:}return this.count++,{value:i,done:!1}}async next(){return this.currentPromise=this.nextState(this.currentPromise),this.currentPromise}},uw=class extends JC{constructor(e,t){super(),this.upstream=e,this.bufferSize=t,this.buffer=new HC(t)}summary(){return`${this.upstream.summary()} -> Prefetch`}refill(){for(;!this.buffer.isFull();){let e=this.upstream.next();this.buffer.push(e)}}next(){return this.refill(),this.buffer.shift()}},dw=class extends uw{constructor(e,t,n){super(e,t),this.upstream=e,this.windowSize=t,this.upstreamExhausted=!1,this.random=AC.alea(n||Ri().toString()),this.lastRead=Promise.resolve({value:null,done:!1})}async next(){return this.lastRead=this.lastRead.then(()=>this.serialNext()),this.lastRead}randomInt(e){return Math.floor(this.random()*e)}chooseIndex(){return this.randomInt(this.buffer.length())}async serialNext(){for(this.upstreamExhausted||this.refill();!this.buffer.isEmpty();){let e=this.chooseIndex(),t=await this.buffer.shuffleExcise(e);if(t.done)this.upstreamExhausted=!0;else return this.refill(),t}return{value:null,done:!0}}},fw=class{constructor(){this.size=null}batch(e,t=!0){let n=this;o(e>0,()=>`batchSize needs to be positive, but it is
      ${e}`);let r;return r=this.size===1/0||this.size==null?this.size:t?Math.ceil(this.size/e):Math.floor(this.size/e),pw(async()=>(await n.iterator()).columnMajorBatch(e,t,gw),r)}concatenate(e){let t=this,n;return n=this.size===1/0||e.size===1/0?1/0:this.size!=null&&e.size!=null?this.size+e.size:null,pw(async()=>(await t.iterator()).concatenate(await e.iterator()),n)}filter(e){let t=this,n;return n=this.size===1/0?1/0:null,pw(async()=>(await t.iterator()).filter(t=>A(()=>e(t))),n)}async forEachAsync(e){return(await this.iterator()).forEachAsync(e)}map(e){let t=this;return pw(async()=>(await t.iterator()).map(t=>A(()=>e(t))),this.size)}mapAsync(e){let t=this;return pw(async()=>(await t.iterator()).mapAsync(e),this.size)}prefetch(e){if(e==null)throw RangeError("`Dataset.prefetch()` requires bufferSize to be specified.");let t=this;return pw(async()=>(await t.iterator()).prefetch(e),this.size)}repeat(e){let t=this,n;return n=this.size!=null&&e>0?this.size*e:e===0?0:this.size!=null&&(e===void 0||e<0)?1/0:null,pw(async()=>KC(GC(async()=>({value:await t.iterator(),done:!1})).take(e)),n)}skip(e){let t=this,n;return n=this.size!=null&&e>=0&&this.size>=e?this.size-e:this.size!=null&&(this.size<e||e===void 0||e<0)?0:null,pw(async()=>(await t.iterator()).skip(e),n)}shuffle(e,t,n=!0){if(e==null||e<0)throw this.size==null?RangeError("`Dataset.shuffle()` requires bufferSize to be specified."):RangeError(`\`Dataset.shuffle()\` requires bufferSize to be specified.  If your data fits in main memory (for regular JS objects), and/or GPU memory (for \`tf.Tensor\`s), consider setting bufferSize to the dataset size (${this.size} elements)`);let r=this,i=AC.alea(t||Ri().toString());return pw(async()=>{let t=i.int32();return n&&(t+=i.int32()),(await r.iterator()).shuffle(e,t.toString())},this.size)}take(e){let t=this,n;return n=this.size!=null&&this.size>e?e:this.size!=null&&this.size<=e?this.size:null,pw(async()=>(await t.iterator()).take(e),n)}async toArray(){if(this.size===1/0)throw Error(`Can not convert infinite data stream to array.`);return(await this.iterator()).toArray()}async toArrayForTest(){if(this.size===1/0)throw Error(`Can not convert infinite data stream to array.`);return(await this.iterator()).toArrayForTest()}};fw.MAX_BUFFER_SIZE=1e4;function pw(e,t=null){return new class extends fw{constructor(){super(...arguments),this.size=t}async iterator(){return e()}}}function mw(e){return pw(async()=>WC(e),e.length)}function hw(e){if(!LC(e))throw Error(`The argument to zip() must be an object or array.`);let t;if(Array.isArray(e))for(let n=0;n<e.length;n++)t=t==null?e[n].size:Math.min(t,e[n].size);else if(e instanceof Object)for(let n in e)t=t==null?e[n].size:Math.min(t,e[n].size);return pw(async()=>qC(await IC(e,e=>{if(e instanceof fw)return{value:e.iterator(),recurse:!1};if(LC(e))return{value:null,recurse:!0};throw Error(`Leaves of the structure passed to zip() must be Datasets, not primitives.`)}),cw.SHORTEST),t)}function gw(e){if(e===null)return null;let t=e[0];return RC(t)?{value:_w(e),recurse:!1}:{value:null,recurse:!0}}function _w(e){if(e.length===0)throw Error(`Can't make a batch of zero elements.`);return e[0]instanceof wc?Or(e):Ye(e)}var vw=class extends fw{constructor(e){super(),this.input=e}async iterator(){return(await this.input.iterator()).decodeUTF8().split(`
`).map(e=>(e.endsWith(`\r`)&&(e=e.slice(0,-1)),e))}},yw=`"`,bw=Symbol(`out`),xw=Symbol(`field`),Sw=Symbol(`quote`),Cw=Symbol(`quoteafterquote`),ww=Symbol(`quoteinquote`),Tw=class extends fw{async columnNames(){return this.columnNamesValidated||await this.setColumnNames(),this.configuredColumnsOnly?Object.keys(this.columnConfigs):this.fullColumnNames}async setColumnNames(){let e=await this.maybeReadHeaderLine();if(!this.fullColumnNames&&!e)throw Error(`Column names must be provided if there is no header line.`);this.fullColumnNames&&e&&o(e.length===this.fullColumnNames.length,()=>`The length of provided columnNames (`+this.fullColumnNames.length.toString()+`) does not match the length of the header line read from file (`+e.length.toString()+`).`),this.fullColumnNames||=e;let t=this.fullColumnNames.reduce((e,t)=>(e[t]=e[t]+1||1,e),{}),n=Object.keys(t).filter(e=>t[e]>1);if(o(n.length===0,()=>`Duplicate column names found: `+n.toString()),this.columnConfigs){for(let e of Object.keys(this.columnConfigs))if(this.fullColumnNames.indexOf(e)===-1)throw Error(`The key "`+e+`" provided in columnConfigs does not match any of the column names (`+this.fullColumnNames.toString()+`).`)}this.columnNamesValidated=!0}async maybeReadHeaderLine(){if(this.hasHeader){let e=await(await this.base.iterator()).next();if(e.done)throw Error(`No data was found for CSV parsing.`);let t=e.value;return this.parseRow(t,!1)}else return null}constructor(e,t){super(),this.input=e,this.hasHeader=!0,this.fullColumnNames=null,this.columnNamesValidated=!1,this.columnConfigs=null,this.configuredColumnsOnly=!1,this.delimiter=`,`,this.delimWhitespace=!1,this.base=new vw(e),t||={},this.hasHeader=t.hasHeader!==!1,this.fullColumnNames=t.columnNames,this.columnConfigs=t.columnConfigs,this.configuredColumnsOnly=t.configuredColumnsOnly,t.delimWhitespace?(o(t.delimiter==null,()=>`Delimiter should not be provided when delimWhitespace is true.`),this.delimWhitespace=!0,this.delimiter=` `):this.delimiter=t.delimiter?t.delimiter:`,`}async iterator(){this.columnNamesValidated||await this.setColumnNames();let e=await this.base.iterator();return this.hasHeader&&(e=e.skip(1)),e.map(e=>this.makeDataElement(e))}makeDataElement(e){let t=this.parseRow(e),n={},r={};for(let i=0;i<this.fullColumnNames.length;i++){let a=this.fullColumnNames[i],o=this.columnConfigs?this.columnConfigs[a]:null;if(!(this.configuredColumnsOnly&&!o)){let s=t[i],c=null;if(s===``)if(o&&o.default!==void 0)c=o.default;else if(o&&(o.required||o.isLabel))throw Error(`Required column ${a} is empty in this line: ${e}`);else c=void 0;else{let e=Number(s);if(isNaN(e))c=o&&o.dtype===`bool`?this.getBoolean(s):s;else if(!o||!o.dtype)c=e;else switch(o.dtype){case`float32`:c=e;break;case`int32`:c=Math.floor(e);break;case`bool`:c=this.getBoolean(s);break;default:c=e}}o&&o.isLabel?r[a]=c:n[a]=c}}return Object.keys(r).length===0?n:{xs:n,ys:r}}getBoolean(e){return+(e===`1`||e.toLowerCase()===`true`)}parseRow(e,t=!0){let n=[],r=0,i=e.length,a=bw;for(let t=0;t<i;t++)switch(a){case bw:switch(e.charAt(t)){case yw:r=t+1,a=Sw;break;case this.delimiter:if(r=t+1,this.delimiter===` `&&this.delimWhitespace)break;n.push(``),a=bw;break;default:a=xw,r=t;break}break;case xw:switch(e.charAt(t)){case this.delimiter:n.push(e.substring(r,t)),a=bw,r=t+1;break;default:}break;case Sw:switch(e.charAt(t)){case yw:a=Cw;break;default:}break;case Cw:switch(e.charAt(t)){case this.delimiter:n.push(e.substring(r,t-1)),a=bw,r=t+1;break;case yw:a=Sw;break;default:a=ww;break}break;case ww:switch(e.charAt(t)){case yw:a=Sw;break;default:}break;default:}if(a===Cw?n.push(e.substring(r,i-1)):n.push(e.substring(r)),t&&n.length!==this.fullColumnNames.length)throw Error(`Invalid row in csv file. Should have ${this.fullColumnNames.length} elements in a row, but got ${n}`);return n}},Ew=class e extends JC{constructor(e){super(),this.microphoneConfig=e,this.isClosed=!1,this.fftSize=e.fftSize||1024;let t=Math.log2(this.fftSize);if(this.fftSize<0||t<4||t>14||!Number.isInteger(t))throw Error(`Invalid fftSize: it must be a power of 2 between 2 to 4 and 2 to 14, but got ${this.fftSize}`);if(this.numFrames=e.numFramesPerSpectrogram||43,this.sampleRateHz=e.sampleRateHz,this.columnTruncateLength=e.columnTruncateLength||this.fftSize,this.audioTrackConstraints=e.audioTrackConstraints,this.smoothingTimeConstant=e.smoothingTimeConstant||0,this.includeSpectrogram=e.includeSpectrogram!==!1,this.includeWaveform=e.includeWaveform===!0,!this.includeSpectrogram&&!this.includeWaveform)throw Error(`Both includeSpectrogram and includeWaveform are false. At least one type of data should be returned.`)}summary(){return`microphone`}static async create(t={}){if(!j().get(`IS_BROWSER`))throw Error(`microphone API is only supported in browser environment.`);let n=new e(t);return await n.start(),n}async start(){try{this.stream=await navigator.mediaDevices.getUserMedia({audio:this.audioTrackConstraints==null||this.audioTrackConstraints,video:!1})}catch(e){throw Error(`Error thrown while initializing video stream: ${e.message}`)}if(!this.stream)throw Error(`Could not obtain audio from microphone.`);let e=window.AudioContext||window.webkitAudioContext;if(this.audioContext=new e,!this.sampleRateHz)this.sampleRateHz=this.audioContext.sampleRate;else if(this.audioContext.sampleRate!==this.sampleRateHz)throw Error(`Mismatch in sampling rate: Expected: ${this.sampleRateHz}; Actual: ${this.audioContext.sampleRate}`);let t=this.audioContext.createMediaStreamSource(this.stream);this.analyser=this.audioContext.createAnalyser(),this.analyser.fftSize=this.fftSize*2,this.analyser.smoothingTimeConstant=this.smoothingTimeConstant,t.connect(this.analyser),this.freqData=new Float32Array(this.fftSize),this.timeData=new Float32Array(this.fftSize)}async next(){if(this.isClosed)return{value:null,done:!0};let e,t,n=await this.getAudioData();if(this.includeSpectrogram){let t=this.flattenQueue(n.freqDataQueue);e=this.getTensorFromAudioDataArray(t,[this.numFrames,this.columnTruncateLength,1])}if(this.includeWaveform){let e=this.flattenQueue(n.timeDataQueue);t=this.getTensorFromAudioDataArray(e,[this.numFrames*this.fftSize,1])}return{value:{spectrogram:e,waveform:t},done:!1}}async capture(){return(await this.next()).value}async getAudioData(){let e=[],t=[],n=0;return new Promise(r=>{let i=setInterval(()=>{this.includeSpectrogram&&(this.analyser.getFloatFrequencyData(this.freqData),this.freqData[0]===-1/0&&r({freqDataQueue:e,timeDataQueue:t}),e.push(this.freqData.slice(0,this.columnTruncateLength))),this.includeWaveform&&(this.analyser.getFloatTimeDomainData(this.timeData),t.push(this.timeData.slice())),++n===this.numFrames&&(clearInterval(i),r({freqDataQueue:e,timeDataQueue:t}))},this.fftSize/this.sampleRateHz*1e3)})}stop(){this.isClosed||(this.isClosed=!0,this.analyser.disconnect(),this.audioContext.close(),this.stream!=null&&this.stream.getTracks().length>0&&this.stream.getTracks()[0].stop())}toArray(){throw Error(`Can not convert infinite audio stream to array.`)}getSampleRate(){return this.sampleRateHz}flattenQueue(e){let t=e[0].length,n=new Float32Array(e.length*t);return e.forEach((e,r)=>n.set(e,r*t)),n}getTensorFromAudioDataArray(e,t){let n=new Float32Array(k(t));return n.set(e,n.length-e.length),Ye(n,t)}},Dw=class e extends JC{constructor(e,t){if(super(),this.webcamVideoElement=e,this.webcamConfig=t,this.isClosed=!0,this.resize=!1,this.needToResize())if(this.resize=!0,this.cropSize=[this.webcamConfig.resizeHeight,this.webcamConfig.resizeWidth],this.cropBoxInd=Tl([0],`int32`),this.webcamConfig.centerCrop){let e=this.webcamConfig.resizeWidth*1/this.webcamVideoElement.width,t=this.webcamConfig.resizeHeight*1/this.webcamVideoElement.height,n=(1-e)/2,r=(1-t)/2,i=n+e,a=t+r;this.cropBox=la([r,n,a,i],[1,4])}else this.cropBox=la([0,0,1,1],[1,4])}summary(){return`webcam`}static async create(t,n={}){if(!j().get(`IS_BROWSER`))throw Error(`tf.data.webcam is only supported in browser environment.`);if(!t){if(t=document.createElement(`video`),!n.resizeWidth||!n.resizeHeight)throw Error(`Please provide webcam video element, or resizeWidth and resizeHeight to create a hidden video element.`);t.width=n.resizeWidth,t.height=n.resizeHeight}let r=new e(t,n);return await r.start(),r}async start(){this.webcamConfig.facingMode&&o(this.webcamConfig.facingMode===`user`||this.webcamConfig.facingMode===`environment`,()=>`Invalid webcam facing mode: ${this.webcamConfig.facingMode}. Please provide 'user' or 'environment'`);try{this.stream=await navigator.mediaDevices.getUserMedia({video:{deviceId:this.webcamConfig.deviceId,facingMode:this.webcamConfig.facingMode?this.webcamConfig.facingMode:`user`,width:this.webcamVideoElement.width,height:this.webcamVideoElement.height}})}catch(e){throw e.message=`Error thrown while initializing video stream: ${e.message}`,e}if(!this.stream)throw Error(`Could not obtain video from webcam.`);try{this.webcamVideoElement.srcObject=this.stream}catch(e){console.log(e),this.webcamVideoElement.src=window.URL.createObjectURL(this.stream)}return this.webcamVideoElement.play(),this.isClosed=!1,new Promise(e=>{this.webcamVideoElement.onloadedmetadata=()=>{e()}})}async next(){if(this.isClosed)return{value:null,done:!0};let e;try{e=vc(this.webcamVideoElement)}catch(e){throw Error(`Error thrown converting video to pixels: ${JSON.stringify(e)}`)}if(this.resize)try{return{value:this.cropAndResizeFrame(e),done:!1}}catch(e){throw Error(`Error thrown cropping the video: ${e.message}`)}finally{e.dispose()}else return{value:e,done:!1}}needToResize(){return!!(this.webcamConfig.resizeWidth&&this.webcamConfig.resizeHeight&&(this.webcamVideoElement.width!==this.webcamConfig.resizeWidth||this.webcamVideoElement.height!==this.webcamConfig.resizeHeight))}cropAndResizeFrame(e){return A(()=>{let t=Cl(F(e,`float32`),0),n;n=oe.cropAndResize(t,this.cropBox,this.cropBoxInd,this.cropSize,`bilinear`);let r=n.shape;return U(n,r.slice(1))})}async capture(){return(await this.next()).value}stop(){this.stream.getTracks().forEach(e=>e.stop());try{this.webcamVideoElement.srcObject=null}catch(e){console.log(e),this.webcamVideoElement.src=null}this.isClosed=!0}toArray(){throw Error(`Can not convert infinite video stream to array.`)}},Ow=class{},kw=class extends JC{split(e){return new Aw(this,e)}},Aw=class extends kw{constructor(e,t){super(),this.upstream=e,this.impl=new jw(e,t)}summary(){return this.impl.summary()}async next(){return this.impl.next()}},jw=class extends aw{constructor(e,t){super(),this.upstream=e,this.separator=t,this.carryover=``}summary(){return`${this.upstream.summary()} -> Split('${this.separator}')`}async pump(){let e=await this.upstream.next();if(e.done)return this.carryover===``?!1:(this.outputQueue.push(this.carryover),this.carryover=``,!0);let t=e.value.split(this.separator);t[0]=this.carryover+t[0];for(let e of t.slice(0,-1))this.outputQueue.push(e);return this.carryover=t[t.length-1],!0}},Mw=class extends JC{decodeUTF8(){return new Nw(this)}},Nw=class extends kw{constructor(e){super(),this.upstream=e,this.impl=new Pw(e)}summary(){return this.impl.summary()}async next(){return this.impl.next()}},Pw=class extends aw{constructor(e){if(super(),this.upstream=e,j().get(`IS_BROWSER`))this.decoder=new TextDecoder(`utf-8`);else{let{StringDecoder:e}=Xc();this.decoder=new e(`utf8`)}}summary(){return`${this.upstream.summary()} -> Utf8`}async pump(){let e=await this.upstream.next(),t;if(e.done)return!1;t=e.value;let n;return n=j().get(`IS_BROWSER`)?this.decoder.decode(t,{stream:!0}):this.decoder.write(Buffer.from(t.buffer)),this.outputQueue.push(n),!0}},Fw=class extends Mw{constructor(e,t={}){super(),this.file=e,this.options=t,o(e instanceof Uint8Array||(j().get(`IS_BROWSER`)?e instanceof File||e instanceof Blob:!1),()=>`FileChunkIterator only supports File, Blob and Uint8Array right now.`),this.offset=t.offset||0,this.chunkSize=t.chunkSize||1024*1024}summary(){return`FileChunks ${this.file}`}async next(){return this.offset>=(this.file instanceof Uint8Array?this.file.byteLength:this.file.size)?{value:null,done:!0}:{value:await new Promise((e,t)=>{let n=this.offset+this.chunkSize;if(this.file instanceof Uint8Array)e(new Uint8Array(this.file.slice(this.offset,n)));else{let r=new FileReader;r.onload=n=>{let i=r.result;if(i instanceof ArrayBuffer&&(i=new Uint8Array(i)),!(i instanceof Uint8Array))return t(TypeError(`FileReader returned unknown type.`));e(i)},r.onabort=e=>t(Error(`Aborted`)),r.onerror=e=>t(Error(e.type));let i=this.file.slice(this.offset,n);r.readAsArrayBuffer(i)}this.offset=n}),done:!1}}};async function Iw(e,t={},n){let r,i;typeof e==`string`?r=e:(r=e.url,i=Lw(e));let a=await(n||gs)(r,i);if(a.ok)return new Fw(new Uint8Array(await a.arrayBuffer()),t);throw Error(a.statusText)}var Lw=e=>({method:e.method,headers:e.headers,body:e.body,mode:e.mode,credentials:e.credentials,cache:e.cache,redirect:e.redirect,referrer:e.referrer,integrity:e.integrity});function Rw(e){return typeof e==`string`&&e.slice(0,7)===`file://`}var zw=class extends Ow{constructor(e,t={}){super(),this.input=e,this.options=t}async iterator(){if(Rw(this.input)&&j().get(`IS_NODE`)){let e=Xc();this.input=e.readFileSync(this.input.slice(7))}return new Fw(this.input,this.options)}},Bw=class extends Ow{constructor(e,t={}){super(),this.url=e,this.fileOptions=t}async iterator(){return Rw(this.url)?new zw(this.url,this.fileOptions).iterator():Iw(this.url,this.fileOptions)}};function Vw(e,t={}){return new Tw(new Bw(e),t)}function Hw(e){let t=GC(e);return pw(async()=>t)}function Uw(e){return pw(async()=>{let t=await e();return GC(()=>t.next())})}async function Ww(e,t){return Dw.create(e,t)}async function Gw(e){return Ew.create(e)}var Kw=`4.22.0`,qw=e({CSVDataset:()=>Tw,Dataset:()=>fw,FileDataSource:()=>zw,TextLineDataset:()=>vw,URLDataSource:()=>Bw,array:()=>mw,csv:()=>Vw,func:()=>Hw,generator:()=>Uw,microphone:()=>Gw,version_data:()=>Kw,webcam:()=>Ww,zip:()=>hw});function Y(e,t){Array.isArray(e)||(e=[e]),e.forEach(e=>{e!=null&&o(e.dtype!==`complex64`,()=>`${t} does not support complex64 tensors in the CPU backend.`)})}var Jw=_c,Yw=class e extends dn{nextDataId(){return e.nextDataId++}constructor(){super(),this.blockSize=48,this.firstUse=!0,this.data=new Vo(this,Mo())}write(e,t,n){this.firstUse&&(this.firstUse=!1,j().get(`IS_NODE`)&&v(`
============================
Hi, looks like you are running TensorFlow.js in Node.js. To speed things up dramatically, install our node backend, visit https://github.com/tensorflow/tfjs-node for more details. 
============================`));let r={id:this.nextDataId()};return this.data.set(r,{values:e,dtype:n,refCount:1}),r}makeTensorInfo(e,t,n){let r;if(t===`string`&&n!=null&&n.length>0&&bs(n[0])){let i=n.map(e=>Js(e));r=this.write(i,e,t)}else r=this.write(n,e,t);return{dataId:r,shape:e,dtype:t}}refCount(e){return this.data.has(e)?this.data.get(e).refCount:0}incRef(e){let t=this.data.get(e);t.refCount++}decRef(e){if(this.data.has(e)){let t=this.data.get(e);t.refCount--}}move(e,t,n,r,i){this.data.set(e,{values:t,dtype:r,refCount:i})}numDataIds(){return this.data.numDataIds()}async read(e){return this.readSync(e)}readSync(e){let{dtype:t,complexTensorInfos:n}=this.data.get(e);return t===`complex64`?od(this.readSync(n.real.dataId),this.readSync(n.imag.dataId)):Ao(this.data.get(e).values,t)}bufferSync(e){let t=this.readSync(e.dataId);if(e.dtype===`string`)try{let n=t.map(e=>qa(e));return M(e.shape,e.dtype,n)}catch{throw Error(`Failed to decode encoded string bytes into utf-8`)}return M(e.shape,e.dtype,t)}makeOutput(e,t,n){return Mo().makeTensorFromTensorInfo(this.makeTensorInfo(t,n,e),this)}disposeData(e,t=!1){if(this.data.has(e)){if(this.data.get(e).refCount--,!t&&this.data.get(e).refCount>0)return!1;let{complexTensorInfos:n}=this.data.get(e);n!=null&&(this.disposeData(n.real.dataId,!0),this.disposeData(n.imag.dataId,!0)),this.data.delete(e)}return!0}disposeIntermediateTensorInfo(e){this.disposeData(e.dataId)}async time(e){let t=Ri();return e(),{kernelMs:Ri()-t}}memory(){return{unreliable:!0,reasons:[`The reported memory is an upper bound. Due to automatic garbage collection, the true allocated memory may be less.`]}}where(e){Y([e],`where`);let t=this.readSync(e.dataId);return Jw(e.shape,t)}dispose(){}floatPrecision(){return 32}epsilon(){return super.epsilon()}};Yw.nextDataId=0;function Xw(e){let t=new Float32Array(e.length);for(let n=0;n<e.length;++n)t[n]=Math.abs(e[n]);return t}var Zw={kernelName:`Abs`,backendName:`cpu`,kernelFunc:e=>{let{x:t}=e.inputs,n=e.backend;Y(t,`abs`);let r=new Float32Array(k(t.shape)),i=n.data.get(t.dataId).values;return r=Xw(i),n.makeOutput(r,t.shape,t.dtype)}};function Qw(e){return(t,n,r,i,a)=>{let o=xi(t,n),s=o.length,c=R(o),l=Hs(a,k(o)),u=t.length,d=n.length,f=R(t),p=R(n),m=Ai(t,o),h=Ai(n,o);if(m.length+h.length===0)for(let t=0;t<l.length;++t)l[t]=e(r[t%r.length],i[t%i.length]);else for(let t=0;t<l.length;++t){let n=xa(t,s,c),a=n.slice(-u);m.forEach(e=>a[e]=0);let o=yo(a,u,f),g=n.slice(-d);h.forEach(e=>g[e]=0);let _=yo(g,d,p);l[t]=e(r[o],i[_])}return[l,o]}}function $w(e){let{inputs:t,backend:n}=e,{real:r,imag:i}=t,a=n.data.get(r.dataId).values,o=n.data.get(i.dataId).values,s=n.makeTensorInfo(r.shape,`complex64`),c=n.data.get(s.dataId);return c.complexTensorInfos={real:n.makeTensorInfo(r.shape,`float32`,a),imag:n.makeTensorInfo(i.shape,`float32`,o)},s}var eT={kernelName:Oo,backendName:`cpu`,kernelFunc:$w};function tT(e,t,n=`float32`){if(n===`complex64`)return $w({inputs:{real:tT(e,t,`float32`),imag:tT(e,t,`float32`)},backend:e});let r=al(k(t),n);return e.makeTensorInfo(t,n,r)}function nT(e){let{inputs:t,backend:n}=e,{x:r}=t;return n.incRef(r.dataId),{dataId:r.dataId,shape:r.shape,dtype:r.dtype}}var rT={kernelName:fi,backendName:`cpu`,kernelFunc:nT};function iT(e){let{inputs:t,backend:n}=e,{input:r}=t,i=n.data.get(r.dataId).complexTensorInfos.real,a=n.data.get(i.dataId).values;return n.makeTensorInfo(i.shape,i.dtype,a)}var aT={kernelName:tc,backendName:`cpu`,kernelFunc:iT};function oT(e,t,n,r){if(r===`int32`)return[t,`int32`,Int32Array.from(e)];if(r===`bool`){let r=tl([0],n),[i,a]=Qw((e,t)=>e===t?0:1)(t,[],e,r,`bool`);return[a,`bool`,i]}throw Error(`Error in Cast: failed to cast ${n} to ${r}`)}function sT(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{dtype:a}=r;if(a===`complex64`){if(i.dtype===`complex64`)return nT({inputs:{x:i},backend:n});let e=tT(n,i.shape,i.dtype),t=sT({inputs:{x:i},backend:n,attrs:{dtype:`float32`}}),r=$w({inputs:{real:t,imag:e},backend:n});return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),r}if(i.dtype===`complex64`){let e=iT({inputs:{input:i},backend:n}),t=sT({inputs:{x:e},backend:n,attrs:{dtype:a}});return n.disposeIntermediateTensorInfo(e),t}if(!Oc(i.dtype,a)){let e=nT({inputs:{x:i},backend:n});return{dataId:e.dataId,shape:e.shape,dtype:a}}let o=n.data.get(i.dataId).values,[s,c,l]=oT(o,i.shape,i.dtype,a);return n.makeTensorInfo(s,c,l)}var cT={kernelName:Lc,backendName:`cpu`,kernelFunc:sT};function lT(e,t,n,r){return n==null?({inputs:n,backend:i})=>{let{a,b:o}=n,s=i;Y([a,o],e);let c=s.data.get(a.dataId).values,l=s.data.get(o.dataId).values,u=a.dtype===`string`?Hd(c):c,d=a.dtype===`string`?Hd(l):l,f=r||a.dtype,[p,m]=t(a.shape,o.shape,u,d,f);return s.makeTensorInfo(m,f,p)}:({inputs:e,backend:i})=>{let{a,b:o}=e,s=i;if(a.dtype===`complex64`||o.dtype===`complex64`){let e=sT({inputs:{x:a},backend:s,attrs:{dtype:`complex64`}}),t=s.data.get(e.dataId),r=t.complexTensorInfos.real,i=t.complexTensorInfos.imag,c=s.data.get(r.dataId).values,l=s.data.get(i.dataId).values,u=sT({inputs:{x:o},backend:s,attrs:{dtype:`complex64`}}),d=s.data.get(u.dataId),f=d.complexTensorInfos.real,p=d.complexTensorInfos.imag,m=s.data.get(f.dataId).values,h=s.data.get(p.dataId).values,[g,_,v]=n(a.shape,o.shape,c,l,m,h),y=s.makeTensorInfo(v,`float32`,g),b=s.makeTensorInfo(v,`float32`,_),x=$w({inputs:{real:y,imag:b},backend:s});return s.disposeIntermediateTensorInfo(e),s.disposeIntermediateTensorInfo(u),s.disposeIntermediateTensorInfo(y),s.disposeIntermediateTensorInfo(b),x}else{let e=s.data.get(a.dataId).values,n=s.data.get(o.dataId).values,i=r||a.dtype,[c,l]=t(a.shape,o.shape,e,n,i);return s.makeTensorInfo(l,i,c)}}}function uT(e){return(t,n,r,i,a,o)=>{let s=xi(t,n),c=k(s),l=s.length,u=R(s),d=Hs(`float32`,c),f=Hs(`float32`,c),p=Ai(t,s),m=Ai(n,s),h=od(r,i),g=od(a,o),_=t.length,v=R(t),y=n.length,b=R(n);if(p.length+m.length===0)for(let t=0;t<d.length;t++){let n=t%h.length,r=t%g.length,i=e(h[n*2],h[n*2+1],g[r*2],g[r*2+1]);d[t]=i.real,f[t]=i.imag}else for(let t=0;t<d.length;t++){let n=xa(t,l,u),r=n.slice(-_);p.forEach(e=>r[e]=0);let i=yo(r,_,v),a=n.slice(-y);m.forEach(e=>a[e]=0);let o=yo(a,y,b),s=e(h[i*2],h[i*2+1],g[o*2],g[o*2+1]);d[t]=s.real,f[t]=s.imag}return[d,f,s]}}var dT=Qw(((e,t)=>e+t)),fT=lT(`Add`,dT,uT(((e,t,n,r)=>({real:e+n,imag:t+r})))),pT={kernelName:`Add`,backendName:`cpu`,kernelFunc:fT};function mT(e,t,n,r,i){let a=k(r),o=al(i,n);for(let n=0;n<e.length;n++){let r=e[n];if(r<0)throw Error(`Input x must be non-negative!`);r>=i||(a>0?o[r]+=t[n]:o[r]+=1)}return o}function hT(e,t,n,r=!1){let i=e.shape[0],a=e.shape[1],o=M([i,n],t.dtype);for(let s=0;s<i;s++)for(let i=0;i<a;i++){let a=e.get(s,i);if(a<0)throw Error(`Input x must be non-negative!`);a>=n||(r?o.set(1,s,a):t.size>0?o.set(o.get(s,a)+t.get(s,i),s,a):o.set(o.get(s,a)+1,s,a))}return o}var gT=Qw(((e,t)=>e&t)),_T={kernelName:Yn,backendName:`cpu`,kernelFunc:lT(Yn,gT)};function vT(e){return(t,n,r)=>{let i=$i(n,t.length);for(let n=0;n<t.length;++n)i[n]=e(t[n],r);return i}}function yT(e,t,n){return bT(e,vT(t),n)}function bT(e,t,n){return({inputs:r,attrs:i,backend:a})=>{let{x:o}=r;Y(o,e);let s=a,c=s.data.get(o.dataId).values,l;if(o.dtype===`string`){if(!Array.isArray(c))throw Error(`String tensor's value was not an instance of Array`);l=Hd(c)}else l=c;let u=n||o.dtype,d=t(l,u,i);return s.makeTensorInfo(o.shape,u,d)}}var xT=vT(e=>Math.ceil(e)),ST={kernelName:ks,backendName:`cpu`,kernelFunc:bT(ks,xT)};function CT(e,t,n,r){let i=$i(n,k(t));if(r&&n!==`string`){let t=0;e.forEach(e=>{let n=k(e.shape);i.set(e.vals,t),t+=n})}else{let r=0;e.forEach(e=>{let a=n===`string`?Hd(e.vals):e.vals,o=0;for(let n=0;n<e.shape[0];++n){let s=n*t[1]+r;for(let t=0;t<e.shape[1];++t)i[s+t]=a[o++]}r+=e.shape[1]})}return i}var wT=Qw((e,t)=>+(e===t)),TT=lT(zo,wT,null,`bool`),ET={kernelName:zo,backendName:`cpu`,kernelFunc:TT},DT=vT(e=>Math.exp(e)),OT=bT(`Exp`,DT,`float32`),kT={kernelName:`Exp`,backendName:`cpu`,kernelFunc:OT},AT=vT(e=>Math.expm1(e)),jT={kernelName:Ke,backendName:`cpu`,kernelFunc:bT(Ke,AT)},MT=vT(e=>Math.floor(e)),NT={kernelName:Wl,backendName:`cpu`,kernelFunc:bT(Wl,MT)},PT=Qw((e,t)=>Math.floor(e/t)),FT={kernelName:ie,backendName:`cpu`,kernelFunc:lT(ie,PT,null,`int32`)};function IT(e,t,n,r,i,a,o,s,c){let l=M([r,a],n);for(let n=0;n<r;n++){let r=[],u=0;for(let t=0;t<i;t++){let a=e[n*i+t];u+=a*o[t],r.push(a)}if(u<0||u>=c/a)throw Error(`Invalid indices: ${r} does not index into ${s}`);for(let e=0;e<a;e++)l.values[n*a+e]=t.get(...t.indexToLoc(u*a+e))}return l}function LT(e,t,n){let r=M(n,e.dtype);for(let n=0;n<r.size;++n){let i=r.indexToLoc(n).slice(),a=i[0],o=i[2],s=t.locToIndex([a,o]);i[2]=t.values[s];let c=e.locToIndex(i);0<=c&&c<e.values.length&&(r.values[n]=e.values[c])}return r}var RT=Qw((e,t)=>+(e>t)),zT={kernelName:oc,backendName:`cpu`,kernelFunc:lT(oc,RT,null,`bool`)},BT=Qw((e,t)=>+(e>=t)),VT={kernelName:Mt,backendName:`cpu`,kernelFunc:lT(Mt,BT,null,`bool`)},HT=Qw((e,t)=>+(e<t)),UT={kernelName:So,backendName:`cpu`,kernelFunc:lT(So,HT,null,`bool`)},WT=Qw((e,t)=>+(e<=t)),GT={kernelName:Gi,backendName:`cpu`,kernelFunc:lT(Gi,WT,null,`bool`)};function KT(e,t,n){let r=(t-e)/(n-1),i=al(n,`float32`);i[0]=e;for(let e=1;e<i.length;e++)i[e]=i[e-1]+r;return i}var qT=vT(e=>Math.log(e)),JT={kernelName:`Log`,backendName:`cpu`,kernelFunc:bT(`Log`,qT)};function YT(e,t,n,r){let i=Hs(r,k(n));for(let n=0;n<i.length;++n){let r=n*t,a=e[r];for(let n=0;n<t;++n){let t=e[r+n];(Number.isNaN(t)||t>a)&&(a=t)}i[n]=a}return i}var XT=Qw(((e,t)=>Math.max(e,t))),ZT={kernelName:dr,backendName:`cpu`,kernelFunc:lT(dr,XT)},QT=Qw(((e,t)=>Math.min(e,t))),$T={kernelName:Sr,backendName:`cpu`,kernelFunc:lT(Sr,QT)},eE=Qw(((e,t)=>e*t)),tE=lT(Wo,eE,uT(((e,t,n,r)=>({real:e*n-t*r,imag:e*r+t*n})))),nE={kernelName:Wo,backendName:`cpu`,kernelFunc:tE};function rE(e,t,n){return eE([],t,Da(-1,n),e,n)}function iE(e){let{inputs:t,backend:n}=e,{x:r}=t;Y(r,`neg`);let i=n.data.get(r.dataId).values,[a,o]=rE(i,r.shape,r.dtype);return n.makeTensorInfo(o,r.dtype,a)}var aE={kernelName:`Neg`,backendName:`cpu`,kernelFunc:iE},oE=Qw(((e,t)=>e===t?0:1)),sE={kernelName:Fn,backendName:`cpu`,kernelFunc:lT(Fn,oE,null,`bool`)};function cE(e,t,n,r,i){let a=t.length,o=k(t),s=R(t),c=R(i),l=Hs(n,k(i));for(let t=0;t<o;++t){let n=xa(t,a,s),i=Array(n.length);for(let e=0;e<i.length;e++)i[e]=n[r[e]];let o=yo(i,a,c);l[o]=e[t]}return l}function lE(e){let{inputs:t,attrs:n,backend:r}=e,{x:i}=t,{perm:a}=n;Y(i,`transpose`);let o=i.shape.length,s=Array(o);for(let e=0;e<s.length;e++)s[e]=i.shape[a[e]];let c=r.data.get(i.dataId).values,l=cE(c,i.shape,i.dtype,a,s);return{dataId:r.write(l,s,i.dtype),shape:s,dtype:i.dtype}}var uE={kernelName:ct,backendName:`cpu`,kernelFunc:lE};function dE(e,t,n,r){let[i,a]=Ge(e,r),o=Rs(t,`int32`),s=al(k(i),o),c=k(a);for(let e=0;e<s.length;++e){let t=e*c,r=1;for(let e=0;e<c;++e)r*=n[t+e];s[e]=r}return{outVals:s,outShape:i,outDtype:o}}function fE(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;Y(i,`prod`);let s=i.shape.length,c=H(a,i.shape),l=Zt(c,s),u=c,d=i,f=[];l!=null&&(d=lE({inputs:{x:i},backend:n,attrs:{perm:l}}),f.push(d),u=or(u.length,s));let p=n.data.get(d.dataId).values,{outVals:m,outShape:h,outDtype:g}=dE(d.shape,d.dtype,p,u),_=h;return o&&(_=xt(h,c)),f.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.makeTensorInfo(_,g,m)}var pE={kernelName:ot,backendName:`cpu`,kernelFunc:fE};function mE(e,t,n){e.forEach((e,r)=>{if(e<0||e>=n){let i=xa(r,t.length,R(t)).join(`,`);throw Error(`indices[${i}] = ${e} is not in [0, ${n})`)}})}function hE(e,t){for(let n=0;n<e.length;++n){let r=e[n],i=n===e.length-1?t:e[n+1].length;if(r.length===0)throw Error(`Ragged splits may not be empty`);if(r[0]<0)throw Error(`Ragged splits must be non-negative`);if(r[r.length-1]>i)throw Error(`Ragged splits must not point past values`);for(let e=1;e<r.length;++e)if(r[e-1]>r[e])throw Error(`Ragged splits must be sorted in ascending order`)}}function gE(e,t,n,r){let i=[],a=0,o=t.length-1+n.length,s=Array(o).fill(null).map(()=>[0]);hE(n,r);let c=1;for(let e=0;e<t.length-1;++e){c*=t[e];let n=t[e+1];for(let t=1;t<c+1;++t)s[e].push(t*n)}for(let r=0;r<e.length;++r){let o=e[r],c=e[r]+1;for(let e=0;e<n.length;++e){let r=n[e],i=e+t.length-1;if(i>=0){let e=s[i],t=e[e.length-1]-r[o];for(let e=o;e<c;++e)s[i].push(r[e+1]+t)}o=r[o],c=r[c]}c!==o&&(i.push([o,c]),a+=c-o)}return{outSplits:s,valueSlices:i,numValues:a}}function _E(e){let t=[];for(let n=0;n<e.length;++n){let r=e[n].length,i=$i(`int32`,r);t.push(i),e[n].forEach((e,t)=>i[t]=e)}return t}function vE(e,t){let n=e.slice(0,t);for(;n.length<t;)n.push(1);for(let r=t;r<e.length;r++)n[t-1]*=e[r];return n}function yE(e,t,n,r,i,a){let o=vE(t,2)[1],s=vE(a,2)[1],c=0;for(let t of n)for(let n=t[0];n<t[1];++n){for(let t=0;t<r;++t)i[c*s+t]=e[n*o+t];++c}}function bE(e,t,n,r,i){let a=t.slice();a[0]=i;let o=$i(n,k(a)),s=e.length;return yE(e,t,r,s===0?0:s/t[0],o,a),[o,a]}function xE(e,t,n,r,i,a,o,s){if(e.length===0)throw Error(`paramsNestedSplits must be non empty`);if(t[0].length===0)throw Error(`Split tensors must not be scalars`);if(mE(a,o,t[0][0]-1),r.length===0)throw Error(`params.rank must be nonzero`);let c=r[0],{outSplits:l,valueSlices:u,numValues:d}=gE(a,o,e,c),f=_E(l),p=bE(n,r,i,u,d);return[f,p[0],p[1]]}var SE=2147483647;function CE(e,t,n,r,i,a,o){if(t.length>1)throw Error(`starts must be a scalar or vector`);if(i.length>1)throw Error(`limits must be a scalar or vector`);if(o.length>1)throw Error(`deltas must be a scalar or vector`);let s=t.length===0,c=i.length===0,l=o.length===0,u=[];s||u.push(t[0]),c||u.push(i[0]),l||u.push(o[0]);for(let e=1;e<u.length;++e)if(u[e]!==u[e-1])throw Error(`starts, limits, and deltas must have the same shape`);let d=u.length===0?1:u[0],f=$i(`int32`,d+1);f[0]=0;for(let t=0;t<d;++t){let n=s?e[0]:e[t],i=c?r[0]:r[t],o=l?a[0]:a[t];if(o===0)throw Error(`Requires delta != 0`);let u;if(o>0&&i<n||o<0&&i>n)u=0;else if(u=Math.ceil(Math.abs((i-n)/o)),u>SE)throw Error(`Requires ((limit - start) / delta) <= ${SE}`);f[t+1]=f[t]+u}let p=f[d],m=$i(n,p),h=0;for(let t=0;t<d;++t){let n=f[t+1]-f[t],r=s?e[0]:e[t],i=l?a[0]:a[t];for(let e=0;e<n;++e)m[h++]=r,r+=i}return[f,m]}var wE=Bu,TE=class e{constructor(e,t,n,r,i,a,o,s,c,l){this.shape=e,this.shapeShape=t,this.values=n,this.valuesShape=r,this.valuesDType=i,this.defaultValue=a,this.defaultValueShape=o,this.rowPartitionValues=s,this.rowPartitionValuesShapes=c,this.rowPartitionTypes=Hu(l),this.raggedRank=Uu(this.rowPartitionTypes)}getRowPartitionTypeByDimension(e){return this.rowPartitionTypes[0]===wE.FIRST_DIM_SIZE?this.rowPartitionTypes[e+1]:this.rowPartitionTypes[e]}getRowPartitionTensor(e){return this.rowPartitionTypes[0]===wE.FIRST_DIM_SIZE?this.rowPartitionValues[e+1]:this.rowPartitionValues[e]}getMaxWidth(t){let n=this.getRowPartitionTensor(t-1);switch(this.getRowPartitionTypeByDimension(t-1)){case wE.VALUE_ROWIDS:return e.getMaxWidthValueRowID(n);case wE.ROW_SPLITS:return e.getMaxWidthRowSplit(n);default:throw Error(`Cannot handle partition type ${wE[this.getRowPartitionTypeByDimension(t-1)]}`)}}static getMaxWidthRowSplit(e){let t=e.length;if(t===0||t===1)return 0;let n=0;for(let r=0;r<t-1;++r){let t=e[r+1]-e[r];t>n&&(n=t)}return n}static getMaxWidthValueRowID(e){let t=e.length;if(t===0)return 0;let n=0,r=e[0],i=0;for(let a=1;a<t;++a){let t=e[a];t!==r&&(r=t,i=Math.max(a-n,i),n=a)}return Math.max(t-n,i)}tensorShapeFromTensor(e,t,n=!0){if(t.length===0){if(e[0]===-1)return[];throw Error(`The only valid scalar shape tensor is the fully unknown shape specified as -1.`)}return DE(e,n)}calculateOutputSize(e){let t=this.valuesShape,n=this.defaultValueShape;Wu(n,t);let r=this.tensorShapeFromTensor(this.shape,this.shapeShape),i=Vu(this.raggedRank,r,t);i[0]<0&&(i[0]=e);for(let e=1;e<=this.raggedRank;++e)i[e]<0&&(i[e]=this.getMaxWidth(e));return i}calculateFirstParentOutputIndex(e,t,n){let r=Math.min(e,n),i=[],a=0;for(let e=0;e<r;++e,a+=t)i.push(a);for(let t=r;t<e;++t)i.push(-1);return o(i.length===e,()=>`Final length of result must be equal to firstDimension.`),i}calculateOutputIndexRowSplit(e,t,n,r){let i=e.length,a=[];for(let o=0;o<i-1;++o){let i=e[o+1]-e[o],s=Math.min(r,i),c=t[o];c===-1&&(s=0);for(let e=0;e<s;++e)a.push(c),c+=n;for(let e=0;e<i-s;++e)a.push(-1)}if(i>0&&a.length!==e[i-1])throw Error(`Invalid row split size.`);return a}calculateOutputIndexValueRowID(e,t,n,r){let i=e.length,a=[];if(i===0)return[];let o=0,s=e[0];if(s>=t.length)throw Error(`Got currentValueRowId=${s}, which is not less than ${t.length}`);let c=t[s];a.push(c);for(let l=1;l<i;++l){let i=e[l];if(i===s)c>=0&&(++o,o<r?c+=n:c=-1);else{if(o=0,s=i,i>=t.length)throw Error(`Got nextValueRowId=${i} which is not less than ${t.length}`);c=t[i]}a.push(c)}if(a.length!==e.length)throw Error(`Invalid row ids.`);return a}calculateOutputIndex(e,t,n,r){let i=this.getRowPartitionTensor(e),a=this.getRowPartitionTypeByDimension(e);switch(a){case wE.VALUE_ROWIDS:return this.calculateOutputIndexValueRowID(i,t,n,r);case wE.ROW_SPLITS:if(i.length-1>t.length)throw Error(`Row partition size is greater than output size: ${i.length-1} > ${t.length}`);return this.calculateOutputIndexRowSplit(i,t,n,r);default:throw Error(`Unsupported partition type: ${wE[a]}`)}}getFirstDimensionSize(){let e=this.rowPartitionValues[0];if(this.rowPartitionTypes.length===0)throw Error(`No row_partition_types given.`);let t=this.rowPartitionTypes[0];switch(t){case wE.FIRST_DIM_SIZE:return e[0];case wE.VALUE_ROWIDS:throw Error(`Cannot handle VALUE_ROWIDS in first dimension.`);case wE.ROW_SPLITS:return this.rowPartitionValuesShapes[0][0]-1;default:throw Error(`Cannot handle type ${wE[t]}`)}}compute(){if(this.rowPartitionValues[0].length<=0)throw Error(`Invalid first partition input. Tensor requires at least one element.`);let e=this.getFirstDimensionSize(),t=this.calculateOutputSize(e),n=Array(this.raggedRank+1);n[n.length-1]=1;for(let e=n.length-2;e>=0;--e)n[e]=n[e+1]*t[e+1];let r=DE(t,!1),i=$i(this.valuesDType,k(r));if(n[0]*t[0]>0){let a=this.calculateFirstParentOutputIndex(e,n[0],t[0]);for(let e=1;e<=this.raggedRank;++e)a=this.calculateOutputIndex(e-1,a,n[e],t[e]);this.setOutput(this.raggedRank,a,i,r)}return[r,i]}setOutput(e,t,n,r){if(n.length===0)return;let i=this.values,a=n,o=r.slice();o=o.slice(e+1);let s=k(o),c=t.length,l=this.defaultValue;if(l.length!==s&&l.length!==1){let e=this.defaultValueShape;A(()=>{l=fr(U(l,e),o).dataSync()})}let u=0,d=0,f=0;for(let e=0;e<=c;++e){let r=e<c?t[e]:-1;if(r===f){++f;continue}if(d<f){let e=i.subarray(u*s);EE(a.subarray(d*s),e,(f-d)*s)}if(e>=c){let e=n.length;r=Math.floor(e/s)}if(r>f)if(this.defaultValue.length===1)a.subarray(f*s,r*s).fill(this.defaultValue[0]),f=r;else for(;r>f;)EE(a.slice(f*s),l,s),++f;r<0?(u=e+1,d=f):(u=e,d=f,f=d+1)}}};function EE(e,t,n){for(let r=0;r<n;r++)e[r]=t[r]}function DE(e,t){let n=[];for(let r of e){if(r<0){if(!t)throw Error(`Dimension ${r} must be >= 0`);if(r<-1)throw Error(`Dimension ${r} must be >= -1`);r=-1}n.push(r)}return n}function OE(e,t,n,r,i,a,o,s,c,l){return new TE(e,t,n,r,i,a,o,s,c,l).compute()}function kE(e,t,n,r){if(e===t||e<t&&n<0||t<e&&n>1)return al(0,r);let i=al(Math.abs(Math.ceil((t-e)/n)),r);t<e&&n===1&&(n=-1),i[0]=e;for(let e=1;e<i.length;e++)i[e]=i[e-1]+n;return i}var AE=vT(e=>1/Math.sqrt(e)),jE={kernelName:Is,backendName:`cpu`,kernelFunc:bT(Is,AE)};function ME(e,t,n,r,i,a,o,s,c,l){let u=[r/i,i],d=e.values,f=t.values;if(r===0)return M(n,t.dtype);let p=c instanceof _a?c:M(u,t.dtype);typeof c==`string`||typeof c==`number`?p.values.fill(c):typeof c==`boolean`&&p.values.fill(+c);for(let e=0;e<a;e++){let a=[],c=0;for(let t=0;t<o;t++){let n=d[e*o+t];a.push(n),c+=n*s[t]}if(c<0||c>=r/i)throw Error(`Invalid indices: ${a} does not index into ${n}`);for(let n=0;n<i;n++)l?p.values[c*i+n]+=f[e*i+n]:p.values[c*i+n]=t.rank===0?f[0]:f[e*i+n]}return p}var NE=vT(e=>1/(1+Math.exp(-e))),PE=yT(Ta,e=>1/(1+Math.exp(-e))),FE={kernelName:Ta,backendName:`cpu`,kernelFunc:PE};function IE(e,t,n,r,i){let a=Du(r,t,n),o=k(n),s=R(r);if(a){let n=Ou(t,s);return i===`string`?e.slice(n,n+o):e.subarray(n,n+o)}let c=M(r,i,i===`string`?Hd(e):e),l=M(n,i);for(let e=0;e<l.size;++e){let n=l.indexToLoc(e),r=n.map((e,n)=>e+t[n]);l.set(c.get(...r),...n)}return i===`string`?Ud(l.values):l.values}function LE(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{begin:a,size:o}=r;Y(i,`slice`);let[s,c]=ku(i,a,o);hu(i,s,c);let l=n.data.get(i.dataId).values,u=IE(l,s,c,i.shape,i.dtype);return n.makeTensorInfo(c,i.dtype,u)}var RE={kernelName:po,backendName:`cpu`,kernelFunc:LE};function zE(e,t,n,r,i,a,o){let s=t[0],c=a[0],l=Array(c),u=Array(s),d=t[1];if(c===0){if(s!==0)throw Error(Td(s));let e=$i(n,0),t=$i(i,0);return[e,[0,d],t,l,u]}let f=!0,p=0,m=Array(c).fill(0);for(let t=0;t<s;++t){let n=e[t*d];if(n<0)throw Error(Ed(t,n));if(n>=c)throw Error(Dd(t,n,c));++m[n],f&&=n>=p,p=n}let h=!0;for(let e=0;e<c;++e){let t=m[e]===0;l[e]=t,h&&=!t,m[e]=Math.max(m[e],1),e>0&&(m[e]+=m[e-1])}if(h&&f){let t=e,n=r;for(let e=0;e<s;++e)u[e]=e;return[t,[s,d],n,l,u]}else{let t=m[c-1],a=$i(n,t*d),f=$i(i,t),p=Array(c).fill(0);for(let t=0;t<s;++t){let n=e[t*d],i=p[n],o=(n===0?0:m[n-1])+i;p[n]++;for(let n=0;n<d;++n)a[o*d+n]=e[t*d+n];f[o]=r[t],u[t]=o}for(let e=0;e<c;++e)if(p[e]===0){let t=e===0?0:m[e-1];a[t*d+0]=e;for(let e=1;e<d;++e)a[t*d+e]=0;f[t]=o}return[a,[t,d],f,l,u]}}function BE(e,t,n,r,i){let a=k(r),o=t[0],s=i.length,c=[],l=1,u=-1;for(let e=0;e<s;++e){let t=i[e];if(t===-1){if(u!==-1)throw Error(Od(u,e));u=e,c.push(1)}else{if(t<0)throw Error(kd(e,t));l*=t,c.push(t)}}if(u!==-1){if(l<=0)throw Error(Ad());let e=Math.trunc(a/l);if(l*e!==a)throw Error(jd(r,c));c[u]=e}if(k(c)!==a)throw Error(Md(r,c));let d=r.length,f=[];if(d>0){f[d-1]=1;for(let e=d-2;e>=0;--e)f[e]=f[e+1]*r[e+1]}let p=[];if(s>0){p[s-1]=1;for(let e=s-2;e>=0;--e)p[e]=p[e+1]*c[e+1]}let m=$i(n,o*s);for(let t=0;t<o;++t){let n=0;for(let r=0;r<d;++r)n+=e[t*d+r]*f[r];for(let e=0;e<s;++e)m[t*s+e]=Math.trunc(n/p[e]),n%=p[e]}return[m,[o,s],c]}function VE(e,t,n,r,i,a=!1,o=0){let s=r.length,c=[t[0],e.length/t[0]],l=c[1],u=s>0?i[s-1]+1:0;if(u<0)throw Error(Nd());let d=t.slice();d[0]=u;let f=$i(n,d.reduce((e,t)=>e*t,1));if(s===0)return u>0&&f.fill(o),[f,d];if(u<=0)throw Error(Nd());let p=0,m=1,h=0,g=i[p];for(;;){let t=0;if(m<s){if(t=i[m],g===t){++m;continue}if(g>=t)throw Error(Pd())}if(g<0||g>=u)throw Error(Fd(g,u));g>h&&f.fill(o,h*l,g*l);for(let t=p;t<m;++t){let n=r[t];if(n<0||n>=c[0])throw Error(Id(t,r[t],c[0]));for(let t=0;t<l;t++)f[g*l+t]+=e[n*l+t]}if(a)for(let e=0;e<l;e++)f[g*l+e]/=m-p;if(p=m,++m,h=g+1,g=t,m>s)break}return h<u&&f.fill(o,h*l,u*l),[f,d]}var HE=vT(e=>Math.sqrt(e)),UE={kernelName:wr,backendName:`cpu`,kernelFunc:yT(wr,e=>Math.sqrt(e))},WE=Qw(((e,t)=>{let n=e-t;return n*n})),GE={kernelName:be,backendName:`cpu`,kernelFunc:lT(be,WE)},KE=vT((e,t)=>{let{pattern:n,replaceGlobal:r,rewrite:i}=t;return e.replace(new RegExp(n,r?`g`:``),i)}),qE={kernelName:En,backendName:`cpu`,kernelFunc:bT(En,KE)};function JE(e,t,n,r){let i=M(e,t.dtype);for(let e=0;e<i.size;e++){let a=i.indexToLoc(e),o=Array(a.length);for(let e=0;e<o.length;e++)o[e]=a[e]*n[e]+r[e];i.set(t.get(...o),...a)}return i}var YE=class{constructor(e,t,n,r,i,a){this.separator=Js(e),this.nGramWidths=t,this.leftPad=Js(n),this.rightPad=Js(r),this.padWidth=i,this.preserveShort=a}getPadWidth(e){return Math.min(this.padWidth<0?e-1:this.padWidth,e-1)}getNumNGrams(e,t){let n=this.getPadWidth(t);return Math.max(0,e+2*n-t+1)}createNGrams(e,t,n,r,i,a){for(let o=0;o<i;++o){let s=this.getPadWidth(a),c=Math.max(0,s-o),l=Math.max(0,s-(i-(o+1))),u=a-(c+l),d=t+(c>0?0:o-s),f=0;f+=c*this.leftPad.length;for(let t=0;t<u;++t)f+=e[d+t].length;f+=l*this.rightPad.length;let p=c+l+u-1;f+=p*this.separator.length,n[r+o]=new Uint8Array(f);let m=n[r+o],h=0,g=e=>e.forEach(e=>m[h++]=e);for(let e=0;e<c;++e)g(this.leftPad),g(this.separator);for(let t=0;t<u-1;++t)g(e[d+t]),g(this.separator);if(u>0){g(e[d+u-1]);for(let e=0;e<l;++e)g(this.separator),g(this.rightPad)}else{for(let e=0;e<l-1;++e)g(this.rightPad),g(this.separator);g(this.rightPad)}}}compute(e,t){let n=e.length,r=t.length;if(r>0){let e=t[0];if(e!==0)throw Error(`First split value must be 0, got ${e}`);for(let i=1;i<r;++i){let r=t[i]>=e;if(r&&=t[i]<=n,!r)throw Error(`Invalid split value ${t[i]}, must be in [${e}, ${n}]`);e=t[i]}if(e!==n)throw Error(`Last split value must be data size. Expected ${n}, got ${e}`)}let i=r-1,a=$i(`int32`,r);if(n===0||r===0){let e=Array(n);for(let e=0;e<=i;++e)a[e]=0;return[e,a]}a[0]=0;for(let e=1;e<=i;++e){let n=t[e]-t[e-1],r=0;this.nGramWidths.forEach(e=>{r+=this.getNumNGrams(n,e)}),this.preserveShort&&n>0&&r===0&&(r=1),a[e]=a[e-1]+r}let o=Array(a[i]);for(let n=0;n<i;++n){let r=t[n],i=a[n];if(this.nGramWidths.forEach(a=>{let s=t[n+1]-t[n],c=this.getNumNGrams(s,a);this.createNGrams(e,r,o,i,c,a),i+=c}),this.preserveShort&&i===a[n]){let a=t[n+1]-t[n];if(a===0)continue;let s=a+2*this.padWidth;this.createNGrams(e,r,o,i,1,s)}}return[o,a]}};function XE(e,t,n,r,i,a,o,s){return new YE(n,r,i,a,o,s).compute(e,t)}function ZE(e,t,n,r){if(!e.length)return;if(t.length===0){for(let t=0;t<e.length;++t)r.push(e.subarray(t,t+1));return}if(t.length===1){let i=t[0],a=e.indexOf(i);for(;a!==-1;){let t=e.subarray(0,a);(!n||t.length!==0)&&r.push(t),e=e.subarray(a+1),a=e.indexOf(i)}(!n||e.length!==0)&&r.push(e);return}let i=0;for(let a=0;a<e.length+1;a++)if(a===e.length||t.indexOf(e[a])!==-1){let t=e.subarray(i,a);(!n||t.length!==0)&&r.push(t),i=a+1}}function QE(e,t,n){let r=e.length,i=[],a=0,o=0,s=Array(r);for(let c=0;c<r;++c){let r=i.length;ZE(e[c],t,n,i);let l=i.length-r;s[c]=l,a+=l,o=Math.max(o,l)}let c=$i(`int32`,a*2),l=Array(a),u=[r,o],d=0;for(let e=0;e<r;++e)for(let t=0;t<s[e];++t)c[d*2]=e,c[d*2+1]=t,l[d]=i[d],++d;return[c,l,u]}function $E(e,t){let n=$i(`int32`,e.length);for(let r=0;r<e.length;++r)n[r]=oa(e[r]).modulo(t).getLowBitsUnsigned();return n}var eD=Qw(((e,t)=>e-t)),tD=lT(`Sub`,eD,uT(((e,t,n,r)=>({real:e-n,imag:t-r})))),nD={kernelName:`Sub`,backendName:`cpu`,kernelFunc:tD};function rD(e,t){let n=Array(e.rank);for(let r=0;r<n.length;r++)n[r]=e.shape[r]*t[r];let r=M(n,e.dtype);for(let t=0;t<r.values.length;++t){let n=r.indexToLoc(t),i=Array(e.rank);for(let t=0;t<i.length;t++)i[t]=n[t]%e.shape[t];let a=e.locToIndex(i);r.values[t]=e.values[a]}return r}var iD=(e,t)=>{let n=t.value-e.value;return n===0?e.index-t.index:n};function aD(e,t,n=0,r=e.length-1){for(;r>n;){if(r-n>600){let i=r-n+1,a=t-n+1,o=Math.log(i),s=.5*Math.exp(2*o/3),c=.5*Math.sqrt(o*s*(i-s)/i)*Math.sign(a-i/2);aD(e,t,Math.max(n,Math.floor(t-a*s/i+c)),Math.min(r,Math.floor(t+(i-a)*s/i+c)))}let i=e[t],a=n,o=r;for(Qo(e,n,t),iD(e[r],i)>0&&Qo(e,n,r);a<o;){for(Qo(e,a,o),a++,o--;iD(e[a],i)<0;)a+=1;for(;iD(e[o],i)>0;)--o}iD(e[n],i)===0?Qo(e,n,o):(o+=1,Qo(e,o,r)),o<=t&&(n=o+1),t<=o&&(r=o-1)}}function oD(e,t,n,r,i){let a=t[t.length-1],[o,s]=[e.length/a,a],c=Hs(n,o*r),l=Hs(`int32`,o*r);for(let t=0;t<o;t++){let n=t*s,a=e.subarray(n,n+s),o=Array(a.length);a.forEach((e,t)=>o[t]={value:e,index:t}),r<o.length&&(aD(o,r),o=o.slice(0,r)),i&&o.sort(iD);let u=t*r,d=c.subarray(u,u+r),f=l.subarray(u,u+r);for(let e=0;e<r;e++)d[e]=o[e].value,f[e]=o[e].index}let u=t.slice();return u[u.length-1]=r,[M(u,n,c),M(u,`int32`,l)]}function sD(e,t,n,r){let i=H(t,n)[0],a=[1,n[0],1];for(let e=0;e<i;e++)a[0]*=n[e];a[1]=n[i];for(let e=i+1;e<n.length;e++)a[2]*=n[e];let o=new Map,s=new Int32Array(n[i]),c=new _a(a,r,e),l=[],u=a[0]===1&&a[2]===1;for(let t=0;t<n[i];t++){let n;if(u)n=e[t].toString();else{let e=[];for(let n=0;n<a[0];n++)for(let r=0;r<a[2];r++)e.push(c.get(n,t,r));n=e.join(`,`)}let r=o.get(n);if(r!=null)s[t]=r;else{let e=o.size;o.set(n,e),s[t]=e,l.push(t)}}let d=a.slice();d[1]=o.size;let f=new _a(d,r);l.forEach((e,t)=>{for(let n=0;n<a[0];n++)for(let r=0;r<a[2];r++)f.set(c.get(n,e,r),n,t,r)});let p=n.slice();return p[i]=d[1],{outputValues:f.values,outputShape:p,indices:s}}var cD=e({addImpl:()=>dT,bincountImpl:()=>mT,bincountReduceImpl:()=>hT,bitwiseAndImpl:()=>gT,castImpl:()=>oT,ceilImpl:()=>xT,concatImpl:()=>CT,equalImpl:()=>wT,expImpl:()=>DT,expm1Impl:()=>AT,floorDivImpl:()=>PT,floorImpl:()=>MT,gatherNdImpl:()=>IT,gatherV2Impl:()=>LT,greaterEqualImpl:()=>BT,greaterImpl:()=>RT,lessEqualImpl:()=>WT,lessImpl:()=>HT,linSpaceImpl:()=>KT,logImpl:()=>qT,maxImpl:()=>YT,maximumImpl:()=>XT,minimumImpl:()=>QT,multiplyImpl:()=>eE,negImpl:()=>rE,notEqualImpl:()=>oE,prodImpl:()=>dE,raggedGatherImpl:()=>xE,raggedRangeImpl:()=>CE,raggedTensorToTensorImpl:()=>OE,rangeImpl:()=>kE,rsqrtImpl:()=>AE,scatterImpl:()=>ME,sigmoidImpl:()=>NE,simpleAbsImpl:()=>Xw,sliceImpl:()=>IE,sparseFillEmptyRowsImpl:()=>zE,sparseReshapeImpl:()=>BE,sparseSegmentReductionImpl:()=>VE,sqrtImpl:()=>HE,squaredDifferenceImpl:()=>WE,staticRegexReplaceImpl:()=>KE,stridedSliceImpl:()=>JE,stringNGramsImpl:()=>XE,stringSplitImpl:()=>QE,stringToHashBucketFastImpl:()=>$E,subImpl:()=>eD,tileImpl:()=>rD,topKImpl:()=>oD,transposeImpl:()=>cE,uniqueImpl:()=>sD}),lD=`4.22.0`;Rl(`cpu`,()=>new Yw,1);var uD=yT(`Elu`,e=>e>=0?e:Math.exp(e)-1),dD={kernelName:`Elu`,backendName:`cpu`,kernelFunc:uD};function fD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{alpha:a}=r;Y([i],`leakyRelu`);let o=k(i.shape),s=n.data.get(i.dataId).values,c=Hs(`float32`,o);for(let e=0;e<s.length;e++)c[e]=s[e]<0?a*s[e]:s[e];return n.makeTensorInfo(i.shape,`float32`,c)}var pD={kernelName:uc,backendName:`cpu`,kernelFunc:fD},mD=Qw((e,t)=>e<0?t*e:e);function hD(e){let{inputs:t,backend:n}=e,{x:r,alpha:i}=t;Y([r,i],`prelu`);let a=n.data.get(r.dataId).values,o=n.data.get(i.dataId).values,[s,c]=mD(r.shape,i.shape,a,o,`float32`);return n.makeTensorInfo(c,`float32`,s)}var gD={kernelName:Br,backendName:`cpu`,kernelFunc:hD},_D=yT(oi,e=>Math.max(0,e)),vD={kernelName:oi,backendName:`cpu`,kernelFunc:_D},yD=yT(Ei,e=>Math.min(Math.max(0,e),6)),bD={kernelName:Ei,backendName:`cpu`,kernelFunc:yD};function xD(e,t,n,r,i){if(n===`linear`)return nT({inputs:{x:t},backend:e});if(n===`relu`)return _D({inputs:{x:t},backend:e});if(n===`elu`)return uD({inputs:{x:t},backend:e});if(n===`relu6`)return yD({inputs:{x:t},backend:e});if(n===`prelu`)return hD({inputs:{x:t,alpha:r},backend:e});if(n===`leakyrelu`)return fD({inputs:{x:t},backend:e,attrs:{alpha:i}});if(n===`sigmoid`)return PE({inputs:{x:t},backend:e});throw Error(`Activation ${n} has not been implemented for the CPU backend.`)}function SD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{shape:a}=r,s=k(i.shape),c=Jc(a,s),l=k(c);o(s===l,()=>`The new shape (${c}) has ${l} elements and the old shape (${i.shape}) has ${s} elements. The new shape and old shape must have the same number of elements.`),n.incRef(i.dataId);let u=n.data.get(i.dataId);if(u.complexTensorInfos!=null){let e=u.complexTensorInfos.real,t=u.complexTensorInfos.imag;e.shape=c,t.shape=c}return{dataId:i.dataId,shape:c,dtype:i.dtype}}var CD={kernelName:Gn,backendName:`cpu`,kernelFunc:SD};function wD(e){let{inputs:t,backend:n,attrs:r}=e,{a:i,b:a}=t,{transposeA:s,transposeB:c}=r;Y([i,a],`matMul`);let l=i.shape.length,u=a.shape.length,d=s?i.shape[l-2]:i.shape[l-1],f=c?a.shape[u-1]:a.shape[u-2],p=s?i.shape[l-1]:i.shape[l-2],m=c?a.shape[u-2]:a.shape[u-1],h=i.shape.slice(0,-2),g=a.shape.slice(0,-2),_=k(h),v=k(g),y=xi(i.shape.slice(0,-2),a.shape.slice(0,-2)).concat([p,m]);o(d===f,()=>`Error in matMul: inner shapes (${d}) and (${f}) of Tensors with shapes ${i.shape} and ${a.shape} and transposeA=${s} and transposeB=${c} must match.`);let b=s?[_,d,p]:[_,p,d],x=c?[v,m,f]:[v,f,m],S=SD({inputs:{x:i},backend:n,attrs:{shape:b}}),C=SD({inputs:{x:a},backend:n,attrs:{shape:x}}),w=s?S.shape[1]:S.shape[2],T=s?S.shape[2]:S.shape[1],E=c?C.shape[1]:C.shape[2],ee=Math.max(_,v),te=n.data.get(S.dataId).values,ne=n.data.get(C.dataId).values,re=R(S.shape),ie=R(C.shape),[ae,oe,se]=s?[re[0],1,re[1]]:[re[0],re[1],1],[ce,le,ue]=c?[1,ie[1],ie[0]]:[ie[1],1,ie[0]],de=T*E,fe=M([ee,T,E],S.dtype),pe=fe.values,me=n.blockSize;for(let e=0;e<ee;e++){let t=e%_,n=e%v;for(let r=0;r<T;r+=me){let i=Math.min(r+me,T);for(let a=0;a<E;a+=me){let o=Math.min(a+me,E);for(let s=0;s<w;s+=me){let c=Math.min(s+me,w);for(let l=r;l<i;l++)for(let r=a;r<o;r++){let i=0;for(let e=s;e<c;e++){let a=te[t*ae+l*oe+e*se],o=ne[e*ce+r*le+n*ue];i+=a*o}pe[e*de+(l*E+r)]+=i}}}}}return n.disposeIntermediateTensorInfo(S),n.disposeIntermediateTensorInfo(C),n.makeTensorInfo(y,fe.dtype,fe.values)}var TD={kernelName:bi,backendName:`cpu`,kernelFunc:wD};function ED(e){let{inputs:t,backend:n,attrs:r}=e,{a:i,b:a,bias:o,preluActivationWeights:s}=t,{transposeA:c,transposeB:l,activation:u,leakyreluAlpha:d}=r,f,p,m,h=[];f=wD({inputs:{a:i,b:a},attrs:{transposeA:c,transposeB:l},backend:n}),o&&(p=fT({inputs:{a:f,b:o},backend:n}),h.push(f),f=p),u&&(m=xD(n,f,u,s,d),h.push(f),f=m);for(let e of h)n.disposeIntermediateTensorInfo(e);return f}var DD={kernelName:Ot,backendName:`cpu`,kernelFunc:ED},OD={kernelName:sn,backendName:`cpu`,kernelFunc:yT(sn,e=>Math.acos(e))},kD={kernelName:vn,backendName:`cpu`,kernelFunc:yT(vn,e=>Math.acosh(e))};function AD(e){let{inputs:t,backend:n}=e,r=t;Y(t,`addN`);let i=r.map(e=>n.data.get(e.dataId).values),a=M(r[0].shape,r[0].dtype),o=a.values;for(let e=0;e<r.length;e++){let t=i[e];for(let e=0;e<o.length;e++)o[e]+=t[e]}return n.makeTensorInfo(a.shape,a.dtype,a.values)}var jD={kernelName:We,backendName:`cpu`,kernelFunc:AD};function MD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;Y(i,`all`);let s=H(a,i.shape),c=s,l=Zt(c,i.shape.length),u=i;l!=null&&(u=lE({inputs:{x:i},backend:n,attrs:{perm:l}}),c=or(c.length,i.shape.length)),cn(`all`,c,u.shape.length);let[d,f]=Ge(u.shape,c),p=k(f),m=al(k(d),u.dtype),h=n.data.get(u.dataId).values;for(let e=0;e<m.length;++e){let t=e*p,n=h[t];for(let e=0;e<p;++e){let r=h[t+e];n&&=r}m[e]=n}l!=null&&n.disposeIntermediateTensorInfo(u);let g=n.makeTensorInfo(d,u.dtype,m);if(o){let e=xt(d,s),t=SD({inputs:{x:g},backend:n,attrs:{shape:e}});return n.disposeIntermediateTensorInfo(g),t}return g}var ND={kernelName:`All`,backendName:`cpu`,kernelFunc:MD};function PD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;Y(i,`any`);let s=H(a,i.shape),c=s,l=Zt(c,i.shape.length),u=i;l!=null&&(u=lE({inputs:{x:i},backend:n,attrs:{perm:l}}),c=or(c.length,i.shape.length)),cn(`any`,c,u.shape.length);let[d,f]=Ge(u.shape,c),p=k(f),m=al(k(d),u.dtype),h=n.data.get(u.dataId).values;for(let e=0;e<m.length;++e){let t=e*p,n=h[t];for(let e=0;e<p;++e){let r=h[t+e];n||=r}m[e]=n}l!=null&&n.disposeIntermediateTensorInfo(u);let g=n.makeTensorInfo(d,u.dtype,m);if(o){let e=xt(d,s),t=SD({inputs:{x:g},backend:n,attrs:{shape:e}});return n.disposeIntermediateTensorInfo(g),t}return g}var FD={kernelName:`Any`,backendName:`cpu`,kernelFunc:PD};function ID(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a}=r;Y(i,`argMax`);let o=H(a,i.shape),s=Zt(o,i.shape.length),c=i,l=[];s!=null&&(c=lE({inputs:{x:i},backend:n,attrs:{perm:s}}),l.push(c),o=or(o.length,c.shape.length)),o=[o[0]],cn(`argMax`,o,c.shape.length);let[u,d]=Ge(c.shape,o),f=al(k(u),`int32`),p=k(d),m=n.data.get(c.dataId).values;for(let e=0;e<f.length;++e){let t=e*p,n=m[t],r=0;for(let e=0;e<p;++e){let i=m[t+e];i>n&&(n=i,r=e)}f[e]=r}return l.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.makeTensorInfo(u,`int32`,f)}var LD={kernelName:ar,backendName:`cpu`,kernelFunc:ID};function RD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a}=r;Y(i,`argMin`);let o=H(a,i.shape),s=Zt(o,i.shape.length),c=i,l=[];s!=null&&(c=lE({inputs:{x:i},backend:n,attrs:{perm:s}}),l.push(c),o=or(o.length,c.shape.length)),o=[o[0]],cn(`argMin`,o,c.shape.length);let[u,d]=Ge(c.shape,o),f=al(k(u),`int32`),p=k(d),m=n.data.get(c.dataId).values;for(let e=0;e<f.length;++e){let t=e*p,n=m[t],r=0;for(let e=0;e<p;++e){let i=m[t+e];i<n&&(n=i,r=e)}f[e]=r}return l.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.makeTensorInfo(u,`int32`,f)}var zD={kernelName:Hl,backendName:`cpu`,kernelFunc:RD},BD={kernelName:ne,backendName:`cpu`,kernelFunc:yT(ne,e=>Math.asin(e))},VD={kernelName:Wr,backendName:`cpu`,kernelFunc:yT(Wr,e=>Math.asinh(e))},HD={kernelName:ut,backendName:`cpu`,kernelFunc:yT(ut,e=>Math.atan(e))},UD={kernelName:Pr,backendName:`cpu`,kernelFunc:lT(Pr,Qw((e,t)=>Math.atan2(e,t)))},WD={kernelName:ei,backendName:`cpu`,kernelFunc:yT(ei,e=>Math.atanh(e))};function GD(e,t,n,r,i,a){let o=i.strideHeight,s=i.strideWidth,c=i.dilationHeight,l=i.dilationWidth,u=i.effectiveFilterHeight,d=i.effectiveFilterWidth,f=i.padInfo.top,p=i.padInfo.left,m=a===`max`?-1/0:1/0,h=M(i.outShape,n),g=h.values,_=i.outShape[1]*i.outShape[2]*i.outShape[3],v=i.outShape[2]*i.outShape[3],y=i.outShape[3];for(let t=0;t<i.batchSize;++t){let n=t*_,h=t*r[0];for(let t=0;t<i.inChannels;++t)for(let _=0;_<i.outHeight;++_){let b=_*o-f,x=Math.max(0,b),S=Math.min(i.inHeight,u+b),C=n+_*v;for(let n=0;n<i.outWidth;++n){let o=n*s-p,u=Math.max(0,o),f=Math.min(i.inWidth,d+o),_=m,v=0,b=0;for(let n=x;n<S;n+=c){let i=h+n*r[1];for(let n=u;n<f;n+=l){let o=e[i+n*r[2]+t];a===`max`&&o>_?_=o:a===`avg`&&(v+=o,b++)}if(isNaN(_))break}let w=C+n*y+t;g[w]=a===`avg`?v/b:_}}}return h}function KD(e,t,n,r,i=!1,a=!1){let o=M(r.outShape,`int32`),s=r.strideHeight,c=r.strideWidth,l=r.dilationHeight,u=r.dilationWidth,d=r.effectiveFilterHeight,f=r.effectiveFilterWidth,p=r.padInfo.top,m=r.padInfo.left,h=M(t,n,e);for(let e=0;e<r.batchSize;++e)for(let t=0;t<r.inChannels;++t)for(let n=0;n<r.outHeight;++n){let g=n*s-p,_=g;for(;_<0;)_+=l;let v=Math.min(r.inHeight,d+g);for(let s=0;s<r.outWidth;++s){let d=s*c-m,p=d;for(;p<0;)p+=u;let y=Math.min(r.inWidth,f+d),b=-1/0,x=-1;for(let n=_;n<v;n+=l){let o=n-g;for(let s=p;s<y;s+=u){let c=s-d,l=h.get(e,n,s,t);l>b&&(b=l,x=i?a?((e*r.inHeight+n)*r.inWidth+s)*r.inChannels+t:(n*r.inWidth+s)*r.inChannels+t:o*f+c)}}o.set(x,e,n,s,t)}}return o}function qD(e,t,n,r,i,a){let o=i.strideDepth,s=i.strideHeight,c=i.strideWidth,l=i.dilationDepth,u=i.dilationHeight,d=i.dilationWidth,f=i.effectiveFilterDepth,p=i.effectiveFilterHeight,m=i.effectiveFilterWidth,h=i.padInfo.front,g=i.padInfo.top,_=i.padInfo.left,v=a===`max`?-1/0:1/0,y=M(i.outShape,n),b=y.values,x=i.outShape[1]*i.outShape[2]*i.outShape[3]*i.outShape[4],S=i.outShape[2]*i.outShape[3]*i.outShape[4],C=i.outShape[3]*i.outShape[4],w=i.outShape[4];for(let t=0;t<i.batchSize;++t){let n=t*x,y=t*r[0];for(let t=0;t<i.inChannels;++t)for(let x=0;x<i.outDepth;++x){let T=x*o-h,E=T;for(;E<0;)E+=l;let ee=Math.min(i.inDepth,f+T),te=n+x*S;for(let n=0;n<i.outHeight;++n){let o=n*s-g,f=o;for(;f<0;)f+=u;let h=Math.min(i.inHeight,p+o),x=te+n*C;for(let n=0;n<i.outWidth;++n){let o=n*c-_,s=o;for(;s<0;)s+=d;let p=Math.min(i.inWidth,m+o),g=x+n*w,S=v,C=0,T=0;for(let n=E;n<ee;n+=l){let i=y+n*r[1];for(let n=f;n<h;n+=u){let o=i+n*r[2];for(let n=s;n<p;n+=d){let i=e[o+n*r[3]+t];if(a===`max`&&i>S?S=i:a===`avg`&&(C+=i,T++),isNaN(S))break}if(isNaN(S))break}if(isNaN(S))break}let te=g+t;b[te]=a===`avg`?C/Math.max(T,1):S}}}}return y}function JD(e,t){let n=M(t.outShape,`int32`),r=t.strideDepth,i=t.strideHeight,a=t.strideWidth,o=t.dilationDepth,s=t.dilationHeight,c=t.dilationWidth,l=t.effectiveFilterDepth,u=t.effectiveFilterHeight,d=t.effectiveFilterWidth,f=t.padInfo.front,p=t.padInfo.top,m=t.padInfo.left;for(let h=0;h<t.batchSize;++h)for(let g=0;g<t.inChannels;++g)for(let _=0;_<t.outDepth;++_){let v=_*r-f,y=v;for(;y<0;)y+=o;let b=Math.min(t.inDepth,l+v);for(let r=0;r<t.outHeight;++r){let l=r*i-p,f=l;for(;f<0;)f+=s;let x=Math.min(t.inHeight,u+l);for(let i=0;i<t.outWidth;++i){let p=i*a-m,S=p;for(;S<0;)S+=c;let C=Math.min(t.inWidth,d+p),w=-1/0,T=-1;for(let t=y;t<b;t+=o){let n=t-v;for(let r=f;r<x;r+=s){let i=r-l;for(let a=S;a<C;a+=c){let o=a-p,s=e.get(h,t,r,a,g);s>=w&&(w=s,T=n*u*d+i*u+o)}}}n.set(T,h,_,r,i,g)}}}return n}function YD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t;Y(i,`avgPool`);let{filterSize:a,strides:s,pad:c,dimRoundingMode:l}=r;o(Dt(s,1),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${s} and dilations '1'`);let u=Ze(i.shape,a,s,1,c,l),d;if(u.filterWidth===1&&u.filterHeight===1&&qn(u.inShape,u.outShape))d=nT({inputs:{x:i},backend:n});else{let e=n.data.get(i.dataId).values,t=R(i.shape),r=GD(e,i.shape,i.dtype,t,u,`avg`);d=n.makeTensorInfo(u.outShape,i.dtype,r.values)}return d}var XD={kernelName:et,backendName:`cpu`,kernelFunc:YD};function ZD(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{filterSize:a,strides:o,pad:s,dimRoundingMode:c,dataFormat:l}=r;Y(i,`avgPool3d`);let u=Lt(i.shape,a,o,1,s,c,l),d=n.data.get(i.dataId).values,f=qD(d,i.shape,i.dtype,R(i.shape),u,`avg`);return n.makeTensorInfo(f.shape,`float32`,f.values)}var QD={kernelName:Bt,backendName:`cpu`,kernelFunc:ZD};function $D(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,{filterSize:o,strides:s,pad:c,dimRoundingMode:l}=r;Y([i,a],`avgPool3DGrad`);let u=Lt(a.shape,o,s,1,c,l),d=u.strideDepth,f=u.strideHeight,p=u.strideWidth,m=u.filterDepth,h=u.filterHeight,g=u.filterWidth,_=u.dilationDepth,v=u.dilationHeight,y=u.dilationWidth,b=u.effectiveFilterDepth,x=u.effectiveFilterHeight,S=u.effectiveFilterWidth,C=b-1-u.padInfo.front,w=S-1-u.padInfo.left,T=x-1-u.padInfo.top,E=M(a.shape,`float32`),ee=1/(m*h*g),te=n.bufferSync(i);for(let e=0;e<u.batchSize;++e)for(let t=0;t<u.inChannels;++t)for(let n=0;n<u.inDepth;++n)for(let r=0;r<u.inHeight;++r)for(let i=0;i<u.inWidth;++i){let a=n-C,o=r-T,s=i-w,c=0;for(let n=0;n<b;n+=_){let r=(a+n)/d;if(!(r<0||r>=u.outDepth||Math.floor(r)!==r))for(let n=0;n<x;n+=v){let i=(o+n)/f;if(!(i<0||i>=u.outHeight||Math.floor(i)!==i))for(let n=0;n<S;n+=y){let a=(s+n)/p;if(a<0||a>=u.outWidth||Math.floor(a)!==a)continue;let o=te.get(e,r,i,a,t);c+=o}}}E.set(c*ee,e,n,r,i,t)}return n.makeTensorInfo(E.shape,E.dtype,E.values)}var eO={kernelName:ic,backendName:`cpu`,kernelFunc:$D};function tO(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,o=a;Y([i,a],`avgPoolGrad`);let{filterSize:s,strides:c,pad:l}=r,u=Ze(o.shape,s,c,1,l),d=u.strideHeight,f=u.strideWidth,p=u.filterHeight,m=u.filterWidth,h=u.dilationHeight,g=u.dilationWidth,_=u.effectiveFilterHeight,v=u.effectiveFilterWidth,y=v-1-u.padInfo.left,b=_-1-u.padInfo.top,x=M(o.shape,`float32`),S=1/(p*m),C=n.data.get(i.dataId).values,w=M(i.shape,`float32`,C);for(let e=0;e<u.batchSize;++e)for(let t=0;t<u.inChannels;++t)for(let n=0;n<u.inHeight;++n)for(let r=0;r<u.inWidth;++r){let i=n-b,a=r-y,o=0;for(let n=0;n<_;n+=h){let r=(i+n)/d;if(!(r<0||r>=u.outHeight||Math.floor(r)!==r))for(let n=0;n<v;n+=g){let i=(a+n)/f;if(i<0||i>=u.outWidth||Math.floor(i)!==i)continue;let s=w.get(e,r,i,t);o+=s}}x.set(o*S,e,n,r,t)}return n.makeTensorInfo(x.shape,x.dtype,x.values)}var nO={kernelName:At,backendName:`cpu`,kernelFunc:tO};function rO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,scale:a,offset:s,mean:c,variance:l}=t;o(c.shape.length===l.shape.length,()=>`Batch normalization gradient requires mean and variance to have equal ranks.`),o(s==null||c.shape.length===s.shape.length,()=>`Batch normalization gradient requires mean and offset to have equal ranks.`),o(a==null||c.shape.length===a.shape.length,()=>`Batch normalization gradient requires mean and scale to have equal ranks.`),Y([i,c,l,a,s],`batchNorm`);let{varianceEpsilon:u}=r;u??=.001;let d=n.data.get(i.dataId).values,f=n.data.get(c.dataId).values,p=n.data.get(l.dataId).values,m=a?n.data.get(a.dataId).values:new Float32Array([1]),h=s?n.data.get(s.dataId).values:new Float32Array([0]),g=new Float32Array(d.length),_=h.length,v=m.length,y=p.length,b=f.length,x=0,S=0,C=0,w=0;for(let e=0;e<d.length;++e)g[e]=h[x++]+(d[e]-f[S++])*m[C++]/Math.sqrt(p[w++]+u),x>=_&&(x=0),S>=b&&(S=0),C>=v&&(C=0),w>=y&&(w=0);return n.makeTensorInfo(i.shape,i.dtype,g)}var iO={kernelName:ft,backendName:`cpu`,kernelFunc:rO};function aO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockShape:a,crops:o}=r;Y([i],`batchToSpaceND`);let s=a.reduce((e,t)=>e*t),c=qu(i.shape,a,s),l=Ju(c.length,a.length),u=Yu(i.shape,a,s),d=Xu(o,a.length),f=Zu(u,o,a.length),p=SD({inputs:{x:i},backend:n,attrs:{shape:c}}),m=lE({inputs:{x:p},backend:n,attrs:{perm:l}}),h=SD({inputs:{x:m},backend:n,attrs:{shape:u}}),g=LE({inputs:{x:h},backend:n,attrs:{begin:d,size:f}});return n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),n.disposeIntermediateTensorInfo(h),g}var oO={kernelName:ui,backendName:`cpu`,kernelFunc:aO};function sO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,weights:a}=t,{size:o}=r,s=n.data.get(i.dataId).values,c=n.data.get(a.dataId).values,l=mT(s,c,a.dtype,a.shape,o);return n.makeTensorInfo([o],a.dtype,l)}var cO={kernelName:ki,backendName:`cpu`,kernelFunc:sO};function lO(e){let{inputs:t,backend:n}=e,{s0:r,s1:i}=t,a=n.data.get(r.dataId).values,o=n.data.get(i.dataId).values,s=xi(Array.from(a),Array.from(o));return n.makeTensorInfo([s.length],`int32`,Int32Array.from(s))}var uO={kernelName:c,backendName:`cpu`,kernelFunc:lO},dO={kernelName:gc,backendName:`cpu`,kernelFunc:yT(gc,(e,t)=>{let n=t;return e>n.clipValueMax?n.clipValueMax:e<n.clipValueMin?n.clipValueMin:e})},fO={kernelName:Zi,backendName:`cpu`,kernelFunc:e=>{let{x:t}=e.inputs,n=e.backend,r=new Float32Array(k(t.shape)),i=n.data.get(t.dataId),a=i.complexTensorInfos.real,o=i.complexTensorInfos.imag,s=n.data.get(a.dataId).values,c=n.data.get(o.dataId).values;for(let e=0;e<s.length;e++){let t=s[e],n=c[e];r[e]=Math.hypot(t,n)}return n.makeOutput(r,t.shape,`float32`)}};function pO(e){let{inputs:t,backend:n}=e,{input:r}=t,i=n.data.get(r.dataId).complexTensorInfos.imag,a=n.data.get(i.dataId).values;return n.makeTensorInfo(i.shape,i.dtype,a)}var mO={kernelName:ji,backendName:`cpu`,kernelFunc:pO};function hO(e){let{inputs:t,backend:n,attrs:r}=e,{axis:i}=r,a=H(i,t[0].shape)[0];Ru(t.map(e=>e.shape),a);let o=zu(t.map(e=>e.shape),a);if(k(o)===0)return n.makeTensorInfo(o,t[0].dtype,[]);let s=t.filter(e=>k(e.shape)>0);if(s.length===1)return nT({inputs:{x:s[0]},backend:n});if(s[0].dtype===`complex64`){let e=s.map(e=>iT({inputs:{input:e},backend:n})),t=s.map(e=>pO({inputs:{input:e},backend:n})),r=hO({inputs:e,backend:n,attrs:{axis:a}}),i=hO({inputs:t,backend:n,attrs:{axis:a}}),o=$w({inputs:{real:r,imag:i},backend:n});return e.forEach(e=>n.disposeIntermediateTensorInfo(e)),t.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.disposeIntermediateTensorInfo(r),n.disposeIntermediateTensorInfo(i),o}let c=s.map(e=>{let t=[-1,k(e.shape.slice(a))];return SD({inputs:{x:e},backend:n,attrs:{shape:t}})}),l=c.map(e=>({vals:n.data.get(e.dataId).values,shape:e.shape}));o=zu(c.map(e=>e.shape),1);let u=c[0].shape[0]===1,d=CT(l,o,t[0].dtype,u),f=zu(s.map(e=>e.shape),a),p=n.makeTensorInfo(f,t[0].dtype,d);return c.forEach(e=>n.disposeIntermediateTensorInfo(e)),p}var gO={kernelName:Bs,backendName:`cpu`,kernelFunc:hO};function _O(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:o,pad:s,dataFormat:c,dilations:l,dimRoundingMode:u}=r;Y([i,a],`conv2d`);let d=nc(c),f=Vr(i.shape,a.shape,o,l,s,u,!1,d),p=f.filterHeight,m=f.filterWidth,h=f.dilationHeight,g=f.dilationWidth,_=f.padInfo.left,v=f.padInfo.top,y=f.dataFormat===`channelsLast`,b=new _a(f.outShape,i.dtype),x=R(i.shape),S=R(a.shape),C=x[0],w=y?x[1]:x[2],T=y?x[2]:1,E=y?1:x[1],ee=b.strides[0],te=y?b.strides[1]:b.strides[2],ne=y?b.strides[2]:1,re=y?1:b.strides[1],ie=n.data.get(i.dataId).values,ae=n.data.get(a.dataId).values,oe=b.values;for(let e=0;e<f.batchSize;++e){let t=e*C,n=e*ee;for(let e=0;e<f.outHeight;++e){let r=n+e*te,i=e*f.strideHeight-v;for(let e=0;e<p;++e){let n=i+e*h;if(n<0||n>=f.inHeight)continue;let a=e*S[0],o=t+n*w;for(let e=0;e<f.outWidth;++e){let t=r+e*ne,n=e*f.strideWidth-_;for(let e=0;e<m;++e){let r=n+e*g;if(r<0||r>=f.inWidth)continue;let i=a+e*S[1],s=o+r*T,c=i;for(let e=0;e<f.inChannels;++e){let n=ie[s+e*E];for(let e=0;e<f.outChannels;++e)oe[t+e*re]+=n*ae[c+e];c+=f.outChannels}}}}}}return n.makeTensorInfo(b.shape,b.dtype,oe)}var vO={kernelName:Ec,backendName:`cpu`,kernelFunc:_O};function yO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,pad:s,dataFormat:c,dimRoundingMode:l,filterShape:u}=r;Y([i,a],`conv2dBackpropFilter`);let d=nc(c),f=Vr(i.shape,u,o,1,s,l,!1,d),{strideHeight:p,strideWidth:m,filterHeight:h,filterWidth:g}=f,_=f.dataFormat===`channelsLast`,v=new _a(f.filterShape,`float32`),y=f.padInfo.left,b=f.padInfo.top,x=n.data.get(i.dataId).values,S=n.data.get(a.dataId).values,C=new _a(i.shape,i.dtype,x),w=new _a(a.shape,a.dtype,S);for(let e=0;e<h;++e){let t=Math.max(0,Math.ceil((b-e)/p)),n=Math.min(f.outHeight,(f.inHeight+b-e)/p);for(let r=0;r<g;++r){let i=Math.max(0,Math.ceil((y-r)/m)),a=Math.min(f.outWidth,(f.inWidth+y-r)/m);for(let o=0;o<f.inChannels;++o)for(let s=0;s<f.outChannels;++s){let c=0;for(let l=0;l<f.batchSize;++l)for(let u=t;u<n;++u){let t=e+u*p-b;for(let e=i;e<a;++e){let n=r+e*m-y;_?c+=C.get(l,t,n,o)*w.get(l,u,e,s):c+=C.get(l,o,t,n)*w.get(l,s,u,e)}}v.set(c,e,r,o,s)}}}return n.makeTensorInfo(v.shape,v.dtype,v.values)}var bO={kernelName:ya,backendName:`cpu`,kernelFunc:yO};function xO(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{inputShape:o,strides:s,pad:c,dataFormat:l,dimRoundingMode:u}=r;Y([i,a],`conv2dBackpropInput`);let d=R(a.shape),f=R(i.shape),p=nc(l),m=Vr(o,a.shape,s,1,c,u,!1,p),h=new _a(m.inShape,`float32`),g=h.values,_=n.data.get(i.dataId).values,v=n.data.get(a.dataId).values,[y,b,x]=d,{batchSize:S,filterHeight:C,filterWidth:w,inChannels:T,inHeight:E,inWidth:ee,outChannels:te,outHeight:ne,outWidth:re,strideHeight:ie,strideWidth:ae}=m;p=m.dataFormat;let oe=C-1-m.padInfo.top,se=w-1-m.padInfo.left,ce=p===`channelsLast`,le=h.strides[0],ue=ce?h.strides[1]:h.strides[2],de=ce?h.strides[2]:1,fe=ce?1:h.strides[1],pe=f[0],me=ce?f[1]:f[2],he=ce?f[2]:1,ge=ce?1:f[1];for(let e=0;e<S;++e)for(let t=0;t<T;++t)for(let n=0;n<E;++n){let r=n-oe,i=Math.max(0,Math.ceil(r/ie)),a=Math.min(ne,(C+r)/ie);for(let o=0;o<ee;++o){let s=o-se,c=Math.max(0,Math.ceil(s/ae)),l=Math.min(re,(w+s)/ae),u=0;for(let n=i;n<a;++n){let i=n*ie-r;for(let r=c;r<l;++r){let a=r*ae-s,o=pe*e+me*n+he*r,c=y*(C-1-i)+b*(w-1-a)+x*t;for(let e=0;e<te;++e){let t=_[o+ge*e],n=v[c+e];u+=t*n}}}let d=le*e+ue*n+de*o+fe*t;g[d]=u}}return n.makeTensorInfo(h.shape,h.dtype,h.values)}var SO={kernelName:ss,backendName:`cpu`,kernelFunc:xO};function CO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:o,pad:s,dilations:c}=r;Y([i,a],`conv3d`);let l=st(i.shape,a.shape,o,c,s),{filterDepth:u,filterHeight:d,filterWidth:f,dilationDepth:p,dilationHeight:m,dilationWidth:h,padInfo:g}=l,_=g.front,v=g.left,y=g.top,b=new _a(l.outShape,i.dtype),x=n.data.get(i.dataId).values,S=n.data.get(a.dataId).values,C=b.values,w=R(i.shape),T=R(a.shape);for(let e=0;e<l.batchSize;++e){let t=e*w[0],n=e*b.strides[0];for(let e=0;e<l.outDepth;++e){let r=n+e*b.strides[1],i=e*l.strideDepth-_;for(let e=0;e<u;++e){let n=i+e*p;if(n<0||n>=l.inDepth)continue;let a=e*T[0],o=t+n*w[1];for(let e=0;e<l.outHeight;++e){let t=r+e*b.strides[2],n=e*l.strideHeight-y;for(let e=0;e<d;++e){let r=n+e*m;if(r<0||r>=l.inHeight)continue;let i=a+e*T[1],s=o+r*w[2];for(let e=0;e<l.outWidth;++e){let n=t+e*l.outChannels,r=e*l.strideWidth-v;for(let e=0;e<f;++e){let t=r+e*h;if(t<0||t>=l.inWidth)continue;let a=i+e*T[2],o=s+t*l.inChannels,c=a;for(let e=0;e<l.inChannels;++e){let t=x[o+e];for(let e=0;e<l.outChannels;++e)C[n+e]+=t*S[c+e];c+=l.outChannels}}}}}}}}return n.makeTensorInfo(b.shape,b.dtype,b.values)}var wO={kernelName:Kc,backendName:`cpu`,kernelFunc:CO};function TO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,pad:s,filterShape:c}=r;Y([i,a],`conv3dBackpropFilterV2`);let l=R(i.shape),u=R(a.shape),d=st(i.shape,c,o,1,s),f=d.strideDepth,p=d.strideHeight,m=d.strideWidth,h=d.filterDepth,g=d.filterHeight,_=d.filterWidth,v=new _a(d.filterShape,`float32`),y=v.values,[b,x,S,C]=v.strides,w=n.data.get(a.dataId).values,[T,E,ee,te]=u,ne=n.data.get(i.dataId).values,[re,ie,ae,oe]=l,se=d.padInfo.front,ce=d.padInfo.left,le=d.padInfo.top;for(let e=0;e<h;++e){let t=Math.max(0,Math.ceil((se-e)/f)),n=Math.min(d.outDepth,(d.inDepth+se-e)/f),r=e*b;for(let i=0;i<g;++i){let a=Math.max(0,Math.ceil((le-i)/p)),o=Math.min(d.outHeight,(d.inHeight+le-i)/p),s=i*x+r;for(let r=0;r<_;++r){let c=Math.max(0,Math.ceil((ce-r)/m)),l=Math.min(d.outWidth,(d.inWidth+ce-r)/m),u=r*S+s;for(let s=0;s<d.inChannels;++s){let h=s*C+u;for(let u=0;u<d.outChannels;++u){let g=0;for(let h=0;h<d.batchSize;++h){let d=h*re,_=h*T;for(let h=t;h<n;++h){let t=(e+h*f-se)*ie+d,n=h*E+_;for(let e=a;e<o;++e){let a=(i+e*p-le)*ae+t,o=e*ee+n;for(let e=c;e<l;++e){let t=(r+e*m-ce)*oe+a,n=e*te+o;g+=ne[t+s]*w[n+u]}}}}y[h+u]=g}}}}}return n.makeTensorInfo(v.shape,v.dtype,v.values)}var EO={kernelName:ka,backendName:`cpu`,kernelFunc:TO};function DO(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{pad:o,strides:s,inputShape:c}=r;Y([i],`conv3dBackpropInputV2`);let l=R(i.shape),u=R(a.shape),d=st(c,a.shape,s,1,o),f=new _a(d.inShape,`float32`),p=f.values,[m,h,g,_]=f.strides,v=n.data.get(i.dataId).values,[y,b,x,S]=l,C=n.data.get(a.dataId).values,[w,T,E,ee]=u,{batchSize:te,filterDepth:ne,filterHeight:re,filterWidth:ie,inChannels:ae,inDepth:oe,inHeight:se,inWidth:ce,outChannels:le,outDepth:ue,outHeight:de,outWidth:fe,strideDepth:pe,strideHeight:me,strideWidth:he}=d,ge=ne-1-d.padInfo.front,_e=re-1-d.padInfo.top,D=ie-1-d.padInfo.left;for(let e=0;e<te;++e)for(let t=0;t<ae;++t)for(let n=0;n<oe;++n){let r=n-ge,i=Math.max(0,Math.ceil(r/pe)),a=Math.min(ue,(ne+r)/pe);for(let o=0;o<se;++o){let s=o-_e,c=Math.max(0,Math.ceil(s/me)),l=Math.min(de,(re+s)/me);for(let u=0;u<ce;++u){let d=u-D,f=Math.max(0,Math.ceil(d/he)),te=Math.min(fe,(ie+d)/he),ae=0;for(let n=i;n<a;++n){let i=n*pe-r;for(let r=c;r<l;++r){let a=r*me-s;for(let o=f;o<te;++o){let s=o*he-d,c=y*e+b*n+x*r+S*o,l=w*(ne-1-i)+T*(re-1-a)+E*(ie-1-s)+ee*t;for(let e=0;e<le;++e){let t=v[c+e],n=C[l+e];ae+=t*n}}}}p[m*e+h*n+g*o+_*u+t]=ae}}}return n.makeTensorInfo(f.shape,f.dtype,f.values)}var OO={kernelName:Ya,backendName:`cpu`,kernelFunc:DO},kO={kernelName:`Cos`,backendName:`cpu`,kernelFunc:yT(`Cos`,e=>Math.cos(e))},AO={kernelName:vs,backendName:`cpu`,kernelFunc:yT(vs,e=>Math.cosh(e))};function jO(e){let{inputs:t,backend:n,attrs:r}=e,{image:i,boxes:a,boxInd:o}=t,{cropSize:s,method:c,extrapolationValue:l}=r,[u,d,f,p]=i.shape,m=a.shape[0],[h,g]=s,_=M([m,h,g,p],`float32`),v=n.data.get(a.dataId).values,y=n.data.get(o.dataId).values,b=n.data.get(i.dataId).values,x=R(i.shape),S=R(_.shape);for(let e=0;e<m;e++){let t=e*4,n=v[t],r=v[t+1],i=v[t+2],a=v[t+3],o=y[e];if(o>=u)continue;let s=h>1?(i-n)*(d-1)/(h-1):0,m=g>1?(a-r)*(f-1)/(g-1):0;for(let t=0;t<h;t++){let u=h>1?n*(d-1)+t*s:.5*(n+i)*(d-1);if(u<0||u>d-1){for(let n=0;n<g;n++)for(let r=0;r<p;r++){let i=r+n*S[2]+t*S[1]+e*S[0];_.values[i]=l}continue}if(c===`bilinear`){let n=Math.floor(u),i=Math.ceil(u),s=u-n;for(let c=0;c<g;c++){let u=g>1?r*(f-1)+c*m:.5*(r+a)*(f-1);if(u<0||u>f-1){for(let n=0;n<p;n++){let r=n+c*S[2]+t*S[1]+e*S[0];_.values[r]=l}continue}let d=Math.floor(u),h=Math.ceil(u),v=u-d;for(let r=0;r<p;r++){let a=r+d*x[2]+n*x[1]+o*x[0],l=b[a];a=r+h*x[2]+n*x[1]+o*x[0];let u=b[a];a=r+d*x[2]+i*x[1]+o*x[0];let f=b[a];a=r+h*x[2]+i*x[1]+o*x[0];let p=b[a],m=l+(u-l)*v,g=f+(p-f)*v;a=r+c*S[2]+t*S[1]+e*S[0],_.values[a]=m+(g-m)*s}}}else for(let n=0;n<g;++n){let i=g>1?r*(f-1)+n*m:.5*(r+a)*(f-1);if(i<0||i>f-1){for(let r=0;r<p;r++){let i=r+n*S[2]+t*S[1]+e*S[0];_.values[i]=l}continue}let s=Math.round(i),c=Math.round(u);for(let r=0;r<p;r++){let i=r+s*x[2]+c*x[1]+o*x[0],a=r+n*S[2]+t*S[1]+e*S[0];_.values[a]=b[i]}}}}return n.makeTensorInfo(_.shape,_.dtype,_.values)}var MO={kernelName:_o,backendName:`cpu`,kernelFunc:jO};function NO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,exclusive:o,reverse:s}=r;Y(i,`cumprod`);let c=Zt([a],i.shape.length),l=i;c!=null&&(l=lE({inputs:{x:i},backend:n,attrs:{perm:c}}));let u=or(1,i.shape.length)[0];if(u!==l.shape.length-1)throw Error(`backend.cumprod in CPU expects an inner-most axis=${l.shape.length-1} but got axis=${u}`);let d=Rs(l.dtype,`int32`),f=so(k(l.shape),d),p=n.data.get(l.dataId).values,m=l.shape[l.shape.length-1],h=s?(e,t)=>e+m-t-1:(e,t)=>e+t;for(let e=0;e<p.length;e+=m)for(let t=0;t<m;t++){let n=h(e,t);if(t===0)f[n]=o?1:p[n];else{let r=h(e,t-1);f[n]=o?p[r]*f[r]:p[n]*f[r]}}let g=n.makeTensorInfo(l.shape,d,f);if(c!=null){let e=Ul(c),t=lE({inputs:{x:g},backend:n,attrs:{perm:e}});return n.disposeIntermediateTensorInfo(g),n.disposeIntermediateTensorInfo(l),t}return g}var PO={kernelName:ao,backendName:`cpu`,kernelFunc:NO};function FO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,exclusive:o,reverse:s}=r;Y(i,`cumsum`);let c=Zt([a],i.shape.length),l=i;c!=null&&(l=lE({inputs:{x:i},backend:n,attrs:{perm:c}}));let u=or(1,i.shape.length)[0];if(u!==l.shape.length-1)throw Error(`backend.cumsum in CPU expects an inner-most axis=${l.shape.length-1} but got axis=${u}`);let d=Rs(l.dtype,`int32`),f=al(k(l.shape),d),p=n.data.get(l.dataId).values,m=l.shape[l.shape.length-1],h=s?(e,t)=>e+m-t-1:(e,t)=>e+t;for(let e=0;e<p.length;e+=m)for(let t=0;t<m;t++){let n=h(e,t);if(t===0)f[n]=o?0:p[n];else{let r=h(e,t-1);f[n]=o?p[r]+f[r]:p[n]+f[r]}}let g=n.makeTensorInfo(l.shape,d,f);if(c!=null){let e=Ul(c),t=lE({inputs:{x:g},backend:n,attrs:{perm:e}});return n.disposeIntermediateTensorInfo(g),n.disposeIntermediateTensorInfo(l),t}return g}var IO={kernelName:Bi,backendName:`cpu`,kernelFunc:FO};function LO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,weights:a}=t,{size:o,binaryOutput:s}=r;if(i.shape.length===1){let e=n.data.get(i.dataId).values,t=n.data.get(a.dataId).values,r=mT(e,t,a.dtype,a.shape,o);return n.makeTensorInfo([o],a.dtype,r)}else if(i.shape.length===2){let e=hT(n.bufferSync(i),n.bufferSync(a),o,s);return n.makeTensorInfo(e.shape,a.dtype,e.values)}throw Error(`Error in denseBincount: input must be at most rank 2, but got rank${i.shape.length}.`)}var RO={kernelName:rl,backendName:`cpu`,kernelFunc:LO};function zO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockSize:a,dataFormat:s}=r;o(s===`NHWC`,()=>`Only NHWC dataFormat supported on CPU for depthToSpace. Got ${s}`);let c=i.shape[0],l=i.shape[1],u=i.shape[2],d=i.shape[3],f=l*a,p=u*a,m=d/(a*a),h=n.data.get(i.dataId).values,g=new Float32Array(c*f*p*m),_=0;for(let e=0;e<c;++e)for(let t=0;t<f;++t){let n=Math.floor(t/a),r=t%a;for(let t=0;t<p;++t){let i=Math.floor(t/a),o=t%a,s=(r*a+o)*m;for(let t=0;t<m;++t){let r=t+s+d*(i+u*(n+l*e));g[_++]=h[r]}}}return n.makeTensorInfo([c,f,p,m],i.dtype,g)}var BO={kernelName:Pl,backendName:`cpu`,kernelFunc:zO};function VO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:s,pad:c,dilations:l,dimRoundingMode:u}=r;Y([i,a],`depthwiseConv2DNative`);let d=R(i.shape),f=R(a.shape),p=l;p??=[1,1],o(Dt(s,p),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${s} and dilations '${p}'`);let m=Vr(i.shape,a.shape,s,p,c,u,!0),{filterHeight:h,filterWidth:g,dilationHeight:_,dilationWidth:v,padInfo:y}=m,b=y.left,x=y.top,S=m.outChannels/m.inChannels,C=new _a(m.outShape,i.dtype),w=n.data.get(i.dataId).values,T=n.data.get(a.dataId).values,E=C.values;for(let e=0;e<m.batchSize;++e){let t=e*d[0],n=e*C.strides[0];for(let e=0;e<m.outHeight;++e){let r=n+e*C.strides[1],i=e*m.strideHeight-x;for(let e=0;e<h;++e){let n=i+e*_;if(n<0||n>=m.inHeight)continue;let a=e*f[0],o=t+n*d[1];for(let e=0;e<m.outWidth;++e){let t=r+e*C.strides[2],n=e*m.strideWidth-b;for(let e=0;e<g;++e){let r=n+e*v;if(r<0||r>=m.inWidth)continue;let i=a+e*f[1],s=o+r*m.inChannels,c=t,l=i;for(let e=0;e<m.inChannels;++e){let t=w[s+e];for(let e=0;e<S;++e)E[c+e]+=t*T[l+e];c+=S,l+=S}}}}}}return n.makeTensorInfo(C.shape,C.dtype,C.values)}var HO={kernelName:ca,backendName:`cpu`,kernelFunc:VO};function UO(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,dilations:s,pad:c,dimRoundingMode:l,filterShape:u}=r;Y([i,a],`depthwiseConv2dNativeBackpropFilter`);let d=Vr(i.shape,u,o,s,c,l,!0),{strideHeight:f,strideWidth:p,filterHeight:m,filterWidth:h}=d,g=new _a(d.filterShape,`float32`),_=d.padInfo.left,v=d.padInfo.top,y=d.outChannels/d.inChannels,b=n.data.get(i.dataId).values,x=new _a(i.shape,i.dtype,b),S=n.data.get(a.dataId).values,C=new _a(a.shape,a.dtype,S);for(let e=0;e<m;++e){let t=Math.max(0,Math.ceil((v-e)/f)),n=Math.min(d.outHeight,(d.inHeight+v-e)/f);for(let r=0;r<h;++r){let i=Math.max(0,Math.ceil((_-r)/p)),a=Math.min(d.outWidth,(d.inWidth+_-r)/p);for(let o=0;o<d.outChannels;++o){let s=Math.trunc(o/y),c=o%y,l=0;for(let c=0;c<d.batchSize;++c)for(let u=t;u<n;++u){let t=e+u*f-v;for(let e=i;e<a;++e){let n=r+e*p-_;l+=x.get(c,t,n,s)*C.get(c,u,e,o)}}g.set(l,e,r,s,c)}}}return n.makeTensorInfo(g.shape,g.dtype,g.values)}var WO={kernelName:wl,backendName:`cpu`,kernelFunc:UO};function GO(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{strides:o,dilations:s,pad:c,dimRoundingMode:l,inputShape:u}=r;Y([i,a],`depthwiseConv2DNativeBackpropInput`);let d=R(i.shape),f=R(a.shape),p=Vr(u,a.shape,o,s,c,l,!0),m=new _a(p.inShape,`float32`),h=m.values,[g,_,v]=m.strides,y=n.data.get(i.dataId).values,[b,x,S]=d,C=n.data.get(a.dataId).values,[w,T,E]=f,{batchSize:ee,filterHeight:te,filterWidth:ne,inChannels:re,inHeight:ie,inWidth:ae,outChannels:oe,outHeight:se,outWidth:ce,strideHeight:le,strideWidth:ue}=p,de=te-1-p.padInfo.top,fe=ne-1-p.padInfo.left,pe=oe/re;for(let e=0;e<ee;++e)for(let t=0;t<re;++t)for(let n=0;n<ie;++n){let r=n-de,i=Math.max(0,Math.ceil(r/le)),a=Math.min(se,(te+r)/le);for(let o=0;o<ae;++o){let s=o-fe,c=Math.max(0,Math.ceil(s/ue)),l=Math.min(ce,(ne+s)/ue),u=0;for(let n=i;n<a;++n){let i=n*le-r;for(let r=c;r<l;++r){let a=r*ue-s,o=b*e+x*n+S*r,c=w*(te-1-i)+T*(ne-1-a)+E*t;for(let e=0;e<pe;++e){let n=y[o+(t*pe+e)],r=C[c+e];u+=n*r}}}h[g*e+_*n+v*o+t]=u}}return n.makeTensorInfo(m.shape,m.dtype,m.values)}var KO={kernelName:_r,backendName:`cpu`,kernelFunc:GO};function qO(e){let{inputs:t,backend:n}=e,{x:r}=t,i=k(r.shape),a=n.data.get(r.dataId).values,o=M([i,i],r.dtype),s=o.values;for(let e=0;e<a.length;e++)s[e*i+e]=a[e];let c=[...r.shape,...r.shape];return n.makeTensorInfo(c,o.dtype,o.values)}var JO={kernelName:me,backendName:`cpu`,kernelFunc:qO},YO={kernelName:ml,backendName:`cpu`,kernelFunc:({inputs:e,backend:t,attrs:n})=>{let{x:r,filter:i}=e,{strides:a,pad:o,dilations:s}=n,c=t,l=c.data.get(r.dataId).values,u=r.shape.length,d=c.data.get(i.dataId).values,f=i.shape.length,{batchSize:p,inHeight:m,inWidth:h,inChannels:g,outHeight:_,outWidth:v,padInfo:y,strideHeight:b,strideWidth:x,filterHeight:S,filterWidth:C,dilationHeight:w,dilationWidth:T,outShape:E}=Zr(r.shape,i.shape,a,o,`NHWC`,s),ee=k(E),te=E.length,ne=$i(r.dtype,ee);for(let e=0;e<p;++e)for(let t=0;t<_;++t){let n=t*b-y.top;for(let a=0;a<v;++a){let o=a*x-y.left;for(let s=0;s<g;++s){let c=-(2**53-1);for(let t=0;t<S;++t){let a=n+t*w;if(a>=0&&a<m)for(let n=0;n<C;++n){let p=o+n*T;if(p>=0&&p<h){let o=yo([e,a,p,s],u,R(r.shape)),m=yo([t,n,s],f,R(i.shape)),h=l[o]+d[m];h>c&&(c=h)}}}let p=yo([e,t,a,s],te,R(E));ne[p]=c}}}return{dataId:c.write(tl(ne,r.dtype),E,r.dtype),shape:E,dtype:r.dtype}}},XO={kernelName:Dr,backendName:`cpu`,kernelFunc:({inputs:e,backend:t,attrs:n})=>{let{x:r,filter:i,dy:a}=e,{strides:s,pad:c,dilations:l}=n,u=t,d=S(r.shape,u.data.get(r.dataId).values),f=S(i.shape,u.data.get(i.dataId).values),{batchSize:p,inHeight:m,inWidth:h,inChannels:g,outHeight:_,outWidth:v,padInfo:y,strideHeight:b,strideWidth:x,filterHeight:C,filterWidth:w,dilationHeight:T,dilationWidth:E,outShape:ee}=Zr(r.shape,i.shape,s,c,`NHWC`,l);o(a.rank===ee.length,()=>`Error in ${Dr}, dy must have the same rank as output ${ee.length}, but got ${a.rank}`);let te=S(ee,u.data.get(a.dataId).values),ne=Hi(i.shape,i.dtype);for(let e=0;e<p;++e)for(let t=0;t<_;++t){let n=t*b-y.top;for(let r=0;r<v;++r){let i=r*x-y.left;for(let a=0;a<g;++a){let o=-(2**53-1),s=0,c=0;for(let t=0;t<C;++t){let r=n+t*T;if(r>=0&&r<m)for(let n=0;n<w;++n){let l=i+n*E;if(l>=0&&l<h){let i=d[e][r][l][a]+f[t][n][a];i>o&&(o=i,s=t,c=n)}}}ne[s][c][a]+=te[e][t][r][a]}}}return{dataId:u.write(tl(ne,r.dtype),i.shape,i.dtype),shape:i.shape,dtype:i.dtype}}},ZO={kernelName:Fe,backendName:`cpu`,kernelFunc:({inputs:e,backend:t,attrs:n})=>{let{x:r,filter:i,dy:a}=e,{strides:s,pad:c,dilations:l}=n,u=t,d=S(r.shape,u.data.get(r.dataId).values),f=S(i.shape,u.data.get(i.dataId).values),{batchSize:p,inHeight:m,inWidth:h,inChannels:g,outHeight:_,outWidth:v,padInfo:y,strideHeight:b,strideWidth:x,filterHeight:C,filterWidth:w,dilationHeight:T,dilationWidth:E,outShape:ee}=Zr(r.shape,i.shape,s,c,`NHWC`,l);o(a.rank===ee.length,()=>`Error in ${Fe}, dy must have the same rank as output ${ee.length}, but got ${a.rank}`);let te=S(ee,u.data.get(a.dataId).values),ne=Hi(r.shape,r.dtype);for(let e=0;e<p;++e)for(let t=0;t<_;++t){let n=t*b-y.top;for(let r=0;r<v;++r){let i=r*x-y.left;for(let a=0;a<g;++a){let o=-(2**53-1),s=n<0?0:n,c=i<0?0:i;for(let t=0;t<C;++t){let r=n+t*T;if(r>=0&&r<m)for(let n=0;n<w;++n){let l=i+n*E;if(l>=0&&l<h){let i=d[e][r][l][a]+f[t][n][a];i>o&&(o=i,s=r,c=l)}}}ne[e][s][c][a]+=te[e][t][r][a]}}}return{dataId:u.write(tl(ne,r.dtype),r.shape,r.dtype),shape:r.shape,dtype:r.dtype}}};function QO(e){let{inputs:t,backend:n,attrs:r}=e,{image:i}=t,{canvas:a,options:o}=r,{contextOptions:s,imageOptions:c}=o||{},l=c?.alpha||1,u=s?.contextType||`2d`;if(u!==`2d`)throw Error(`Context type ${s.contextType} is not supported by the CPU backend.`);let d=a.getContext(u,s?.contextAttributes||{});if(d==null)throw Error(`Could not get the context with ${u} type.`);let[f,p]=i.shape.slice(0,2),m=i.shape.length===2?1:i.shape[2],h=n.data.get(i.dataId).values,g=i.dtype===`float32`?255:1,_=new Uint8ClampedArray(p*f*4);for(let e=0;e<f*p;++e){let t=[0,0,0,255*l];for(let n=0;n<m;n++){let r=h[e*m+n];if(i.dtype===`float32`){if(r<0||r>1)throw Error(`Tensor values for a float32 Tensor must be in the range [0 - 1] but encountered ${r}.`)}else if(i.dtype===`int32`&&(r<0||r>255))throw Error(`Tensor values for a int32 Tensor must be in the range [0 - 255] but encountered ${r}.`);m===1?(t[0]=r*g,t[1]=r*g,t[2]=r*g):t[n]=r*g}let n=e*4;_[n+0]=Math.round(t[0]),_[n+1]=Math.round(t[1]),_[n+2]=Math.round(t[2]),_[n+3]=Math.round(t[3])}a.width=p,a.height=f;let v=new ImageData(_,p,f);return d.putImageData(v,0,0),i}var $O={kernelName:we,backendName:`cpu`,kernelFunc:QO};function ek(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;Y(i,`sum`);let s;s=i.dtype===`bool`?sT({inputs:{x:i},backend:n,attrs:{dtype:`int32`}}):nT({inputs:{x:i},backend:n});let c=s.shape.length,l=H(a,s.shape),u=Zt(l,c),d=l,f=s;u!=null&&(f=lE({inputs:{x:s},backend:n,attrs:{perm:u}}),d=or(d.length,c)),cn(`sum`,d,f.shape.length);let[p,m]=Ge(f.shape,d),h=tT(n,p,Rs(f.dtype,`int32`)),g=k(m),_=n.data.get(h.dataId).values,v=n.data.get(f.dataId).values;for(let e=0;e<_.length;++e){let t=e*g,n=0;for(let e=0;e<g;++e)n+=v[t+e];_[e]=n}if(o){let e=xt(h.shape,l),t=h;h=SD({inputs:{x:h},backend:n,attrs:{shape:e}}),n.disposeIntermediateTensorInfo(t)}return n.disposeIntermediateTensorInfo(s),u!=null&&n.disposeIntermediateTensorInfo(f),h}var tk={kernelName:`Sum`,backendName:`cpu`,kernelFunc:ek};function nk(e){let{inputs:t,backend:n,attrs:r}=e,{equation:i}=r,a=t,{allDims:o,summedDims:s,idDims:c}=vd(i,a.length);bd(o.length,c,a);let{path:l,steps:u}=xd(s,c),d=u.length,f=null,p=o.length,m=[];for(let e=0;e<d;++e){for(let t of u[e]){let{permutationIndices:e,expandDims:r}=yd(p,c[t]),i;Sd(e)?i=a[t]:(i=lE({inputs:{x:a[t]},backend:n,attrs:{perm:e}}),m.push(i));let o=i.shape.slice();for(let e=0;e<r.length;++e)o.splice(r[e],0,1);qn(i.shape,o)||(i=SD({inputs:{x:i},backend:n,attrs:{shape:o}}),m.push(i)),f===null?f=i:(f=tE({inputs:{a:i,b:f},backend:n}),m.push(f))}e<d-1&&(l[e]>=0&&(f=ek({inputs:{x:f},backend:n,attrs:{axis:l[e]-(o.length-p),keepDims:!1}}),m.push(f)),p--)}for(let e of m)e!==f&&n.disposeIntermediateTensorInfo(e);return f}var rk={kernelName:An,backendName:`cpu`,kernelFunc:nk};function ik(e){let{inputs:t,backend:n}=e,{dy:r,y:i}=t;Y([r,i],`eluGrad`);let a=new Float32Array(k(i.shape)),o=n.data.get(i.dataId).values,s=n.data.get(r.dataId).values;for(let e=0;e<o.length;++e){let t=o[e];t>=0?a[e]=s[e]:a[e]=s[e]*(t+1)}return n.makeTensorInfo(i.shape,`float32`,a)}var ak={kernelName:b,backendName:`cpu`,kernelFunc:ik},ok=ed,sk=td,ck=nd,lk=rd,uk=id,dk=ad,fk={kernelName:`Erf`,backendName:`cpu`,kernelFunc:yT(`Erf`,e=>{let t=Math.sign(e),n=Math.abs(e),r=1/(1+ok*n);return t*(1-((((dk*r+uk)*r+lk)*r+ck)*r+sk)*r*Math.exp(-n*n))})};function pk(e){let{inputs:t,backend:n,attrs:r}=e,{input:i}=t,{dim:a}=r,s=i.shape.length,c=i.shape.slice(),l=a;return a<0&&(o(-(s+1)<=a,()=>`Axis must be in the interval [${-(s+1)}, ${s}]`),l=s+a+1),c.splice(l,0,1),SD({inputs:{x:i},backend:n,attrs:{shape:c}})}var mk={kernelName:Vn,backendName:`cpu`,kernelFunc:pk},hk=lT(Et,Qw((e,t)=>e/t)),gk={kernelName:Et,backendName:`cpu`,kernelFunc:hk};function _k(e,t,n){let r=e.shape,i=r[0],a=r[1],o=n.data.get(e.dataId),s=o.complexTensorInfos.real,c=o.complexTensorInfos.imag,l=[i,a],u=k(l),d=Hs(`float32`,u),f=Hs(`float32`,u);for(let e=0;e<i;e++){let r=LE({inputs:{x:s},backend:n,attrs:{begin:[e,0],size:[1,a]}}),i=LE({inputs:{x:c},backend:n,attrs:{begin:[e,0],size:[1,a]}}),o=$w({inputs:{real:r,imag:i},backend:n}),{real:l,imag:u}=vk(o,t,n),p=od(l,u);for(let t=0;t<a;t++){let n=ud(p,t);d[e*a+t]=n.real,f[e*a+t]=n.imag}n.disposeIntermediateTensorInfo(r),n.disposeIntermediateTensorInfo(i),n.disposeIntermediateTensorInfo(o)}let p=n.makeTensorInfo(l,`float32`,d),m=n.makeTensorInfo(l,`float32`,f),h=$w({inputs:{real:p,imag:m},backend:n});return n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),h}function vk(e,t,n){let r=k(e.shape),i=n.data.get(e.dataId),a=n.data.get(i.complexTensorInfos.real.dataId).values,o=n.data.get(i.complexTensorInfos.imag.dataId).values;if(yk(r)){let i=bk(a,o,r,t,n),s=[e.shape[0],e.shape[1]];if(t){let e=n.makeTensorInfo(s,`float32`,i.real),t=n.makeTensorInfo(s,`float32`,i.imag),a=n.makeTensorInfo([],`float32`,Da(r,`float32`)),o=nT({inputs:{x:a},backend:n}),c=gk.kernelFunc({inputs:{a:e,b:a},backend:n}),l=gk.kernelFunc({inputs:{a:t,b:o},backend:n}),u=n.data.get(c.dataId).values,d=n.data.get(l.dataId).values;return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),n.disposeIntermediateTensorInfo(a),n.disposeIntermediateTensorInfo(o),n.disposeIntermediateTensorInfo(c),n.disposeIntermediateTensorInfo(l),{real:u,imag:d}}return i}else return sd(xk(od(a,o),r,t))}function yk(e){return(e&e-1)==0}function bk(e,t,n,r,i){if(n===1)return{real:e,imag:t};let a=od(e,t),o=n/2,s=cd(a),c=s.real,l=s.imag,u=[c.length],d=i.makeTensorInfo(u,`float32`,c),f=i.makeTensorInfo(u,`float32`,l),p=$w({inputs:{real:d,imag:f},backend:i}),m=ld(a),h=m.real,g=m.imag,_=[h.length],v=i.makeTensorInfo(_,`float32`,h),y=i.makeTensorInfo(_,`float32`,g),b=$w({inputs:{real:v,imag:y},backend:i}),x=bk(c,l,o,r,i),S=x.real,C=x.imag,w=[S.length],T=i.makeTensorInfo(w,`float32`,S),E=i.makeTensorInfo(w,`float32`,C),ee=$w({inputs:{real:T,imag:E},backend:i}),te=bk(h,g,o,r,i),ne=te.real,re=te.imag,ie=[ne.length],ae=i.makeTensorInfo(ie,`float32`,ne),oe=i.makeTensorInfo(ie,`float32`,re),se=$w({inputs:{real:ae,imag:oe},backend:i}),ce=fd(n,r),le=[ce.real.length],ue=i.makeTensorInfo(le,`float32`,ce.real),de=i.makeTensorInfo(le,`float32`,ce.imag),fe=$w({inputs:{real:ue,imag:de},backend:i}),pe=tE({inputs:{a:fe,b:se},backend:i}),me=fT({inputs:{a:ee,b:pe},backend:i}),he=tD({inputs:{a:ee,b:pe},backend:i}),ge=iT({inputs:{input:me},backend:i}),_e=iT({inputs:{input:he},backend:i}),D=pO({inputs:{input:me},backend:i}),ve=pO({inputs:{input:he},backend:i}),ye=hO({inputs:[ge,_e],backend:i,attrs:{axis:0}}),be=hO({inputs:[D,ve],backend:i,attrs:{axis:0}}),xe=i.data.get(ye.dataId).values,Se=i.data.get(be.dataId).values;return i.disposeIntermediateTensorInfo(d),i.disposeIntermediateTensorInfo(f),i.disposeIntermediateTensorInfo(p),i.disposeIntermediateTensorInfo(v),i.disposeIntermediateTensorInfo(y),i.disposeIntermediateTensorInfo(b),i.disposeIntermediateTensorInfo(T),i.disposeIntermediateTensorInfo(E),i.disposeIntermediateTensorInfo(ee),i.disposeIntermediateTensorInfo(ae),i.disposeIntermediateTensorInfo(oe),i.disposeIntermediateTensorInfo(se),i.disposeIntermediateTensorInfo(ue),i.disposeIntermediateTensorInfo(de),i.disposeIntermediateTensorInfo(fe),i.disposeIntermediateTensorInfo(pe),i.disposeIntermediateTensorInfo(me),i.disposeIntermediateTensorInfo(he),i.disposeIntermediateTensorInfo(ge),i.disposeIntermediateTensorInfo(D),i.disposeIntermediateTensorInfo(_e),i.disposeIntermediateTensorInfo(ve),i.disposeIntermediateTensorInfo(ye),i.disposeIntermediateTensorInfo(be),{real:xe,imag:Se}}function xk(e,t,n){let r=new Float32Array(t*2);for(let i=0;i<t;i++){let a=0,o=0;for(let r=0;r<t;r++){let s=pd(i*r,t,n),c=ud(e,r);a+=c.real*s.real-c.imag*s.imag,o+=c.real*s.imag+c.imag*s.real}n&&(a/=t,o/=t),dd(r,a,o,i)}return r}function Sk(e){let{inputs:t,backend:n}=e,{input:r}=t,i=k(r.shape),a=r.shape[r.shape.length-1],o=i/a,s=SD({inputs:{x:r},backend:n,attrs:{shape:[o,a]}}),c=_k(s,!1,n),l=SD({inputs:{x:c},backend:n,attrs:{shape:r.shape}});return n.disposeIntermediateTensorInfo(s),n.disposeIntermediateTensorInfo(c),l}var Ck={kernelName:`FFT`,backendName:`cpu`,kernelFunc:Sk};function wk(e){let{backend:t,attrs:n}=e,{shape:r,value:i,dtype:a}=n,o=a||ls(i),s=$i(o,k(r));return Ek(s,i,o),t.makeTensorInfo(r,o,s)}var Tk={kernelName:Qt,backendName:`cpu`,kernelFunc:wk};function Ek(e,t,n){e.fill(t)}var Dk={kernelName:sr,backendName:`cpu`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{image:r}=e,i=n,a=Hs(r.dtype,k(r.shape)),[o,s,c,l]=r.shape,u=i.data.get(r.dataId).values;for(let e=0;e<o;e++){let t=e*c*s*l;for(let e=0;e<s;e++){let n=c*l*e;for(let e=0;e<c;e++){let r=e*l;for(let i=0;i<l;i++){let o=Math.round(c-e-1),s=t+n+r+i,d=u[s];if(o>=0&&o<c){let e=o*l;d=u[t+n+e+i]}a[s]=d}}}}return{dataId:i.write(a,r.shape,r.dtype),shape:r.shape,dtype:r.dtype}}};function Ok(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a,bias:o,preluActivationWeights:s}=t,{strides:c,pad:l,dataFormat:u,dilations:d,dimRoundingMode:f,activation:p,leakyreluAlpha:m}=r,h=_O({inputs:{x:i,filter:a},backend:n,attrs:{strides:c,pad:l,dataFormat:u,dilations:d,dimRoundingMode:f}});if(o){let e=h;if(u===`NCHW`&&o.shape.length===1&&o.shape[0]!==1){let e=SD({inputs:{x:o},backend:n,attrs:{shape:[o.shape[0],1,1]}});h=fT({inputs:{a:h,b:e},backend:n}),n.disposeIntermediateTensorInfo(e)}else h=fT({inputs:{a:h,b:o},backend:n});n.disposeIntermediateTensorInfo(e)}if(p){let e=h;if(u===`NCHW`&&p===`prelu`&&s.shape.length===1&&s.shape[0]!==1){let e=SD({inputs:{x:s},backend:n,attrs:{shape:[s.shape[0],1,1]}});h=xD(n,h,p,e,m),n.disposeIntermediateTensorInfo(e)}else h=xD(n,h,p,s,m);n.disposeIntermediateTensorInfo(e)}return h}var kk={kernelName:Ir,backendName:`cpu`,kernelFunc:Ok};function Ak(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a,bias:o,preluActivationWeights:s}=t,{strides:c,pad:l,dataFormat:u,dilations:d,dimRoundingMode:f,activation:p,leakyreluAlpha:m}=r,h=VO({inputs:{x:i,filter:a},backend:n,attrs:{strides:c,pad:l,dataFormat:u,dilations:d,dimRoundingMode:f}});if(o){let e=h;h=fT({inputs:{a:h,b:o},backend:n}),n.disposeIntermediateTensorInfo(e)}if(p){let e=h;h=xD(n,h,p,s,m),n.disposeIntermediateTensorInfo(e)}return h}var jk={kernelName:ni,backendName:`cpu`,kernelFunc:Ak};function Mk(e){let{inputs:t,backend:n}=e,{params:r,indices:i}=t,a=k(r.shape),o=i.shape,s=o[o.length-1],[c,l,u,d]=du(r,i);if(l===0)return n.makeTensorInfo(c,r.dtype,[]);let f=n.data.get(i.dataId).values,p=IT(f,n.bufferSync(r),r.dtype,l,s,u,d,r.shape,a);return n.makeTensorInfo(c,r.dtype,p.values)}var Nk={kernelName:nt,backendName:`cpu`,kernelFunc:Mk};function Pk(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,indices:a}=t,{axis:s,batchDims:c}=r;Y([i,a],`gatherV2`);let l=H(s,i.shape)[0],u=n.data.get(a.dataId).values,d=i.shape[l];for(let e=0;e<u.length;++e){let t=u[e];o(t<=d-1&&t>=0,()=>`GatherV2: the index value ${t} is not in [0, ${d-1}]`)}let f=c;c??(f=0);let p=k(a.shape),m=Bd(i,a,l,f),h=SD({inputs:{x:i},backend:n,attrs:{shape:[m.batchSize,m.outerSize,m.dimSize,m.sliceSize]}}),g=SD({inputs:{x:a},backend:n,attrs:{shape:[m.batchSize,p/m.batchSize]}}),_=[m.batchSize,m.outerSize,p/m.batchSize,m.sliceSize],v=n.bufferSync(g),y=LT(n.bufferSync(h),v,_);return n.disposeIntermediateTensorInfo(h),n.disposeIntermediateTensorInfo(g),n.makeTensorInfo(m.outputShape,y.dtype,y.values)}var Fk={kernelName:Ht,backendName:`cpu`,kernelFunc:Pk};function Ik(e){let{inputs:t,backend:n}=e,{input:r}=t,i=k(r.shape),a=r.shape[r.shape.length-1],o=i/a,s=SD({inputs:{x:r},backend:n,attrs:{shape:[o,a]}}),c=_k(s,!0,n),l=SD({inputs:{x:c},backend:n,attrs:{shape:r.shape}});return n.disposeIntermediateTensorInfo(s),n.disposeIntermediateTensorInfo(c),l}var Lk={kernelName:Si,backendName:`cpu`,kernelFunc:Ik},Rk={kernelName:Zn,backendName:`cpu`,kernelFunc:yT(Zn,e=>+!!Number.isFinite(e),`bool`)},zk={kernelName:u,backendName:`cpu`,kernelFunc:yT(u,e=>+(Math.abs(e)===1/0),`bool`)},Bk={kernelName:Na,backendName:`cpu`,kernelFunc:yT(Na,e=>+!!Number.isNaN(e),`bool`)};function Vk(e){let{backend:t,attrs:n}=e,{start:r,stop:i,num:a}=n,o=KT(r,i,a);return t.makeTensorInfo([o.length],`float32`,o)}var Hk={kernelName:Ps,backendName:`cpu`,kernelFunc:Vk},Uk={kernelName:pa,backendName:`cpu`,kernelFunc:yT(pa,e=>Math.log1p(e))},Wk={kernelName:Vc,backendName:`cpu`,kernelFunc:lT(Vc,Qw((e,t)=>e&&t),null,`bool`)},Gk={kernelName:Ca,backendName:`cpu`,kernelFunc:yT(Ca,e=>+!e,`bool`)},Kk={kernelName:Ua,backendName:`cpu`,kernelFunc:lT(Ua,Qw((e,t)=>e||t),null,`bool`)};function qk(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{depthRadius:a,bias:o,alpha:s,beta:c}=r;Y(i,`LRN`);let l=i.shape[3],u=l-1,d=n.data.get(i.dataId).values,f=k(i.shape),p=new Float32Array(f);function m(e){let t=e%l,n=e-t+Math.max(0,t-a),r=e-t+Math.min(t+a,u),i=0;for(;n<=r;n++){let e=d[n];i+=e*e}return i}for(let e=0;e<f;e++){let t=m(e);p[e]=d[e]*(o+s*t)**+-c}return n.makeTensorInfo(i.shape,i.dtype,p)}var Jk={kernelName:`LRN`,backendName:`cpu`,kernelFunc:qk};function Yk(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,y:a,dy:o}=t,{depthRadius:s,bias:c,alpha:l,beta:u}=r;Y(o,`LRNGrad`);let d=k(o.shape),f=o.shape[3],p=n.data.get(o.dataId).values,m=n.data.get(i.dataId).values,h=n.data.get(a.dataId).values,g=new Float32Array(d),_=d;for(let e=0;e<_;e++){let t=e%f,n=e-t+Math.max(0,t-s),r=e-t+Math.min(f,t+s+1),i=0;for(let e=n;e<r;e++)i+=m[e]**2;i=l*i+c;for(let t=n;t<r;t++){let n=-2*l*u*m[t]*h[e]/i;e===t&&(n+=i**+-u),n*=p[e],g[t]+=n}}return n.makeTensorInfo(o.shape,i.dtype,g)}var Xk={kernelName:Cs,backendName:`cpu`,kernelFunc:Yk};function Zk(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{reductionIndices:a,keepDims:o}=r,s=n,c=i.shape,l=c.length,u=H(a,c),d=u,f=Zt(d,l),p=s.data.get(i.dataId).values;if(f!=null){let e=Array(l);for(let t=0;t<e.length;t++)e[t]=c[f[t]];p=cE(p,c,i.dtype,f,e),d=or(d.length,l),c=e}Y(i,`max`),cn(`max`,d,l);let[m,h]=Ge(c,d),g=k(h),_=YT(p,g,m,i.dtype),v=s.write(_,m,i.dtype),y=m;return o&&(y=xt(m,u)),{dataId:v,shape:y,dtype:i.dtype}}var Qk={kernelName:`Max`,backendName:`cpu`,kernelFunc:Zk};function $k(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t;Y(i,`maxPool`);let{filterSize:a,strides:s,pad:c,dimRoundingMode:l}=r;o(Dt(s,1),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${s} and dilations '1'`);let u=Ze(i.shape,a,s,1,c,l),d;if(u.filterWidth===1&&u.filterHeight===1&&qn(u.inShape,u.outShape))d=nT({inputs:{x:i},backend:n});else{let e=n.data.get(i.dataId).values,t=R(i.shape),r=GD(e,i.shape,i.dtype,t,u,`max`);d=n.makeTensorInfo(u.outShape,i.dtype,r.values)}return d}var eA={kernelName:Pi,backendName:`cpu`,kernelFunc:$k};function tA(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{filterSize:a,strides:o,pad:s,dimRoundingMode:c,dataFormat:l}=r;Y(i,`maxPool3d`);let u=Lt(i.shape,a,o,1,s,c,l),d=n.data.get(i.dataId).values,f=qD(d,i.shape,i.dtype,R(i.shape),u,`max`);return n.makeTensorInfo(f.shape,`float32`,f.values)}var nA={kernelName:Zc,backendName:`cpu`,kernelFunc:tA};function rA(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,{filterSize:o,strides:s,pad:c,dimRoundingMode:l}=r;Y([i,a],`maxPool3DGrad`);let u=Lt(a.shape,o,s,1,c,l),d=JD(n.bufferSync(a),u),f=u.strideDepth,p=u.strideHeight,m=u.strideWidth,h=u.dilationDepth,g=u.dilationHeight,_=u.dilationWidth,v=u.effectiveFilterDepth,y=u.effectiveFilterHeight,b=u.effectiveFilterWidth,x=v-1-u.padInfo.front,S=b-1-u.padInfo.left,C=y-1-u.padInfo.top,w=M(a.shape,`float32`),T=n.bufferSync(i);for(let e=0;e<u.batchSize;++e)for(let t=0;t<u.inChannels;++t)for(let n=0;n<u.inDepth;++n)for(let r=0;r<u.inHeight;++r)for(let i=0;i<u.inWidth;++i){let a=n-x,o=r-C,s=i-S,c=0;for(let n=0;n<v;n+=h){let r=(a+n)/f;if(!(r<0||r>=u.outDepth||Math.floor(r)!==r))for(let i=0;i<y;i+=g){let a=(o+i)/p;if(!(a<0||a>=u.outHeight||Math.floor(a)!==a))for(let o=0;o<b;o+=_){let l=(s+o)/m;if(l<0||l>=u.outWidth||Math.floor(l)!==l)continue;let f=+(v*y*b-1-d.get(e,r,a,l,t)===n*y*b+i*b+o);if(f===0)continue;let p=T.get(e,r,a,l,t);c+=p*f}}}w.set(c,e,n,r,i,t)}return n.makeTensorInfo(w.shape,w.dtype,w.values)}var iA={kernelName:Ol,backendName:`cpu`,kernelFunc:rA};function aA(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a,output:o}=t,s=a;Y([a,o],`maxPoolGrad`);let{filterSize:c,strides:l,pad:u,dimRoundingMode:d}=r,f=Ze(s.shape,c,l,1,u,d),p=n.data.get(s.dataId).values,m=M(f.outShape,s.dtype,KD(p,s.shape,s.dtype,f).values),h=f.strideHeight,g=f.strideWidth,_=f.dilationHeight,v=f.dilationWidth,y=f.effectiveFilterHeight,b=f.effectiveFilterWidth,x=b-1-f.padInfo.left,S=y-1-f.padInfo.top,C=M(s.shape,`float32`),w=n.data.get(i.dataId).values,T=M(i.shape,`float32`,w);for(let e=0;e<f.batchSize;++e)for(let t=0;t<f.inChannels;++t)for(let n=0;n<f.inHeight;++n)for(let r=0;r<f.inWidth;++r){let i=n-S,a=r-x,o=0;for(let n=0;n<y;n+=_){let r=(i+n)/h;if(!(r<0||r>=f.outHeight||Math.floor(r)!==r))for(let i=0;i<b;i+=v){let s=(a+i)/g;if(s<0||s>=f.outWidth||Math.floor(s)!==s)continue;let c=+(y*b-1-m.get(e,r,s,t)===n*b+i);if(c===0)continue;let l=T.get(e,r,s,t);o+=l*c}}C.set(o,e,n,r,t)}return n.makeTensorInfo(C.shape,C.dtype,C.values)}var oA={kernelName:na,backendName:`cpu`,kernelFunc:aA};function sA(e,t,n,r,i){let a=GD(e,t,n,R(t),i,`max`),o=KD(e,t,n,i,!0,r);return[a.values,o.values]}var cA={kernelName:vl,backendName:`cpu`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{x:r}=e,{filterSize:i,strides:a,pad:o,includeBatchInIndex:s}=t,c=n;Y(r,`MaxPoolWithArgmax`);let l=c.data.get(r.dataId).values,u=Ze(r.shape,i,a,[1,1],o),[d,f]=sA(l,r.shape,r.dtype,s,u),p=c.write(d,u.outShape,r.dtype),m=c.write(f,u.outShape,r.dtype);return[{dataId:p,shape:u.outShape,dtype:r.dtype},{dataId:m,shape:u.outShape,dtype:`int32`}]}};function lA(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r,s=H(a,i.shape),c=Ge(i.shape,s)[1],l=k(c),u=[],d=n.makeTensorInfo([],`float32`,new Float32Array([l]));u.push(d);let f=sT({inputs:{x:i},backend:n,attrs:{dtype:`float32`}});u.push(f);let p=hk({inputs:{a:f,b:d},backend:n});u.push(p);let m=ek({inputs:{x:p},backend:n,attrs:{axis:a,keepDims:o}});return u.forEach(e=>n.disposeIntermediateTensorInfo(e)),m}var uA={kernelName:ce,backendName:`cpu`,kernelFunc:lA};function dA(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;Y(i,`min`);let s=H(a,i.shape),c=s,l=Zt(c,i.shape.length),u=i;l!=null&&(u=lE({inputs:{x:i},backend:n,attrs:{perm:l}}),c=or(c.length,i.shape.length)),cn(`min`,c,u.shape.length);let[d,f]=Ge(u.shape,c),p=k(f),m=al(k(d),u.dtype),h=n.data.get(u.dataId).values;for(let e=0;e<m.length;++e){let t=e*p,n=h[t];for(let e=0;e<p;++e){let r=h[t+e];(Number.isNaN(r)||r<n)&&(n=r)}m[e]=n}l!=null&&n.disposeIntermediateTensorInfo(u);let g=n.makeTensorInfo(d,u.dtype,m);if(o){let e=xt(d,s),t=SD({inputs:{x:g},backend:n,attrs:{shape:e}});return n.disposeIntermediateTensorInfo(g),t}return g}var fA={kernelName:`Min`,backendName:`cpu`,kernelFunc:dA};function pA(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{paddings:a,mode:o}=r;Y(i,`mirrorPad`);let s=a.map((e,t)=>e[0]+i.shape[t]+e[1]),c=a.map(e=>e[0]),l=a.map((e,t)=>e[0]+i.shape[t]),u=o===`reflect`?0:1,d=n.data.get(i.dataId).values,f=i.shape.length,p=R(i.shape),m=k(s),h=s.length,g=R(s),_=Hs(i.dtype,m);for(let e=0;e<m;e++){let t=xa(e,h,g);for(let e=0;e<h;e++)t[e]<c[e]?t[e]=c[e]*2-t[e]-u:t[e]>=l[e]&&(t[e]=(l[e]-1)*2-t[e]+u);t=t.map((e,t)=>e-c[t]),_[e]=d[yo(t,f,p)]}return{dataId:n.write(_,s,i.dtype),shape:s,dtype:i.dtype}}var mA={kernelName:ke,backendName:`cpu`,kernelFunc:pA},hA={kernelName:`Mod`,backendName:`cpu`,kernelFunc:lT(`Mod`,Qw(((e,t)=>{let n=e%t;return e<0&&t<0||e>=0&&t>=0?n:(n+t)%t})))};function gA(e){let{inputs:t,backend:n,attrs:r}=e,{logits:i}=t,{dim:a}=r,o=i.shape.length,s=a;if(s===-1&&(s=o-1),s!==o-1)throw Error(`Softmax along a non-last dimension is not yet supported. Logits was rank ${o} and dim was ${s}`);let c=H([s],i.shape),l=Zk({inputs:{x:i},backend:n,attrs:{reductionIndices:c,keepDims:!1}}),u=xt(l.shape,c),d=SD({inputs:{x:l},backend:n,attrs:{shape:u}}),f=tD({inputs:{a:i,b:d},backend:n}),p=OT({inputs:{x:f},backend:n}),m=ek({inputs:{x:p},backend:n,attrs:{axis:c,keepDims:!1}}),h=SD({inputs:{x:m},backend:n,attrs:{shape:u}}),g=hk({inputs:{a:p,b:h},backend:n});return n.disposeIntermediateTensorInfo(l),n.disposeIntermediateTensorInfo(d),n.disposeIntermediateTensorInfo(f),n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),n.disposeIntermediateTensorInfo(h),g}var _A={kernelName:to,backendName:`cpu`,kernelFunc:gA};function vA(e){let{inputs:t,backend:n,attrs:r}=e,{logits:i}=t,{numSamples:a,seed:o,normalized:s}=r;Y(i,`multinomial`);let c=s?i:gA({inputs:{logits:i},backend:n,attrs:{dim:-1}}),l=c.shape[0],u=c.shape[1],d=n.data.get(c.dataId).values,f=[l,a],p=al(k(f),`int32`);for(let e=0;e<l;++e){let t=e*u,n=new Float32Array(u-1);n[0]=d[t];for(let e=1;e<n.length;++e)n[e]=n[e-1]+d[t+e];let r=AC.alea(o.toString()),i=e*a;for(let e=0;e<a;++e){let t=r();p[i+e]=n.length;for(let r=0;r<n.length;r++)if(t<n[r]){p[i+e]=r;break}}}return s||n.disposeIntermediateTensorInfo(c),n.makeTensorInfo(f,`int32`,p)}var yA={kernelName:wn,backendName:`cpu`,kernelFunc:vA},bA=fn;function xA(e){let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c}=r;Y(i,`NonMaxSuppression`);let l=n.data.get(i.dataId).values,u=n.data.get(a.dataId).values,{selectedIndices:d}=bA(l,u,o,s,c);return n.makeTensorInfo([d.length],`int32`,new Int32Array(d))}var SA={kernelName:No,backendName:`cpu`,kernelFunc:xA},CA=Nn;function wA(e){let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c,padToMaxOutputSize:l}=r;Y(i,`NonMaxSuppressionPadded`);let u=n.data.get(i.dataId).values,d=n.data.get(a.dataId).values,{selectedIndices:f,validOutputs:p}=CA(u,d,o,s,c,l);return[n.makeTensorInfo([f.length],`int32`,new Int32Array(f)),n.makeTensorInfo([],`int32`,new Int32Array([p]))]}var TA={kernelName:nn,backendName:`cpu`,kernelFunc:wA},EA=Re;function DA(e){let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c,softNmsSigma:l}=r;Y(i,`NonMaxSuppressionWithScore`);let u=n.data.get(i.dataId).values,d=n.data.get(a.dataId).values,{selectedIndices:f,selectedScores:p}=EA(u,d,o,s,c,l);return[n.makeTensorInfo([f.length],`int32`,new Int32Array(f)),n.makeTensorInfo([p.length],`float32`,new Float32Array(p))]}var OA={kernelName:mn,backendName:`cpu`,kernelFunc:DA};function kA(e){let{inputs:t,backend:n,attrs:r}=e,{indices:i}=t,{dtype:a,depth:o,onValue:s,offValue:c}=r;Y(i,`oneHot`);let l=k(i.shape),u=new Float32Array(l*o);u.fill(c);let d=n.data.get(i.dataId).values;for(let e=0;e<l;++e)d[e]>=0&&d[e]<o&&(u[e*o+d[e]]=s);return n.makeTensorInfo([...i.shape,o],a,u)}var AA={kernelName:Be,backendName:`cpu`,kernelFunc:kA};function jA(e){let{inputs:t,backend:n}=e,{x:r}=t;if(r.dtype===`string`)throw Error(`zerosLike is not supported for string tensors`);if(r.dtype===`complex64`){let e=iT({inputs:{input:r},backend:n}),t=jA({inputs:{x:e},backend:n}),i=pO({inputs:{input:r},backend:n}),a=jA({inputs:{x:i},backend:n}),o=$w({inputs:{real:t,imag:a},backend:n});return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),n.disposeIntermediateTensorInfo(i),n.disposeIntermediateTensorInfo(a),o}else return wk({backend:n,attrs:{shape:r.shape,value:0,dtype:r.dtype}})}var MA={kernelName:rc,backendName:`cpu`,kernelFunc:jA};function NA(e){let{inputs:t,backend:n}=e,{x:r}=t;if(r.dtype===`string`)throw Error(`onesLike is not supported for string tensors`);if(r.dtype===`complex64`){let e=iT({inputs:{input:r},backend:n}),t=NA({inputs:{x:e},backend:n}),i=pO({inputs:{input:r},backend:n}),a=jA({inputs:{x:i},backend:n}),o=$w({inputs:{real:t,imag:a},backend:n});return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),n.disposeIntermediateTensorInfo(i),n.disposeIntermediateTensorInfo(a),o}else return wk({backend:n,attrs:{shape:r.shape,value:1,dtype:r.dtype}})}var PA={kernelName:gt,backendName:`cpu`,kernelFunc:NA};function FA(e){let{inputs:t,backend:n,attrs:r}=e,{axis:i}=r;if(t.length===1)return pk({inputs:{input:t[0]},backend:n,attrs:{dim:i}});let a=t[0].shape,s=t[0].dtype;t.forEach(e=>{Ba(a,e.shape,`All tensors passed to stack must have matching shapes`),o(s===e.dtype,()=>`All tensors passed to stack must have matching dtypes`)});let c=[],l=hO({inputs:t.map(e=>{let t=pk({inputs:{input:e},backend:n,attrs:{dim:i}});return c.push(t),t}),backend:n,attrs:{axis:i}});return c.forEach(e=>n.disposeIntermediateTensorInfo(e)),l}var IA={kernelName:Kt,backendName:`cpu`,kernelFunc:FA};function LA(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{paddings:a,constantValue:o}=r;Y(i,`pad`);let s=a.map((e,t)=>e[0]+i.shape[t]+e[1]),c=a.map(e=>e[0]),l=n.data.get(i.dataId).values,u=k(i.shape),d=i.shape.length,f=R(i.shape),p=k(s),m=s.length,h=R(s),g=Hs(i.dtype,p);o!==0&&g.fill(o);for(let e=0;e<u;e++){let t=yo(xa(e,d,f).map((e,t)=>e+c[t]),m,h);g[t]=l[e]}return{dataId:n.write(g,s,i.dtype),shape:s,dtype:i.dtype}}var RA={kernelName:tr,backendName:`cpu`,kernelFunc:LA},zA={kernelName:`Pow`,backendName:`cpu`,kernelFunc:lT(`Pow`,Qw((e,t)=>e**+t))};function BA(e){let{inputs:t,backend:n,attrs:r}=e,{paramsNestedSplits:i,paramsDenseValues:a,indices:o}=t,{outputRaggedRank:s}=r,c=i.map(e=>n.data.get(e.dataId).values),l=i.map(e=>e.shape),u=n.data.get(a.dataId).values,d=n.data.get(o.dataId).values,[f,p,m]=xE(c,l,u,a.shape,a.dtype,d,o.shape,s),h=f.map(e=>n.makeTensorInfo([e.length],`int32`,e)),g=n.makeTensorInfo(m,a.dtype,p);return h.concat([g])}var VA={kernelName:Ar,backendName:`cpu`,kernelFunc:BA};function HA(e){let{inputs:t,backend:n}=e,{starts:r,limits:i,deltas:a}=t,o=n.data.get(r.dataId).values,s=n.data.get(i.dataId).values,c=n.data.get(a.dataId).values,[l,u]=CE(o,r.shape,r.dtype,s,i.shape,c,a.shape);return[n.makeTensorInfo([l.length],`int32`,l),n.makeTensorInfo([u.length],r.dtype,u)]}var UA={kernelName:Xr,backendName:`cpu`,kernelFunc:HA};function WA(e){let{inputs:t,backend:n,attrs:r}=e,{shape:i,values:a,defaultValue:o,rowPartitionTensors:s}=t,{rowPartitionTypes:c}=r,l=n.data.get(i.dataId).values,u=n.data.get(a.dataId).values,d=n.data.get(o.dataId).values,f=s.map(e=>n.data.get(e.dataId).values),p=s.map(e=>e.shape),[m,h]=OE(l,i.shape,u,a.shape,a.dtype,d,o.shape,f,p,c);return n.makeTensorInfo(m,a.dtype,h)}var GA={kernelName:Xe,backendName:`cpu`,kernelFunc:WA};function KA(e){let{backend:t,attrs:n}=e,{start:r,stop:i,dtype:a,step:o}=n,s=kE(r,i,o,a);return t.makeTensorInfo([s.length],a,s)}var qA={kernelName:It,backendName:`cpu`,kernelFunc:KA},JA={kernelName:gi,backendName:`cpu`,kernelFunc:yT(gi,e=>1/e)};function YA(e){let{inputs:t,backend:n,attrs:r}=e,{images:i}=t,{alignCorners:a,halfPixelCenters:o,size:s}=r;Y(i,`resizeBilinear`);let c=R(i.shape),[l,u]=s,[d,f,p,m]=i.shape,h=n.data.get(i.dataId).values,g=new Float32Array(k([d,l,u,m])),_=[a&&l>1?f-1:f,a&&u>1?p-1:p],v=[a&&l>1?l-1:l,a&&u>1?u-1:u],y=0,b=_[0]/v[0],x=_[1]/v[1];for(let e=0;e<d;e++)for(let t=0;t<l;t++){let n;n=o?b*(t+.5)-.5:b*t;let r=Math.max(0,Math.floor(n)),i=n-r,a=Math.min(f-1,Math.ceil(n)),s=e*c[0]+r*c[1],l=e*c[0]+a*c[1];for(let e=0;e<u;e++){let t;t=o?x*(e+.5)-.5:x*e;let n=Math.max(0,Math.floor(t)),r=t-n,a=Math.min(p-1,Math.ceil(t)),u=s+n*c[2],d=l+n*c[2],f=s+a*c[2],_=l+a*c[2];for(let e=0;e<m;e++){let t=h[u+e],n=h[d+e],a=h[f+e],o=h[_+e],s=t+(a-t)*r,c=s+(n+(o-n)*r-s)*i;g[y++]=c}}}return n.makeTensorInfo([d,l,u,m],`float32`,g)}var XA={kernelName:i,backendName:`cpu`,kernelFunc:YA};function ZA(e){let{inputs:t,backend:n,attrs:r}=e,{images:i,dy:a}=t,{alignCorners:o}=r;Y([a,i],`resizeBilinearGrad`);let s=R(i.shape),[c,l,u,d]=i.shape,[,f,p]=a.shape,m=new Float32Array(c*l*u*d),h=[o&&f>1?l-1:l,o&&p>1?u-1:u],g=[o&&f>1?f-1:f,o&&p>1?p-1:p],_=h[0]/g[0],v=h[1]/g[1],y=n.data.get(a.dataId).values,b=0;for(let e=0;e<c;e++){let t=e*s[0];for(let e=0;e<f;e++){let n=e*_,r=Math.floor(n),i=Math.min(Math.ceil(n),l-1),a=t+r*s[1],o=t+i*s[1],c=n-r,f=1-c;for(let e=0;e<p;e++){let t=e*v,n=Math.floor(t),r=Math.min(Math.ceil(t),u-1),i=t-n,l=1-i,p=a+n*s[2],h=a+r*s[2],g=o+n*s[2],_=o+r*s[2],x=f*l,S=f*i,C=c*l,w=c*i;for(let e=0;e<d;e++){let t=y[b++];m[p+e]+=t*x,m[h+e]+=t*S,m[g+e]+=t*C,m[_+e]+=t*w}}}}return n.makeTensorInfo([c,u,l,d],`float32`,m)}var QA={kernelName:Fa,backendName:`cpu`,kernelFunc:ZA};function $A(e){let{inputs:t,backend:n,attrs:r}=e,{images:i}=t,{alignCorners:a,halfPixelCenters:o,size:s}=r;Y(i,`resizeNearestNeighbor`);let c=R(i.shape),[l,u]=s,[d,f,p,m]=i.shape,h=n.data.get(i.dataId).values,g=new Float32Array(d*l*u*m),_=[a&&l>1?f-1:f,a&&u>1?p-1:p],v=[a&&l>1?l-1:l,a&&u>1?u-1:u],y=_[0]/v[0],b=_[1]/v[1],x=0;for(let e=0;e<d;e++){let t=e*c[0];for(let e=0;e<l;e++){let n=o?y*(e+.5):y*e,r=Math.min(f-1,a?Math.round(n):Math.floor(n));o&&(r=Math.max(0,r));let i=t+r*c[1];for(let e=0;e<u;e++){let t=o?b*(e+.5):b*e,n=Math.min(p-1,a?Math.round(t):Math.floor(t));o&&(n=Math.max(0,n));let r=i+n*c[2];for(let e=0;e<m;e++){let t=h[r+e];g[x++]=t}}}}return n.makeTensorInfo([d,l,u,m],i.dtype,g)}var ej={kernelName:Nc,backendName:`cpu`,kernelFunc:$A};function tj(e){let{inputs:t,backend:n,attrs:r}=e,{images:i,dy:a}=t,{alignCorners:o}=r;Y([a,i],`resizeNearestNeighborGrad`);let s=R(i.shape),c=R(a.shape),[l,u,d,f]=i.shape,[,p,m]=a.shape,h=new Float32Array(l*u*d*f),g=n.data.get(a.dataId).values,_=[o&&p>1?u-1:u,o&&m>1?d-1:d],v=[o&&p>1?p-1:p,o&&m>1?m-1:m],y=_[0]/v[0],b=_[1]/v[1],x=1/y,S=1/b,C=Math.ceil(x)*2+2,w=Math.ceil(S)*2+2;for(let e=0;e<l;e++){let t=e*s[0];for(let e=0;e<u;e++){let n=t+e*s[1],r=Math.floor(e*x),i=Math.floor(r-C/2);for(let r=0;r<d;r++){let a=n+r*s[2],l=Math.floor(r*S),_=Math.floor(l-w/2);for(let n=0;n<f;n++){let s=0;for(let a=0;a<C;a++){let l=a+i;if(l<0||l>=p)continue;let f=t+l*c[1],h=l*y,v=Math.min(u-1,o?Math.round(h):Math.floor(h));if(e===v)for(let e=0;e<w;e++){let t=e+_;if(t<0||t>=m)continue;let i=f+t*c[2],a=t*b,l=Math.min(d-1,o?Math.round(a):Math.floor(a));r===l&&(s+=g[i+n])}}h[a+n]=s}}}}return n.makeTensorInfo(i.shape,i.dtype,h)}var nj={kernelName:Ts,backendName:`cpu`,kernelFunc:tj};function rj(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{dims:a}=r;Y(i,`reverse`);let o=i.shape.length,s=H(a,i.shape);if(o===0)return nT({inputs:{x:i},backend:n});let c=new _a(i.shape,i.dtype),l=n.bufferSync(i);for(let e=0;e<c.size;e++){let t=c.indexToLoc(e),n=t.slice();s.forEach(e=>n[e]=i.shape[e]-1-n[e]),c.set(l.get(...n),...t)}return n.makeTensorInfo(c.shape,c.dtype,c.values)}var ij={kernelName:fc,backendName:`cpu`,kernelFunc:rj},aj={kernelName:wo,backendName:`cpu`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{image:r}=e,{radians:i,fillValue:a,center:o}=t,s=n,c=Hs(r.dtype,k(r.shape)),[l,u,d,f]=r.shape,[p,m]=Ku(o,u,d),h=Math.sin(i),g=Math.cos(i),_=s.data.get(r.dataId).values;for(let e=0;e<l;e++){let t=e*d*u*f;for(let e=0;e<u;e++){let n=d*f*e;for(let r=0;r<d;r++){let i=r*f;for(let o=0;o<f;o++){let s=[l,e,r,o],v=s[2],y=s[1],b=(v-p)*g-(y-m)*h,x=(v-p)*h+(y-m)*g;b=Math.round(b+p),x=Math.round(x+m);let S=a;if(typeof a!=`number`&&(S=o===3?255:a[o]),b>=0&&b<d&&x>=0&&x<u){let e=d*f*x,n=b*f;S=_[t+e+n+o]}let C=t+n+i+o;c[C]=S}}}}return{dataId:s.write(c,r.shape,r.dtype),shape:r.shape,dtype:r.dtype}}},oj={kernelName:qi,backendName:`cpu`,kernelFunc:yT(qi,e=>{let t=Math.floor(e);return e-t<.5?Math.floor(e):e-t>.5?Math.ceil(e):t%2==0?t:t+1})};function sj(e){let{inputs:t,backend:n,attrs:r}=e,{indices:i,updates:a}=t,{shape:o}=r,{sliceRank:s,numUpdates:c,sliceSize:l,strides:u,outputSize:d}=Xa(a,i,o),f=ME(n.bufferSync(i),n.bufferSync(a),o,d,l,c,s,u,0,!0);return n.makeTensorInfo(o,f.dtype,f.values)}var cj={kernelName:Sc,backendName:`cpu`,kernelFunc:sj};function lj(e,t){let n=0,r=e.length,i=0;for(;n<r;)i=Math.floor((n+r)/2),e[i]<t?n=i+1:r=i;return r}function uj(e,t){let n=0,r=e.length,i=0;for(;n<r;)i=Math.floor((n+r)/2),e[i]<=t?n=i+1:r=i;return r}function dj(e,t,n,r,i,a){let o=$i(`int32`,n*i);for(let s=0;s<n;++s){let n=e.slice(s*r,(s+1)*r),c=s*i;for(let e=0;e<i;++e)o[c+e]=a===`left`?lj(n,t[e+c]):uj(n,t[e+c])}return o}function fj(e){let{inputs:t,backend:n,attrs:r}=e,{sortedSequence:i,values:a}=t,{side:o}=r,s=n.data.get(i.dataId).values,c=n.data.get(a.dataId).values,l=dj(s,c,i.shape[0],i.shape[1],a.shape[1],o);return n.makeTensorInfo(a.shape,`int32`,l)}var pj={kernelName:ha,backendName:`cpu`,kernelFunc:fj};function mj(e){let{inputs:t,backend:n}=e,{condition:r,t:i,e:a}=t;Y([r,i,a],`select`);let o=r.shape.length,s=n.data.get(r.dataId).values,c=n.data.get(i.dataId).values,l=n.data.get(a.dataId).values,u=Rs(i.dtype,a.dtype),d=al(k(i.shape),u),f=0,p=o===0||o>1||i.shape.length===1?1:k(i.shape.slice(1));for(let e=0;e<s.length;e++)for(let t=0;t<p;t++)s[e]===1?d[f++]=c[e]:d[f++]=l[e];return n.makeTensorInfo(i.shape,u,d)}var hj={kernelName:rs,backendName:`cpu`,kernelFunc:mj},gj=Qu,_j=$u,vj={kernelName:Uc,backendName:`cpu`,kernelFunc:yT(Uc,e=>e>=0?_j*e:gj*(Math.exp(e)-1))},yj={kernelName:Ga,backendName:`cpu`,kernelFunc:yT(Ga,e=>e<0?-1:+(e>0))},bj={kernelName:`Sin`,backendName:`cpu`,kernelFunc:yT(`Sin`,e=>Math.sin(e))},xj={kernelName:ms,backendName:`cpu`,kernelFunc:yT(ms,e=>Math.sinh(e))},Sj=Math.log(1.1920928955078125e-7)+2,Cj={kernelName:Ii,backendName:`cpu`,kernelFunc:yT(Ii,e=>{let t=e>-Sj,n=e<Sj,r=Math.exp(e),i;return i=n?r:t?e:Math.log(1+r),i})};function wj(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockShape:a,paddings:o}=r;Y([i],`spaceToBatchND`);let s=k(a),c=[[0,0]];c.push(...o);for(let e=1+a.length;e<i.shape.length;++e)c.push([0,0]);let l=RA.kernelFunc({inputs:{x:i},backend:n,attrs:{paddings:c,constantValue:0}}),u=qu(l.shape,a,s,!1),d=Ju(u.length,a.length,!1),f=Yu(l.shape,a,s,!1),p=SD({inputs:{x:l},backend:n,attrs:{shape:u}}),m=lE({inputs:{x:p},backend:n,attrs:{perm:d}}),h=SD({inputs:{x:m},backend:n,attrs:{shape:f}});return n.disposeIntermediateTensorInfo(l),n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),h}var Tj={kernelName:$c,backendName:`cpu`,kernelFunc:wj};function Ej(e){let{inputs:t,backend:n}=e,{indices:r,values:i,denseShape:a,defaultValue:o}=t;if(a.shape.length!==1)throw Error(`Dense shape must be a vector, saw:
        ${a.shape}`);if(r.shape.length!==2)throw Error(`Indices must be a matrix, saw:
        ${r.shape}`);if(i.shape.length!==1)throw Error(`Values must be a vector, saw:
        ${i.shape}`);if(o.shape.length!==0)throw Error(`Default value must be a scalar, saw:
        ${o.shape}`);let s=n.data.get(r.dataId).values,c=n.data.get(i.dataId).values,l=n.data.get(a.dataId).values,u=n.data.get(o.dataId).values[0],[d,f,p,m,h]=zE(s,r.shape,r.dtype,c,i.dtype,l,u);return[n.makeTensorInfo(f,r.dtype,d),n.makeTensorInfo([f[0]],i.dtype,p),n.makeTensorInfo([m.length],`bool`,new Uint8Array(m.map(e=>Number(e)))),n.makeTensorInfo([h.length],r.dtype,new Int32Array(h))]}var Dj={kernelName:Al,backendName:`cpu`,kernelFunc:Ej};function Oj(e){let{inputs:t,backend:n}=e,{inputIndices:r,inputShape:i,newShape:a}=t;if(r.shape.length!==2)throw Error(`Input indices should be a matrix but received shape
        ${r.shape}`);if(i.shape.length!==1)throw Error(`Input shape should be a vector but received shape
        ${i.shape}`);if(a.shape.length!==1)throw Error(`Target shape should be a vector but received shape ${a.shape}`);let o=Array.from(n.data.get(i.dataId).values),s=n.data.get(r.dataId).values,c=Array.from(n.data.get(a.dataId).values),[l,u,d]=BE(s,r.shape,r.dtype,o,c);return[n.makeTensorInfo(u,r.dtype,l),n.makeTensorInfo([d.length],a.dtype,new Int32Array(d))]}var kj={kernelName:ia,backendName:`cpu`,kernelFunc:Oj};function Aj(e){let{inputs:t,backend:n}=e,{data:r,indices:i,segmentIds:a}=t;if(r.shape.length<1)throw Error(`Data should be at least 1 dimensional but received scalar`);if(i.shape.length!==1)throw Error(`Indices should be a vector but received shape
          ${i.shape}`);if(a.shape.length!==1)throw Error(`Segment ids should be a vector but received shape
          ${a.shape}`);if(i.shape[0]!==a.shape[0])throw Error(`segmentIds and indices should have same size.`);let o=n.data.get(r.dataId).values,s=n.data.get(i.dataId).values,c=n.data.get(a.dataId).values,[l,u]=VE(o,r.shape,r.dtype,s,c,!0);return n.makeTensorInfo(u,r.dtype,l)}var jj={kernelName:bl,backendName:`cpu`,kernelFunc:Aj};function Mj(e){let{inputs:t,backend:n}=e,{data:r,indices:i,segmentIds:a}=t;if(r.shape.length<1)throw Error(`Data should be at least 1 dimensional but received scalar`);if(i.shape.length!==1)throw Error(`Indices should be a vector but received shape
         ${i.shape}`);if(a.shape.length!==1)throw Error(`Segment ids should be a vector but received shape
         ${a.shape}`);if(i.shape[0]!==a.shape[0])throw Error(`segmentIds and indices should have same size.`);let o=n.data.get(r.dataId).values,s=n.data.get(i.dataId).values,c=n.data.get(a.dataId).values,[l,u]=VE(o,r.shape,r.dtype,s,c);return n.makeTensorInfo(u,r.dtype,l)}var Nj={kernelName:pr,backendName:`cpu`,kernelFunc:Mj};function Pj(e){let{inputs:t,backend:n,attrs:r}=e,{sparseIndices:i,sparseValues:a,defaultValue:o}=t,{outputShape:s}=r,{sliceRank:c,numUpdates:l,sliceSize:u,strides:d,outputSize:f}=Xa(a,i,s),p=n.bufferSync(i),m;switch(a.dtype){case`bool`:m=ME(p,n.bufferSync(a),s,f,u,l,c,d,!!n.data.get(o.dataId).values[0],!1);break;case`float32`:{let e=n.bufferSync(a),t=n.data.get(o.dataId).values[0];m=ME(p,e,s,f,u,l,c,d,t,!1);break}case`int32`:{let e=n.bufferSync(a),t=n.data.get(o.dataId).values[0];m=ME(p,e,s,f,u,l,c,d,t,!1);break}case`string`:m=ME(p,n.bufferSync(a),s,f,u,l,c,d,qa(n.data.get(o.dataId).values[0]),!1);break;default:throw Error(`Unsupported type ${a.dtype}`)}return n.makeTensorInfo(s,m.dtype,m.values)}var Fj={kernelName:ue,backendName:`cpu`,kernelFunc:Pj};function Ij(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{numOrSizeSplits:a,axis:o}=r,s=H(o,i.shape)[0],c=wd(i,a,s),l=Array(i.shape.length).fill(0),u=i.shape.slice();return c.map(e=>{let t=[...u];t[s]=e;let r=LE({inputs:{x:i},backend:n,attrs:{begin:l,size:t}});return l[s]+=e,r})}var Lj={kernelName:ul,backendName:`cpu`,kernelFunc:Ij},Rj={kernelName:je,backendName:`cpu`,kernelFunc:({inputs:e,backend:t})=>{let{x:n}=e,r=t;Y(n,`square`);let i=r.data.get(n.dataId).values,a=new Float32Array(i.length);for(let e=0;e<i.length;++e){let t=i[e];a[e]=t*t}return{dataId:r.write(a,n.shape,n.dtype),shape:n.shape,dtype:n.dtype}}},zj={kernelName:Ko,backendName:`cpu`,kernelFunc:yT(Ko,(e,t)=>isNaN(e)?NaN:e>0?1:t.alpha)};function Bj(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{begin:a,end:s,strides:c,beginMask:l,endMask:u,ellipsisMask:d,newAxisMask:f,shrinkAxisMask:p}=r;Y(i,`stridedSlice`);let{finalShapeSparse:m,finalShape:h,isIdentity:g,sliceDim0:_,isSimpleSlice:v,begin:y,end:b,strides:x}=Au(i.shape,a,s,c,l,u,d,f,p),S;if(g)S=SD({inputs:{x:i},backend:n,attrs:{shape:h}});else if(_||v){o(i.shape.length>=1,()=>`Input must have rank at least 1, got: ${i.shape.length}`);let e=_u(y,b,x),t=LE({inputs:{x:i},backend:n,attrs:{begin:y,size:e}});S=SD({inputs:{x:t},backend:n,attrs:{shape:h}}),n.disposeIntermediateTensorInfo(t)}else{let e=JE(m,n.bufferSync(i),x,y);S=n.makeTensorInfo(h,e.dtype,e.values)}return S}var Vj={kernelName:g,backendName:`cpu`,kernelFunc:Bj};function Hj(e){let{inputs:t,backend:n,attrs:r}=e,{separator:i,nGramWidths:a,leftPad:o,rightPad:s,padWidth:c,preserveShortSequences:l}=r,{data:u,dataSplits:d}=t,f=n.data.get(u.dataId).values,p=n.data.get(d.dataId).values,[m,h]=XE(f,p,i,a,o,s,c,l);return[n.makeTensorInfo([m.length],`string`,m),n.makeTensorInfo(d.shape,`int32`,h)]}var Uj={kernelName:Fo,backendName:`cpu`,kernelFunc:Hj};function Wj(e){let{inputs:t,backend:n,attrs:r}=e,{skipEmpty:i}=r,{input:a,delimiter:o}=t;if(a.dtype!==`string`)throw Error(`Input must be of datatype string`);if(a.shape.length!==1)throw Error(`Input must be a vector, got shape: ${a.shape}`);if(o.shape.length!==0)throw Error(`Delimiter must be a scalar, got shape: ${o.shape}`);let s=n.data.get(a.dataId).values,c=n.data.get(o.dataId).values[0],[l,u,d]=QE(s,c,i),f=u.length;return[n.makeTensorInfo([f,2],`int32`,l),n.makeTensorInfo([f],`string`,u),n.makeTensorInfo([2],`int32`,new Int32Array(d))]}var Gj={kernelName:an,backendName:`cpu`,kernelFunc:Wj};function Kj(e){let{inputs:t,backend:n,attrs:r}=e,{numBuckets:i}=r,{input:a}=t;if(a.dtype!==`string`)throw Error(`Input must be of datatype string`);if(i<=0)throw Error(`Number of buckets must be at least 1`);let o=n.data.get(a.dataId).values,s=$E(o,i);return n.makeTensorInfo(a.shape,`int32`,s)}var qj={kernelName:gn,backendName:`cpu`,kernelFunc:Kj},Jj={kernelName:`Tan`,backendName:`cpu`,kernelFunc:yT(`Tan`,e=>Math.tan(e))},Yj={kernelName:Jt,backendName:`cpu`,kernelFunc:yT(Jt,e=>Math.tanh(e))};function Xj(e){let{inputs:t,backend:n}=e,{tensor:r,indices:i,updates:a}=t,{sliceRank:o,numUpdates:s,sliceSize:c,strides:l,outputSize:u}=Xa(a,i,r.shape),d=n.bufferSync(i),f=n.bufferSync(a),p=n.bufferSync(r),m=ME(d,f,r.shape,u,c,s,o,l,p,!1);return n.makeTensorInfo(r.shape,m.dtype,m.values)}var Zj={kernelName:rr,backendName:`cpu`,kernelFunc:Xj};function Qj(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{reps:a}=r;Y(i,`tile`);let o=rD(n.bufferSync(i),a);return n.makeTensorInfo(o.shape,o.dtype,o.values)}var $j={kernelName:Bl,backendName:`cpu`,kernelFunc:Qj};function eM(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{k:a,sorted:o}=r;Y(i,`topk`);let s=n.data.get(i.dataId).values,[c,l]=oD(s,i.shape,i.dtype,a,o);return[n.makeTensorInfo(c.shape,c.dtype,c.values),n.makeTensorInfo(l.shape,l.dtype,l.values)]}var tM={kernelName:ee,backendName:`cpu`,kernelFunc:eM};function nM(e){let{inputs:t,attrs:n,backend:r}=e,{image:i,transforms:a}=t,{interpolation:o,fillMode:s,fillValue:c,outputShape:l}=n,[u,d,f,p]=i.shape,[m,h]=l??[d,f],g=[u,m,h,p],_=R(i.shape),v=_[0],y=_[1],b=_[2],x=R(g),S=x[0],C=x[1],w=x[2],T=Hs(i.dtype,k(g));T.fill(c);let E=r.data.get(i.dataId).values,ee=r.data.get(a.dataId).values;for(let e=0;e<u;++e){let t=a.shape[0]===1?ee:ee.subarray(e*8,e*8+8);for(let n=0;n<m;++n)for(let r=0;r<h;++r)for(let i=0;i<p;++i){let a,l=t[6]*r+t[7]*n+1;if(l===0)continue;let u=(t[0]*r+t[1]*n+t[2])/l,p=(t[3]*r+t[4]*n+t[5])/l,m=iM(u,f,s),h=iM(p,d,s);switch(o){case`nearest`:a=uM(E,d,f,v,y,b,e,h,m,i,c);break;case`bilinear`:a=dM(E,d,f,v,y,b,e,h,m,i,c);break;default:throw Error(`Error in Transform: Expect 'nearest' or 'bilinear', but got ${o}`)}let g=e*S+n*C+r*w+i;T[g]=a}return r.makeTensorInfo(g,i.dtype,T)}return{dataId:r.write(T,g,i.dtype),shape:i.shape,dtype:i.dtype}}var rM={kernelName:Hr,backendName:`cpu`,kernelFunc:nM};function iM(e,t,n){switch(n){case`reflect`:return aM(e,t);case`wrap`:return oM(e,t);case`nearest`:return cM(e,t);default:return sM(e,t)}}function aM(e,t){let n=e;if(n<0)if(t<=1)n=0;else{let e=2*t;n<e&&(n=e*Math.trunc(-n/e)+n),n=n<-t?n+e:-n-1}else if(n>t-1)if(t<=1)n=0;else{let e=2*t;n-=e*Math.trunc(n/e),n>=t&&(n=e-n-1)}return js(0,n,t-1)}function oM(e,t){let n=e;if(n<0)if(t<=1)n=0;else{let e=t-1;n+=t*(Math.trunc(-n/e)+1)}else if(n>t-1)if(t<=1)n=0;else{let e=t-1;n-=t*Math.trunc(n/e)}return js(0,n,t-1)}function sM(e,t){return e}function cM(e,t){return js(0,e,t-1)}function lM(e,t,n,r,i,a,o,s,c,l,u){let d=o*r+s*i+c*a+l;return 0<=s&&s<t&&0<=c&&c<n?e[d]:u}function uM(e,t,n,r,i,a,o,s,c,l,u){return lM(e,t,n,r,i,a,o,Math.round(s),Math.round(c),l,u)}function dM(e,t,n,r,i,a,o,s,c,l,u){let d=Math.floor(s),f=Math.floor(c),p=d+1,m=f+1,h=(m-c)*lM(e,t,n,r,i,a,o,d,f,l,u)+(c-f)*lM(e,t,n,r,i,a,o,d,m,l,u),g=(m-c)*lM(e,t,n,r,i,a,o,p,f,l,u)+(c-f)*lM(e,t,n,r,i,a,o,p,m,l,u);return(p-s)*h+(s-d)*g}function fM(e){let{inputs:t,attrs:n,backend:r}=e,{axis:i}=n,{x:a}=t;Y(a,`unique`);let o=r.data.get(a.dataId).values,{outputValues:s,outputShape:c,indices:l}=sD(o,i,a.shape,a.dtype);return[r.makeTensorInfo(c,a.dtype,s),r.makeTensorInfo([l.length],`int32`,l)]}var pM={kernelName:Mr,backendName:`cpu`,kernelFunc:fM};function mM(e){let{inputs:t,backend:n,attrs:r}=e,{value:i}=t,{axis:a}=r;a<0&&(a+=i.shape.length);let o=i.shape.length,s=i.shape[a],c=Array(o-1),l=0;for(let e=0;e<o;e++)e!==a&&(c[l++]=i.shape[e]);let u=Array(o).fill(0),d=i.shape.slice();d[a]=1;let f=Array(s);for(let e=0;e<f.length;e++){u[a]=e;let t=LE({inputs:{x:i},backend:n,attrs:{begin:u,size:d}});f[e]=SD({inputs:{x:t},backend:n,attrs:{shape:c}}),n.disposeIntermediateTensorInfo(t)}return f}var hM={kernelName:Qr,backendName:`cpu`,kernelFunc:mM};function gM(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,segmentIds:a}=t,{numSegments:o}=r;Y(i,`unsortedSegmentSum`);let s=i.shape.length,c=a.shape.length,l=[],u=[],d=s-c,f=a;for(let e=0;e<d;++e){let t=pk({inputs:{input:f},backend:n,attrs:{dim:e+1}});f=t,u.push(t)}for(let e=0;e<o;++e){let t=Da(e,`int32`),r=n.makeTensorInfo([],`int32`,t),a=TT({inputs:{a:r,b:f},backend:n}),o=sT({inputs:{x:a},backend:n,attrs:{dtype:`float32`}}),s=tE({inputs:{a:o,b:i},backend:n}),c=ek({inputs:{x:s},backend:n,attrs:{axis:0,keepDims:!1}});l.push(c),u.push(r),u.push(a),u.push(o),u.push(s),u.push(c)}let p=FA({inputs:l,backend:n,attrs:{axis:0}});return u.forEach(e=>n.disposeIntermediateTensorInfo(e)),p}var _M=[DD,Zw,OD,kD,pT,jD,ND,FD,LD,zD,BD,VD,HD,UD,WD,XD,QD,eO,nO,TD,iO,oO,cO,_T,uO,cT,ST,dO,eT,fO,gO,vO,bO,SO,wO,EO,OO,kO,AO,MO,PO,IO,RO,BO,HO,WO,KO,JO,YO,XO,ZO,$O,rk,dD,ak,ET,fk,kT,mk,jT,Ck,Tk,Dk,NT,FT,kk,jk,Nk,Fk,zT,VT,rT,Lk,mO,Rk,zk,Bk,pD,UT,GT,Hk,JT,Uk,Wk,Gk,Kk,Jk,Xk,Qk,ZT,eA,nA,iA,oA,cA,uA,fA,$T,mA,hA,yA,nE,aE,SA,TA,OA,sE,AA,PA,IA,RA,zA,gD,pE,VA,UA,GA,qA,aT,gk,JA,vD,bD,CD,XA,QA,ej,nj,ij,aj,oj,jE,cj,pj,hj,vj,FE,yj,bj,xj,RE,_A,Cj,Tj,Dj,kj,jj,Nj,Fj,Lj,UE,Rj,GE,qE,zj,Vj,Uj,Gj,qj,nD,tk,Jj,Yj,Zj,$j,tM,rM,uE,pM,hM,{kernelName:Qe,backendName:`cpu`,kernelFunc:gM},MA];for(let e of _M)Ne(e);var vM={},yM={alpha:!1,antialias:!1,premultipliedAlpha:!1,preserveDrawingBuffer:!1,depth:!1,stencil:!1,failIfMajorPerformanceCaveat:!0};function bM(e,t){vM[e]=t}function xM(e,t){if(!(e in vM)||t!=null){let n=CM(e,t);if(n!==null)vM[e]=n;else return console.log(`Could not get context for WebGL version`,e),null}let n=vM[e];return n==null||n.isContextLost()?(delete vM[e],xM(e)):(n.disable(n.DEPTH_TEST),n.disable(n.STENCIL_TEST),n.disable(n.BLEND),n.disable(n.DITHER),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SAMPLE_COVERAGE),n.enable(n.SCISSOR_TEST),n.enable(n.CULL_FACE),n.cullFace(n.BACK),vM[e])}function SM(e){if(!j().getBool(`IS_SAFARI`)&&typeof OffscreenCanvas<`u`&&e===2)return new OffscreenCanvas(300,150);if(typeof document<`u`)return document.createElement(`canvas`);throw Error(`Cannot create a canvas in this context`)}function CM(e,t){if(e!==1&&e!==2)throw Error(`Cannot get WebGL rendering context, WebGL is disabled.`);let n=t??SM(e);return n.addEventListener(`webglcontextlost`,t=>{t.preventDefault(),delete vM[e]},!1),j().getBool(`SOFTWARE_WEBGL_ENABLED`)&&(yM.failIfMajorPerformanceCaveat=!1),e===1?n.getContext(`webgl`,yM)||n.getContext(`experimental-webgl`,yM):n.getContext(`webgl2`,yM)}var wM;(function(e){e[e.DENSE=0]=`DENSE`,e[e.SHARED_BATCH=1]=`SHARED_BATCH`})(wM||={});var TM;(function(e){e[e.RENDER=0]=`RENDER`,e[e.UPLOAD=1]=`UPLOAD`,e[e.PIXELS=2]=`PIXELS`,e[e.DOWNLOAD=3]=`DOWNLOAD`})(TM||={});var EM;(function(e){e[e.UNPACKED_FLOAT16=0]=`UNPACKED_FLOAT16`,e[e.UNPACKED_FLOAT32=1]=`UNPACKED_FLOAT32`,e[e.PACKED_4X1_UNSIGNED_BYTE=2]=`PACKED_4X1_UNSIGNED_BYTE`,e[e.PACKED_2X2_FLOAT32=3]=`PACKED_2X2_FLOAT32`,e[e.PACKED_2X2_FLOAT16=4]=`PACKED_2X2_FLOAT16`})(EM||={});function DM(e,t){return[t,e]}function OM(e,t){return e*t}function kM(e){let t=k(e);return Le(Math.ceil(t/4))}function AM(e,t){return[Math.max(1,Math.ceil(t/2)),Math.max(1,Math.ceil(e/2))]}function jM(e,t){let[n,r]=AM(e,t);return n*r*4}function MM(e,t){let n=e,r,i,a,o,s,c,l,u,d,f;return j().getNumber(`WEBGL_VERSION`)===2?(r=n.R32F,i=n.R16F,a=n.RGBA16F,o=n.RGBA32F,s=n.RED,l=4,u=1,d=n.HALF_FLOAT,f=n.FLOAT,c=n.RGBA8):(r=e.RGBA,i=e.RGBA,a=e.RGBA,o=n.RGBA,s=e.RGBA,l=4,u=4,d=t==null?null:t.HALF_FLOAT_OES,f=e.FLOAT,c=e.RGBA),{internalFormatFloat:r,internalFormatHalfFloat:i,internalFormatPackedHalfFloat:a,internalFormatPackedFloat:o,textureFormatFloat:s,downloadTextureFormat:c,downloadUnpackNumChannels:l,defaultNumChannels:u,textureTypeHalfFloat:d,textureTypeFloat:f}}var NM=e({assertNotComplex:()=>MN,bindCanvasToFramebuffer:()=>aN,bindColorTextureToFramebuffer:()=>oN,bindTextureToProgramUniformSampler:()=>iN,bindTextureUnit:()=>eN,bindVertexBufferToProgramAttribute:()=>$M,callAndCheck:()=>X,canBeRepresented:()=>LM,createFragmentShader:()=>VM,createFramebuffer:()=>QM,createProgram:()=>WM,createStaticIndexBuffer:()=>JM,createStaticVertexBuffer:()=>qM,createTexture:()=>XM,createVertexShader:()=>BM,getBatchDim:()=>fN,getExtensionOrThrow:()=>zM,getFramebufferErrorMessage:()=>lN,getMaxTexturesInShader:()=>CN,getNumChannels:()=>YM,getProgramUniformLocation:()=>rN,getProgramUniformLocationOrThrow:()=>nN,getRowsCols:()=>pN,getShapeAs3D:()=>mN,getTextureShapeFromLogicalShape:()=>hN,getWebGLDisjointQueryTimerVersion:()=>wN,getWebGLErrorMessage:()=>RM,getWebGLMaxTextureSize:()=>bN,hasExtension:()=>TN,isCapableOfRenderingToFloatTexture:()=>DN,isDownloadFloatTextureEnabled:()=>ON,isReshapeFree:()=>_N,isWebGLFenceEnabled:()=>jN,isWebGLVersionEnabled:()=>EN,linkProgram:()=>GM,logShaderSourceAndInfoLog:()=>UM,resetMaxTextureSize:()=>xN,resetMaxTexturesInShader:()=>SN,unbindColorTextureFromFramebuffer:()=>sN,unbindTextureUnit:()=>tN,validateFramebuffer:()=>cN,validateProgram:()=>KM,validateTextureSize:()=>ZM});function X(e,t){let n=t();return j().getBool(`DEBUG`)&&PM(e),n}function PM(e){let t=e.getError();if(t!==e.NO_ERROR)throw Error(`WebGL Error: `+RM(e,t))}var FM=5.96e-8,IM=65504;function LM(e){return!!(j().getBool(`WEBGL_RENDER_FLOAT32_ENABLED`)||e===0||FM<Math.abs(e)&&Math.abs(e)<IM)}function RM(e,t){switch(t){case e.NO_ERROR:return`NO_ERROR`;case e.INVALID_ENUM:return`INVALID_ENUM`;case e.INVALID_VALUE:return`INVALID_VALUE`;case e.INVALID_OPERATION:return`INVALID_OPERATION`;case e.INVALID_FRAMEBUFFER_OPERATION:return`INVALID_FRAMEBUFFER_OPERATION`;case e.OUT_OF_MEMORY:return`OUT_OF_MEMORY`;case e.CONTEXT_LOST_WEBGL:return`CONTEXT_LOST_WEBGL`;default:return`Unknown error code ${t}`}}function zM(e,t){return uN(e,()=>e.getExtension(t),`Extension "`+t+`" not supported on this browser.`)}function BM(e,t){let n=uN(e,()=>e.createShader(e.VERTEX_SHADER),`Unable to create vertex WebGLShader.`);if(X(e,()=>e.shaderSource(n,t)),X(e,()=>e.compileShader(n)),e.getShaderParameter(n,e.COMPILE_STATUS)===!1)throw console.log(e.getShaderInfoLog(n)),Error(`Failed to compile vertex shader.`);return n}function VM(e,t){let n=uN(e,()=>e.createShader(e.FRAGMENT_SHADER),`Unable to create fragment WebGLShader.`);if(X(e,()=>e.shaderSource(n,t)),X(e,()=>e.compileShader(n)),j().get(`ENGINE_COMPILE_ONLY`))return n;if(e.getShaderParameter(n,e.COMPILE_STATUS)===!1)throw UM(t,e.getShaderInfoLog(n)),Error(`Failed to compile fragment shader.`);return n}var HM=/ERROR: [0-9]+:([0-9]+):/g;function UM(e,t){let n=HM.exec(t);if(n==null){console.log(`Couldn't parse line number in error: ${t}`),console.log(e);return}let r=+n[1],i=e.split(`
`),a=i.length.toString().length+2,o=i.map((e,t)=>ge((t+1).toString(),a)+e),s=0;for(let e=0;e<o.length;e++)s=Math.max(o[e].length,s);let c=o.slice(0,r-1),l=o.slice(r-1,r),u=o.slice(r);console.log(c.join(`
`)),console.log(t.split(`
`)[0]),console.log(`%c ${ge(l[0],s)}`,`border:1px solid red; background-color:#e3d2d2; color:#a61717`),console.log(u.join(`
`))}function WM(e){return uN(e,()=>e.createProgram(),`Unable to create WebGLProgram.`)}function GM(e,t){if(X(e,()=>e.linkProgram(t)),!j().get(`ENGINE_COMPILE_ONLY`)&&e.getProgramParameter(t,e.LINK_STATUS)===!1)throw console.log(e.getProgramInfoLog(t)),Error(`Failed to link vertex and fragment shaders.`)}function KM(e,t){if(X(e,()=>e.validateProgram(t)),e.getProgramParameter(t,e.VALIDATE_STATUS)===!1)throw console.log(e.getProgramInfoLog(t)),Error(`Shader program validation failed.`)}function qM(e,t){let n=uN(e,()=>e.createBuffer(),`Unable to create WebGLBuffer`);return X(e,()=>e.bindBuffer(e.ARRAY_BUFFER,n)),X(e,()=>e.bufferData(e.ARRAY_BUFFER,t,e.STATIC_DRAW)),n}function JM(e,t){let n=uN(e,()=>e.createBuffer(),`Unable to create WebGLBuffer`);return X(e,()=>e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,n)),X(e,()=>e.bufferData(e.ELEMENT_ARRAY_BUFFER,t,e.STATIC_DRAW)),n}function YM(){return j().getNumber(`WEBGL_VERSION`)===2?1:4}function XM(e){return uN(e,()=>e.createTexture(),`Unable to create WebGLTexture.`)}function ZM(e,t){let n=j().getNumber(`WEBGL_MAX_TEXTURE_SIZE`);if(e<=0||t<=0){let n=`[${e}x${t}]`;throw Error(`Requested texture size `+n+` is invalid.`)}if(e>n||t>n){let r=`[${e}x${t}]`,i=`[${n}x${n}]`;throw Error(`Requested texture size `+r+` greater than WebGL maximum on this browser / GPU `+i+`.`)}}function QM(e){return uN(e,()=>e.createFramebuffer(),`Unable to create WebGLFramebuffer.`)}function $M(e,t,n,r,i,a,o){let s=e.getAttribLocation(t,n);return s===-1?!1:(X(e,()=>e.bindBuffer(e.ARRAY_BUFFER,r)),X(e,()=>e.vertexAttribPointer(s,i,e.FLOAT,!1,a,o)),X(e,()=>e.enableVertexAttribArray(s)),!0)}function eN(e,t,n){dN(e,n),X(e,()=>e.activeTexture(e.TEXTURE0+n)),X(e,()=>e.bindTexture(e.TEXTURE_2D,t))}function tN(e,t){dN(e,t),X(e,()=>e.activeTexture(e.TEXTURE0+t)),X(e,()=>e.bindTexture(e.TEXTURE_2D,null))}function nN(e,t,n){return uN(e,()=>e.getUniformLocation(t,n),`uniform "`+n+`" not present in program.`)}function rN(e,t,n){return e.getUniformLocation(t,n)}function iN(e,t,n,r){X(e,()=>eN(e,t,r)),X(e,()=>e.uniform1i(n,r))}function aN(e){X(e,()=>e.bindFramebuffer(e.FRAMEBUFFER,null)),X(e,()=>e.viewport(0,0,e.canvas.width,e.canvas.height)),X(e,()=>e.scissor(0,0,e.canvas.width,e.canvas.height))}function oN(e,t,n){X(e,()=>e.bindFramebuffer(e.FRAMEBUFFER,n)),X(e,()=>e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0))}function sN(e,t){X(e,()=>e.bindFramebuffer(e.FRAMEBUFFER,t)),X(e,()=>e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,null,0))}function cN(e){let t=e.checkFramebufferStatus(e.FRAMEBUFFER);if(t!==e.FRAMEBUFFER_COMPLETE)throw Error(`Error binding framebuffer: `+lN(e,t))}function lN(e,t){switch(t){case e.FRAMEBUFFER_INCOMPLETE_ATTACHMENT:return`FRAMEBUFFER_INCOMPLETE_ATTACHMENT`;case e.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:return`FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT`;case e.FRAMEBUFFER_INCOMPLETE_DIMENSIONS:return`FRAMEBUFFER_INCOMPLETE_DIMENSIONS`;case e.FRAMEBUFFER_UNSUPPORTED:return`FRAMEBUFFER_UNSUPPORTED`;default:return`unknown error ${t}`}}function uN(e,t,n){let r=X(e,()=>t());if(r==null)throw Error(n);return r}function dN(e,t){let n=e.MAX_COMBINED_TEXTURE_IMAGE_UNITS-1,r=t+e.TEXTURE0;if(r<e.TEXTURE0||r>n){let e=`[gl.TEXTURE0, gl.TEXTURE${n}]`;throw Error(`textureUnit must be in ${e}.`)}}function fN(e,t=2){return k(e.slice(0,e.length-t))}function pN(e){if(e.length===0)throw Error(`Cannot get rows and columns of an empty shape array.`);return[e.length>1?e[e.length-2]:1,e[e.length-1]]}function mN(e){let t=[1,1,1];return e.length===0||e.length===1&&e[0]===1||(t=[fN(e),...pN(e)]),t}function hN(e,t=!1){let n=j().getNumber(`WEBGL_MAX_TEXTURE_SIZE`),r=j().getNumber(`WEBGL_MAX_SIZE_FOR_NARROW_TEXTURE`);r===1/0&&j().getBool(`WEBGL_AUTO_SQUARIFY_NARROW_TEXTURE_SHAPE`)&&(r=n/2),t&&(n*=2,r*=2,e=e.map((t,n)=>n>=e.length-2?ua(e[n]):e[n]),e.length===1&&(e=[2,e[0]])),e.length!==2&&(e=Ee(e).newShape);let i=k(e),a=null;e.length<=1&&i<=n?a=[1,i]:e.length===2&&e[0]<=n&&e[1]<=n?a=e:e.length===3&&e[0]*e[1]<=n&&e[2]<=n?a=[e[0]*e[1],e[2]]:e.length===3&&e[0]<=n&&e[1]*e[2]<=n?a=[e[0],e[1]*e[2]]:e.length===4&&e[0]*e[1]*e[2]<=n&&e[3]<=n?a=[e[0]*e[1]*e[2],e[3]]:e.length===4&&e[0]<=n&&e[1]*e[2]*e[3]<=n&&(a=[e[0],e[1]*e[2]*e[3]]);let o=a!=null&&Math.max(...a)>r&&Math.min(...a)<=(t?2:1)&&Math.min(...a)>0;if(a==null||o)if(t){let t=fN(e),n=2,r=2;e.length&&([n,r]=pN(e)),i=n/2*t*(r/2),a=Le(i).map(e=>e*2)}else a=Le(i);return a}function gN(e){return e%2==0}function _N(e,t){if(e=e.slice(-2),t=t.slice(-2),qn(e,t)||!e.length||!t.length||e[0]===0||e[1]===0||t[0]===0||t[1]===0)return!0;if(e.length!==t.length){let n=e[e.length-1],r=t[t.length-1];if(n===r||gN(n)&&gN(r)&&(e[0]===1||t[0]===1))return!0}return e[1]===t[1]&&gN(e[0])&&gN(t[0])}var vN,yN;function bN(e){if(vN==null){let t=xM(e);vN=t.getParameter(t.MAX_TEXTURE_SIZE)}return vN}function xN(){vN=null}function SN(){yN=null}function CN(e){if(yN==null){let t=xM(e);yN=t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS)}return Math.min(16,yN)}function wN(e){if(e===0)return 0;let t,n=xM(e);return t=TN(n,`EXT_disjoint_timer_query_webgl2`)&&e===2?2:+!!TN(n,`EXT_disjoint_timer_query`),t}function TN(e,t){return e.getExtension(t)!=null}function EN(e){try{if(xM(e)!=null)return!0}catch(e){return console.log(`Error when getting WebGL context: `,e),!1}return!1}function DN(e){if(e===0)return!1;let t=xM(e);if(e===1){if(!TN(t,`OES_texture_float`))return!1}else if(!TN(t,`EXT_color_buffer_float`))return!1;return kN(t)}function ON(e){if(e===0)return!1;let t=xM(e);if(e===1){if(!TN(t,`OES_texture_float`)||!TN(t,`WEBGL_color_buffer_float`))return!1}else{if(TN(t,`EXT_color_buffer_float`))return kN(t);let e=`EXT_color_buffer_half_float`;return TN(t,e)?AN(t,t.getExtension(e)):!1}return kN(t)}function kN(e){let t=MM(e),n=e.createTexture();e.bindTexture(e.TEXTURE_2D,n),e.texImage2D(e.TEXTURE_2D,0,t.internalFormatFloat,1,1,0,t.textureFormatFloat,t.textureTypeFloat,null);let r=e.createFramebuffer();e.bindFramebuffer(e.FRAMEBUFFER,r),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,n,0);let i=e.checkFramebufferStatus(e.FRAMEBUFFER)===e.FRAMEBUFFER_COMPLETE;return e.bindTexture(e.TEXTURE_2D,null),e.bindFramebuffer(e.FRAMEBUFFER,null),e.deleteTexture(n),e.deleteFramebuffer(r),i}function AN(e,t){let n=MM(e,t),r=e.createTexture();e.bindTexture(e.TEXTURE_2D,r),e.texImage2D(e.TEXTURE_2D,0,n.internalFormatHalfFloat,1,1,0,n.textureFormatFloat,n.textureTypeHalfFloat,null);let i=e.createFramebuffer();e.bindFramebuffer(e.FRAMEBUFFER,i),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,r,0);let a=e.checkFramebufferStatus(e.FRAMEBUFFER)===e.FRAMEBUFFER_COMPLETE;return e.bindTexture(e.TEXTURE_2D,null),e.bindFramebuffer(e.FRAMEBUFFER,null),e.deleteTexture(r),e.deleteFramebuffer(i),a}function jN(e){return e===2&&xM(e).fenceSync!=null}function MN(e,t){Array.isArray(e)||(e=[e]),e.forEach(e=>{e!=null&&o(e.dtype!==`complex64`,()=>`${t} does not support complex64 tensors in the WebGL backend.`)})}var Z=j();Z.registerFlag(`HAS_WEBGL`,()=>Z.getNumber(`WEBGL_VERSION`)>0),Z.registerFlag(`WEBGL_VERSION`,()=>EN(2)?2:+!!EN(1)),Z.registerFlag(`WEBGL_CHECK_NUMERICAL_PROBLEMS`,()=>!1),Z.registerFlag(`WEBGL_BUFFER_SUPPORTED`,()=>Z.get(`WEBGL_VERSION`)===2),Z.registerFlag(`WEBGL_CPU_FORWARD`,()=>!0),Z.registerFlag(`WEBGL_FORCE_F16_TEXTURES`,()=>!1),Z.registerFlag(`WEBGL_PACK`,()=>Z.getBool(`HAS_WEBGL`)),Z.registerFlag(`WEBGL_PACK_NORMALIZATION`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_CLIP`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_DEPTHWISECONV`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_BINARY_OPERATIONS`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_UNARY_OPERATIONS`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_ARRAY_OPERATIONS`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_IMAGE_OPERATIONS`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_REDUCE`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_LAZILY_UNPACK`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_CONV_IM2COL`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_PACK_CONV2DTRANSPOSE`,()=>Z.getBool(`WEBGL_PACK`)),Z.registerFlag(`WEBGL_MAX_TEXTURE_SIZE`,()=>bN(Z.getNumber(`WEBGL_VERSION`))),Z.registerFlag(`WEBGL_MAX_TEXTURES_IN_SHADER`,()=>CN(Z.getNumber(`WEBGL_VERSION`))),Z.registerFlag(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`,()=>{let e=Z.getNumber(`WEBGL_VERSION`);return e===0?0:wN(e)}),Z.registerFlag(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`,()=>Z.getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`)>0&&!r()),Z.registerFlag(`WEBGL_RENDER_FLOAT32_CAPABLE`,()=>DN(Z.getNumber(`WEBGL_VERSION`))),Z.registerFlag(`WEBGL_RENDER_FLOAT32_ENABLED`,()=>!Z.getBool(`WEBGL_FORCE_F16_TEXTURES`)&&Z.getBool(`WEBGL_RENDER_FLOAT32_CAPABLE`)),Z.registerFlag(`WEBGL_DOWNLOAD_FLOAT_ENABLED`,()=>ON(Z.getNumber(`WEBGL_VERSION`))),Z.registerFlag(`WEBGL_FENCE_API_ENABLED`,()=>jN(Z.getNumber(`WEBGL_VERSION`))),Z.registerFlag(`WEBGL_SIZE_UPLOAD_UNIFORM`,()=>Z.getBool(`WEBGL_RENDER_FLOAT32_ENABLED`)?4:0),Z.registerFlag(`WEBGL_DELETE_TEXTURE_THRESHOLD`,()=>-1,e=>{if(typeof e!=`number`)throw Error(`WEBGL_DELETE_TEXTURE_THRESHOLD must be a number but got ${e}.`);if(e<0&&e!==-1)throw Error(`WEBGL_DELETE_TEXTURE_THRESHOLD must be -1 (indicating never delete) or at least 0, but got ${e}.`)}),Z.registerFlag(`WEBGL_FLUSH_THRESHOLD`,()=>r()?1:-1,e=>{if(typeof e!=`number`)throw Error(`WEBGL_FLUSH_THRESHOLD must be a number but got ${e}.`);if(e<0&&e!==-1)throw Error(`WEBGL_FLUSH_THRESHOLD must be -1 (indicating never manual flush) or at least 0, but got ${e}.`)}),Z.registerFlag(`CPU_HANDOFF_SIZE_THRESHOLD`,()=>128),Z.registerFlag(`WEBGL_USE_SHAPES_UNIFORMS`,()=>!1),Z.registerFlag(`TOPK_LAST_DIM_CPU_HANDOFF_SIZE_THRESHOLD`,()=>1e5),Z.registerFlag(`TOPK_K_CPU_HANDOFF_THRESHOLD`,()=>128),Z.registerFlag(`WEBGL_EXP_CONV`,()=>!1),Z.registerFlag(`SOFTWARE_WEBGL_ENABLED`,()=>Z.getBool(`IS_TEST`)),Z.registerFlag(`WEBGL_MAX_SIZE_FOR_NARROW_TEXTURE`,()=>1/0),Z.registerFlag(`WEBGL_AUTO_SQUARIFY_NARROW_TEXTURE_SHAPE`,()=>!1),Z.registerFlag(`WEBGL2_ISNAN_CUSTOM`,()=>!1),Z.registerFlag(`ENGINE_COMPILE_ONLY`,()=>!1);function NN(){let e,t,n,r,i,a,o,s,c,l;return j().getNumber(`WEBGL_VERSION`)===2?(e=`#version 300 es`,t=`in`,n=`out`,r=`in`,i=`texture`,a=`outputColor`,o=`out vec4 outputColor;`,s=j().getBool(`WEBGL2_ISNAN_CUSTOM`)?`
      bool isnan_custom(float val) {
        uint floatToUint = floatBitsToUint(val);
        return (floatToUint & 0x7fffffffu) > 0x7f800000u;
      }

      bvec4 isnan_custom(vec4 val) {
        return bvec4(isnan_custom(val.x),
          isnan_custom(val.y), isnan_custom(val.z), isnan_custom(val.w));
      }

      #define isnan(value) isnan_custom(value)
    `:``,c=``,l=`
      #define round(value) newRound(value)
      int newRound(float value) {
        return int(floor(value + 0.5));
      }

      ivec4 newRound(vec4 value) {
        return ivec4(floor(value + vec4(0.5)));
      }
    `):(e=``,t=`attribute`,n=`varying`,r=`varying`,i=`texture2D`,a=`gl_FragColor`,o=``,s=`
      #define isnan(value) isnan_custom(value)
      bool isnan_custom(float val) {
        return (val > 0. || val < 1. || val == 0.) ? false : true;
      }
      bvec4 isnan_custom(vec4 val) {
        return bvec4(isnan(val.x), isnan(val.y), isnan(val.z), isnan(val.w));
      }
    `,c=`
      uniform float INFINITY;

      bool isinf(float val) {
        return abs(val) == INFINITY;
      }
      bvec4 isinf(vec4 val) {
        return equal(abs(val), vec4(INFINITY));
      }
    `,l=`
      int round(float value) {
        return int(floor(value + 0.5));
      }

      ivec4 round(vec4 value) {
        return ivec4(floor(value + vec4(0.5)));
      }
    `),{version:e,attribute:t,varyingVs:n,varyingFs:r,texture2D:i,output:a,defineOutput:o,defineSpecialNaN:s,defineSpecialInf:c,defineRound:l}}function PN(e,t,n=`index`){let r=R(t);return r.map((t,i)=>`${`int ${e[i]} = ${n} / ${t}`}; ${i===r.length-1?`int ${e[i+1]} = ${n} - ${e[i]} * ${t}`:`index -= ${e[i]} * ${t}`};`).join(``)}function FN(e,t,n=`index`){let r=R(t);return r.map((t,i)=>`${`int ${e[i]} = ${n} / outShapeStrides[${i}]`}; ${i===r.length-1?`int ${e[i+1]} = ${n} - ${e[i]} * outShapeStrides[${i}]`:`index -= ${e[i]} * outShapeStrides[${i}]`};`).join(``)}function IN(e,t){let n=e.length,r=e.map(e=>`${t}[${e}]`),i=Array(n-1);i[n-2]=r[n-1];for(let e=n-3;e>=0;--e)i[e]=`(${i[e+1]} * ${r[e+1]})`;return i}function LN(e,t,n=`index`){let r=IN(e.map((e,t)=>t),t);return r.map((t,i)=>`${`int ${e[i]} = ${n} / ${r[i]}`}; ${i===r.length-1?`int ${e[i+1]} = ${n} - ${e[i]} * ${r[i]}`:`index -= ${e[i]} * ${r[i]}`};`).join(``)}function RN(e){let t=R(e).map(e=>e.toString());return`
  int getFlatIndex(ivec3 coords) {
    return coords.x * ${t[0]} + coords.y * ${t[1]} + coords.z;
  }
`}function zN(){return`
  int getFlatIndex(ivec3 coords) {
    return coords.x * outShapeStrides[0] + coords.y * outShapeStrides[1] + coords.z;
  }
`}var BN=`
  const float FLOAT_MAX = 1.70141184e38;
  const float FLOAT_MIN = 1.17549435e-38;

  lowp vec4 encode_float(highp float v) {
    if (isnan(v)) {
      return vec4(255, 255, 255, 255);
    }

    highp float av = abs(v);

    if(av < FLOAT_MIN) {
      return vec4(0.0, 0.0, 0.0, 0.0);
    } else if(v > FLOAT_MAX) {
      return vec4(0.0, 0.0, 128.0, 127.0) / 255.0;
    } else if(v < -FLOAT_MAX) {
      return vec4(0.0, 0.0,  128.0, 255.0) / 255.0;
    }

    highp vec4 c = vec4(0,0,0,0);

    highp float e = floor(log2(av));
    highp float m = exp2(fract(log2(av))) - 1.0;

    c[2] = floor(128.0 * m);
    m -= c[2] / 128.0;
    c[1] = floor(32768.0 * m);
    m -= c[1] / 32768.0;
    c[0] = floor(8388608.0 * m);

    highp float ebias = e + 127.0;
    c[3] = floor(ebias / 2.0);
    ebias -= c[3] * 2.0;
    c[2] += floor(ebias) * 128.0;

    c[3] += 128.0 * step(0.0, -v);

    return c / 255.0;
  }
`,{getBroadcastDims:VN}=Vd;function HN(e,t,n){let r=[];if(e.forEach(e=>{let t=k(e.shapeInfo.logicalShape);if(e.shapeInfo.isUniform?r.push(`uniform float ${e.name}${t>1?`[${t}]`:``};`):(r.push(`uniform sampler2D ${e.name};`),r.push(`uniform int offset${e.name};`)),n.enableShapeUniforms){let{uniformShape:t}=AP(n.packedInputs,e.shapeInfo.logicalShape,e.shapeInfo.texShape);switch(t.length){case 1:r.push(`uniform int ${e.name}Shape;`);break;case 2:r.push(`uniform ivec2 ${e.name}Shape;`);break;case 3:r.push(`uniform ivec3 ${e.name}Shape;`);break;case 4:r.push(`uniform ivec4 ${e.name}Shape;`);break;default:break}r.push(`uniform ivec2 ${e.name}TexShape;`)}}),n.enableShapeUniforms){switch(t.logicalShape.length){case 1:r.push(`uniform int outShape;`);break;case 2:r.push(`uniform ivec2 outShape;`),r.push(`uniform int outShapeStrides;`);break;case 3:r.push(`uniform ivec3 outShape;`),r.push(`uniform ivec2 outShapeStrides;`);break;case 4:r.push(`uniform ivec4 outShape;`),r.push(`uniform ivec3 outShapeStrides;`);break;default:break}r.push(`uniform ivec2 outTexShape;`)}n.customUniforms&&n.customUniforms.forEach(e=>{r.push(`uniform ${e.type} ${e.name}${e.arrayIndex?`[${e.arrayIndex}]`:``};`)});let i=r.join(`
`),a=e.map(e=>GN(e,t,n.packedInputs,n.enableShapeUniforms)).join(`
`),o=t.texShape,s=NN(),c=JN(s),l,u,d=ZN(s);return t.isPacked?(l=KN(t.logicalShape,o,n.enableShapeUniforms),u=XN(s)):(l=qN(t.logicalShape,o,n.enableShapeUniforms),u=YN(s)),n.packedInputs&&(d+=tP),[d,c,u,i,l,a,n.userCode].join(`
`)}function UN(e,t=!1){let n=e.shapeInfo.logicalShape;switch(n.length){case 0:return hP(e,t);case 1:return _P(e,t);case 2:return yP(e,t);case 3:return xP(e,t);case 4:return CP(e,t);case 5:return wP(e);case 6:return TP(e);default:throw Error(`${n.length}-D input sampling is not yet supported`)}}function WN(e,t){switch(e.shapeInfo.logicalShape.length){case 0:return mP(e);case 1:return gP(e,t);case 2:return vP(e,t);case 3:return bP(e,t);default:return SP(e,t)}}function GN(e,t,n=!1,r){let i=``;n?i+=WN(e,r):i+=UN(e,r);let a=e.shapeInfo.logicalShape,o=t.logicalShape;return a.length<=o.length&&(n?i+=DP(e,t):i+=OP(e,t)),i}function KN(e,t,n){switch(e.length){case 0:return nP();case 1:return rP(e,t,n);case 2:return dP(e,t,n);case 3:return aP(e,t,n);default:return sP(e,t,n)}}function qN(e,t,n){switch(e.length){case 0:return nP();case 1:return iP(e,t,n);case 2:return fP(e,t,n);case 3:return oP(e,t,n);case 4:return cP(e,t,n);case 5:return lP(e,t);case 6:return uP(e,t);default:throw Error(`${e.length}-D output sampling is not yet supported`)}}function JN(e){return`
    float sampleTexture(sampler2D textureSampler, vec2 uv) {
      return ${e.texture2D}(textureSampler, uv).r;
    }
  `}function YN(e){return`
    void setOutput(float val) {
      ${e.output} = vec4(val, 0, 0, 0);
    }
  `}function XN(e){return`
    void setOutput(vec4 val) {
      ${e.output} = val;
    }
  `}function ZN(e){return`${e.version}
    precision highp float;
    precision highp int;
    precision highp sampler2D;
    ${e.varyingFs} vec2 resultUV;
    ${e.defineOutput}
    const vec2 halfCR = vec2(0.5, 0.5);

    struct ivec5
    {
      int x;
      int y;
      int z;
      int w;
      int u;
    };

    struct ivec6
    {
      int x;
      int y;
      int z;
      int w;
      int u;
      int v;
    };

    uniform float NAN;
    ${e.defineSpecialNaN}
    ${e.defineSpecialInf}
    ${e.defineRound}

    int imod(int x, int y) {
      return x - y * (x / y);
    }

    int idiv(int a, int b, float sign) {
      int res = a / b;
      int mod = imod(a, b);
      if (sign < 0. && mod != 0) {
        res -= 1;
      }
      return res;
    }

    //Based on the work of Dave Hoskins
    //https://www.shadertoy.com/view/4djSRW
    #define HASHSCALE1 443.8975
    float random(float seed){
      vec2 p = resultUV * seed;
      vec3 p3  = fract(vec3(p.xyx) * HASHSCALE1);
      p3 += dot(p3, p3.yzx + 19.19);
      return fract((p3.x + p3.y) * p3.z);
    }

    ${QN}
    ${$N}
    ${eP}
  `}var QN=`
vec2 uvFromFlat(int texNumR, int texNumC, int index) {
  int texR = index / texNumC;
  int texC = index - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
vec2 packedUVfrom1D(int texNumR, int texNumC, int index) {
  int texelIndex = index / 2;
  int texR = texelIndex / texNumC;
  int texC = texelIndex - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,$N=`
vec2 packedUVfrom2D(int texelsInLogicalRow, int texNumR,
  int texNumC, int row, int col) {
  int texelIndex = (row / 2) * texelsInLogicalRow + (col / 2);
  int texR = texelIndex / texNumC;
  int texC = texelIndex - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,eP=`
vec2 packedUVfrom3D(int texNumR, int texNumC,
    int texelsInBatch, int texelsInLogicalRow, int b,
    int row, int col) {
  int index = b * texelsInBatch + (row / 2) * texelsInLogicalRow + (col / 2);
  int texR = index / texNumC;
  int texC = index - texR * texNumC;
  return (vec2(texC, texR) + halfCR) / vec2(texNumC, texNumR);
}
`,tP=`
  float getChannel(vec4 frag, vec2 innerDims) {
    vec2 modCoord = mod(innerDims, 2.);
    return modCoord.x == 0. ?
      (modCoord.y == 0. ? frag.r : frag.g) :
      (modCoord.y == 0. ? frag.b : frag.a);
  }
  float getChannel(vec4 frag, int dim) {
    float modCoord = mod(float(dim), 2.);
    return modCoord == 0. ? frag.r : frag.g;
  }
`;function nP(){return`
    int getOutputCoords() {
      return 0;
    }
  `}function rP(e,t,n){let r=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)];return r[0]===1?n?`
      int getOutputCoords() {
        return 2 * int(resultUV.x * ceil(float(outTexShape[1]) / 2.0));
      }
    `:`
      int getOutputCoords() {
        return 2 * int(resultUV.x * ${r[1]}.0);
      }
    `:r[1]===1?n?`
      int getOutputCoords() {
        return 2 * int(resultUV.y * ceil(float(outTexShape[0]) / 2.0));
      }
    `:`
      int getOutputCoords() {
        return 2 * int(resultUV.y * ${r[0]}.0);
      }
    `:n?`
    int getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      return 2 * (resTexRC.x * packedTexShape[1] + resTexRC.y);
    }
  `:`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${r[0]}, ${r[1]}));
      return 2 * (resTexRC.x * ${r[1]} + resTexRC.y);
    }
  `}function iP(e,t,n){return t[0]===1?n?`
      int getOutputCoords() {
        return int(resultUV.x * float(outTexShape[1]));
      }
    `:`
      int getOutputCoords() {
        return int(resultUV.x * ${t[1]}.0);
      }
    `:t[1]===1?n?`
      int getOutputCoords() {
        return int(resultUV.y * float(outTexShape[0]));
      }
    `:`
      int getOutputCoords() {
        return int(resultUV.y * ${t[0]}.0);
      }
    `:n?`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(outTexShape[0], outTexShape[1]));
      return resTexRC.x * outTexShape[1] + resTexRC.y;
    }
  `:`
    int getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      return resTexRC.x * ${t[1]} + resTexRC.y;
    }
  `}function aP(e,t,n){if(n)return`
    ivec3 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      int texelsInLogicalRow = int(ceil(float(outShape[2]) / 2.0));
      int texelsInBatch = texelsInLogicalRow * int(ceil(float(outShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;

      int b = index / texelsInBatch;
      index -= b * texelsInBatch;

      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec3(b, r, c);
    }
  `;let r=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)],i=Math.ceil(e[2]/2),a=i*Math.ceil(e[1]/2);return`
    ivec3 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${r[0]}, ${r[1]}));
      int index = resTexRC.x * ${r[1]} + resTexRC.y;

      int b = index / ${a};
      index -= b * ${a};

      int r = 2 * (index / ${i});
      int c = imod(index, ${i}) * 2;

      return ivec3(b, r, c);
    }
  `}function oP(e,t,n){if(n)return`
  ivec3 getOutputCoords() {
    ivec2 resTexRC = ivec2(resultUV.yx *
                           vec2(outTexShape[0], outTexShape[1]));
    int index = resTexRC.x * outTexShape[1] + resTexRC.y;
    ${FN([`r`,`c`,`d`],e)}
    return ivec3(r, c, d);
  }
`;let r=PN([`r`,`c`,`d`],e);return`
    ivec3 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      ${r}
      return ivec3(r, c, d);
    }
  `}function sP(e,t,n){if(n)return`
    ivec4 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));
      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;

      int texelsInLogicalRow = int(ceil(float(outShape[3]) / 2.0));
      int texelsInBatch = texelsInLogicalRow * int(ceil(float(outShape[2]) / 2.0));
      int texelsInBatchN = texelsInBatch * outShape[1];

      int b2 = index / texelsInBatchN;
      index -= b2 * texelsInBatchN;

      int b = index / texelsInBatch;
      index -= b * texelsInBatch;

      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec4(b2, b, r, c);
    }
  `;let r=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)],i=Math.ceil(e[e.length-1]/2),a=i*Math.ceil(e[e.length-2]/2),o=a,s=``,c=`b, r, c`;for(let t=2;t<e.length-1;t++)o*=e[e.length-t-1],s=`
      int b${t} = index / ${o};
      index -= b${t} * ${o};
    `+s,c=`b${t}, `+c;return`
    ivec${e.length} getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${r[0]}, ${r[1]}));
      int index = resTexRC.x * ${r[1]} + resTexRC.y;

      ${s}

      int b = index / ${a};
      index -= b * ${a};

      int r = 2 * (index / ${i});
      int c = imod(index, ${i}) * 2;

      return ivec${e.length}(${c});
    }
  `}function cP(e,t,n){if(n)return`
    ivec4 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(outTexShape[0], outTexShape[1]));
      int index = resTexRC.x * outTexShape[1] + resTexRC.y;
      ${FN([`r`,`c`,`d`,`d2`],e)}
      return ivec4(r, c, d, d2);
    }
  `;let r=PN([`r`,`c`,`d`,`d2`],e);return`
    ivec4 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      ${r}
      return ivec4(r, c, d, d2);
    }
  `}function lP(e,t){let n=PN([`r`,`c`,`d`,`d2`,`d3`],e);return`
    ivec5 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx * vec2(${t[0]},
                             ${t[1]}));

      int index = resTexRC.x * ${t[1]} + resTexRC.y;

      ${n}

      ivec5 outShape = ivec5(r, c, d, d2, d3);
      return outShape;
    }
  `}function uP(e,t){let n=PN([`r`,`c`,`d`,`d2`,`d3`,`d4`],e);return`
    ivec6 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
        vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;

      ${n}

      ivec6 result = ivec6(r, c, d, d2, d3, d4);
      return result;
    }
  `}function dP(e,t,n){let r=[Math.ceil(t[0]/2),Math.ceil(t[1]/2)];if(qn(e,t))return n?`
      ivec2 getOutputCoords() {
        ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
        return 2 * ivec2(resultUV.yx * vec2(packedTexShape[0], packedTexShape[1]));
      }
    `:`
      ivec2 getOutputCoords() {
        return 2 * ivec2(resultUV.yx * vec2(${r[0]}, ${r[1]}));
      }
    `;let i=Math.ceil(e[1]/2);return n?`
    ivec2 getOutputCoords() {
      ivec2 packedTexShape = ivec2(ceil(float(outTexShape[0]) / 2.0), ceil(float(outTexShape[1]) / 2.0));
      int texelsInLogicalRow = int(ceil(float(outShape[1]) / 2.0));
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(packedTexShape[0], packedTexShape[1]));

      int index = resTexRC.x * packedTexShape[1] + resTexRC.y;
      int r = 2 * (index / texelsInLogicalRow);
      int c = imod(index, texelsInLogicalRow) * 2;

      return ivec2(r, c);
    }
  `:`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${r[0]}, ${r[1]}));

      int index = resTexRC.x * ${r[1]} + resTexRC.y;
      int r = 2 * (index / ${i});
      int c = imod(index, ${i}) * 2;

      return ivec2(r, c);
    }
  `}function fP(e,t,n){return qn(e,t)?n?`
      ivec2 getOutputCoords() {
        return ivec2(resultUV.yx * vec2(outTexShape[0], outTexShape[1]));
      }
    `:`
      ivec2 getOutputCoords() {
        return ivec2(resultUV.yx * vec2(${t[0]}, ${t[1]}));
      }
    `:e[1]===1?n?`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(outTexShape[0], outTexShape[1]));
        int index = resTexRC.x * outTexShape[1] + resTexRC.y;
        return ivec2(index, 0);
      }
    `:`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(${t[0]}, ${t[1]}));
        int index = resTexRC.x * ${t[1]} + resTexRC.y;
        return ivec2(index, 0);
      }
    `:e[0]===1?n?`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(outTexShape[0], outTexShape[1]));
        int index = resTexRC.x * outTexShape[1] + resTexRC.y;
        return ivec2(0, index);
      }
    `:`
      ivec2 getOutputCoords() {
        ivec2 resTexRC = ivec2(resultUV.yx *
                               vec2(${t[0]}, ${t[1]}));
        int index = resTexRC.x * ${t[1]} + resTexRC.y;
        return ivec2(0, index);
      }
    `:n?`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(outTexShape[0], outTexShape[1]));
      int index = resTexRC.x * outTexShape[1] + resTexRC.y;
      int r = index / outShape[1];
      int c = index - r * outShape[1];
      return ivec2(r, c);
    }
  `:`
    ivec2 getOutputCoords() {
      ivec2 resTexRC = ivec2(resultUV.yx *
                             vec2(${t[0]}, ${t[1]}));
      int index = resTexRC.x * ${t[1]} + resTexRC.y;
      int r = index / ${e[1]};
      int c = index - r * ${e[1]};
      return ivec2(r, c);
    }
  `}function pP(e){return`offset${e}`}function mP(e){let t=e.name;return`
    vec4 ${`get`+t.charAt(0).toUpperCase()+t.slice(1)}() {
      return ${NN().texture2D}(${t}, halfCR);
    }
  `}function hP(e,t){let n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1);if(e.shapeInfo.isUniform)return`float ${r}() {return ${n};}`;let[i,a]=e.shapeInfo.texShape;if(i===1&&a===1)return`
      float ${r}() {
        return sampleTexture(${n}, halfCR);
      }
    `;let o=pP(n);if(t)return`
    float ${r}() {
      vec2 uv = uvFromFlat(${n}TexShape[0], ${n}TexShape[1], ${o});
      return sampleTexture(${n}, uv);
    }
  `;let[s,c]=e.shapeInfo.texShape;return`
    float ${r}() {
      vec2 uv = uvFromFlat(${s}, ${c}, ${o});
      return sampleTexture(${n}, uv);
    }
  `}function gP(e,t){let n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1),i=e.shapeInfo.texShape,a=NN();if(t)return`
    vec4 ${r}(int index) {
      ivec2 packedTexShape = ivec2(ceil(float(${n}TexShape[0]) / 2.0), ceil(float(${n}TexShape[1]) / 2.0));
      vec2 uv = packedUVfrom1D(
        packedTexShape[0], packedTexShape[1], index);
      return ${a.texture2D}(${n}, uv);
    }
  `;let o=[Math.ceil(i[0]/2),Math.ceil(i[1]/2)];return`
    vec4 ${r}(int index) {
      vec2 uv = packedUVfrom1D(
        ${o[0]}, ${o[1]}, index);
      return ${a.texture2D}(${n}, uv);
    }
  `}function _P(e,t){let n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1);if(e.shapeInfo.isUniform)return`
      float ${r}(int index) {
        ${EP(e)}
      }
    `;let i=e.shapeInfo.texShape,a=i[0],o=i[1];if(o===1&&a===1)return`
      float ${r}(int index) {
        return sampleTexture(${n}, halfCR);
      }
    `;let s=pP(n);return o===1?t?`
      float ${r}(int index) {
        vec2 uv = vec2(0.5, (float(index + ${s}) + 0.5) / float(${n}TexShape[0]));
        return sampleTexture(${n}, uv);
      }
    `:`
      float ${r}(int index) {
        vec2 uv = vec2(0.5, (float(index + ${s}) + 0.5) / ${a}.0);
        return sampleTexture(${n}, uv);
      }
    `:a===1?t?`
      float ${r}(int index) {
        vec2 uv = vec2((float(index + ${s}) + 0.5) / float(${n}TexShape[1]), 0.5);
        return sampleTexture(${n}, uv);
      }
    `:`
      float ${r}(int index) {
        vec2 uv = vec2((float(index + ${s}) + 0.5) / ${o}.0, 0.5);
        return sampleTexture(${n}, uv);
      }
    `:t?`
    float ${r}(int index) {
      vec2 uv = uvFromFlat(${n}TexShape[0], ${n}TexShape[1], index + ${s});
      return sampleTexture(${n}, uv);
    }
  `:`
    float ${r}(int index) {
      vec2 uv = uvFromFlat(${a}, ${o}, index + ${s});
      return sampleTexture(${n}, uv);
    }
  `}function vP(e,t){let n=e.shapeInfo.logicalShape,r=e.name,i=`get`+r.charAt(0).toUpperCase()+r.slice(1),a=e.shapeInfo.texShape,o=a[0],s=a[1],c=NN();if(a!=null&&qn(n,a))return t?`
      vec4 ${i}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${r}TexShape[1], ${r}TexShape[0]);

        return ${c.texture2D}(${r}, uv);
      }
    `:`
      vec4 ${i}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${s}.0, ${o}.0);

        return ${c.texture2D}(${r}, uv);
      }
    `;if(t)return`
    vec4 ${i}(int row, int col) {
      ivec2 packedTexShape = ivec2(ceil(float(${r}TexShape[0]) / 2.0), ceil(float(${r}TexShape[1]) / 2.0));
      int valuesPerRow = int(ceil(float(${r}Shape[1]) / 2.0));
      vec2 uv = packedUVfrom2D(valuesPerRow, packedTexShape[0], packedTexShape[1], row, col);
      return ${c.texture2D}(${r}, uv);
    }
  `;let l=[Math.ceil(a[0]/2),Math.ceil(a[1]/2)];return`
    vec4 ${i}(int row, int col) {
      vec2 uv = packedUVfrom2D(${Math.ceil(n[1]/2)}, ${l[0]}, ${l[1]}, row, col);
      return ${c.texture2D}(${r}, uv);
    }
  `}function yP(e,t){let n=e.shapeInfo.logicalShape,r=e.name,i=`get`+r.charAt(0).toUpperCase()+r.slice(1),a=e.shapeInfo.texShape;if(a!=null&&qn(n,a)){if(t)return`
      float ${i}(int row, int col) {
        vec2 uv = (vec2(col, row) + halfCR) / vec2(${r}TexShape[1], ${r}TexShape[0]);
        return sampleTexture(${r}, uv);
      }
    `;let e=a[0];return`
    float ${i}(int row, int col) {
      vec2 uv = (vec2(col, row) + halfCR) / vec2(${a[1]}.0, ${e}.0);
      return sampleTexture(${r}, uv);
    }
  `}let{newShape:o,keptDims:s}=Ee(n),c=o;if(c.length<n.length)return`
      ${UN(jP(e,c),t)}
      float ${i}(int row, int col) {
        return ${i}(${MP([`row`,`col`],s)});
      }
    `;if(e.shapeInfo.isUniform)return`
      float ${i}(int row, int col) {
        int index = round(dot(vec2(row, col), vec2(${n[1]}, 1)));
        ${EP(e)}
      }
    `;let l=a[0],u=a[1],d=pP(r);return u===1?t?`
      float ${i}(int row, int col) {
        float index = dot(vec3(row, col, ${d}), vec3(${r}Shape[1], 1, 1));
        vec2 uv = vec2(0.5, (index + 0.5) / float(${r}TexShape[0]));
        return sampleTexture(${r}, uv);
      }
    `:`
    float ${i}(int row, int col) {
      float index = dot(vec3(row, col, ${d}), vec3(${n[1]}, 1, 1));
      vec2 uv = vec2(0.5, (index + 0.5) / ${l}.0);
      return sampleTexture(${r}, uv);
    }
  `:l===1?t?`
      float ${i}(int row, int col) {
        float index = dot(vec3(row, col, ${d}), vec3(${r}Shape[1], 1, 1));
        vec2 uv = vec2((index + 0.5) / float(${r}TexShape[1]), 0.5);
        return sampleTexture(${r}, uv);
      }
    `:`
    float ${i}(int row, int col) {
      float index = dot(vec3(row, col, ${d}), vec3(${n[1]}, 1, 1));
      vec2 uv = vec2((index + 0.5) / ${u}.0, 0.5);
      return sampleTexture(${r}, uv);
    }
  `:t?`
      float ${i}(int row, int col) {
        // Explicitly use integer operations as dot() only works on floats.
        int index = row * ${r}Shape[1] + col + ${d};
        vec2 uv = uvFromFlat(${r}TexShape[0], ${r}TexShape[1], index);
        return sampleTexture(${r}, uv);
      }
    `:`
  float ${i}(int row, int col) {
    // Explicitly use integer operations as dot() only works on floats.
    int index = row * ${n[1]} + col + ${d};
    vec2 uv = uvFromFlat(${l}, ${u}, index);
    return sampleTexture(${r}, uv);
  }
`}function bP(e,t){let n=e.shapeInfo.logicalShape,r=e.name,i=`get`+r.charAt(0).toUpperCase()+r.slice(1),a=e.shapeInfo.texShape,o=[Math.ceil(a[0]/2),Math.ceil(a[1]/2)];if(n[0]===1)return`
        ${WN(jP(e,n.slice(1)),t)}
        vec4 ${i}(int b, int row, int col) {
          return ${i}(${MP([`b`,`row`,`col`],[1,2])});
        }
      `;let s=NN();if(t)return`
    vec4 ${i}(int b, int row, int col) {
      ivec2 packedTexShape = ivec2(ceil(float(${r}TexShape[0]) / 2.0), ceil(float(${r}TexShape[1]) / 2.0));
      int valuesPerRow = int(ceil(float(${r}Shape[2]) / 2.0));
      int texelsInBatch = valuesPerRow * int(ceil(float(${r}Shape[1]) / 2.0));
      vec2 uv = packedUVfrom3D(
        packedTexShape[0], packedTexShape[1], texelsInBatch, valuesPerRow, b, row, col);
      return ${s.texture2D}(${r}, uv);
    }
  `;let c=o[0],l=o[1],u=Math.ceil(n[2]/2);return`
    vec4 ${i}(int b, int row, int col) {
      vec2 uv = packedUVfrom3D(
        ${c}, ${l}, ${u*Math.ceil(n[1]/2)}, ${u}, b, row, col);
      return ${s.texture2D}(${r}, uv);
    }
  `}function xP(e,t){let n=e.shapeInfo.logicalShape,r=e.name,i=`get`+r.charAt(0).toUpperCase()+r.slice(1),a=n[1]*n[2],o=n[2],{newShape:s,keptDims:c}=Ee(n),l=s;if(l.length<n.length)return`
        ${UN(jP(e,l),t)}
        float ${i}(int row, int col, int depth) {
          return ${i}(${MP([`row`,`col`,`depth`],c)});
        }
      `;if(e.shapeInfo.isUniform)return`
      float ${i}(int row, int col, int depth) {
        int index = round(dot(vec3(row, col, depth),
                          vec3(${a}, ${o}, 1)));
        ${EP(e)}
      }
    `;let u=e.shapeInfo.texShape,d=u[0],f=u[1],p=e.shapeInfo.flatOffset;if(f===a&&p==null)return t?`
      float ${i}(int row, int col, int depth) {
        int stride1 = ${r}Shape[2];
        float texR = float(row);
        float texC = dot(vec2(col, depth), vec2(stride1, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${r}TexShape[1], ${r}TexShape[0]);
        return sampleTexture(${r}, uv);
      }
    `:`
        float ${i}(int row, int col, int depth) {
          float texR = float(row);
          float texC = dot(vec2(col, depth), vec2(${o}, 1));
          vec2 uv = (vec2(texC, texR) + halfCR) /
                     vec2(${f}.0, ${d}.0);
          return sampleTexture(${r}, uv);
        }
      `;if(f===o&&p==null)return t?`
      float ${i}(int row, int col, int depth) {
        float texR = dot(vec2(row, col), vec2(${r}Shape[1], 1));
        float texC = float(depth);
        vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${r}TexShape[1], ${r}TexShape[0]);
        return sampleTexture(${r}, uv);
      }
    `:`
    float ${i}(int row, int col, int depth) {
      float texR = dot(vec2(row, col), vec2(${n[1]}, 1));
      float texC = float(depth);
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${f}.0, ${d}.0);
      return sampleTexture(${r}, uv);
    }
  `;let m=pP(r);return t?`
    float ${i}(int row, int col, int depth) {
      // Explicitly use integer operations as dot() only works on floats.
      int stride0 = ${r}Shape[1] * ${r}Shape[2];
      int stride1 = ${r}Shape[2];
      int index = row * stride0 + col * stride1 + depth + ${m};
      vec2 uv = uvFromFlat(${r}TexShape[0], ${r}TexShape[1], index);
      return sampleTexture(${r}, uv);
    }
    `:`
      float ${i}(int row, int col, int depth) {
        // Explicitly use integer operations as dot() only works on floats.
        int index = row * ${a} + col * ${o} + depth + ${m};
        vec2 uv = uvFromFlat(${d}, ${f}, index);
        return sampleTexture(${r}, uv);
      }
  `}function SP(e,t){let n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1),i=NN();if(t)return`
    vec4 ${r}(int b2, int b, int row, int col) {
      int valuesPerRow = int(ceil(float(${n}Shape[3]) / 2.0));
      int texelsInBatch = valuesPerRow * int(ceil(float(${n}Shape[2]) / 2.0));
      int index = b * texelsInBatch + (row / 2) * valuesPerRow + (col / 2);
      texelsInBatch *= ${n}Shape[1];
      index = b2 * texelsInBatch + index;
      ivec2 packedTexShape = ivec2(ceil(float(${n}TexShape[0]) / 2.0), ceil(float(${n}TexShape[1]) / 2.0));
      int texR = index / packedTexShape[1];
      int texC = index - texR * packedTexShape[1];
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(packedTexShape[1], packedTexShape[0]); return ${i.texture2D}(${n}, uv);
    }
  `;let a=e.shapeInfo.logicalShape,o=a.length,s=e.shapeInfo.texShape,c=[Math.ceil(s[0]/2),Math.ceil(s[1]/2)],l=c[0],u=c[1],d=Math.ceil(a[o-1]/2),f=d*Math.ceil(a[o-2]/2),p=`int b, int row, int col`,m=`b * ${f} + (row / 2) * ${d} + (col / 2)`;for(let e=2;e<o-1;e++)p=`int b${e}, `+p,f*=a[o-e-1],m=`b${e} * ${f} + `+m;return`
    vec4 ${r}(${p}) {
      int index = ${m};
      int texR = index / ${u};
      int texC = index - texR * ${u};
      vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${u}, ${l});
      return ${i.texture2D}(${n}, uv);
    }
  `}function CP(e,t){let n=e.shapeInfo.logicalShape,r=e.name,i=`get`+r.charAt(0).toUpperCase()+r.slice(1),a=n[3],o=n[2]*a,s=n[1]*o,{newShape:c,keptDims:l}=Ee(n);if(c.length<n.length)return`
      ${UN(jP(e,c),t)}
      float ${i}(int row, int col, int depth, int depth2) {
        return ${i}(${MP([`row`,`col`,`depth`,`depth2`],l)});
      }
    `;if(e.shapeInfo.isUniform)return`
      float ${i}(int row, int col, int depth, int depth2) {
        int index = round(dot(vec4(row, col, depth, depth2),
                          vec4(${s}, ${o}, ${a}, 1)));
        ${EP(e)}
      }
    `;let u=e.shapeInfo.flatOffset,d=e.shapeInfo.texShape,f=d[0],p=d[1],m=`int stride2 = ${r}Shape[3];`,h=`int stride1 = ${r}Shape[2] * stride2;`,g=`int stride0 = ${r}Shape[1] * stride1;`;if(p===s&&u==null)return t?`
      float ${i}(int row, int col, int depth, int depth2) {
        ${m}
        ${h}
        float texR = float(row);
        float texC =
            dot(vec3(col, depth, depth2),
                vec3(stride1, stride2, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${r}TexShape[1], ${r}TexShape[0]);
        return sampleTexture(${r}, uv);
      }
    `:`
      float ${i}(int row, int col, int depth, int depth2) {
        float texR = float(row);
        float texC =
            dot(vec3(col, depth, depth2),
                vec3(${o}, ${a}, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${p}.0, ${f}.0);
        return sampleTexture(${r}, uv);
      }
    `;if(p===a&&u==null)return t?`
      float ${i}(int row, int col, int depth, int depth2) {
        float texR = dot(vec3(row, col, depth),
                         vec3(${r}Shape[1] * ${r}Shape[2], ${r}Shape[2], 1));
        float texC = float(depth2);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${r}TexShape[1], ${r}TexShape[0]);
        return sampleTexture(${r}, uv);
      }
    `:`
      float ${i}(int row, int col, int depth, int depth2) {
        float texR = dot(vec3(row, col, depth),
                         vec3(${n[1]*n[2]}, ${n[2]}, 1));
        float texC = float(depth2);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${p}.0, ${f}.0);
        return sampleTexture(${r}, uv);
      }
    `;let _=pP(r);return t?`
    float ${i}(int row, int col, int depth, int depth2) {
      // Explicitly use integer operations as dot() only works on floats.
      ${m}
      ${h}
      ${g}
      int index = row * stride0 + col * stride1 +
          depth * stride2 + depth2;
      vec2 uv = uvFromFlat(${r}TexShape[0], ${r}TexShape[1], index + ${_});
      return sampleTexture(${r}, uv);
    }
  `:`
    float ${i}(int row, int col, int depth, int depth2) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${s} + col * ${o} +
          depth * ${a} + depth2;
      vec2 uv = uvFromFlat(${f}, ${p}, index + ${_});
      return sampleTexture(${r}, uv);
    }
  `}function wP(e){let t=e.shapeInfo.logicalShape,n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1),i=t[4],a=t[3]*i,o=t[2]*a,s=t[1]*o,{newShape:c,keptDims:l}=Ee(t);if(c.length<t.length)return`
      ${UN(jP(e,c))}
      float ${r}(int row, int col, int depth, int depth2, int depth3) {
        return ${r}(${MP([`row`,`col`,`depth`,`depth2`,`depth3`],l)});
      }
    `;if(e.shapeInfo.isUniform)return`
      float ${r}(int row, int col, int depth, int depth2, int depth3) {
        float index = dot(
          vec4(row, col, depth, depth2),
          vec4(${s}, ${o}, ${a}, ${i})) +
          depth3;
        ${EP(e)}
      }
    `;let u=e.shapeInfo.flatOffset,d=e.shapeInfo.texShape,f=d[0],p=d[1];return p===s&&u==null?`
      float ${r}(int row, int col, int depth, int depth2, int depth3) {
        int texR = row;
        float texC = dot(vec4(col, depth, depth2, depth3),
                         vec4(${o}, ${a}, ${i}, 1));
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${p}.0, ${f}.0);
        return sampleTexture(${n}, uv);
      }
    `:p===i&&u==null?`
      float ${r}(int row, int col, int depth, int depth2, int depth3) {
        float texR = dot(
          vec4(row, col, depth, depth2),
          vec4(${t[1]*t[2]*t[3]},
               ${t[2]*t[3]}, ${t[3]}, 1));
        int texC = depth3;
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${p}.0, ${f}.0);
        return sampleTexture(${n}, uv);
      }
    `:`
    float ${r}(int row, int col, int depth, int depth2, int depth3) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${s} + col * ${o} + depth * ${a} +
          depth2 * ${i} + depth3 + ${pP(n)};
      vec2 uv = uvFromFlat(${f}, ${p}, index);
      return sampleTexture(${n}, uv);
    }
  `}function TP(e){let t=e.shapeInfo.logicalShape,n=e.name,r=`get`+n.charAt(0).toUpperCase()+n.slice(1),{newShape:i,keptDims:a}=Ee(t);if(i.length<t.length)return`
      ${UN(jP(e,i))}
      float ${r}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        return ${r}(${MP([`row`,`col`,`depth`,`depth2`,`depth3`,`depth4`],a)});
      }
    `;let o=t[5],s=t[4]*o,c=t[3]*s,l=t[2]*c,u=t[1]*l;if(e.shapeInfo.isUniform)return`
      float ${r}(int row, int col, int depth,
                  int depth2, int depth3, int depth4) {
        int index = round(dot(
          vec4(row, col, depth, depth2),
          vec4(${u}, ${l}, ${c}, ${s})) +
          dot(
            vec2(depth3, depth4),
            vec2(${o}, 1)));
        ${EP(e)}
      }
    `;let d=e.shapeInfo.flatOffset,f=e.shapeInfo.texShape,p=f[0],m=f[1];return m===u&&d==null?`
      float ${r}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        int texR = row;
        float texC = dot(vec4(col, depth, depth2, depth3),
          vec4(${l}, ${c}, ${s}, ${o})) +
               float(depth4);
        vec2 uv = (vec2(texC, texR) + halfCR) /
                   vec2(${m}.0, ${p}.0);
        return sampleTexture(${n}, uv);
      }
    `:m===o&&d==null?`
      float ${r}(int row, int col, int depth,
                    int depth2, int depth3, int depth4) {
        float texR = dot(vec4(row, col, depth, depth2),
          vec4(${t[1]*t[2]*t[3]*t[4]},
               ${t[2]*t[3]*t[4]},
               ${t[3]*t[4]},
               ${t[4]})) + float(depth3);
        int texC = depth4;
        vec2 uv = (vec2(texC, texR) + halfCR) /
                  vec2(${m}.0, ${p}.0);
        return sampleTexture(${n}, uv);
      }
    `:`
    float ${r}(int row, int col, int depth,
                  int depth2, int depth3, int depth4) {
      // Explicitly use integer operations as dot() only works on floats.
      int index = row * ${u} + col * ${l} + depth * ${c} +
          depth2 * ${s} + depth3 * ${o} + depth4 + ${pP(n)};
      vec2 uv = uvFromFlat(${p}, ${m}, index);
      return sampleTexture(${n}, uv);
    }
  `}function EP(e){let t=e.name,n=k(e.shapeInfo.logicalShape);return n<2?`return ${t};`:`
    for (int i = 0; i < ${n}; i++) {
      if (i == index) {
        return ${t}[i];
      }
    }
  `}function DP(e,t){let n=e.name,r=n.charAt(0).toUpperCase()+n.slice(1),i=`get`+r+`AtOutCoords`,a=e.shapeInfo.logicalShape.length,o=t.logicalShape.length,s=VN(e.shapeInfo.logicalShape,t.logicalShape),c=kP(o),l=o-a,u,d=[`x`,`y`,`z`,`w`,`u`,`v`];u=a===0?``:o<2&&s.length>=1?`coords = 0;`:s.map(e=>`coords.${d[e+l]} = 0;`).join(`
`);let f=``;f=o<2&&a>0?`coords`:e.shapeInfo.logicalShape.map((e,t)=>`coords.${d[t+l]}`).join(`, `);let p=`return outputValue;`,m=k(e.shapeInfo.logicalShape)===1,h=k(t.logicalShape)===1;if(a===1&&!m&&!h)p=`
      return vec4(outputValue.xy, outputValue.xy);
    `;else if(m&&!h)p=o===1?`
        return vec4(outputValue.x, outputValue.x, 0., 0.);
      `:`
        return vec4(outputValue.x);
      `;else if(s.length){let e=a-2,t=a-1;s.indexOf(e)>-1&&s.indexOf(t)>-1?p=`return vec4(outputValue.x);`:s.indexOf(e)>-1?p=`return vec4(outputValue.x, outputValue.y, outputValue.x, outputValue.y);`:s.indexOf(t)>-1&&(p=`return vec4(outputValue.xx, outputValue.zz);`)}return`
    vec4 ${i}() {
      ${c} coords = getOutputCoords();
      ${u}
      vec4 outputValue = get${r}(${f});
      ${p}
    }
  `}function OP(e,t){let n=e.name,r=n.charAt(0).toUpperCase()+n.slice(1),i=`get`+r+`AtOutCoords`,a=t.texShape,o=e.shapeInfo.texShape,s=e.shapeInfo.logicalShape.length,c=t.logicalShape.length;if(!e.shapeInfo.isUniform&&s===c&&e.shapeInfo.flatOffset==null&&qn(o,a))return`
      float ${i}() {
        return sampleTexture(${n}, resultUV);
      }
    `;let l=kP(c),u=VN(e.shapeInfo.logicalShape,t.logicalShape),d=c-s,f,p=[`x`,`y`,`z`,`w`,`u`,`v`];f=s===0?``:c<2&&u.length>=1?`coords = 0;`:u.map(e=>`coords.${p[e+d]} = 0;`).join(`
`);let m=``;return m=c<2&&s>0?`coords`:e.shapeInfo.logicalShape.map((e,t)=>`coords.${p[t+d]}`).join(`, `),`
    float ${i}() {
      ${l} coords = getOutputCoords();
      ${f}
      return get${r}(${m});
    }
  `}function kP(e){if(e<=1)return`int`;if(e===2)return`ivec2`;if(e===3)return`ivec3`;if(e===4)return`ivec4`;if(e===5)return`ivec5`;if(e===6)return`ivec6`;throw Error(`GPU for rank ${e} is not yet supported`)}function AP(e,t,n){let{newShape:r,keptDims:i}=Ee(t),a=t.length,o=e&&a===3&&t[0]===1,s=o?t.slice(1):r,c=!e&&a>1&&!qn(t,n)&&r.length<a||o;return{useSqueezeShape:c,uniformShape:c?s:t,keptDims:i}}function jP(e,t){let n=JSON.parse(JSON.stringify(e));return n.shapeInfo.logicalShape=t,n}function MP(e,t){return t.map(t=>e[t]).join(`, `)}function NP(e,t,n,r){let i=n.map((e,n)=>{let r={logicalShape:e.shape,texShape:e.isUniform?null:e.texData.texShape,isUniform:e.isUniform,isPacked:!e.isUniform&&e.texData.isPacked,flatOffset:null};return e.texData!=null&&e.texData.slice!=null&&e.texData.slice.flatOffset>0&&(r.flatOffset=e.texData.slice.flatOffset),{name:t.variableNames[n],shapeInfo:r}}),a=i.map(e=>e.shapeInfo),o={logicalShape:r.shape,texShape:r.texData.texShape,isUniform:!1,isPacked:r.texData.isPacked,flatOffset:null},s=HN(i,o,t),c=VM(e.gl,s),l=e.createProgram(c);return j().get(`ENGINE_COMPILE_ONLY`)?{program:t,fragmentShader:c,source:s,webGLProgram:l,inShapeInfos:a,outShapeInfo:o,variablesLocations:null,customUniformLocations:null,infLoc:null,nanLoc:null,outShapeLocation:null,outShapeStridesLocation:null,outTexShapeLocation:null}:(e.buildVao(l),Object.assign({program:t,fragmentShader:c,source:s,webGLProgram:l,inShapeInfos:a,outShapeInfo:o},PP(e,t,l)))}function PP(e,t,n){let r=[],i=[],a,o,s,c=null,l=null;l=e.getUniformLocation(n,`NAN`,!1),j().getNumber(`WEBGL_VERSION`)===1&&(c=e.getUniformLocation(n,`INFINITY`,!1));for(let i of t.variableNames){let a={name:i,uniform:e.getUniformLocation(n,i,!1),offset:e.getUniformLocation(n,`offset${i}`,!1)};t.enableShapeUniforms&&(a.shape=e.getUniformLocation(n,`${i}Shape`,!1),a.texShape=e.getUniformLocation(n,`${i}TexShape`,!1)),r.push(a)}if(t.enableShapeUniforms&&(a=e.getUniformLocation(n,`outShape`,!1),s=e.getUniformLocation(n,`outShapeStrides`,!1),o=e.getUniformLocation(n,`outTexShape`,!1)),t.customUniforms)for(let r of t.customUniforms)i.push(e.getUniformLocation(n,r.name,!1));return{variablesLocations:r,customUniformLocations:i,infLoc:c,nanLoc:l,outShapeLocation:a,outShapeStridesLocation:s,outTexShapeLocation:o}}function FP(e,t){if(e.length!==t.length)throw Error(`Binary was compiled with ${e.length} inputs, but was executed with ${t.length} inputs`);e.forEach((e,n)=>{let r=e.logicalShape,i=t[n],a=i.shape;if(!qn(r,a))throw Error(`Binary was compiled with different shapes than the current args. Shapes ${r} and ${a} must match`);if(e.isUniform&&i.isUniform)return;let o=e.texShape,s=i.isUniform?null:i.texData.texShape;if(!qn(o,s))throw Error(`Binary was compiled with different texture shapes than the current args. Shape ${o} and ${s} must match`)})}function IP(e,t,n,r,i){t.program.enableShapeUniforms||(FP(t.inShapeInfos,n),FP([t.outShapeInfo],[r]));let a=r.texData.texture,o=r.texData.texShape;r.texData.isPacked?e.setOutputPackedMatrixTexture(a.texture,o[0],o[1]):e.setOutputMatrixTexture(a.texture,o[0],o[1]),e.setProgram(t.webGLProgram),e.bindVertexArray(t.webGLProgram.vao),j().getNumber(`WEBGL_VERSION`)===1&&t.infLoc!==null&&e.gl.uniform1f(t.infLoc,1/0),t.nanLoc!==null&&e.gl.uniform1f(t.nanLoc,NaN);for(let r=0;r<n.length;++r){let i=n[r],{uniform:a,offset:o,shape:s,texShape:c}=t.variablesLocations[r];if(s){let{uniformShape:n}=AP(t.program.packedInputs,i.shape,i.texData.texShape);switch(n.length){case 1:e.gl.uniform1iv(s,new Int32Array(n));break;case 2:e.gl.uniform2iv(s,new Int32Array(n));break;case 3:e.gl.uniform3iv(s,new Int32Array(n));break;case 4:e.gl.uniform4iv(s,new Int32Array(n));break;default:break}}if(c&&e.gl.uniform2i(c,i.texData.texShape[0],i.texData.texShape[1]),a!=null){if(i.isUniform){if(k(i.shape)<2)e.gl.uniform1f(a,i.uniformValues[0]);else{let t=i.uniformValues;t instanceof Float32Array||(t=new Float32Array(t)),e.gl.uniform1fv(a,t)}continue}i.texData.slice!=null&&o!=null&&e.gl.uniform1i(o,i.texData.slice.flatOffset),e.setInputMatrixTexture(i.texData.texture.texture,a,r)}}let s=t.outShapeLocation;if(s)switch(r.shape.length){case 1:e.gl.uniform1iv(s,new Int32Array(r.shape));break;case 2:e.gl.uniform2iv(s,new Int32Array(r.shape));break;case 3:e.gl.uniform3iv(s,new Int32Array(r.shape));break;case 4:e.gl.uniform4iv(s,new Int32Array(r.shape));break;default:break}if(t.outShapeStridesLocation){let n=R(r.shape);switch(r.shape.length){case 2:e.gl.uniform1iv(t.outShapeStridesLocation,new Int32Array(n));break;case 3:e.gl.uniform2iv(t.outShapeStridesLocation,new Int32Array(n));break;case 4:e.gl.uniform3iv(t.outShapeStridesLocation,new Int32Array(n));break;default:break}}if(t.outTexShapeLocation&&e.gl.uniform2i(t.outTexShapeLocation,r.texData.texShape[0],r.texData.texShape[1]),t.program.customUniforms&&i)for(let n=0;n<t.program.customUniforms.length;++n){let r=t.program.customUniforms[n],a=t.customUniformLocations[n],o=i[n];if(r.type===`float`)e.gl.uniform1fv(a,o);else if(r.type===`vec2`)e.gl.uniform2fv(a,o);else if(r.type===`vec3`)e.gl.uniform3fv(a,o);else if(r.type===`vec4`)e.gl.uniform4fv(a,o);else if(r.type===`int`)e.gl.uniform1iv(a,o);else if(r.type===`ivec2`)e.gl.uniform2iv(a,o);else if(r.type===`ivec3`)e.gl.uniform3iv(a,o);else if(r.type===`ivec4`)e.gl.uniform4iv(a,o);else throw Error(`uniform type ${r.type} is not supported yet.`)}e.executeProgram()}function LP(e,t,n){let r=``;t.concat(n).forEach(t=>{let i=t.texData!=null&&t.texData.slice!=null&&t.texData.slice.flatOffset>0;if(e.enableShapeUniforms&&!t.isUniform){let a=t.texData.texShape,{useSqueezeShape:o,uniformShape:s,keptDims:c}=AP(e.packedInputs,t.shape,a),l=``,u=``,d=``;if(s.length===1&&e.packedInputs){let e=[Math.ceil(a[0]/2),Math.ceil(a[1]/2)];l=`${e[0]>1}_${e[1]>1}`}else if(s.length===2&&!e.packedInputs)u=`${s[0]>1}_${s[1]>1}`;else if(s.length>2&&!e.packedInputs){let e=R(s);d=`${e[0]===a[1]}_${e[e.length-1]===a[1]}`}let f=t.shape.length,p=s.length===2&&qn(t.shape,a),m=k(t.shape)===1,h=Ai(t.shape,n.shape),g=!e.packedInputs&&f===n.shape.length&&qn(a,n.texData.texShape),_=e.packedInputs||s.length>2?``:`${a[0]>1}_${a[1]>1}`;r+=`${f}_${g}_${o?c:``}_${s.length}_${m}_${h}_${p}_${l}_${u}_${d}_${_}_${i}`}else{let e=t.isUniform?`uniform`:t.texData.texShape;r+=`${t.shape}_${e}_${i}`}});let i=e.userCode,a=e.constructor.name;return a+=`_`+r+`_`+i+`${j().getNumber(`WEBGL_VERSION`)}`,a}function RP(e){return j().getBool(`WEBGL_USE_SHAPES_UNIFORMS`)&&e<=4}var zP=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!1,this.packedOutput=!0,this.outPackingScheme=wM.DENSE,this.customUniforms=[{name:`texShape`,type:`ivec2`}];let t=NN();this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length),this.userCode=`
      ivec3 outCoordsFromFlatIndex(int index) {
        ${this.enableShapeUniforms?FN([`r`,`c`,`d`],e):PN([`r`,`c`,`d`],e)}
        return ivec3(r, c, d);
      }

      void main() {
        ivec2 resTexRC = ivec2(resultUV.yx * vec2(texShape[0], texShape[1]));
        int index = 4 * (resTexRC.x * texShape[1] + resTexRC.y);

        vec4 result = vec4(0.);

        for (int i=0; i<4; i++) {
          int flatIndex = index + i;
          ivec3 rc = outCoordsFromFlatIndex(flatIndex);
          result[i] = getA(rc.x, rc.y, rc.z);
        }

        ${t.output} = result;
      }
    `}},BP=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.outPackingScheme=wM.DENSE,this.customUniforms=[{name:`texShape`,type:`ivec2`}];let t=NN();this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length),this.userCode=`
      ivec3 outCoordsFromFlatIndex(int index) {
        ${this.enableShapeUniforms?FN([`r`,`c`,`d`],e):PN([`r`,`c`,`d`],e)}
        return ivec3(r, c, d);
      }

      void main() {
        ivec2 resTexRC = ivec2(resultUV.yx * vec2(texShape[0], texShape[1]));
        int index = 4 * (resTexRC.x * texShape[1] + resTexRC.y);

        vec4 result = vec4(0.);

        for (int i=0; i<4; i++) {
          int flatIndex = index + i;
          ivec3 rc = outCoordsFromFlatIndex(flatIndex);
          result[i] = getChannel(getA(rc.x, rc.y, rc.z), vec2(rc.y, rc.z));
        }

        ${t.output} = result;
      }
    `}},VP=class{constructor(e){this.variableNames=[`A`],this.outTexUsage=TM.DOWNLOAD;let t=NN();this.outputShape=e,this.userCode=`
      ${BN}

      void main() {
        float x = getAAtOutCoords();
        ${t.output} = encode_float(x);
      }
    `}},HP=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!1,this.outTexUsage=TM.DOWNLOAD;let t=NN();this.outputShape=e,this.userCode=`
      ${BN}

      void main() {
        ivec3 coords = getOutputCoords();
        float x = getChannel(getAAtOutCoords(), vec2(coords.y, coords.z));
        ${t.output} = encode_float(x);
      }
    `}},UP={R:0,G:1,B:2,A:3},WP=class{constructor(e,t=!1,n=`RGBA`){this.variableNames=[`A`],this.customUniforms=[{name:`texShape`,type:`ivec2`}];let r=NN();this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length);let i=`result`;t&&(i=`floor(result * 255. + 0.5)`);let a=``;for(let e=0;e<n.length;e++){let t=n[e];a+=`
          if(offset == ${e}) {
            result = values[${UP[t]}];
          }`}this.userCode=`
      ${this.enableShapeUniforms?zN():RN(e)}

      void main() {
        ivec3 coords = getOutputCoords();
        int flatIndex = getFlatIndex(coords);
        float result = 0.;
        int offset = imod(flatIndex, ${n.length});

        flatIndex = idiv(flatIndex, ${n.length}, 1.);

        int r = flatIndex / texShape[1];
        if (r < texShape[0]) {
          int c = imod(flatIndex, texShape[1]);
          vec2 uv = (vec2(c, r) + halfCR) / vec2(texShape[1], texShape[0]);
          vec4 values = ${r.texture2D}(A, uv);
          ${a}
        }
        ${r.output} = vec4(${i}, 0., 0., 0.);
      }
    `}},GP=class{constructor(e,t=!1){this.variableNames=[`A`],this.packedInputs=!1,this.packedOutput=!0,this.customUniforms=[{name:`texShape`,type:`ivec2`}];let n=NN();this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length);let r=``,i=`result`;t&&(i=`floor(result * 255. + 0.5)`);for(let t=0;t<=1;t++)for(let i=0;i<=1;i++){let a=t*2+i;r+=`
          localCoords = coords;
          if(localCoords[2] + ${i} < ${this.enableShapeUniforms?`outShape[2]`:`${e[2]}`}) {
          localCoords[2] += ${i};
          if (localCoords[1] + ${t} < ${this.enableShapeUniforms?`outShape[1]`:`${e[1]}`}) {
            localCoords[1] += ${t};

            flatIndex = getFlatIndex(localCoords);
            offset = imod(flatIndex, 4);

            flatIndex = idiv(flatIndex, 4, 1.);

            int r = flatIndex / texShape[1];
            int c = imod(flatIndex, texShape[1]);
            vec2 uv = (vec2(c, r) + halfCR) / vec2(texShape[1], texShape[0]);
            values = ${n.texture2D}(A, uv);

            if (offset == 0) {
              result[${a}] = values[0];
            } else if (offset == 1) {
              result[${a}] = values[1];
            } else if (offset == 2) {
              result[${a}] = values[2];
            } else {
              result[${a}] = values[3];
            }
          }
        }
        `}this.userCode=`
        ${this.enableShapeUniforms?zN():RN(e)}

        void main() {
          ivec3 coords = getOutputCoords();

          vec4 result = vec4(0.);
          int flatIndex, r, c, offset;
          ivec3 localCoords;
          vec2 uv;
          vec4 values;

          ${r}

          ${n.output} = ${i};
        }
    `}},KP=e({bindVertexProgramAttributeStreams:()=>sF,createBufferFromOutputTexture:()=>uF,createFloat16MatrixTexture:()=>eF,createFloat16PackedMatrixTexture:()=>oF,createFloat32MatrixTexture:()=>QP,createIndexBuffer:()=>YP,createPackedMatrixTexture:()=>iF,createUnsignedBytesMatrixTexture:()=>nF,createVertexBuffer:()=>JP,createVertexShader:()=>qP,downloadByteEncodedFloatMatrixFromOutputTexture:()=>fF,downloadFloat32MatrixFromBuffer:()=>dF,downloadMatrixFromPackedOutputTexture:()=>mF,downloadPackedMatrixFromBuffer:()=>pF,getInternalFormatForFloat16MatrixTexture:()=>$P,getInternalFormatForFloat16PackedMatrixTexture:()=>aF,getInternalFormatForFloat32MatrixTexture:()=>ZP,getInternalFormatForPackedMatrixTexture:()=>rF,getInternalFormatForUnsignedBytesMatrixTexture:()=>tF,uploadDenseMatrixToTexture:()=>cF,uploadPixelDataToTexture:()=>lF});function qP(e){let t=NN();return BM(e,`${t.version}
    precision highp float;
    ${t.attribute} vec3 clipSpacePos;
    ${t.attribute} vec2 uv;
    ${t.varyingVs} vec2 resultUV;

    void main() {
      gl_Position = vec4(clipSpacePos, 1);
      resultUV = uv;
    }`)}function JP(e){return qM(e,new Float32Array([-1,1,0,0,1,-1,-1,0,0,0,1,1,0,1,1,1,-1,0,1,0]))}function YP(e){return JM(e,new Uint16Array([0,1,2,2,1,3]))}function XP(e,t,n,r,i,a){ZM(t,n);let o=XM(e),s=e.TEXTURE_2D;return X(e,()=>e.bindTexture(s,o)),X(e,()=>e.texParameteri(s,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE)),X(e,()=>e.texParameteri(s,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)),X(e,()=>e.texParameteri(s,e.TEXTURE_MIN_FILTER,e.NEAREST)),X(e,()=>e.texParameteri(s,e.TEXTURE_MAG_FILTER,e.NEAREST)),j().getNumber(`WEBGL_VERSION`)===1?X(e,()=>e.texImage2D(s,0,r,t,n,0,i,a,null)):X(e,()=>e.texStorage2D(s,1,r,t,n)),X(e,()=>e.bindTexture(e.TEXTURE_2D,null)),{texture:o,texShape:[n,t]}}function ZP(e){return e.internalFormatFloat}function QP(e,t,n,r){let[i,a]=DM(t,n);return XP(e,i,a,ZP(r),r.textureFormatFloat,e.FLOAT)}function $P(e){return e.internalFormatHalfFloat}function eF(e,t,n,r){let[i,a]=DM(t,n);return XP(e,i,a,$P(r),r.textureFormatFloat,r.textureTypeHalfFloat)}function tF(e){return e.downloadTextureFormat}function nF(e,t,n,r){let[i,a]=DM(t,n);return XP(e,i,a,tF(r),e.RGBA,e.UNSIGNED_BYTE)}function rF(e){return e.internalFormatPackedFloat}function iF(e,t,n,r){let[i,a]=AM(t,n);return XP(e,i,a,rF(r),e.RGBA,e.FLOAT)}function aF(e){return e.internalFormatPackedHalfFloat}function oF(e,t,n,r){let[i,a]=AM(t,n);return XP(e,i,a,aF(r),e.RGBA,r.textureTypeHalfFloat)}function sF(e,t,n){return X(e,()=>e.bindBuffer(e.ARRAY_BUFFER,n)),$M(e,t,`clipSpacePos`,n,3,20,0)&&$M(e,t,`uv`,n,2,20,12)}function cF(e,t,n,r,i,a){X(e,()=>e.bindTexture(e.TEXTURE_2D,t));let o,s,c;i instanceof Uint8Array?(o=new Uint8Array(n*r*4),s=e.UNSIGNED_BYTE,c=e.RGBA):(o=new Float32Array(n*r*4),s=e.FLOAT,c=a.internalFormatPackedFloat),o.set(i),j().getNumber(`WEBGL_VERSION`)===2?X(e,()=>e.texSubImage2D(e.TEXTURE_2D,0,0,0,n,r,e.RGBA,s,o)):X(e,()=>e.texImage2D(e.TEXTURE_2D,0,c,n,r,0,e.RGBA,s,o)),X(e,()=>e.bindTexture(e.TEXTURE_2D,null))}function lF(e,t,n){X(e,()=>e.bindTexture(e.TEXTURE_2D,t)),n.data instanceof Uint8Array?j().getNumber(`WEBGL_VERSION`)===2?X(e,()=>e.texSubImage2D(e.TEXTURE_2D,0,0,0,n.width,n.height,e.RGBA,e.UNSIGNED_BYTE,n.data)):X(e,()=>e.texImage2D(e.TEXTURE_2D,0,e.RGBA,n.width,n.height,0,e.RGBA,e.UNSIGNED_BYTE,n.data)):j().getNumber(`WEBGL_VERSION`)===2?X(e,()=>e.texSubImage2D(e.TEXTURE_2D,0,0,0,e.RGBA,e.UNSIGNED_BYTE,n)):X(e,()=>e.texImage2D(e.TEXTURE_2D,0,e.RGBA,e.RGBA,e.UNSIGNED_BYTE,n)),X(e,()=>e.bindTexture(e.TEXTURE_2D,null))}function uF(e,t,n,r){let i=e.createBuffer();X(e,()=>e.bindBuffer(e.PIXEL_PACK_BUFFER,i));let a=16*t*n;return X(e,()=>e.bufferData(e.PIXEL_PACK_BUFFER,a,e.STREAM_READ)),X(e,()=>e.readPixels(0,0,n,t,e.RGBA,e.FLOAT,0)),X(e,()=>e.bindBuffer(e.PIXEL_PACK_BUFFER,null)),i}function dF(e,t,n){let r=e,i=new Float32Array(n);return r.bindBuffer(r.PIXEL_PACK_BUFFER,t),r.getBufferSubData(r.PIXEL_PACK_BUFFER,0,i),r.bindBuffer(r.PIXEL_PACK_BUFFER,null),i}function fF(e,t,n,r){let[i,a]=DM(t,n),o=new Uint8Array(OM(t*n,4));return X(e,()=>e.readPixels(0,0,i,a,r.downloadTextureFormat,e.UNSIGNED_BYTE,o)),new Float32Array(o.buffer)}function pF(e,t,n,r,i,a,o,s){let c=e,l=new Float32Array(jM(a,o));return c.bindBuffer(c.PIXEL_PACK_BUFFER,t),c.getBufferSubData(c.PIXEL_PACK_BUFFER,0,l),c.bindBuffer(c.PIXEL_PACK_BUFFER,null),l}function mF(e,t,n){let r=new Float32Array(t*n*4);return X(e,()=>e.readPixels(0,0,n,t,e.RGBA,e.FLOAT,r)),r}var hF=class{constructor(e){this.outputTexture=null,this.program=null,this.disposed=!1,this.itemsToPoll=[];let t=j().getNumber(`WEBGL_VERSION`);if(e==null?this.gl=xM(t):(this.gl=e,bM(t,e)),e=this.gl,j().getNumber(`WEBGL_VERSION`)===2){let t=e;this.createVertexArray=()=>X(t,()=>t.createVertexArray()),this.bindVertexArray=e=>X(t,()=>t.bindVertexArray(e)),this.deleteVertexArray=e=>X(t,()=>t.deleteVertexArray(e)),this.getVertexArray=()=>X(t,()=>t.getParameter(t.VERTEX_ARRAY_BINDING))}else if(e!=null){let t=e.getExtension(`OES_vertex_array_object`);if(t==null)throw Error(`All WebGL1 implementations are expected to offer OES_vertex_array_object.`);this.createVertexArray=()=>X(e,()=>t.createVertexArrayOES()),this.bindVertexArray=n=>X(e,()=>t.bindVertexArrayOES(n)),this.deleteVertexArray=n=>X(e,()=>t.deleteVertexArrayOES(n)),this.getVertexArray=()=>X(e,()=>e.getParameter(t.VERTEX_ARRAY_BINDING_OES))}let n=`WEBGL_color_buffer_float`,r=`EXT_color_buffer_half_float`;if(this.parallelCompilationExtension=this.gl.getExtension(`KHR_parallel_shader_compile`),j().getNumber(`WEBGL_VERSION`)===1){let e=`OES_texture_half_float`;if(this.textureFloatExtension=zM(this.gl,`OES_texture_float`),TN(this.gl,e))this.textureHalfFloatExtension=zM(this.gl,e);else if(j().get(`WEBGL_FORCE_F16_TEXTURES`))throw Error(`GL context does not support half float textures, yet the environment flag WEBGL_FORCE_F16_TEXTURES is set to true.`);if(this.colorBufferFloatExtension=this.gl.getExtension(n),TN(this.gl,r))this.colorBufferHalfFloatExtension=zM(this.gl,r);else if(j().get(`WEBGL_FORCE_F16_TEXTURES`))throw Error(`GL context does not support color renderable half floats, yet the environment flag WEBGL_FORCE_F16_TEXTURES is set to true.`)}else if(n=`EXT_color_buffer_float`,TN(this.gl,n))this.colorBufferFloatExtension=this.gl.getExtension(n);else if(TN(this.gl,r))this.colorBufferHalfFloatExtension=this.gl.getExtension(r);else throw Error(`GL context does not support color renderable floats`);this.vertexBuffer=JP(this.gl),this.indexBuffer=YP(this.gl),this.framebuffer=QM(this.gl),this.textureConfig=MM(this.gl,this.textureHalfFloatExtension)}get debug(){return j().getBool(`DEBUG`)}dispose(){if(this.disposed)return;this.program!=null&&console.warn(`Disposing a GPGPUContext that still has a bound WebGLProgram. This is probably a resource leak, delete the program with GPGPUContext.deleteProgram before disposing.`),this.outputTexture!=null&&console.warn(`Disposing a GPGPUContext that still has a bound output matrix texture.  This is probably a resource leak, delete the output matrix texture with GPGPUContext.deleteMatrixTexture before disposing.`);let e=this.gl;X(e,()=>e.finish()),X(e,()=>e.bindFramebuffer(e.FRAMEBUFFER,null)),X(e,()=>e.deleteFramebuffer(this.framebuffer)),X(e,()=>e.bindBuffer(e.ARRAY_BUFFER,null)),X(e,()=>e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,null)),X(e,()=>e.deleteBuffer(this.indexBuffer)),this.disposed=!0}createFloat32MatrixTexture(e,t){return this.throwIfDisposed(),QP(this.gl,e,t,this.textureConfig)}createFloat16MatrixTexture(e,t){return this.throwIfDisposed(),eF(this.gl,e,t,this.textureConfig)}createUnsignedBytesMatrixTexture(e,t){return this.throwIfDisposed(),nF(this.gl,e,t,this.textureConfig)}uploadPixelDataToTexture(e,t){this.throwIfDisposed(),lF(this.gl,e,t)}uploadDenseMatrixToTexture(e,t,n,r){this.throwIfDisposed(),cF(this.gl,e,t,n,r,this.textureConfig)}createFloat16PackedMatrixTexture(e,t){return this.throwIfDisposed(),oF(this.gl,e,t,this.textureConfig)}createPackedMatrixTexture(e,t){return this.throwIfDisposed(),iF(this.gl,e,t,this.textureConfig)}deleteMatrixTexture(e){this.throwIfDisposed(),this.outputTexture===e&&(sN(this.gl,this.framebuffer),this.outputTexture=null),X(this.gl,()=>this.gl.deleteTexture(e))}downloadByteEncodedFloatMatrixFromOutputTexture(e,t,n){return this.downloadMatrixDriver(e,()=>fF(this.gl,t,n,this.textureConfig))}downloadPackedMatrixFromBuffer(e,t,n,r,i,a){return pF(this.gl,e,t,n,r,i,a,this.textureConfig)}downloadFloat32MatrixFromBuffer(e,t){return dF(this.gl,e,t)}createBufferFromTexture(e,t,n){this.bindTextureToFrameBuffer(e);let r=uF(this.gl,t,n,this.textureConfig);return this.unbindTextureToFrameBuffer(),r}createAndWaitForFence(){let e=this.createFence(this.gl);return this.pollFence(e)}createFence(e){let t,n;if(j().getBool(`WEBGL_FENCE_API_ENABLED`)){let r=e,i=r.fenceSync(r.SYNC_GPU_COMMANDS_COMPLETE,0);e.flush(),n=()=>{let e=r.clientWaitSync(i,0,0);return e===r.ALREADY_SIGNALED||e===r.CONDITION_SATISFIED},t=i}else j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`)>0?(t=this.beginQuery(),this.endQuery(),n=()=>this.isQueryAvailable(t,j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`))):n=()=>!0;return{query:t,isFencePassed:n}}downloadMatrixFromPackedTexture(e,t,n){return this.downloadMatrixDriver(e,()=>mF(this.gl,t,n))}createProgram(e){this.throwIfDisposed();let t=this.gl;this.vertexShader??=qP(t);let n=WM(t);X(t,()=>t.attachShader(n,this.vertexShader)),X(t,()=>t.attachShader(n,e)),GM(t,n);let r=Object.assign(n,{vao:this.createVertexArray()});return this.debug&&KM(t,r),r}buildVao(e){this.setProgram(e),this.bindVertexArray(e.vao);let t=this.gl;X(t,()=>t.bindBuffer(t.ELEMENT_ARRAY_BUFFER,this.indexBuffer)),sF(t,e,this.vertexBuffer)}deleteProgram(e){this.throwIfDisposed(),e===this.program&&(this.program=null),e!=null&&(X(this.gl,()=>this.gl.deleteProgram(e)),this.deleteVertexArray(e.vao))}setProgram(e){this.throwIfDisposed(),this.program=e,this.program!=null&&this.debug&&KM(this.gl,this.program),X(this.gl,()=>this.gl.useProgram(e))}getUniformLocation(e,t,n=!0){return this.throwIfDisposed(),n?nN(this.gl,e,t):rN(this.gl,e,t)}getAttributeLocation(e,t){return this.throwIfDisposed(),X(this.gl,()=>this.gl.getAttribLocation(e,t))}getUniformLocationNoThrow(e,t){return this.throwIfDisposed(),this.gl.getUniformLocation(e,t)}setInputMatrixTexture(e,t,n){this.throwIfDisposed(),this.throwIfNoProgram(),iN(this.gl,e,t,n)}setOutputMatrixTexture(e,t,n){this.setOutputMatrixTextureDriver(e,n,t)}setOutputPackedMatrixTexture(e,t,n){this.throwIfDisposed();let[r,i]=AM(t,n);this.setOutputMatrixTextureDriver(e,r,i)}setOutputMatrixWriteRegion(e,t,n,r){this.setOutputMatrixWriteRegionDriver(n,e,r,t)}setOutputPackedMatrixWriteRegion(e,t,n,r){throw Error(`setOutputPackedMatrixWriteRegion not implemented.`)}debugValidate(){this.program!=null&&KM(this.gl,this.program),cN(this.gl)}executeProgram(){this.throwIfDisposed(),this.throwIfNoProgram();let e=this.gl;if(this.debug){let e=this.getVertexArray();console.assert(e===this.program.vao,`VAO changed between setProgram and executeProgram!`),this.debugValidate()}X(e,()=>e.drawElements(e.TRIANGLES,6,e.UNSIGNED_SHORT,0))}blockUntilAllProgramsCompleted(){this.throwIfDisposed(),X(this.gl,()=>this.gl.finish())}getQueryTimerExtension(){return this.disjointQueryTimerExtension??=zM(this.gl,j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`)===2?`EXT_disjoint_timer_query_webgl2`:`EXT_disjoint_timer_query`),this.disjointQueryTimerExtension}getQueryTimerExtensionWebGL2(){return this.getQueryTimerExtension()}getQueryTimerExtensionWebGL1(){return this.getQueryTimerExtension()}beginQuery(){if(j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`)===2){let e=this.gl,t=this.getQueryTimerExtensionWebGL2(),n=e.createQuery();return e.beginQuery(t.TIME_ELAPSED_EXT,n),n}let e=this.getQueryTimerExtensionWebGL1(),t=e.createQueryEXT();return e.beginQueryEXT(e.TIME_ELAPSED_EXT,t),t}endQuery(){if(j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`)===2){let e=this.gl,t=this.getQueryTimerExtensionWebGL2();e.endQuery(t.TIME_ELAPSED_EXT);return}let e=this.getQueryTimerExtensionWebGL1();e.endQueryEXT(e.TIME_ELAPSED_EXT)}async waitForQueryAndGetTime(e){return await yr(()=>this.disposed||this.isQueryAvailable(e,j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`))),this.getQueryTime(e,j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_VERSION`))}getQueryTime(e,t){if(t===0)return null;if(t===2){let t=this.gl;return t.getQueryParameter(e,t.QUERY_RESULT)/1e6}else{let t=this.getQueryTimerExtensionWebGL1();return t.getQueryObjectEXT(e,t.QUERY_RESULT_EXT)/1e6}}isQueryAvailable(e,t){if(t===0)return!0;if(t===2){let t=this.gl,n=this.getQueryTimerExtensionWebGL2(),r=t.getQueryParameter(e,t.QUERY_RESULT_AVAILABLE);return this.disjoint??=this.gl.getParameter(n.GPU_DISJOINT_EXT),r&&!this.disjoint}else{let t=this.getQueryTimerExtensionWebGL1(),n=t.getQueryObjectEXT(e,t.QUERY_RESULT_AVAILABLE_EXT);return this.disjoint??=this.gl.getParameter(t.GPU_DISJOINT_EXT),n&&!this.disjoint}}pollFence(e){return new Promise(t=>{this.addItemToPoll(()=>e.isFencePassed(),()=>t())})}pollItems(){let e=gF(this.itemsToPoll.map(e=>e.isDoneFn));for(let t=0;t<=e;++t){let{resolveFn:e}=this.itemsToPoll[t];e()}this.itemsToPoll=this.itemsToPoll.slice(e+1)}addItemToPoll(e,t){if(this.itemsToPoll.push({isDoneFn:e,resolveFn:t}),this.itemsToPoll.length>1)return;let n;`setTimeoutCustom`in j().platform&&(n=j().platform.setTimeoutCustom.bind(j().platform)),yr(()=>(this.pollItems(),this.itemsToPoll.length===0),()=>0,null,n)}bindTextureToFrameBuffer(e){this.throwIfDisposed(),oN(this.gl,e,this.framebuffer),this.debug&&cN(this.gl)}unbindTextureToFrameBuffer(){this.outputTexture==null?sN(this.gl,this.framebuffer):(oN(this.gl,this.outputTexture,this.framebuffer),this.debug&&cN(this.gl))}downloadMatrixDriver(e,t){this.bindTextureToFrameBuffer(e);let n=t();return this.unbindTextureToFrameBuffer(),n}setOutputMatrixTextureDriver(e,t,n){this.throwIfDisposed();let r=this.gl;oN(r,e,this.framebuffer),this.debug&&cN(r),this.outputTexture=e,X(r,()=>r.viewport(0,0,t,n)),X(r,()=>r.scissor(0,0,t,n))}setOutputMatrixWriteRegionDriver(e,t,n,r){this.throwIfDisposed(),X(this.gl,()=>this.gl.scissor(e,t,n,r))}throwIfDisposed(){if(this.disposed)throw Error(`Attempted to use disposed GPGPUContext.`)}throwIfNoProgram(){if(this.program==null)throw Error(`No GPU program is currently set.`)}};function gF(e){let t=0;for(;t<e.length&&e[t]();++t);return t-1}var{addImpl:_F,bincountImpl:vF,bincountReduceImpl:yF,bitwiseAndImpl:bF,castImpl:xF,ceilImpl:SF,concatImpl:CF,equalImpl:wF,expImpl:TF,expm1Impl:EF,floorImpl:DF,gatherNdImpl:OF,gatherV2Impl:kF,greaterImpl:AF,greaterEqualImpl:jF,lessImpl:MF,lessEqualImpl:NF,linSpaceImpl:PF,logImpl:FF,maxImpl:IF,maximumImpl:LF,minimumImpl:RF,multiplyImpl:zF,negImpl:BF,notEqualImpl:VF,prodImpl:HF,raggedGatherImpl:UF,raggedRangeImpl:WF,raggedTensorToTensorImpl:GF,rangeImpl:KF,rsqrtImpl:qF,scatterImpl:JF,sigmoidImpl:YF,simpleAbsImpl:XF,sliceImpl:ZF,sparseFillEmptyRowsImpl:QF,sparseReshapeImpl:$F,sparseSegmentReductionImpl:eI,sqrtImpl:tI,staticRegexReplaceImpl:nI,stridedSliceImpl:rI,stringNGramsImpl:iI,stringSplitImpl:aI,stringToHashBucketFastImpl:oI,subImpl:sI,tileImpl:cI,topKImpl:lI,transposeImpl:uI,uniqueImpl:dI}=cD;function fI(e,t){return[`x`,`y`,`z`,`w`,`u`,`v`].slice(0,t).map(t=>`${e}.${t}`)}function pI(e,t){return t===1?[e]:fI(e,t)}function mI(e,t){if(e===1)return`rc`;let n=``;for(let r=0;r<e;r++)n+=t[r],r<e-1&&(n+=`,`);return n}var hI=class{constructor(e){if(this.variableNames=[`A`],this.packedInputs=!1,this.packedOutput=!0,this.outputShape=e,this.rank=e.length,this.enableShapeUniforms=RP(this.outputShape.length),this.rank===0)this.userCode=`
        void main() {
          setOutput(vec4(getA(), 0., 0., 0.));
        }
      `;else{let e=pI(`rc`,this.rank),t=kP(this.rank),n=this.getOutOfBoundsCondition(e),r=this.getSetup(e),i=this.getOutput(e);this.userCode=`
        void main() {
          ${t} rc = getOutputCoords();

          if(${n}) {
            setOutput(vec4(0));
          } else {
            ${r}

            setOutput(vec4(${i}));
          }
        }
      `}}getSourceCoordsArr(e){let t=[];for(let n=0;n<=1;n++)for(let r=0;r<=1;r++){let i=`${n===0?`r`:`rp1`}, ${r===0?`c`:`cp1`}`;for(let t=2;t<this.rank;t++)i=`${e[e.length-1-t]},`+i;t.push(i)}return t}getOutOfBoundsCondition(e){if(this.rank===1)return`rc > ${this.enableShapeUniforms?`outShape`:this.outputShape[0]}`;let t=``;for(let n=this.rank-2;n<this.rank;n++)t+=`${e[n]} >= ${this.enableShapeUniforms?`outShape[${n}]`:this.outputShape[n]}`,n<this.rank-1&&(t+=`||`);return t}getSetup(e){if(this.rank===1)return``;let t=e.slice(-2),n=this.enableShapeUniforms?`outShape[${this.rank} - 1]`:this.outputShape[this.rank-1],r=this.enableShapeUniforms?`outShape[${this.rank} - 2]`:this.outputShape[this.rank-2];return`
      int r = ${t[0]};
      int c = ${t[1]};
      int rp1 = r + 1;
      int cp1 = c + 1;

      bool cEdge = cp1 >= ${n};
      bool rEdge = rp1 >= ${r};
    `}getOutput(e){let t=this.getSourceCoordsArr(e);return this.rank===1?`getA(rc), (rc + 1 >= ${this.enableShapeUniforms?`outShape`:this.outputShape[0]} ? 0. : getA(rc + 1)), 0, 0`:`getA(${t[0]}),
            cEdge ? 0. : getA(${t[1]}),
            rEdge ? 0. : getA(${t[2]}),
            rEdge || cEdge ? 0. : getA(${t[3]})`}},gI=class{constructor(e,t){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`inputShape`,type:`ivec3`}],this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length);let n=``;for(let e=0;e<4;e++){let t=`thisRC = rc;`;e%2==1&&(t+=`thisRC.z += 1;`),e>1&&(t+=`thisRC.y += 1;`),n+=`
        ${t}
        ${e>0?`if(thisRC.y < rows && thisRC.z < cols){`:``}
          int flatIndex = getFlatIndex(thisRC);

          ivec3 inputRC = inputCoordsFromReshapedOutCoords(flatIndex);
          vec2 inputRCInnerDims = vec2(float(inputRC.y),float(inputRC.z));

          result[${e}] =
            getChannel(getA(inputRC.x, inputRC.y, inputRC.z), inputRCInnerDims);
        ${e>0?`}`:``}
      `}this.userCode=`
      ${_I(t,this.enableShapeUniforms)}
      ${this.enableShapeUniforms?zN():RN(e)}

      void main() {
        ivec3 rc = getOutputCoords();

        vec4 result = vec4(0.);

        ivec3 thisRC;
        int rows = ${this.enableShapeUniforms?`outShape[1]`:e[1]};
        int cols = ${this.enableShapeUniforms?`outShape[2]`:e[2]};

        ${n}

        setOutput(result);
      }
    `}};function _I(e,t){return`
    ivec3 inputCoordsFromReshapedOutCoords(int index) {
      ${t?LN([`r`,`c`,`d`],`inputShape`):PN([`r`,`c`,`d`],e)}
      return ivec3(r, c, d);
    }
  `}var vI=class{constructor(e){this.gpgpu=e,this.numUsedTextures=0,this.numFreeTextures=0,this._numBytesAllocated=0,this._numBytesFree=0,this.freeTextures={},this.usedTextures={},this.logEnabled=!1}acquireTexture(e,t,n){let r=CI(t,n),i=wI(e,r,n);i in this.freeTextures||(this.freeTextures[i]=[]),i in this.usedTextures||(this.usedTextures[i]=[]);let a=bI(e,r,this.gpgpu.gl,this.gpgpu.textureConfig,n);if(this.freeTextures[i].length>0){this.numFreeTextures--,this.numUsedTextures++,this._numBytesFree-=a,this.log();let e=this.freeTextures[i].pop();return this.usedTextures[i].push(e),e}let o;return r===EM.PACKED_2X2_FLOAT32?o=this.gpgpu.createPackedMatrixTexture(e[0],e[1]):r===EM.PACKED_2X2_FLOAT16?o=this.gpgpu.createFloat16PackedMatrixTexture(e[0],e[1]):r===EM.UNPACKED_FLOAT32?o=this.gpgpu.createFloat32MatrixTexture(e[0],e[1]):r===EM.UNPACKED_FLOAT16?o=this.gpgpu.createFloat16MatrixTexture(e[0],e[1]):r===EM.PACKED_4X1_UNSIGNED_BYTE&&(o=this.gpgpu.createUnsignedBytesMatrixTexture(e[0],e[1])),this.usedTextures[i].push(o),this.numUsedTextures++,this._numBytesAllocated+=a,this.log(),o}releaseTexture(e,t,n,r){if(this.freeTextures==null)return;let i=CI(n,r),a=wI(t,i,r);a in this.freeTextures||(this.freeTextures[a]=[]);let o=bI(t,i,this.gpgpu.gl,this.gpgpu.textureConfig,r),s=j().getNumber(`WEBGL_DELETE_TEXTURE_THRESHOLD`);s!==-1&&this._numBytesAllocated>s?(this.gpgpu.deleteMatrixTexture(e.texture),this._numBytesAllocated-=o):(this.freeTextures[a].push(e),this.numFreeTextures++,this._numBytesFree+=o),this.numUsedTextures--;let c=this.usedTextures[a],l=c&&c.indexOf(e);if(l==null||l<0)throw Error(`Cannot release a texture that was never provided by this texture manager`);c[l]=c[c.length-1],c.pop(),this.log()}log(){if(!this.logEnabled)return;let e=this.numFreeTextures+this.numUsedTextures;console.log(`Free/Used`,`${this.numFreeTextures} / ${this.numUsedTextures}`,`(${e})`);let t=this._numBytesFree/this._numBytesAllocated;console.log(`Bytes allocated: ${this._numBytesAllocated}`),console.log(`Bytes unused: ${this._numBytesFree} (${Math.round(100*t)}%)`)}get numBytesAllocated(){return this._numBytesAllocated}get numBytesFree(){return this._numBytesFree}getNumUsedTextures(){return this.numUsedTextures}getNumFreeTextures(){return this.numFreeTextures}dispose(){if(this.freeTextures!=null){for(let e in this.freeTextures)this.freeTextures[e].forEach(e=>{this.gpgpu.deleteMatrixTexture(e.texture)});for(let e in this.usedTextures)this.usedTextures[e].forEach(e=>{this.gpgpu.deleteMatrixTexture(e.texture)});this.freeTextures=null,this.usedTextures=null,this.numUsedTextures=0,this.numFreeTextures=0,this._numBytesAllocated=0,this._numBytesFree=0}}};function yI(e,t){let n=e;if(t===n.R32F)return 4;if(t===n.R16F)return 2;if(t===n.RGBA32F||t===e.RGBA)return 16;if(t===n.RGBA16F)return 8;if(t===n.RGBA8)return 4;throw Error(`Unknown internal format ${t}`)}function bI(e,t,n,r,i){let a=xI(t,r),o;if(i){let[t,n]=AM(e[0],e[1]);o=t*n}else{let[t,n]=DM(e[0],e[1]);o=t*n}let s=yI(n,a);return o*s}function xI(e,t){switch(e){case EM.PACKED_2X2_FLOAT32:return rF(t);case EM.PACKED_2X2_FLOAT16:return aF(t);case EM.UNPACKED_FLOAT32:return ZP(t);case EM.UNPACKED_FLOAT16:return $P(t);case EM.PACKED_4X1_UNSIGNED_BYTE:return tF(t);default:throw Error(`Unknown physical texture type ${e}`)}}function SI(e){return j().getBool(`WEBGL_RENDER_FLOAT32_ENABLED`)?e?EM.PACKED_2X2_FLOAT32:EM.UNPACKED_FLOAT32:e?EM.PACKED_2X2_FLOAT16:EM.UNPACKED_FLOAT16}function CI(e,t){if(e===TM.UPLOAD)return EM.PACKED_2X2_FLOAT32;if(e===TM.RENDER||e==null)return SI(t);if(e===TM.DOWNLOAD||e===TM.PIXELS)return EM.PACKED_4X1_UNSIGNED_BYTE;throw Error(`Unknown logical texture type ${e}`)}function wI(e,t,n){return`${e[0]}_${e[1]}_${t}_${n}`}var TI=class{constructor(e,t){this.variableNames=[`A`],this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length),this.userCode=`
      float unaryOperation(float x) {
        ${t}
      }

      void main() {
        float x = getAAtOutCoords();
        float y = unaryOperation(x);

        setOutput(y);
      }
    `}},EI=`if (isnan(x)) return x;`,DI=`return x;`,OI=`return abs(x);`,kI=`return (x >= 0.0) ? x : (exp(x) - 1.0);`,AI=EI+`
  return (x < 0.0) ? 0.0 : x;
`,jI=EI+`
  return (x < 0.0) ? 0.0 : min(6.0, x);
`,MI=`return x;`,NI=`return 1.0 / (1.0 + exp(-1.0 * x));`,PI=`return x;`,FI=`
  vec4 result;

  result.r = (x.r >= 0.0) ? x.r : (exp(x.r) - 1.0);
  result.g = (x.g >= 0.0) ? x.g : (exp(x.g) - 1.0);
  result.b = (x.b >= 0.0) ? x.b : (exp(x.b) - 1.0);
  result.a = (x.a >= 0.0) ? x.a : (exp(x.a) - 1.0);

  return result;
`,II=`
  vec4 result = x * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,LI=`
  vec4 result = min(x, vec4(6.)) * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,RI=`return 1.0 / (1.0 + exp(-1.0 * x));`,zI=class{constructor(e,t){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length),this.userCode=`
      vec4 unaryOperation(vec4 x) {
        ${t}
      }

      void main() {
        vec4 x = getAAtOutCoords();
        vec4 y = unaryOperation(x);

        setOutput(y);
      }
    `}},BI=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!1,this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length);let t=e.length,n=pI(`rc`,t),r=kP(t),i=mI(t,n),a=n.slice(-2),o=t<=1?`rc`:`vec2(${a.join(`,`)})`;this.userCode=`
      void main() {
        ${r} rc = getOutputCoords();
        vec4 packedInput = getA(${i});

        setOutput(getChannel(packedInput, ${o}));
      }
    `}},VI=_c,HI=1e-7,UI=1e-4,WI={};function GI(e){return e in WI||(WI[e]={}),WI[e]}var KI=j().getNumber(`CPU_HANDOFF_SIZE_THRESHOLD`),qI=600;function JI(){return j().global.screen==null?1024:j().global.screen.height*j().global.screen.width*window.devicePixelRatio*qI/1024/1024}var YI=class e extends dn{nextDataId(){return e.nextDataId++}constructor(e){if(super(),this.pendingRead=new WeakMap,this.pendingDisposal=new WeakSet,this.dataRefCount=new WeakMap,this.numBytesInGPU=0,this.uploadWaitMs=0,this.downloadWaitMs=0,this.lastGlFlushTime=0,this.warnedAboutMemory=!1,this.pendingDeletes=0,this.disposed=!1,!j().getBool(`HAS_WEBGL`))throw Error(`WebGL is not supported on this device`);let t;e==null?(t=new hF(xM(j().getNumber(`WEBGL_VERSION`))),this.binaryCache=GI(j().getNumber(`WEBGL_VERSION`)),this.gpgpuCreatedLocally=!0):(t=e instanceof hF?e:new hF(xM(j().getNumber(`WEBGL_VERSION`),e)),this.binaryCache={},this.gpgpuCreatedLocally=!1),this.gpgpu=t,this.canvas=this.gpgpu.gl.canvas,this.textureManager=new vI(this.gpgpu),this.numMBBeforeWarning=JI(),this.texData=new Vo(this,Mo())}numDataIds(){return this.texData.numDataIds()-this.pendingDeletes}writeTexture(e,t,n,r,i,a){let o=this.makeTensorInfo(t,n),s=this.texData.get(o.dataId);s.isPacked=!1,s.texture={texture:e,texShape:[r,i]},s.texShape=[r,i];let c=new WP(mN(t),!1,a),l=this.runWebGLProgram(c,[o],n,[[r,i]]);return l.shape=t,s.texture=null,this.disposeIntermediateTensorInfo(o),l.dataId}write(e,t,n){if((j().getBool(`WEBGL_CHECK_NUMERICAL_PROBLEMS`)||j().getBool(`DEBUG`))&&this.checkNumericalProblems(e),n===`complex64`&&e!=null)throw Error(`Cannot write to a complex64 dtype. Please use tf.complex(real, imag).`);let r={id:this.nextDataId()};return this.texData.set(r,{shape:t,dtype:n,values:e,usage:TM.UPLOAD,refCount:1}),r}refCount(e){return this.texData.has(e)?this.texData.get(e).refCount:0}incRef(e){let t=this.texData.get(e);t.refCount++}decRef(e){if(this.texData.has(e)){let t=this.texData.get(e);t.refCount--}}move(e,t,n,r,i){if(j().getBool(`DEBUG`)&&this.checkNumericalProblems(t),r===`complex64`)throw Error(`Cannot write to a complex64 dtype. Please use tf.complex(real, imag).`);this.texData.set(e,{shape:n,dtype:r,values:t,usage:TM.UPLOAD,refCount:i})}disposeIntermediateTensorInfo(e){this.disposeData(e.dataId)}readSync(e){let{values:t,dtype:n,complexTensorInfos:r,slice:i,shape:a,isPacked:o}=this.texData.get(e);if(i!=null){let t;t=o?new zI(a,MI):new TI(a,MI);let r=this.runWebGLProgram(t,[{dataId:e,shape:a,dtype:n}],n),i=this.readSync(r.dataId);return this.disposeIntermediateTensorInfo(r),i}if(t!=null)return this.convertAndCacheOnCPU(e);if(n===`string`)return t;let s=this.activeTimers!=null,c;s&&(c=Ri());let l;return l=n===`complex64`?od(this.readSync(r.real.dataId),this.readSync(r.imag.dataId)):this.getValuesFromTexture(e),s&&(this.downloadWaitMs+=Ri()-c),this.convertAndCacheOnCPU(e,l)}async read(e){if(this.pendingRead.has(e)){let t=this.pendingRead.get(e);return new Promise(e=>t.push(e))}let{values:t,shape:n,slice:r,dtype:i,complexTensorInfos:a,isPacked:o}=this.texData.get(e);if(r!=null){let t;t=o?new zI(n,MI):new TI(n,MI);let r=this.runWebGLProgram(t,[{dataId:e,shape:n,dtype:i}],i),a=this.read(r.dataId);return this.disposeIntermediateTensorInfo(r),a}if(t!=null)return this.convertAndCacheOnCPU(e);if(j().getBool(`DEBUG`)&&!j().getBool(`WEBGL_DOWNLOAD_FLOAT_ENABLED`)&&j().getNumber(`WEBGL_VERSION`)===2)throw Error(`tensor.data() with WEBGL_DOWNLOAD_FLOAT_ENABLED=false and WEBGL_VERSION=2 not yet supported.`);let s=null,c;if(i!==`complex64`&&j().get(`WEBGL_BUFFER_SUPPORTED`)){c=this.decode(e);let t=this.texData.get(c.dataId);s=this.gpgpu.createBufferFromTexture(t.texture.texture,...kM(n))}this.pendingRead.set(e,[]),i!==`complex64`&&await this.gpgpu.createAndWaitForFence();let l;if(i===`complex64`){let e=await Promise.all([this.read(a.real.dataId),this.read(a.imag.dataId)]),t=e[0],n=e[1];l=od(t,n)}else if(s==null)l=this.getValuesFromTexture(e);else{let e=k(n);l=this.gpgpu.downloadFloat32MatrixFromBuffer(s,e)}if(c!=null&&this.disposeIntermediateTensorInfo(c),s!=null){let e=this.gpgpu.gl;X(e,()=>e.deleteBuffer(s))}let u=this.convertAndCacheOnCPU(e,l),d=this.pendingRead.get(e);return this.pendingRead.delete(e),d.forEach(e=>e(u)),this.pendingDisposal.has(e)&&(this.pendingDisposal.delete(e),this.disposeData(e)&&Mo().removeDataId(e,this),this.pendingDeletes--),u}readToGPU(e,t={}){let{values:n,shape:r,slice:i,dtype:a,isPacked:o,texture:s}=this.texData.get(e);if(a===`complex64`)throw Error(`Does not support reading texture for complex64 dtype.`);if(i!=null){let n;n=o?new zI(r,MI):new TI(r,MI);let i=this.runWebGLProgram(n,[{dataId:e,shape:r,dtype:a}],a),s=this.readToGPU(i,t);return this.disposeIntermediateTensorInfo(i),s}if(s==null)throw Error(n==null?`There is no data on GPU or CPU.`:`Data is not on GPU but on CPU.`);let c=this.decode(e,t.customTexShape),l=Mo().makeTensorFromTensorInfo(c),u=this.texData.get(c.dataId);return Object.assign({tensorRef:l},u.texture)}bufferSync(e){let t=this.readSync(e.dataId);if(e.dtype===`string`)try{let n=t.map(e=>qa(e));return M(e.shape,e.dtype,n)}catch{throw Error(`Failed to decode encoded string bytes into utf-8`)}return M(e.shape,e.dtype,t)}checkNumericalProblems(e){if(e!=null)for(let t=0;t<e.length;t++){let n=e[t];if(!LM(n))throw j().getBool(`WEBGL_RENDER_FLOAT32_CAPABLE`)?Error(`The value ${n} cannot be represented with your current settings. Consider enabling float32 rendering: 'tf.env().set('WEBGL_RENDER_FLOAT32_ENABLED', true);'`):Error(`The value ${n} cannot be represented on this device.`)}}getValuesFromTexture(e){let{shape:t,dtype:n,isPacked:r}=this.texData.get(e),i=k(t);if(j().getBool(`WEBGL_DOWNLOAD_FLOAT_ENABLED`)){let n=this.decode(e),r=this.texData.get(n.dataId),a=this.gpgpu.downloadMatrixFromPackedTexture(r.texture.texture,...kM(t)).subarray(0,i);return this.disposeIntermediateTensorInfo(n),a}let a=j().getBool(`WEBGL_PACK`)&&r===!0,o=a?mN(t):t,s=a?new HP(o):new VP(o),c=this.runWebGLProgram(s,[{shape:o,dtype:n,dataId:e}],`float32`),l=this.texData.get(c.dataId),u=this.gpgpu.downloadByteEncodedFloatMatrixFromOutputTexture(l.texture.texture,l.texShape[0],l.texShape[1]).subarray(0,i);return this.disposeIntermediateTensorInfo(c),u}timerAvailable(){return j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`)>0}time(e){let t=this.activeTimers,n=[],r=!1;this.programTimersStack==null?(this.programTimersStack=n,r=!0):this.activeTimers.push(n),this.activeTimers=n,e();let i=ho(this.activeTimers.map(e=>e.query)).filter(e=>e!=null),a=ho(this.activeTimers.map(e=>e.name)).filter(e=>e!=null);this.activeTimers=t,r&&(this.programTimersStack=null);let o={uploadWaitMs:this.uploadWaitMs,downloadWaitMs:this.downloadWaitMs,kernelMs:null,wallMs:null};return(async()=>{if(j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`)>0){let e=await Promise.all(i);o.kernelMs=Mn(e),o.getExtraProfileInfo=()=>e.map((e,t)=>({name:a[t],ms:e})).map(e=>`${e.name}: ${e.ms}`).join(`, `)}else o.kernelMs={error:`WebGL query timers are not supported in this environment.`};return this.uploadWaitMs=0,this.downloadWaitMs=0,o})()}memory(){return{unreliable:!1,numBytesInGPU:this.numBytesInGPU,numBytesInGPUAllocated:this.textureManager.numBytesAllocated,numBytesInGPUFree:this.textureManager.numBytesFree}}startTimer(){return j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`)>0?this.gpgpu.beginQuery():{startMs:Ri(),endMs:null}}endTimer(e){return j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`)>0?(this.gpgpu.endQuery(),e):(e.endMs=Ri(),e)}async getQueryTime(e){if(j().getNumber(`WEBGL_DISJOINT_QUERY_TIMER_EXTENSION_RELIABLE`)>0)return this.gpgpu.waitForQueryAndGetTime(e);let t=e;return t.endMs-t.startMs}disposeData(e,t=!1){if(this.pendingDisposal.has(e))return!1;if(!this.texData.has(e))return!0;if(t?this.texData.get(e).refCount=0:this.texData.get(e).refCount--,!t&&this.texData.get(e).refCount>0)return!1;if(this.pendingRead.has(e))return this.pendingDisposal.add(e),this.pendingDeletes++,!1;this.releaseGPUData(e);let{complexTensorInfos:n}=this.texData.get(e);return n!=null&&(this.disposeData(n.real.dataId,t),this.disposeData(n.imag.dataId,t)),this.texData.delete(e),!0}releaseGPUData(e){let{texture:t,dtype:n,texShape:r,usage:i,isPacked:a,slice:o}=this.texData.get(e),s=o&&o.origDataId||e,c=this.dataRefCount.get(s);c>1?this.dataRefCount.set(s,c-1):(this.dataRefCount.delete(s),t!=null&&(this.numBytesInGPU-=this.computeBytes(r,n),this.textureManager.releaseTexture(t,r,i,a)));let l=this.texData.get(e);l.texture=null,l.texShape=null,l.isPacked=!1,l.slice=null}getTexture(e){return this.uploadToGPU(e),this.texData.get(e).texture.texture}getDataInfo(e){return this.texData.get(e)}shouldExecuteOnCPU(e,t=KI){return j().getBool(`WEBGL_CPU_FORWARD`)&&e.every(e=>this.texData.get(e.dataId).texture==null&&k(e.shape)<t)}getGPGPUContext(){return this.gpgpu}where(e){v(`tf.where() in webgl locks the UI thread. Call tf.whereAsync() instead`);let t=e.dataSync();return VI(e.shape,t)}packedUnaryOp(e,t,n){let r=new zI(e.shape,t),i=this.compileAndRun(r,[e],n);return Mo().makeTensorFromTensorInfo(i)}abs(e){if(this.shouldExecuteOnCPU([e])&&e.dtype!==`complex64`){let t=XF(this.texData.get(e.dataId).values);return this.makeOutput(e.shape,e.dtype,t)}if(j().getBool(`WEBGL_PACK_UNARY_OPERATIONS`))return this.packedUnaryOp(e,OI,e.dtype);let t=new TI(e.shape,OI),n=this.compileAndRun(t,[e]);return Mo().makeTensorFromTensorInfo(n)}makeTensorInfo(e,t,n){let r;if(t===`string`&&n!=null&&n.length>0&&bs(n[0])){let i=n.map(e=>Js(e));r=this.write(i,e,t)}else r=this.write(n,e,t);return this.texData.get(r).usage=null,{dataId:r,shape:e,dtype:t}}makeOutput(e,t,n){return Mo().makeTensorFromTensorInfo(this.makeTensorInfo(e,t,n),this)}unpackTensor(e){let t=new BI(e.shape);return this.runWebGLProgram(t,[e],e.dtype)}packTensor(e){let t=new hI(e.shape);return this.runWebGLProgram(t,[e],e.dtype,null,!0)}packedReshape(e,t){let n=[fN(e.shape),...pN(e.shape)],r={dtype:e.dtype,shape:n,dataId:e.dataId},i=new gI([fN(t),...pN(t)],n),a=[n],o=this.runWebGLProgram(i,[r],e.dtype,a,!0);return{dataId:o.dataId,shape:t,dtype:o.dtype}}decode(e,t){let{isPacked:n,shape:r,dtype:i}=this.texData.get(e);t!=null&&o(k(r)<=t[0]*t[1]*4,()=>`customTexShape is too small. Row * Column * 4 should be equal or larger than the size of the tensor data.`);let a=mN(r),s;s=n?new BP(a):new zP(a);let c=[t??kM(a)];return{dtype:i,shape:r,dataId:this.runWebGLProgram(s,[{shape:a,dtype:i,dataId:e}],i,c,!0,t).dataId}}runWebGLProgram(e,t,n,r,i=!1,a){let o=this.makeTensorInfo(e.outputShape,n),s=this.texData.get(o.dataId);if(e.packedOutput&&(s.isPacked=!0),e.outPackingScheme===wM.DENSE&&(s.texShape=(a??kM(e.outputShape)).map(e=>e*2)),e.outTexUsage!=null&&(s.usage=e.outTexUsage),k(o.shape)===0)return s.values=Hs(o.dtype,0),o;let c=[],l=t.map(t=>{if(t.dtype===`complex64`)throw Error(`GPGPUProgram does not support complex64 input. For complex64 dtypes, please separate the program into real and imaginary parts.`);let n=this.texData.get(t.dataId);if(n.texture==null){if(!e.packedInputs&&k(t.shape)<=j().getNumber(`WEBGL_SIZE_UPLOAD_UNIFORM`))return{shape:t.shape,texData:null,isUniform:!0,uniformValues:n.values};e.packedInputs&&(n.isPacked=!0,n.shape=t.shape)}if(this.uploadToGPU(t.dataId),!!n.isPacked!=!!e.packedInputs)t=n.isPacked?this.unpackTensor(t):this.packTensor(t),c.push(t),n=this.texData.get(t.dataId);else if(n.isPacked&&!_N(n.shape,t.shape)){let e=t,r=t.shape;t.shape=n.shape,t=this.packedReshape(t,r),c.push(t),n=this.texData.get(t.dataId),e.shape=r}return{shape:t.shape,texData:n,isUniform:!1}});this.uploadToGPU(o.dataId);let u={shape:o.shape,texData:s,isUniform:!1},d=LP(e,l,u),f=this.getAndSaveBinary(d,()=>NP(this.gpgpu,e,l,u)),p=this.activeTimers!=null,m;p&&(m=this.startTimer()),j().get(`ENGINE_COMPILE_ONLY`)||IP(this.gpgpu,f,l,u,r),c.forEach(e=>this.disposeIntermediateTensorInfo(e)),p&&(m=this.endTimer(m),this.activeTimers.push({name:e.constructor.name,query:this.getQueryTime(m)}));let h=j().getNumber(`WEBGL_FLUSH_THRESHOLD`);if(h>0){let e=Ri();e-this.lastGlFlushTime>h&&(this.gpgpu.gl.flush(),this.lastGlFlushTime=e)}if(!j().getBool(`WEBGL_LAZILY_UNPACK`)&&s.isPacked&&i===!1){let e=this.unpackTensor(o);return this.disposeIntermediateTensorInfo(o),e}return o}compileAndRun(e,t,n,r,i=!1){return n||=t[0].dtype,this.runWebGLProgram(e,t,n,r,i)}getAndSaveBinary(e,t){return e in this.binaryCache||(this.binaryCache[e]=t()),this.binaryCache[e]}getTextureManager(){return this.textureManager}dispose(){this.disposed||=(j().getBool(`IS_TEST`)||Object.keys(this.binaryCache).forEach(e=>{this.gpgpu.deleteProgram(this.binaryCache[e].webGLProgram),delete this.binaryCache[e]}),this.textureManager.dispose(),this.canvas!=null&&typeof HTMLCanvasElement<`u`&&this.canvas instanceof HTMLCanvasElement?this.canvas.remove():this.canvas=null,this.gpgpuCreatedLocally&&(this.gpgpu.program=null,this.gpgpu.dispose()),!0)}floatPrecision(){return this.floatPrecisionValue??=A(()=>{if(!j().get(`WEBGL_RENDER_FLOAT32_ENABLED`)){let e=j().getBool(`DEBUG`);j().set(`DEBUG`,!1);let t=this.abs(kn(1e-8)).dataSync()[0];if(j().set(`DEBUG`,e),t>0)return 32}return 16}),this.floatPrecisionValue}epsilon(){return this.floatPrecision()===32?HI:UI}uploadToGPU(e){let t=this.texData.get(e),{shape:n,dtype:r,values:i,texture:a,usage:o,isPacked:s}=t;if(a!=null)return;let c=this.activeTimers!=null,l;c&&(l=Ri());let u=t.texShape;if(u??(u=hN(n,s),t.texShape=u),i!=null){let e=mN(n),a,o=u[1],d=u[0],f=i instanceof Uint8Array||i instanceof Uint8ClampedArray;(s||!f)&&([o,d]=AM(u[0],u[1])),a=s?new GP(e,f):new WP(e,f);let p=f?[d,o]:u,m=this.makeTensorInfo(p,r),h=this.texData.get(m.dataId);f?h.usage=TM.PIXELS:h.usage=TM.UPLOAD,h.texShape=p,this.gpgpu.uploadDenseMatrixToTexture(this.getTexture(m.dataId),o,d,i);let g=[[d,o]],_=this.runWebGLProgram(a,[m],r,g,!0),v=this.texData.get(_.dataId);t.texShape=v.texShape,t.isPacked=v.isPacked,t.usage=v.usage,j().get(`ENGINE_COMPILE_ONLY`)?this.disposeData(_.dataId):(t.texture=v.texture,t.values=null,this.texData.delete(_.dataId)),this.disposeIntermediateTensorInfo(m),c&&(this.uploadWaitMs+=Ri()-l)}else t.texture=this.acquireTexture(u,o,r,s)}convertAndCacheOnCPU(e,t){let n=this.texData.get(e),{dtype:r}=n;return t!=null&&(n.values=XI(t,r)),n.values}acquireTexture(e,t,n,r){if(this.numBytesInGPU+=this.computeBytes(e,n),!this.warnedAboutMemory&&this.numBytesInGPU>this.numMBBeforeWarning*1024*1024){let e=(this.numBytesInGPU/1024/1024).toFixed(2);this.warnedAboutMemory=!0,console.warn(`High memory usage in GPU: ${e} MB, most likely due to a memory leak`)}return this.textureManager.acquireTexture(e,t,r)}computeBytes(e,t){return e[0]*e[1]*zc(t)}checkCompileCompletion(){for(let[,e]of Object.entries(this.binaryCache))this.checkCompletion_(e)}async checkCompileCompletionAsync(){let e=[];if(this.gpgpu.parallelCompilationExtension){for(let[,t]of Object.entries(this.binaryCache))e.push(this.checkCompletionAsync_(t));return Promise.all(e)}else{for(let[,t]of Object.entries(this.binaryCache)){let n=new Promise(e=>{try{this.checkCompletion_(t),e(!0)}catch(e){throw e}});e.push(n)}return Promise.all(e)}}async checkCompletionAsync_(e){return this.gpgpu.gl.getProgramParameter(e.webGLProgram,this.gpgpu.parallelCompilationExtension.COMPLETION_STATUS_KHR)?this.checkCompletion_(e):(await Lu(),this.checkCompletionAsync_(e))}checkCompletion_(e){if(this.gpgpu.gl.getProgramParameter(e.webGLProgram,this.gpgpu.gl.LINK_STATUS)===!1)throw console.log(this.gpgpu.gl.getProgramInfoLog(e.webGLProgram)),this.gpgpu.gl.getShaderParameter(e.fragmentShader,this.gpgpu.gl.COMPILE_STATUS)===!1?(UM(e.source,this.gpgpu.gl.getShaderInfoLog(e.fragmentShader)),Error(`Failed to compile fragment shader.`)):Error(`Failed to link vertex and fragment shaders.`);return!0}getUniformLocations(){for(let e of Object.values(this.binaryCache)){this.gpgpu.buildVao(e.webGLProgram);let{variablesLocations:t,customUniformLocations:n,infLoc:r,nanLoc:i,outShapeLocation:a,outShapeStridesLocation:o,outTexShapeLocation:s}=PP(this.gpgpu,e.program,e.webGLProgram);e.variablesLocations=t,e.customUniformLocations=n,e.infLoc=r,e.nanLoc=i,e.outShapeLocation=a,e.outShapeStridesLocation=o,e.outTexShapeLocation=s}}createTensorFromGPUData(e,t,n){e.channels=e.channels||`RGBA`;let{texture:r,height:i,width:a,channels:o}=e,s=Mo().backend;if(!s.gpgpu.gl.isTexture(r))throw Error(`The texture is invalid. Also, please make sure the texture and the TFJS WebGL backend are using the same canvas. If you want to use your own custom canvas, you have to create and use the custom TFJS WebGL backend created from the canvas through 'new tf.MathBackendWebGL(customCanvas)'.`);let c=s.writeTexture(r,t,n,i,a,o);return Mo().makeTensorFromDataId(c,t,n,s)}};YI.nextDataId=0;function XI(e,t){if(t===`float32`||t===`complex64`)return e;if(t===`int32`||t===`bool`){let n=t===`int32`?new Int32Array(e.length):new Uint8Array(e.length);for(let t=0;t<n.length;++t)n[t]=Math.round(e[t]);return n}else throw Error(`Unknown dtype ${t}`)}var ZI=`4.22.0`;function QI(){j().set(`WEBGL_FORCE_F16_TEXTURES`,!0)}Wn()&&Rl(`webgl`,()=>new YI,2);var $I={forceHalfFloat:QI},eL=`
  if (isnan(a)) return a;
  if (isnan(b)) return b;
`,tL=class{constructor(e,t,n){this.variableNames=[`A`,`B`],this.outputShape=xi(t,n),this.enableShapeUniforms=RP(this.outputShape.length),this.userCode=`
      float binaryOperation(float a, float b) {
        ${e}
      }

      void main() {
        float a = getAAtOutCoords();
        float b = getBAtOutCoords();
        setOutput(binaryOperation(a, b));
      }
    `}},nL=`
  result.r = isNaN.r ? NAN : result.r;
  result.g = isNaN.g ? NAN : result.g;
  result.b = isNaN.b ? NAN : result.b;
  result.a = isNaN.a ? NAN : result.a;
`,rL=class{constructor(e,t,n,r=!1){this.variableNames=[`A`,`B`],this.supportsBroadcasting=!0,this.packedInputs=!0,this.packedOutput=!0,this.outputShape=xi(t,n);let i=this.outputShape.length;this.enableShapeUniforms=RP(i);let a=``;if(r)if(i===0||k(this.outputShape)===1)a=`
          result.y = 0.;
          result.z = 0.;
          result.w = 0.;
        `;else if(a=`
          ${kP(i)} coords = getOutputCoords();
        `,i===1)this.enableShapeUniforms?a+=`
            result.y = (coords + 1) >= outShape ? 0. : result.y;
            result.z = 0.;
            result.w = 0.;
          `:a+=`
            result.y = (coords + 1) >= ${this.outputShape[0]} ? 0. : result.y;
            result.z = 0.;
            result.w = 0.;
          `;else{let e=pI(`coords`,i);this.enableShapeUniforms?a+=`
            bool nextRowOutOfBounds =
              (${e[i-2]} + 1) >= outShape[${i} - 2];
            bool nextColOutOfBounds =
              (${e[i-1]} + 1) >= outShape[${i} - 1];
            result.y = nextColOutOfBounds ? 0. : result.y;
            result.z = nextRowOutOfBounds ? 0. : result.z;
            result.w = nextColOutOfBounds || nextRowOutOfBounds ? 0. : result.w;
          `:a+=`
            bool nextRowOutOfBounds =
              (${e[i-2]} + 1) >= ${this.outputShape[i-2]};
            bool nextColOutOfBounds =
              (${e[i-1]} + 1) >= ${this.outputShape[i-1]};
            result.y = nextColOutOfBounds ? 0. : result.y;
            result.z = nextRowOutOfBounds ? 0. : result.z;
            result.w = nextColOutOfBounds || nextRowOutOfBounds ? 0. : result.w;
          `}this.userCode=`
      vec4 binaryOperation(vec4 a, vec4 b) {
        ${e}
      }

      void main() {
        vec4 a = getAAtOutCoords();
        vec4 b = getBAtOutCoords();

        vec4 result = binaryOperation(a, b);
        ${a}

        setOutput(result);
      }
    `}};function iL(e){let{inputs:t,backend:n}=e,{x:r}=t;return n.incRef(r.dataId),{dataId:r.dataId,shape:r.shape,dtype:r.dtype}}var aL={kernelName:fi,backendName:`webgl`,kernelFunc:iL};function oL(e){let{inputs:t,backend:n}=e,{real:r,imag:i}=t,a=n.makeTensorInfo(r.shape,`complex64`),o=n.texData.get(a.dataId);return o.complexTensorInfos={real:iL({inputs:{x:r},backend:n}),imag:iL({inputs:{x:i},backend:n})},a}var sL={kernelName:Oo,backendName:`webgl`,kernelFunc:oL},cL=`return (a < 0.) ? b * a : a;`,lL=`
  vec4 aLessThanZero = vec4(lessThan(a, vec4(0.)));
  return (aLessThanZero * (b * a)) + ((vec4(1.0) - aLessThanZero) * a);
`;function uL(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{alpha:a}=r,o=n.makeTensorInfo([],`float32`,Da(a,`float32`)),s=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`)?new rL(lL,i.shape,o.shape):new tL(cL,i.shape,o.shape),c=n.runWebGLProgram(s,[i,o],`float32`);return n.disposeIntermediateTensorInfo(o),c}var dL={kernelName:uc,backendName:`webgl`,kernelFunc:uL},fL=`return (a < 0.) ? b * a : a;`,pL=`
  vec4 aLessThanZero = vec4(lessThan(a, vec4(0.)));
  return (aLessThanZero * (b * a)) + ((vec4(1.0) - aLessThanZero) * a);
`;function mL(e){let{inputs:t,backend:n}=e,{x:r,alpha:i}=t,a=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`)?new rL(pL,r.shape,i.shape):new tL(fL,r.shape,i.shape);return n.runWebGLProgram(a,[r,i],`float32`)}var hL={kernelName:Br,backendName:`webgl`,kernelFunc:mL},gL=`if (isnan(x)) return x;`;function Q({opSnippet:e,packedOpSnippet:t,cpuKernelImpl:n,dtype:r}){return({inputs:i,backend:a})=>{let{x:o}=i,s=a,c=r||o.dtype;if(s.shouldExecuteOnCPU([o])&&n!=null){let e=n(s.texData.get(o.dataId).values,c);return s.makeTensorInfo(o.shape,c,e)}let l=j().getBool(`WEBGL_PACK_UNARY_OPERATIONS`)&&t!=null,u;return u=l?new zI(o.shape,t):new TI(o.shape,e),s.runWebGLProgram(u,[o],c)}}function _L({opSnippet:e,packedOpSnippet:t,checkOutOfBounds:n=!1,supportsComplex:r=!1,cpuKernelImpl:i,dtype:a}){return({inputs:o,backend:s})=>{let{a:c,b:l}=o,u=s;if(r&&c.dtype===`complex64`){let t=u.texData.get(c.dataId),n=u.texData.get(l.dataId),[r,i]=[[t.complexTensorInfos.real,n.complexTensorInfos.real],[t.complexTensorInfos.imag,n.complexTensorInfos.imag]].map(t=>{let[n,r]=t,i={dataId:n.dataId,dtype:n.dtype,shape:c.shape},a={dataId:r.dataId,dtype:r.dtype,shape:l.shape},o=new tL(e,c.shape,l.shape);return u.runWebGLProgram(o,[i,a],Rs(n.dtype,r.dtype))}),a=oL({inputs:{real:r,imag:i},backend:u});return u.disposeIntermediateTensorInfo(r),u.disposeIntermediateTensorInfo(i),a}let d=a||Rs(c.dtype,l.dtype);if((c.dtype===`string`||l.dtype===`string`||u.shouldExecuteOnCPU([c,l]))&&i!=null){let e=u.texData.get(c.dataId).values,t=u.texData.get(l.dataId).values,n=c.dtype===`string`?Hd(e):e,r=c.dtype===`string`?Hd(t):t,[a,o]=i(c.shape,l.shape,n,r,d),s=u.makeTensorInfo(o,d),f=u.texData.get(s.dataId);return f.values=a,s}let f=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`)&&t!=null,p;return p=f?new rL(t,c.shape,l.shape,n):new tL(e,c.shape,l.shape),u.runWebGLProgram(p,[c,l],d)}}function vL(e,t=!1){if(e===`linear`)return t?PI:DI;if(e===`relu`)return t?II:AI;if(e===`elu`)return t?FI:kI;if(e===`relu6`)return t?LI:jI;if(e===`prelu`)return t?pL:fL;if(e===`leakyrelu`)return t?lL:cL;if(e===`sigmoid`)return t?RI:NI;throw Error(`Activation ${e} has not been implemented for the WebGL backend.`)}var yL=class{constructor(e,t,n,r=!1,i=!1,a=!1,o=null,s=!1,c=!1){this.variableNames=[`matrixA`,`matrixB`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=n,this.enableShapeUniforms=RP(this.outputShape.length);let l=r?e[1]:e[2],u=Math.ceil(l/2),d=r?`i * 2, rc.y`:`rc.y, i * 2`,f=i?`rc.z, i * 2`:`i * 2, rc.z`,p=r?[`a.xxyy`,`a.zzww`]:[`a.xxzz`,`a.yyww`],m=i?[`b.xzxz`,`b.ywyw`]:[`b.xyxy`,`b.zwzw`],h=``,g=``;o&&(h=s?`vec4 activation(vec4 a) {
          vec4 b = getPreluActivationWeightsAtOutCoords();
          ${o}
        }`:c?`vec4 activation(vec4 a) {
          vec4 b = getLeakyreluAlphaAtOutCoords();
          ${o}
        }`:`vec4 activation(vec4 x) {
          ${o}
        }`,g=`result = activation(result);`);let _=a?`result += getBiasAtOutCoords();`:``;a&&this.variableNames.push(`bias`),s&&this.variableNames.push(`preluActivationWeights`),c&&this.variableNames.push(`leakyreluAlpha`);let v=`rc.x`,y=`rc.x`;e[0]<t[0]?v=`imod(rc.x, ${e[0]})`:t[0]<e[0]&&(y=`imod(rc.x, ${t[0]})`),this.userCode=`
      ${h}
      // Don't use uniform for sharedDimensionPacked for performance.
      const float sharedDimension = ${u}.0;

      vec4 dot2x2ARowBCol(ivec3 rc) {
        vec4 result = vec4(0);
        int batchA = ${v};
        int batchB = ${y};
        for (int i = 0; i < ${u}; i++) {
          vec4 a = getMatrixA(batchA, ${d});
          vec4 b = getMatrixB(batchB, ${f});

          // These swizzled products need to be separately added.
          // See: https://github.com/tensorflow/tfjs/issues/1735
          result += (${p[0]} * ${m[0]});
          result += (${p[1]} * ${m[1]});
        }
        return result;
      }

      void main() {
        ivec3 rc = getOutputCoords();
        vec4 result = dot2x2ARowBCol(rc);

        ${_}

        ${g}

        setOutput(result);
      }
    `}},bL={REAL:`return areal * breal - aimag * bimag;`,IMAG:`return areal * bimag + aimag * breal;`},xL=class{constructor(e,t,n){this.variableNames=[`AReal`,`AImag`,`BReal`,`BImag`],this.outputShape=xi(t,n),this.userCode=`
      float binaryOpComplex(
          float areal, float aimag, float breal, float bimag) {
        ${e}
      }

      void main() {
        float areal = getARealAtOutCoords();
        float aimag = getAImagAtOutCoords();
        float breal = getBRealAtOutCoords();
        float bimag = getBImagAtOutCoords();
        setOutput(binaryOpComplex(areal, aimag, breal, bimag));
      }
    `}},SL=`return a * b;`;function CL(e){let{inputs:t,backend:n}=e,{a:r,b:i}=t,a=Rs(r.dtype,i.dtype);if(r.dtype===`complex64`){let e=n.texData.get(r.dataId),t=n.texData.get(i.dataId),a=new xL(bL.REAL,r.shape,i.shape),o=new xL(bL.IMAG,r.shape,i.shape),s=[{dataId:e.complexTensorInfos.real.dataId,dtype:e.complexTensorInfos.real.dtype,shape:r.shape},{dataId:e.complexTensorInfos.imag.dataId,dtype:e.complexTensorInfos.imag.dtype,shape:r.shape},{dataId:t.complexTensorInfos.real.dataId,dtype:t.complexTensorInfos.real.dtype,shape:i.shape},{dataId:t.complexTensorInfos.imag.dataId,dtype:t.complexTensorInfos.imag.dtype,shape:i.shape}],c=n.runWebGLProgram(a,s,`float32`),l=n.runWebGLProgram(o,s,`float32`),u=oL({inputs:{real:c,imag:l},backend:n});return n.disposeIntermediateTensorInfo(c),n.disposeIntermediateTensorInfo(l),u}if(n.shouldExecuteOnCPU([r,i])){let e=n.texData.get(r.dataId),t=n.texData.get(i.dataId),[o,s]=zF(r.shape,i.shape,e.values,t.values,a),c=n.makeTensorInfo(s,a),l=n.texData.get(c.dataId);return l.values=o,c}let o;return o=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`)?new rL(SL,r.shape,i.shape):new tL(SL,r.shape,i.shape),n.runWebGLProgram(o,[r,i],a)}var wL={kernelName:Wo,backendName:`webgl`,kernelFunc:CL};function TL(e,t,n){let r=[fN(e.shape),...pN(e.shape)],i={dtype:e.dtype,shape:r,dataId:e.dataId},a=new gI([fN(t),...pN(t)],r),o=[r],s=n.runWebGLProgram(a,[i],e.dtype,o,!0);return{dataId:s.dataId,shape:t,dtype:s.dtype}}function $(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{shape:a}=r,s=n,c=k(i.shape),l=Jc(a,c),u=k(l);o(c===u,()=>`The new shape (${l}) has ${u} elements and the old shape (${i.shape}) has ${c} elements. The new shape and old shape must have the same number of elements.`);let d=s.texData.get(i.dataId);return d.isPacked&&!_N(i.shape,l)&&!(d.texture!==null&&_N(d.shape,l))?TL(i,l,s):(s.incRef(i.dataId),{dataId:i.dataId,shape:l,dtype:i.dtype})}var EL={kernelName:Gn,backendName:`webgl`,kernelFunc:$},DL=class{constructor(e,t){this.variableNames=[`x`];let{windowSize:n,batchSize:r,inSize:i,outSize:a}=e;this.outputShape=[r,a];let o=Math.floor(n/4)*4,s=n%4,c=`sumValue += dot(values, ones);`;if(t!=null){let e=1/t;c=`sumValue += dot(values * ${ja(e)?e.toPrecision(2):e}, ones);`}let l=``;i%n>0&&(l=`
        if (inIdx < 0 || inIdx >= ${i}) {
          return 0.0;
        }
      `),this.userCode=`
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float getValue(int batch, int inIdx) {
        ${l}
        return getX(batch, inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${n};

        float sumValue = 0.0;

        for (int i = 0; i < ${o}; i += 4) {
          int inIdx = inOffset + i;
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          ${c}
        }

        int inIdx = inOffset + ${o};
        if (${s===1}) {
          vec4 values = vec4(getValue(batch, inIdx), 0.0, 0.0, 0.0);

          ${c}
        } else if (${s===2}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1), 0.0, 0.0);

          ${c}
        } else if (${s===3}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2), 0.0);

          ${c}
        }
        setOutput(sumValue);
      }
    `}},OL=class{constructor(e,t){this.variableNames=[`x`];let{windowSize:n,batchSize:r,inSize:i,outSize:a}=e;this.outputShape=[r,a];let o=`0.0`,s=``;t===`prod`?o=`1.0`:t===`min`?(o=`1.0 / 1e-20`,s=`min`):t===`max`&&(o=`-1.0 / 1e-20`,s=`max`);let c=`${t}(${t}(${t}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;t===`sum`?c=`sumValue`:t===`prod`?c=`prodValue`:t===`all`?c=`allValue`:t===`any`&&(c=`anyValue`);let l=Math.floor(n/4)*4,u=n%4,d=`
      if (${t===`sum`}) {
        sumValue += dot(values, ones);
      } else if (${t===`prod`}) {
        vec2 tmp = vec2(values[0], values[1]) * vec2(values[2], values[3]);
        prodValue *= tmp[0] * tmp[1];
      } else {
        minMaxValue = ${s}(values, minMaxValue);
        if (${t===`min`} || ${t===`max`}) {
          minMaxValue = ${s}(values, minMaxValue);
          bvec4 isNaN = isnan(values);
          if (isNaN.r || isNaN.g || isNaN.b || isNaN.a) {
            minMaxValue = vec4(NAN);
          }
        }
      }
    `,f=`vec4`;t===`all`?(o=`1.0`,d=`
        bool reducedAllValue = all(values);
        float floatedReducedAllValue = float(reducedAllValue);
        allValue = float(allValue >= 1.0 && floatedReducedAllValue >= 1.0);
      `,f=`bvec4`):t===`any`&&(o=`0.0`,d=`
        bool reducedAnyValue = any(values);
        float floatedReducedAnyValue = float(reducedAnyValue);
        anyValue = float(anyValue >= 1.0 || floatedReducedAnyValue >= 1.0);
      `,f=`bvec4`);let p=``;i%n>0&&(p=`
        if (inIdx < 0 || inIdx >= ${i}) {
          return initializationValue;
        }
      `),this.userCode=`
      const float initializationValue = ${o};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float getValue(int batch, int inIdx) {
        ${p}
        return getX(batch, inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${n};

        vec4 minMaxValue = vec4(${o});
        float prodValue = 1.0;
        float sumValue = 0.0;
        float allValue = 1.0;
        float anyValue = 0.0;

        for (int i = 0; i < ${l}; i += 4) {
          int inIdx = inOffset + i;
          ${f} values = ${f}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          ${d}
        }

        int inIdx = inOffset + ${l};
        if (${u===1}) {
          ${f} values = ${f}(
            getValue(batch, inIdx),
            initializationValue,
            initializationValue,
            initializationValue
          );

          ${d}
        } else if (${u===2}) {
          ${f} values = ${f}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            initializationValue,
            initializationValue
          );

          ${d}
        } else if (${u===3}) {
          ${f} values = ${f}(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            initializationValue
          );

          ${d}
        }
        setOutput(${c});
      }
    `}};function kL(e){let t=[];for(;t.length===0||t[t.length-1].outSize!==1;){let n=t.length?t[t.length-1].outSize:e[1],r=Gu(n);t.push({inSize:n,windowSize:r,outSize:Math.ceil(n/r)})}return t}function AL(e,t,n,r){let i=kL(e.shape),a=e;for(let o=0;o<i.length;o++){let{inSize:s,windowSize:c,outSize:l}=i[o],u,d;u=n===`mean`?o===0?new DL({windowSize:c,inSize:s,batchSize:e.shape[0],outSize:l},s):new DL({windowSize:c,inSize:s,batchSize:e.shape[0],outSize:l}):new OL({windowSize:c,inSize:s,batchSize:e.shape[0],outSize:l},n),d=a,a=r.runWebGLProgram(u,[a],t),d.dataId!==e.dataId&&r.disposeIntermediateTensorInfo(d)}return a}var jL=class{constructor(e,t){this.variableNames=[`A`];let n=Array(e.length);for(let r=0;r<n.length;r++)n[r]=e[t[r]];this.outputShape=n,this.rank=n.length;let r=kP(this.rank),i=ML(t);this.userCode=`
    void main() {
      ${r} resRC = getOutputCoords();
      setOutput(getA(${i}));
    }
    `}};function ML(e){let t=e.length;if(t>6)throw Error(`Transpose for rank ${t} is not yet supported`);let n=[`resRC.x`,`resRC.y`,`resRC.z`,`resRC.w`,`resRC.u`,`resRC.v`],r=Array(t);for(let t=0;t<e.length;t++)r[e[t]]=n[t];return r.join()}var NL=class{constructor(e,t){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0;let n=Array(e.length);for(let r=0;r<n.length;r++)n[r]=e[t[r]];if(this.outputShape=n,this.rank=n.length,this.rank>6)throw Error(`Packed transpose for rank ${this.rank} is not yet supported.`);let r=kP(this.rank),i=fI(`rc`,this.rank),a=Array(this.rank);for(let e=0;e<t.length;e++)a[t[e]]=i[e];let o=`vec2(${a.slice(-2).join()})`,s=`++${i[this.rank-1]} < ${n[this.rank-1]}`,c=`getChannel(getA(${a.join()}), ${o})`;this.userCode=`
    void main() {
      ${r} rc = getOutputCoords();
      vec4 result = vec4(0.);
      result[0] = ${c};
      if(${s}) {
        result[1] = ${c};
      }
      --${i[this.rank-1]};
      if(++${i[this.rank-2]} < ${n[this.rank-2]}) {
        result[2] = ${c};
        if(${s}) {
          result[3] = ${c};
        }
      }
      setOutput(result);
    }
    `}};function PL(e,t,n){let r=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)?new NL(e.shape,t):new jL(e.shape,t);return n.runWebGLProgram(r,[e],e.dtype)}function FL(e,t,n,r){let i=t,a=e.shape.length,o=H(i,e.shape),s=o,c=Zt(s,a),l=c!=null,u=e;l&&(u=PL(e,c,r),s=or(s.length,a)),cn(`sum`,s,a);let[d,f]=Ge(u.shape,s),p=d;n&&(p=xt(d,o));let m=k(f),h=k(e.shape)/m,g=$({inputs:{x:u},attrs:{shape:[h,m]},backend:r}),_=AL(g,Yi(e.dtype),`sum`,r),v=$({inputs:{x:_},attrs:{shape:p},backend:r});return r.disposeIntermediateTensorInfo(g),r.disposeIntermediateTensorInfo(_),l&&r.disposeIntermediateTensorInfo(u),v}function IL(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r;return FL(i,a,o,n)}var LL={kernelName:`Sum`,backendName:`webgl`,kernelFunc:IL};function RL(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{perm:a}=r,o=n,s=i.shape.length,c=Array(s);for(let e=0;e<c.length;e++)c[e]=i.shape[a[e]];let l;if(o.shouldExecuteOnCPU([i])){let e=o.texData.get(i.dataId).values,t=uI(e,i.shape,i.dtype,a,c);l=o.makeTensorInfo(c,i.dtype);let n=o.texData.get(l.dataId);n.values=t}else l=PL(i,a,o);return l}var zL={kernelName:ct,backendName:`webgl`,kernelFunc:RL};function BL({a:e,b:t,transposeA:n,transposeB:r,backend:i,bias:a=null,preluActivationWeights:s=null,leakyreluAlpha:c=0,activation:l=null}){let u=e.shape.length,d=t.shape.length,f=n?e.shape[u-2]:e.shape[u-1],p=r?t.shape[d-1]:t.shape[d-2],m=n?e.shape[u-1]:e.shape[u-2],h=r?t.shape[d-2]:t.shape[d-1],g=e.shape.slice(0,-2),_=t.shape.slice(0,-2),v=k(g),y=k(_),b=xi(e.shape.slice(0,-2),t.shape.slice(0,-2)).concat([m,h]);o(f===p,()=>`Error in matMul: inner shapes (${f}) and (${p}) of Tensors with shapes ${e.shape} and ${t.shape} and transposeA=${n} and transposeB=${r} must match.`);let x=n?[v,f,m]:[v,m,f],S=r?[y,h,p]:[y,p,h],C=$({inputs:{x:e},backend:i,attrs:{shape:x}}),w=$({inputs:{x:t},backend:i,attrs:{shape:S}}),T=[C,w],E=Math.max(v,y),ee=n?C.shape[1]:C.shape[2],te=a!=null,ne=s!=null,re=l===`leakyrelu`,ie=l==null?null:vL(l,!0),ae=te||ne||re||ie!=null,oe;if((m===1||h===1)&&ee>1e3&&ae===!1){let e=C,t=w;n&&(e=RL({inputs:{x:C},backend:i,attrs:{perm:[0,2,1]}}),T.push(e)),r&&(t=RL({inputs:{x:w},backend:i,attrs:{perm:[0,2,1]}}),T.push(t));let a=h!==1,o=h===1,s=e;a&&(s=$({inputs:{x:e},backend:i,attrs:{shape:[E,ee,1]}}),T.push(s));let c=h===1?2:1,l=t;o&&(l=$({inputs:{x:t},backend:i,attrs:{shape:[E,1,ee]}}),T.push(l));let u=CL({inputs:{a:s,b:l},backend:i});oe=IL({inputs:{x:u},backend:i,attrs:{axis:c,keepDims:!0}}),T.push(u)}else{let o=Rs(e.dtype,t.dtype),l=new yL(x,S,[E,m,h],n,r,te,ie,ne,re),u=[C,w];if(a!=null&&u.push(a),ne&&u.push(s),re){let e=i.makeTensorInfo([],`float32`,Da(c,`float32`));u.push(e),T.push(e)}oe=i.runWebGLProgram(l,u,o)}let se=$({inputs:{x:oe},backend:i,attrs:{shape:b}});T.push(oe);for(let e of T)i.disposeIntermediateTensorInfo(e);return se}function VL(e){let{inputs:t,backend:n,attrs:r}=e,{a:i,b:a,bias:o,preluActivationWeights:s}=t,{transposeA:c,transposeB:l,activation:u,leakyreluAlpha:d}=r;return BL({a:i,b:a,transposeA:c,transposeB:l,backend:n,bias:o,preluActivationWeights:s,leakyreluAlpha:d,activation:u})}var HL={kernelName:Ot,backendName:`webgl`,kernelFunc:VL},UL=`return abs(x);`;function WL(e){let{inputs:t,backend:n}=e,{x:r}=t;if(n.shouldExecuteOnCPU([r])&&r.dtype!==`complex64`){let e=XF(n.texData.get(r.dataId).values);return n.makeTensorInfo(r.shape,r.dtype,e)}let i;return i=j().getBool(`WEBGL_PACK_UNARY_OPERATIONS`)?new zI(r.shape,UL):new TI(r.shape,UL),n.runWebGLProgram(i,[r],r.dtype)}var GL={kernelName:`Abs`,backendName:`webgl`,kernelFunc:WL},KL={kernelName:sn,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  if (abs(x) > 1.) {
    return NAN;
  }
  return acos(x);
`})},qL={kernelName:vn,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  if (x < 1.0) return NAN;
return log(x + sqrt(x * x - 1.0));`})},JL=`return a + b;`,YL={kernelName:`Add`,backendName:`webgl`,kernelFunc:_L({opSnippet:JL,packedOpSnippet:JL,supportsComplex:!0,cpuKernelImpl:_F})},XL=class{constructor(e,t){this.outputShape=[],this.outputShape=e,this.variableNames=t.map((e,t)=>`T${t}`);let n=[];this.variableNames.forEach(e=>{n.push(`float v${e} = get${e}AtOutCoords();`)});let r=this.variableNames.map(e=>`v${e}`).join(` + `);this.userCode=`
      void main() {
        ${n.join(`
        `)}

        float result = ${r};
        setOutput(result);
      }
    `}},ZL=class{constructor(e,t){this.outputShape=[],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=e,this.variableNames=t.map((e,t)=>`T${t}`);let n=[];this.variableNames.forEach(e=>{n.push(`vec4 v${e} = get${e}AtOutCoords();`)});let r=this.variableNames.map(e=>`v${e}`).join(` + `);this.userCode=`
      void main() {
        ${n.join(`
        `)}

        vec4 result = ${r};
        setOutput(result);
      }
    `}};function QL(e){let{inputs:t,backend:n}=e,r=t;if(r.length===1)return iL({inputs:{x:r[0]},backend:n});if(r.length>j().getNumber(`WEBGL_MAX_TEXTURES_IN_SHADER`)){let e=Math.floor(r.length/2);return QL({inputs:[QL({inputs:r.slice(0,e),backend:n}),QL({inputs:r.slice(e),backend:n})],backend:n})}let i=r.map(e=>e.dtype).reduce((e,t)=>Rs(e,t)),a=r.map(e=>e.shape),o=j().getBool(`WEBGL_PACK`)?new ZL(r[0].shape,a):new XL(r[0].shape,a);return n.runWebGLProgram(o,r,i)}var $L={kernelName:We,backendName:`webgl`,kernelFunc:QL};function eR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r,s=i.shape.length,c=H(a,i.shape),l=c,u=Zt(l,s),d=i;u!=null&&(d=RL({inputs:{x:i},backend:n,attrs:{perm:u}}),l=or(l.length,s)),cn(`all`,l,s);let[f,p]=Ge(d.shape,l),m=k(p),h=$({inputs:{x:d},backend:n,attrs:{shape:[-1,m]}}),g=AL(h,h.dtype,`all`,n),_;if(o){let e=xt(f,c);_=$({inputs:{x:g},backend:n,attrs:{shape:e}})}else _=$({inputs:{x:g},backend:n,attrs:{shape:f}});return n.disposeIntermediateTensorInfo(h),n.disposeIntermediateTensorInfo(g),u!=null&&n.disposeIntermediateTensorInfo(d),_}var tR={kernelName:`All`,backendName:`webgl`,kernelFunc:eR};function nR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r,s=i.shape.length,c=H(a,i.shape),l=c,u=Zt(l,s),d=i;u!=null&&(d=RL({inputs:{x:i},backend:n,attrs:{perm:u}}),l=or(l.length,s)),cn(`any`,l,s);let[f,p]=Ge(d.shape,l),m=k(p),h=$({inputs:{x:d},backend:n,attrs:{shape:[-1,m]}}),g=AL(h,h.dtype,`any`,n),_;if(o){let e=xt(f,c);_=$({inputs:{x:g},backend:n,attrs:{shape:e}})}else _=$({inputs:{x:g},backend:n,attrs:{shape:f}});return n.disposeIntermediateTensorInfo(h),n.disposeIntermediateTensorInfo(g),u!=null&&n.disposeIntermediateTensorInfo(d),_}var rR={kernelName:`Any`,backendName:`webgl`,kernelFunc:nR},iR=class{constructor(e,t,n){this.variableNames=[`A`];let{windowSize:r,batchSize:i,outSize:a}=e;n||this.variableNames.push(`bestIndicesA`),this.outputShape=[i,a];let o=t===`max`?`>`:`<`,s=n?`inOffset + i;`:`round(getBestIndicesA(batch, inOffset + i));`;this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = outIdx * ${r};

        int bestIndex = inOffset;
        float bestValue = getA(batch, bestIndex);

        for (int i = 0; i < ${r}; i++) {
          int inIdx = ${s};
          float candidate = getA(batch, inIdx);
          if (candidate ${o} bestValue) {
            bestValue = candidate;
            bestIndex = inIdx;
          }
        }
        setOutput(float(bestIndex));
      }
    `}},aR=class{constructor(e,t,n,r){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,o(e.length>2,()=>`Packed arg${n.charAt(0).toUpperCase()+n.slice(1)} supports only inputs with rank above 2.`);let i=e[e.length-1],a=Math.ceil(i/t);this.outputShape=e.slice(0,-1),a>1&&this.outputShape.push(a),r||this.variableNames.push(`bestIndicesA`);let s=this.outputShape,c=s.length,l=kP(c),u=pI(`coords`,c),d,f;if(a===1){f=c+1;let e=kP(f);d=`
        ${e} sourceLocR = ${e}(${u.join()}, 0);
        ++${u[c-1]};
        ${e} sourceLocG = ${e}(${u.join()}, 0);
        ++${u[c-2]};
        ${e} sourceLocA = ${e}(${u.join()}, 0);
        --${u[c-1]};
        ${e} sourceLocB = ${e}(${u.join()}, 0);
        --${u[c-2]};`}else f=c,d=`
        ${l} sourceLocR = coords;
        ++${u[c-1]};
        ${l} sourceLocG = coords;
        ++${u[c-2]};
        ${l} sourceLocA = coords;
        --${u[c-1]};
        ${l} sourceLocB = coords;
        --${u[c-2]};`;let p=[`x`,`y`,`z`,`w`,`u`,`v`].slice(0,f),m=`.`+p[f-1],h=p.map(e=>`int `+e),g=pI(`sourceLocR`,f-1).concat(`inIdx.r`),_=pI(`sourceLocG`,f-1).concat(`inIdx.g`),v=pI(`sourceLocB`,f-1).concat(`inIdx.b`),y=pI(`sourceLocA`,f-1).concat(`inIdx.a`),b=n===`max`?`greaterThan`:`lessThan`,x=r?``:`
          inIdx = round(vec4(getBestIndicesAChannel(${g.join()}),
                             getBestIndicesAChannel(${_.join()}),
                             getBestIndicesAChannel(${v.join()}),
                             getBestIndicesAChannel(${y.join()})));`,S=`vec4(
            getAChannel(${g.join()}),
            hasNextCol ? getAChannel(${_.join()}) : 0.,
            hasNextRow ? getAChannel(${v.join()}) : 0.,
            hasNextRow && hasNextCol ? getAChannel(${y.join()}) : 0.)`,C=r?``:`
      float getBestIndicesAChannel(${h.join()}) {
        return getChannel(getBestIndicesA(${p.join()}),
                                          vec2(${p.slice(-2).join()}));
      }`;this.userCode=`
      float getAChannel(${h.join()}) {
        return getChannel(getA(${p.join()}),
                               vec2(${p.slice(-2).join()}));
      }
      ${C}
      void main() {
        ${l} coords = getOutputCoords();
        bool hasNextCol = ${u[c-1]} < ${s[c-1]-1};
        bool hasNextRow = ${u[c-2]} < ${s[c-2]-1};
        ${d}
        ivec4 srcIdx = ivec4(sourceLocR${m}, sourceLocG${m},
          sourceLocB${m}, sourceLocA${m}) * ${t};
        ivec4 inIdx = srcIdx;
        vec4 bestIndex = vec4(inIdx);
        vec4 bestValue = ${S};

        for (int i = 0; i < ${t}; i++) {
          inIdx = srcIdx;
          ${x}
          vec4 candidate = ${S};
          bvec4 nan = isnan(candidate);
          bvec4 replace = bvec4(
            vec4(${b}(candidate, bestValue)) * (vec4(1.0) - vec4(nan)));

          bestValue = vec4(replace.x  ? candidate.x : bestValue.x,
                           replace.y  ? candidate.y : bestValue.y,
                           replace.z  ? candidate.z : bestValue.z,
                           replace.w  ? candidate.w : bestValue.w);
          bestIndex = mix(bestIndex, vec4(inIdx), vec4(replace));
          srcIdx++;
        }
        setOutput(bestIndex);
      }
    `}};function oR(e,t,n,r=null){let i=t.shape[0],a=t.shape[1];r!=null&&(i=r.shape[0],a=r.shape[1]);let o=Gu(a),s=new iR({windowSize:o,inSize:a,batchSize:i,outSize:Math.ceil(a/o)},n,r==null),c=[t];r!=null&&c.push(r);let l=e.runWebGLProgram(s,c,`int32`);if(l.shape[1]===1)return l;let u=oR(e,t,n,l);return e.disposeIntermediateTensorInfo(l),u}function sR(e,t,n,r=null){let i=r==null?t.shape:r.shape,a=i[i.length-1],o=new aR(i,Gu(a),n,r==null),s=r==null?[t]:[t,r],c=e.runWebGLProgram(o,s,`int32`);if(c.shape.length===t.shape.length){let r=sR(e,t,n,c);return e.disposeIntermediateTensorInfo(c),r}return c}function cR(e,t,n,r){let i=[n];if(cn(`arg`+r.charAt(0).toUpperCase()+r.slice(1),i,t.shape.length),!j().getBool(`WEBGL_PACK_REDUCE`)||t.shape.length<=2){let n=[],a=e.texData.get(t.dataId),o=a!==null&&a.isPacked,s=t;o&&(s=e.unpackTensor(t),n.push(s));let[c,l]=Ge(s.shape,i),u=k(l),d=$({inputs:{x:s},backend:e,attrs:{shape:[-1,u]}});n.push(d);let f=oR(e,d,r);n.push(f);let p=$({inputs:{x:f},backend:e,attrs:{shape:c}});return n.forEach(t=>e.disposeIntermediateTensorInfo(t)),p}return sR(e,t,r)}function lR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a}=r,o=H(a,i.shape),s=Zt(o,i.shape.length),c=i,l=[];s!=null&&(c=RL({inputs:{x:i},backend:n,attrs:{perm:s}}),l.push(c),o=or(o.length,c.shape.length)),cn(`argMax`,[o[0]],c.shape.length);let u=cR(n,c,o[0],`max`);return l.forEach(e=>n.disposeIntermediateTensorInfo(e)),u}var uR={kernelName:ar,backendName:`webgl`,kernelFunc:lR};function dR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a}=r,o=H(a,i.shape),s=Zt(o,i.shape.length),c=i,l=[];s!=null&&(c=RL({inputs:{x:i},backend:n,attrs:{perm:s}}),l.push(c),o=or(o.length,c.shape.length)),cn(`argMin`,[o[0]],c.shape.length);let u=cR(n,c,o[0],`min`);return l.forEach(e=>n.disposeIntermediateTensorInfo(e)),u}var fR={kernelName:Hl,backendName:`webgl`,kernelFunc:dR},pR={kernelName:ne,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  if (abs(x) > 1.) {
    return NAN;
  }
  return asin(x);
`})},mR={kernelName:Wr,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`return log(x + sqrt(x * x + 1.0));`})},hR={kernelName:ut,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  return atan(x);
`})},gR={kernelName:Pr,backendName:`webgl`,kernelFunc:_L({opSnippet:eL+`
  return atan(a, b);
`,packedOpSnippet:`
  vec4 result = atan(a, b);
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+nL+`
  return result;
`})},_R={kernelName:ei,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  if ((x < -1.0) || (x > 1.0)) return NAN;
return (log(1.0 + x) - log(1.0 - x)) / 2.0;`})},vR=class{constructor(e,t,n,r=!1,i=!1){if(this.variableNames=[`x`],t===`avg`&&n)throw Error(`Cannot compute positions for average pool.`);let a=e.filterWidth,o=e.strideHeight,s=e.strideWidth,c=e.dilationHeight,l=e.dilationWidth,u=e.effectiveFilterHeight,d=e.effectiveFilterWidth,f=e.padInfo.top,p=e.padInfo.left;this.outputShape=e.outShape;let m=t===`avg`,h=`((batch  * ${e.inHeight} + xR) * ${e.inWidth} + xC) * ${e.inChannels} + d`,g=`(xR * ${e.inWidth} + xC) * ${e.inChannels} + d`,_=`0.0`;if(m||(_=`-1.0 / 1e-20`),n){this.userCode=`
        const ivec2 strides = ivec2(${o}, ${s});
        const ivec2 pads = ivec2(${f}, ${p});

        void main() {
          ivec4 coords = getOutputCoords();
          int batch = coords[0];
          int d = coords[3];

          ivec2 xRCCorner = coords.yz * strides - pads;
          int xRCorner = xRCCorner.x;
          int xCCorner = xRCCorner.y;

          // max/min x(?, ?, d) to get y(yR, yC, d).
          // ? = to be determined
          float minMaxValue = 0.0;
          float minMaxValueFound = 0.0;
          int minMaxPosition = 0;
          float avgValue = 0.0;

          for (int wR = 0; wR < ${u};
              wR += ${c}) {
            int xR = xRCorner + wR;

            if (xR < 0 || xR >= ${e.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${d};
                wC += ${l}) {
              int xC = xCCorner + wC;

              if (xC < 0 || xC >= ${e.inWidth}) {
                continue;
              }

              float value = getX(batch, xR, xC, d);

              // If a min / max value has already been found, use it. If not,
              // use the current value.
              float currMinMaxValue = mix(
                  value, minMaxValue, minMaxValueFound);
              if (value >= currMinMaxValue) {
                minMaxValue = value;
                minMaxValueFound = 1.0;
                minMaxPosition = ${r?i?h:g:`wR * ${d} + wC`};
              }
            }
          }
          setOutput(float(minMaxPosition));
        }
      `;return}let v=`${t}(${t}(${t}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;t===`avg`&&(v=`avgValue / max(count, 1.0)`);let y=Math.floor(a/4)*4,b=a%4,x=`
      if (${m}) {
        avgValue += dot(values, ones);
      } else {
        minMaxValue = max(values, minMaxValue);
      }
    `;this.userCode=`
      const ivec2 strides = ivec2(${o}, ${s});
      const ivec2 pads = ivec2(${f}, ${p});
      const float initializationValue = ${_};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float count = 0.0;

      float getValue(int batch, int xR, int xC, int d) {
        if (xC < 0 || xC >= ${e.inWidth}) {
          return initializationValue;
        }
        count += 1.0;
        return getX(batch, xR, xC, d);
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d = coords[3];

        ivec2 xRCCorner = coords.yz * strides - pads;
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // max/min x(?, ?, d) to get y(yR, yC, d).
        // ? = to be determined
        vec4 minMaxValue = vec4(${_});
        float avgValue = 0.0;
        count = 0.0;

        for (int wR = 0; wR < ${u};
            wR += ${c}) {
          int xR = xRCorner + wR;

          if (xR < 0 || xR >= ${e.inHeight}) {
            continue;
          }

          for (int wC = 0; wC < ${y}; wC += 4) {
            int xC = xCCorner + wC * ${l};

            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${l}, d),
              getValue(batch, xR, xC + 2 * ${l}, d),
              getValue(batch, xR, xC + 3 * ${l}, d)
            );

            ${x}
          }

          int xC = xCCorner + ${y};
          if (${b===1}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              initializationValue,
              initializationValue,
              initializationValue
            );

            ${x}
          } else if (${b===2}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${l}, d),
              initializationValue,
              initializationValue
            );

            ${x}
          } else if (${b===3}) {
            vec4 values = vec4(
              getValue(batch, xR, xC, d),
              getValue(batch, xR, xC + ${l}, d),
              getValue(batch, xR, xC + 2 * ${l}, d),
              initializationValue
            );

            ${x}
          }
        }
        setOutput(${v});
      }
    `}},yR=class{constructor(e,t,n,r=!1,i=!1){if(this.variableNames=[`x`],t===`avg`&&n)throw Error(`Cannot compute positions for average pool.`);let a=e.filterWidth,o=e.strideDepth,s=e.strideHeight,c=e.strideWidth,l=e.dilationDepth,u=e.dilationHeight,d=e.dilationWidth,f=e.effectiveFilterDepth,p=e.effectiveFilterHeight,m=e.effectiveFilterWidth,h=e.padInfo.front,g=e.padInfo.top,_=e.padInfo.left;this.outputShape=e.outShape;let v=t===`avg`,y=`0.0`;if(v||(y=`-1.0 / 1e-20`),n){this.userCode=`
        const ivec3 strides =
            ivec3(${o}, ${s}, ${c});
        const ivec3 pads = ivec3(${h}, ${g}, ${_});

        void main() {
          ivec5 coords = getOutputCoords();
          int batch = coords.x;
          int ch = coords.u;

          ivec3 xCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
          int xDCorner = xCorner.x;
          int xRCorner = xCorner.y;
          int xCCorner = xCorner.z;

          // max/min x(?, ?, ?, ch) to get y(yD, yR, yC, ch).
          // ? = to be determined
          float minMaxValue = 0.0;
          float minMaxValueFound = 0.0;
          int minMaxPosition = 0;

          for (int wD = 0; wD < ${f};
              wD += ${l}) {
            int xD = xDCorner + wD;

            if (xD < 0 || xD >= ${e.inDepth}) {
              continue;
            }

            for (int wR = 0; wR < ${p};
                wR += ${u}) {
              int xR = xRCorner + wR;

              if (xR < 0 || xR >= ${e.inHeight}) {
                continue;
              }

              for (int wC = 0; wC < ${m};
                  wC += ${d}) {
                int xC = xCCorner + wC;

                if (xC < 0 || xC >= ${e.inWidth}) {
                  continue;
                }

                float value = getX(batch, xD, xR, xC, ch);

                // If a min / max value has already been found, use it. If not,
                // use the current value.
                float currMinMaxValue = mix(
                    value, minMaxValue, minMaxValueFound);
                if (value >= currMinMaxValue) {
                  minMaxValue = value;
                  minMaxValueFound = 1.0;
                  minMaxPosition = ${r?i?`(((batch * ${e.inDepth} + xD) * ${e.inHeight} + xR) * ${e.inWidth} + xC) * ${e.inChannels} + ch`:`((xD * ${e.inHeight} + xR) * ${e.inWidth} + xC) * ${e.inChannels} + ch`:`wD * ${p} * ${m} +
                      wR * ${m} + wC`};
                }
              }
            }
          }
          setOutput(float(minMaxPosition));
        }
      `;return}let b=`${t}(${t}(${t}(minMaxValue[0], minMaxValue[1]), minMaxValue[2]), minMaxValue[3])`;t===`avg`&&(b=`avgValue / max(count, 1.0)`);let x=Math.floor(a/4)*4,S=a%4,C=`
      if (${v}) {
        avgValue += dot(values, ones);
      } else {
        minMaxValue = max(values, minMaxValue);
      }
    `;this.userCode=`
      const ivec3 strides =
        ivec3(${o}, ${s}, ${c});
      const ivec3 pads = ivec3(${h}, ${g}, ${_});
      const float initializationValue = ${y};
      const vec4 ones = vec4(1.0, 1.0, 1.0, 1.0);

      float count = 0.0;

      float getValue(int batch, int xD, int xR, int xC, int ch) {
        if (xC < 0 || xC >= ${e.inWidth}) {
          return initializationValue;
        }
        count += 1.0;
        return getX(batch, xD, xR, xC, ch);
      }

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 xCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
        int xDCorner = xCorner.x;
        int xRCorner = xCorner.y;
        int xCCorner = xCorner.z;

        // max/min x(?, ?, ?, d) to get y(yD, yR, yC, ch).
        // ? = to be determined
        vec4 minMaxValue = vec4(${y});
        float avgValue = 0.0;
        count = 0.0;

        for (int wD = 0; wD < ${f};
            wD += ${l}) {
          int xD = xDCorner + wD;

          if (xD < 0 || xD >= ${e.inDepth}) {
            continue;
          }

          for (int wR = 0; wR < ${p};
            wR += ${u}) {
            int xR = xRCorner + wR;

            if (xR < 0 || xR >= ${e.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${x}; wC += 4) {
              int xC = xCCorner + wC * ${d};

              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                getValue(batch, xD, xR, xC + 2 * ${d}, ch),
                getValue(batch, xD, xR, xC + 3 * ${d}, ch)
              );

              ${C}
            }

            int xC = xCCorner + ${x};
            if (${S===1}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                initializationValue,
                initializationValue,
                initializationValue
              );

              ${C}
            } else if (${S===2}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                initializationValue,
                initializationValue
              );

              ${C}
            } else if (${S===3}) {
              vec4 values = vec4(
                getValue(batch, xD, xR, xC, ch),
                getValue(batch, xD, xR, xC + ${d}, ch),
                getValue(batch, xD, xR, xC + 2 * ${d}, ch),
                initializationValue
              );

              ${C}
            }
          }
        }
        setOutput(${b});
      }
    `}};function bR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t;MN(i,`avgPool`);let{filterSize:a,strides:s,pad:c,dimRoundingMode:l}=r;o(Dt(s,1),()=>`Error in avgPool: Either strides or dilations must be 1. Got strides ${s} and dilations '1'`);let u=Ze(i.shape,a,s,1,c,l);if(u.filterWidth===1&&u.filterHeight===1&&qn(u.inShape,u.outShape))return iL({inputs:{x:i},backend:n});let d=new vR(u,`avg`,!1);return n.runWebGLProgram(d,[i],`float32`)}var xR={kernelName:et,backendName:`webgl`,kernelFunc:bR};function SR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{filterSize:a,strides:o,pad:s,dimRoundingMode:c,dataFormat:l}=r,u=new yR(Lt(i.shape,a,o,[1,1,1],s,c,l),`avg`,!1);return n.runWebGLProgram(u,[i],`float32`)}var CR={kernelName:Bt,backendName:`webgl`,kernelFunc:SR},wR=class{constructor(e){this.variableNames=[`dy`],this.outputShape=e.inShape;let t=e.filterHeight,n=e.filterWidth,r=e.strideHeight,i=e.strideWidth,a=e.dilationHeight,o=e.dilationWidth,s=e.effectiveFilterHeight,c=e.effectiveFilterWidth,l=s-1-e.padInfo.top,u=c-1-e.padInfo.left,d=1/(t*n);this.userCode=`
      const ivec2 pads = ivec2(${l}, ${u});
      const float avgMultiplier = float(${d});

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];

        ivec2 dyRCCorner = coords.yz - pads;
        int dyRCorner = dyRCCorner.x;
        int dyCCorner = dyRCCorner.y;

        // Convolve dy(?, ?, d) with pos mask(:, :, d) to get dx(xR, xC, d).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${s};
            wR += ${a}) {
          float dyR = float(dyRCorner + wR) / ${r}.0;

          if (dyR < 0.0 || dyR >= ${e.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          for (int wC = 0; wC < ${c};
            wC+= ${o}) {
            float dyC = float(dyCCorner + wC) / ${i}.0;

            if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            float dyValue = getDy(b, idyR, idyC, d);

            dotProd += dyValue * avgMultiplier;
          }
        }
        setOutput(dotProd);
      }
    `}},TR=class{constructor(e){this.variableNames=[`dy`],this.outputShape=e.inShape;let t=e.filterDepth,n=e.filterHeight,r=e.filterWidth,i=e.strideDepth,a=e.strideHeight,o=e.strideWidth,s=e.dilationDepth,c=e.dilationHeight,l=e.dilationWidth,u=e.effectiveFilterDepth,d=e.effectiveFilterHeight,f=e.effectiveFilterWidth,p=u-1-e.padInfo.front,m=d-1-e.padInfo.top,h=f-1-e.padInfo.left,g=1/(t*n*r);this.userCode=`
      const ivec3 pads = ivec3(${p}, ${m}, ${h});
      const float avgMultiplier = float(${g});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyDCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        // Convolve dy(?, ?, ?, d) with pos mask(:, :, :, ch) to get
        // dx(xD, xR, xC, ch).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int wD = 0; wD < ${u};
            wD += ${s}) {
          float dyD = float(dyDCorner + wD) / ${i}.0;

          if (dyD < 0.0 || dyD >= ${e.outDepth}.0 || fract(dyD) > 0.0) {
            continue;
          }
          int idyD = int(dyD);

          for (int wR = 0; wR < ${d};
              wR += ${c}) {
            float dyR = float(dyRCorner + wR) / ${a}.0;

            if (dyR < 0.0 || dyR >= ${e.outHeight}.0 ||
                fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            for (int wC = 0; wC < ${f};
                wC += ${l}) {
              float dyC = float(dyCCorner + wC) / ${o}.0;

              if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              float dyValue = getDy(batch, idyD, idyR, idyC, ch);

              dotProd += dyValue * avgMultiplier;
            }
          }
        }
        setOutput(dotProd);
      }
    `}};function ER(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,o=a,{filterSize:s,strides:c,pad:l,dimRoundingMode:u}=r,d=new TR(Lt(o.shape,s,c,[1,1,1],l,u));return n.runWebGLProgram(d,[i],o.dtype)}var DR={kernelName:ic,backendName:`webgl`,kernelFunc:ER};function OR(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,o=a;MN([i,a],`avgPoolGrad`);let{filterSize:s,strides:c,pad:l}=r,u=new wR(Ze(o.shape,s,c,1,l));return n.runWebGLProgram(u,[i],o.dtype)}var kR={kernelName:At,backendName:`webgl`,kernelFunc:OR};function AR(e){let{inputs:t,backend:n,attrs:r}=e,{a:i,b:a}=t,{transposeA:o,transposeB:s}=r;return BL({a:i,b:a,transposeA:o,transposeB:s,backend:n})}var jR={kernelName:bi,backendName:`webgl`,kernelFunc:AR},MR=class{constructor(e,t,n,r,i,a){this.outputShape=[],this.variableNames=[`x`,`mean`,`variance`],xi(e,t),xi(e,n);let o=`0.0`;r!=null&&(xi(e,r),this.variableNames.push(`offset`),o=`getOffsetAtOutCoords()`);let s=`1.0`;i!=null&&(xi(e,i),this.variableNames.push(`scale`),s=`getScaleAtOutCoords()`),this.outputShape=e,this.userCode=`
      void main() {
        float x = getXAtOutCoords();
        float mean = getMeanAtOutCoords();
        float variance = getVarianceAtOutCoords();
        float offset = ${o};
        float scale = ${s};
        float inv = scale * inversesqrt(variance + float(${a}));
        setOutput(dot(vec3(x, -mean, offset), vec3(inv, inv, 1)));
      }
    `}},NR=class{constructor(e,t,n,r,i,a){this.packedInputs=!0,this.packedOutput=!0,this.variableNames=[`x`,`mean`,`variance`],xi(e,t),xi(e,n);let o=`vec4(0.0)`;r!=null&&(xi(e,r),this.variableNames.push(`offset`),o=`getOffsetAtOutCoords()`);let s=`vec4(1.0)`;i!=null&&(xi(e,i),this.variableNames.push(`scale`),s=`getScaleAtOutCoords()`),this.outputShape=e,this.userCode=`
      void main() {
        vec4 offset = ${o};
        vec4 scale = ${s};

        vec4 x = getXAtOutCoords();
        vec4 mean = getMeanAtOutCoords();
        vec4 variance = getVarianceAtOutCoords();

        vec4 inv = scale * inversesqrt(variance + vec4(${a}));

        setOutput((x - mean) * inv + offset);
      }
    `}},PR={kernelName:ft,backendName:`webgl`,kernelFunc:({inputs:e,backend:t,attrs:n})=>{let{x:r,mean:i,variance:a,offset:s,scale:c}=e;o(i.shape.length===a.shape.length,()=>`Batch normalization gradient requires mean and variance to have equal ranks.`),o(s==null||i.shape.length===s.shape.length,()=>`Batch normalization gradient requires mean and offset to have equal ranks.`),o(c==null||i.shape.length===c.shape.length,()=>`Batch normalization gradient requires mean and scale to have equal ranks.`);let{varianceEpsilon:l}=n;l??=.001;let u=[r,i,a],d=null;s!=null&&(d=s.shape,u.push(s));let f=null;c!=null&&(f=c.shape,u.push(c));let p=j().getBool(`WEBGL_PACK_NORMALIZATION`)?new NR(r.shape,i.shape,a.shape,d,f,l):new MR(r.shape,i.shape,a.shape,d,f,l);return t.runWebGLProgram(p,u,u[0].dtype)}},FR=class{constructor(e){this.variableNames=[`source`],this.outputShape=e,this.rank=e.length;let t=kP(this.rank);this.customUniforms=[{name:`start`,arrayIndex:this.rank,type:`int`}];let n=LR(this.rank),r;r=`
        ${t} sourceLoc;
        ${t} coords = getOutputCoords();
        ${e.map((e,t)=>`sourceLoc.${IR[t]} = start[${t}] + coords.${IR[t]};`).join(`
`)}
      `,this.userCode=`
      void main() {
        ${r}
        setOutput(getSource(${n}));
      }
    `}},IR=[`x`,`y`,`z`,`w`,`u`,`v`];function LR(e){if(e===1)return`sourceLoc`;if(e<=6)return IR.slice(0,e).map(e=>`sourceLoc.`+e).join(`,`);throw Error(`Slicing for rank ${e} is not yet supported`)}var RR=class{constructor(e){this.variableNames=[`source`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=e,this.rank=e.length,this.customUniforms=[{name:`start`,arrayIndex:this.rank,type:`int`}];let t=kP(this.rank),n=pI(`coords`,this.rank),r=pI(`sourceLoc`,this.rank),i=this.rank===1?`sourceLoc`:`vec2(${r.slice(-2).join()})`,a=`getChannel(getSource(${r.join()}), ${i})`,o=`
      result.x = ${a};
      if (++${n[this.rank-1]} < ${e[this.rank-1]}) {
        ++${r[this.rank-1]};
        result.y = ${a};
        --${r[this.rank-1]};
      }
    `,s=this.rank===1?``:`
      --${n[this.rank-1]};
      if (++${n[this.rank-2]} < ${e[this.rank-2]}) {
        ++${r[this.rank-2]};
        result.z = ${a};
        if (++${n[this.rank-1]} < ${e[this.rank-1]}) {
          ++${r[this.rank-1]};
          result.w = ${a};
        }
      }
    `,c=this.rank<=4?`sourceLoc = coords +
            ${t}(${e.map((e,t)=>`start[${t}]`).join()});`:e.map((e,t)=>`${r[t]} = ${n[t]} + start[${t}];`).join(`
`);this.userCode=`
      void main() {
        ${t} coords = getOutputCoords();
        ${t} sourceLoc;
        ${c}
        vec4 result = vec4(0.);
        ${o}
        ${s}
        setOutput(result);
      }
    `}};function zR(e,t,n,r){let i=r.texData.get(e.dataId),a=r.makeTensorInfo(n,e.dtype),o=r.texData.get(a.dataId);Object.assign(o,i),o.refCount=1,o.shape=n,o.dtype=e.dtype;let s=Ou(t,R(e.shape));i.slice&&(s+=i.slice.flatOffset),o.slice={flatOffset:s,origDataId:i.slice&&i.slice.origDataId||e.dataId};let c=r.dataRefCount.get(o.slice.origDataId)||1;return r.dataRefCount.set(o.slice.origDataId,c+1),a}function BR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{begin:a,size:o}=r,[s,c]=ku(i,a,o);if(hu(i,s,c),k(c)===0)return n.makeTensorInfo(c,i.dtype,[]);if(n.shouldExecuteOnCPU([i])||i.dtype===`string`){let e=ZF(n.texData.get(i.dataId).values,s,c,i.shape,i.dtype);return n.makeTensorInfo(c,i.dtype,e)}let{isPacked:l}=n.texData.get(i.dataId),u=Du(i.shape,s,c);if(l||!u){let e=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)?new RR(c):new FR(c),t=[s];return n.runWebGLProgram(e,[i],i.dtype,t)}return n.uploadToGPU(i.dataId),zR(i,s,c,n)}var VR={kernelName:po,backendName:`webgl`,kernelFunc:BR},HR={kernelName:ui,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockShape:a,crops:s}=r;o(i.shape.length<=4,()=>`batchToSpaceND for rank > 4 with a WebGL backend not implemented yet`);let c=a.reduce((e,t)=>e*t),l=qu(i.shape,a,c),u=Ju(l.length,a.length),d=Yu(i.shape,a,c),f=Xu(s,a.length),p=Zu(d,s,a.length),m=[],h=$({inputs:{x:i},backend:n,attrs:{shape:l}}),g=RL({inputs:{x:h},backend:n,attrs:{perm:u}}),_=$({inputs:{x:g},backend:n,attrs:{shape:d}}),v=BR({inputs:{x:_},backend:n,attrs:{begin:f,size:p}});return m.push(h),m.push(g),m.push(_),m.forEach(e=>n.disposeIntermediateTensorInfo(e)),v}};function UR(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,weights:a}=t,{size:o}=r,s=vF(n.readSync(i.dataId),n.readSync(a.dataId),a.dtype,a.shape,o);return n.makeTensorInfo([o],a.dtype,s)}var WR={kernelName:ki,backendName:`webgl`,kernelFunc:UR},GR=`
  int r = int(a.r) & int(b.r);
  int g = int(a.g) & int(b.g);
  int rb = int(a.b) & int(b.b);
  int ra = int(a.a) & int(b.a);
  return vec4(r, g, rb, ra);
`,KR=`
  return float(int(a.r) & int(b.r));
`;function qR(e){let{inputs:t,backend:n}=e,{a:r,b:i}=t,a=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`),o=j().getNumber(`WEBGL_VERSION`);if(n.shouldExecuteOnCPU([r,i])||o===1){let e=n.texData.get(r.dataId).values,t=n.texData.get(i.dataId).values,[a,o]=bF(r.shape,i.shape,e,t,r.dtype),s=n.makeTensorInfo(o,r.dtype),c=n.texData.get(s.dataId);return c.values=a,s}let s;return s=a?new rL(GR,r.shape,i.shape,!1):new tL(KR,r.shape,i.shape),n.runWebGLProgram(s,[r,i],r.dtype)}var JR={kernelName:Yn,backendName:`webgl`,kernelFunc:qR};function YR(e){let{inputs:t,backend:n}=e,{s0:r,s1:i}=t,a=n.readSync(r.dataId),o=n.readSync(i.dataId),s=xi(Array.from(a),Array.from(o));return n.makeTensorInfo([s.length],`int32`,Int32Array.from(s))}var XR={kernelName:c,backendName:`webgl`,kernelFunc:YR},ZR=_L({opSnippet:`return float(a != b);`,cpuKernelImpl:VF,dtype:`bool`}),QR={kernelName:Fn,backendName:`webgl`,kernelFunc:ZR};function $R(e){let{inputs:t,backend:n}=e,{input:r}=t;return iL({inputs:{x:n.texData.get(r.dataId).complexTensorInfos.real},backend:n})}var ez={kernelName:tc,backendName:`webgl`,kernelFunc:$R},tz=`return float(int(x));`;function nz(e,t){let n=new TI(e.shape,tz),r=t.runWebGLProgram(n,[e],`int32`);return{dataId:r.dataId,shape:r.shape,dtype:r.dtype}}function rz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{dtype:a}=r;if(a===`complex64`){if(i.dtype===`complex64`)return iL({inputs:{x:i},backend:n});let e=_n(i.shape),t=rz({inputs:{x:i},backend:n,attrs:{dtype:`float32`}}),r=oL({inputs:{real:t,imag:e},backend:n});return e.dispose(),n.disposeIntermediateTensorInfo(t),r}if(i.dtype===`complex64`){let e=$R({inputs:{input:i},backend:n}),t=rz({inputs:{x:e},backend:n,attrs:{dtype:a}});return n.disposeIntermediateTensorInfo(e),t}if(!Oc(i.dtype,a)){let e=iL({inputs:{x:i},backend:n});return{dataId:e.dataId,shape:e.shape,dtype:a}}if(n.shouldExecuteOnCPU([i])){let e=n.texData.get(i.dataId).values,[t,r,o]=xF(e,i.shape,i.dtype,a);return n.makeTensorInfo(t,r,o)}if(a===`int32`)return nz(i,n);if(a===`bool`){let e=n.makeTensorInfo([],`bool`,Hs(`bool`,1)),t=ZR({inputs:{a:i,b:e},backend:n});return n.disposeIntermediateTensorInfo(e),t}throw Error(`Error in Cast: failed to cast ${i.dtype} to ${a}`)}var iz={kernelName:Lc,backendName:`webgl`,kernelFunc:rz},az=`return ceil(x);`,oz={kernelName:ks,backendName:`webgl`,kernelFunc:Q({opSnippet:az,packedOpSnippet:az,cpuKernelImpl:SF})},sz=class{constructor(e){this.variableNames=[`A`],this.customUniforms=[{name:`minVal`,type:`float`},{name:`maxVal`,type:`float`}],this.outputShape=e,this.userCode=`

      void main() {
        float value = getAAtOutCoords();
        if (isnan(value)) {
          setOutput(value);
          return;
        }

        setOutput(clamp(value, minVal, maxVal));
      }
    `}},cz=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`minVal`,type:`float`},{name:`maxVal`,type:`float`}],this.outputShape=e,this.userCode=`
      void main() {
        vec4 value = getAAtOutCoords();

        if (any(isnan(value))) {
          setOutput(value);
          return;
        }

        setOutput(clamp(value, vec4(minVal), vec4(maxVal)));
      }
    `}};function lz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{clipValueMin:a,clipValueMax:o}=r,s;s=j().getBool(`WEBGL_PACK_CLIP`)?new cz(i.shape):new sz(i.shape);let c=[[a],[o]];return n.runWebGLProgram(s,[i],i.dtype,c)}var uz={kernelName:gc,backendName:`webgl`,kernelFunc:lz},dz=class{constructor(e){this.variableNames=[`real`,`imag`],this.outputShape=e,this.userCode=`
      void main() {
        float re = abs(getRealAtOutCoords());
        float im = abs(getImagAtOutCoords());
        float mx = max(re, im);

        // sadly the length function in glsl is not underflow-safe
        // (at least not on Intel GPUs). So the safe solution is
        // to ensure underflow-safety in all cases.
        setOutput(
          mx == 0.0 ? 0.0 : mx * length(vec2(1, min(re, im)/mx))
        );
      }
    `}};function fz(e,t){return{dataId:t.dataId,dtype:t.dtype,shape:e.shape}}function pz(e){let{inputs:t,backend:n}=e,{x:r}=t,i=n.texData.get(r.dataId),a=new dz(r.shape),o=[fz(r,i.complexTensorInfos.real),fz(r,i.complexTensorInfos.imag)];return n.runWebGLProgram(a,o,o[0].dtype)}var mz={kernelName:Zi,backendName:`webgl`,kernelFunc:pz},hz=class{constructor(e){this.outputShape=[],this.outputShape=zu(e,1),this.variableNames=e.map((e,t)=>`T${t}`);let t=Array(e.length-1);t[0]=e[0][1];for(let n=1;n<t.length;n++)t[n]=t[n-1]+e[n][1];let n=[`if (yC < ${t[0]}) setOutput(getT0(yR, yC));`];for(let e=1;e<t.length;e++){let r=t[e-1];n.push(`else if (yC < ${t[e]}) setOutput(getT${e}(yR, yC-${r}));`)}let r=t.length,i=t[t.length-1];n.push(`else setOutput(getT${r}(yR, yC-${i}));`),this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int yR = coords.x;
        int yC = coords.y;

        ${n.join(`
        `)}
      }
    `}},gz=class{constructor(e,t){this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[],this.outputShape=zu(e,t);let n=this.outputShape,r=n.length,i=kP(r),a=pI(`coords`,r),o=[`x`,`y`,`z`,`w`,`u`,`v`].slice(0,r);this.variableNames=e.map((e,t)=>`T${t}`);let s=Array(e.length-1);s[0]=e[0][t];for(let n=1;n<s.length;n++)s[n]=s[n-1]+e[n][t];let c=o[t],l=o.slice(-2),u=o.join(),d=`if (${c} < ${s[0]}) {
        return getChannel(
            getT0(${u}), vec2(${l.join()}));
        }`;for(let e=1;e<s.length;e++){let t=s[e-1];d+=`
        if (${c} < ${s[e]}  && ${c} >= ${s[e-1]}) {
          return getChannel(
            getT${e}(${_z(o,c,t)}),
            vec2(${_z(l,c,t)}));
        }`}let f=s.length,p=s[s.length-1];d+=`
        return getChannel(
          getT${f}(${_z(o,c,p)}),
          vec2(${_z(l,c,p)}));`,this.userCode=`
      float getValue(${o.map(e=>`int `+e)}) {
        ${d}
      }

      void main() {
        ${i} coords = getOutputCoords();
        vec4 result = vec4(getValue(${a}), 0., 0., 0.);

        ${a[r-1]} = ${a[r-1]} + 1;
        if (${a[r-1]} < ${n[r-1]}) {
          result.g = getValue(${a});
        }

        ${a[r-2]} = ${a[r-2]} + 1;
        if (${a[r-2]} < ${n[r-2]}) {
          result.a = getValue(${a});
        }

        ${a[r-1]} = ${a[r-1]} - 1;
        if (${a[r-2]} < ${n[r-2]} &&
            ${a[r-1]} < ${n[r-1]}) {
          result.b = getValue(${a});
        }
        setOutput(result);
      }
    `}};function _z(e,t,n){let r=e.indexOf(t);return e.map((e,t)=>t===r?`${e} - ${n}`:e).join()}function vz(e){let{inputs:t,backend:n}=e,{input:r}=t;return iL({inputs:{x:n.texData.get(r.dataId).complexTensorInfos.imag},backend:n})}var yz={kernelName:ji,backendName:`webgl`,kernelFunc:vz};function bz(e,t,n){let r=e[0].dtype;if(r===`complex64`){let r=e.map(e=>$R({inputs:{input:e},backend:n})),i=e.map(e=>vz({inputs:{input:e},backend:n})),a=bz(r,t,n),o=bz(i,t,n),s=oL({inputs:{real:a,imag:o},backend:n});return r.forEach(e=>n.disposeIntermediateTensorInfo(e)),i.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.disposeIntermediateTensorInfo(a),n.disposeIntermediateTensorInfo(o),s}let i=n.shouldExecuteOnCPU(e);if(r===`string`&&(i=!0),i){let i=e.map(e=>{let r=[-1,k(e.shape.slice(t))];return $({inputs:{x:e},backend:n,attrs:{shape:r}})}),a=CF(i.map(e=>({vals:n.readSync(e.dataId),shape:e.shape})),zu(i.map(e=>e.shape),1),r,i[0].shape[0]===1),o=zu(e.map(e=>e.shape),t),s=n.makeTensorInfo(o,r,a);return i.forEach(e=>n.disposeIntermediateTensorInfo(e)),s}let a=e.filter(e=>k(e.shape)>0),o=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)&&a[0].shape.length>1;if(a.length===1){let t=o?new TI(e[0].shape,MI):new zI(e[0].shape,MI);return n.runWebGLProgram(t,e,r)}let s=j().getNumber(`WEBGL_MAX_TEXTURES_IN_SHADER`);if(a.length>s){let e=[];for(let r=0;r<a.length;r+=s){let i=a.slice(r,r+s);e.push(bz(i,t,n))}let r=bz(e,t,n);for(let t of e)n.disposeIntermediateTensorInfo(t);return r}if(o){let e=new gz(a.map(e=>e.shape),t);return n.runWebGLProgram(e,a,r)}let{tensors2D:c,outShape:l}=xz(a,t,n),u=new hz(c.map(e=>e.shape)),d=n.runWebGLProgram(u,c,r);c.forEach(e=>n.disposeIntermediateTensorInfo(e));let f=$({inputs:{x:d},attrs:{shape:l},backend:n});return n.disposeIntermediateTensorInfo(d),f}function xz(e,t,n){let r=zu(e.map(e=>e.shape),t);return{tensors2D:e.map(e=>$({inputs:{x:e},attrs:{shape:[-1,k(e.shape.slice(t))]},backend:n})),outShape:r}}function Sz(e){let{inputs:t,backend:n,attrs:r}=e,{axis:i}=r,a=H(i,t[0].shape)[0];Ru(t.map(e=>e.shape),a);let o=zu(t.map(e=>e.shape),a);if(k(o)===0)return n.makeTensorInfo(o,t[0].dtype,[]);let s=t.filter(e=>k(e.shape)>0);return s.length===1?iL({inputs:{x:s[0]},backend:n}):bz(s,a,n)}var Cz={kernelName:Bs,backendName:`webgl`,kernelFunc:Sz},wz=class{constructor(e,t=!1,n=null,r=!1,i=!1){this.variableNames=[`x`,`W`],this.outputShape=e.outShape;let a=e.padInfo.top,o=e.padInfo.left,s=e.strideHeight,c=e.strideWidth,l=e.dilationHeight,u=e.dilationWidth,d=e.filterHeight,f=e.filterWidth,p=Math.floor(e.inChannels/4)*4,m=e.inChannels%4,h=e.dataFormat===`channelsLast`,g=h?1:2,_=h?2:3,v=h?3:1,y=``,b=``;n&&(y=r?`float activation(float a) {
          float b = getPreluActivationWeightsAtOutCoords();
          ${n}
        }`:i?`float activation(float a) {
          float b = getLeakyreluAlphaAtOutCoords();
          ${n}
        }`:`
          float activation(float x) {
            ${n}
          }
        `,b=`result = activation(result);`);let x=t?`result += getBiasAtOutCoords();`:``;t&&this.variableNames.push(`bias`),r&&this.variableNames.push(`preluActivationWeights`),i&&this.variableNames.push(`leakyreluAlpha`),this.userCode=`
      ${y}

      const ivec2 strides = ivec2(${s}, ${c});
      const ivec2 pads = ivec2(${a}, ${o});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d2 = coords[${v}];

        ivec2 xRCCorner =
            ivec2(coords[${g}], coords[${_}]) * strides - pads;
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // Convolve x(?, ?, d1) with w(:, :, d1, d2) to get y(yR, yC, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${d}; wR++) {
          int xR = xRCorner + wR * ${l};

          if (xR < 0 || xR >= ${e.inHeight}) {
            continue;
          }

          for (int wC = 0; wC < ${f}; wC++) {
            int xC = xCCorner + wC * ${u};

            if (xC < 0 || xC >= ${e.inWidth}) {
              continue;
            }

            for (int d1 = 0; d1 < ${p}; d1 += 4) {
              vec4 wValues = vec4(
                getW(wR, wC, d1, d2),
                getW(wR, wC, d1 + 1, d2),
                getW(wR, wC, d1 + 2, d2),
                getW(wR, wC, d1 + 3, d2)
              );

              if (${h}) {
                vec4 xValues = vec4(
                  getX(batch, xR, xC, d1),
                  getX(batch, xR, xC, d1 + 1),
                  getX(batch, xR, xC, d1 + 2),
                  getX(batch, xR, xC, d1 + 3)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec4 xValues = vec4(
                  getX(batch, d1, xR, xC),
                  getX(batch, d1 + 1, xR, xC),
                  getX(batch, d1 + 2, xR, xC),
                  getX(batch, d1 + 3, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }
            }

            if (${m===1}) {

              if (${h}) {
                dotProd +=
                    getX(batch, xR, xC, ${p}) *
                    getW(wR, wC, ${p}, d2);
              } else {
                dotProd +=
                    getX(batch, ${p}, xR, xC) *
                    getW(wR, wC, ${p}, d2);
              }

            } else if (${m===2}) {
              vec2 wValues = vec2(
                getW(wR, wC, ${p}, d2),
                getW(wR, wC, ${p} + 1, d2)
              );

              if (${h}) {
                vec2 xValues = vec2(
                  getX(batch, xR, xC, ${p}),
                  getX(batch, xR, xC, ${p} + 1)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec2 xValues = vec2(
                  getX(batch, ${p}, xR, xC),
                  getX(batch, ${p} + 1, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }

            } else if (${m===3}) {
              vec3 wValues = vec3(
                getW(wR, wC, ${p}, d2),
                getW(wR, wC, ${p} + 1, d2),
                getW(wR, wC, ${p} + 2, d2)
              );

              if (${h}) {
                vec3 xValues = vec3(
                  getX(batch, xR, xC, ${p}),
                  getX(batch, xR, xC, ${p} + 1),
                  getX(batch, xR, xC, ${p} + 2)
                );
                dotProd += dot(xValues, wValues);
              } else {
                vec3 xValues = vec3(
                  getX(batch, ${p}, xR, xC),
                  getX(batch, ${p} + 1, xR, xC),
                  getX(batch, ${p} + 2, xR, xC)
                );
                dotProd += dot(xValues, wValues);
              }

            }
          }
        }

        float result = dotProd;
        ${x}
        ${b}
        setOutput(result);
      }
    `}},Tz=class{constructor(e){this.variableNames=[`x`,`W`],this.outputShape=e.outShape;let t=e.padInfo.front,n=e.padInfo.top,r=e.padInfo.left,i=e.strideDepth,a=e.strideHeight,o=e.strideWidth,s=e.dilationDepth,c=e.dilationHeight,l=e.dilationWidth,u=e.filterDepth,d=e.filterHeight,f=e.filterWidth,p=Math.floor(e.inChannels/4)*4,m=e.inChannels%4;this.userCode=`
      const ivec3 strides = ivec3(${i}, ${a}, ${o});
      const ivec3 pads = ivec3(${t}, ${n}, ${r});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int d2 = coords.u;

        ivec3 xFRCCorner = ivec3(coords.y, coords.z, coords.w) * strides - pads;
        int xFCorner = xFRCCorner.x;
        int xRCorner = xFRCCorner.y;
        int xCCorner = xFRCCorner.z;

        // Convolve x(?, ?, ?, d1) with w(:, :, :, d1, d2) to get
        // y(yF, yR, yC, d2). ? = to be determined. : = across all
        // values in that axis.
        float dotProd = 0.0;
        for (int wF = 0; wF < ${u}; wF++) {
          int xF = xFCorner + wF * ${s};

          if (xF < 0 || xF >= ${e.inDepth}) {
            continue;
          }

          for (int wR = 0; wR < ${d}; wR++) {
            int xR = xRCorner + wR * ${c};

            if (xR < 0 || xR >= ${e.inHeight}) {
              continue;
            }

            for (int wC = 0; wC < ${f}; wC++) {
              int xC = xCCorner + wC * ${l};

              if (xC < 0 || xC >= ${e.inWidth}) {
                continue;
              }

              for (int d1 = 0; d1 < ${p}; d1 += 4) {
                vec4 xValues = vec4(
                  getX(batch, xF, xR, xC, d1),
                  getX(batch, xF, xR, xC, d1 + 1),
                  getX(batch, xF, xR, xC, d1 + 2),
                  getX(batch, xF, xR, xC, d1 + 3)
                );
                vec4 wValues = vec4(
                  getW(wF, wR, wC, d1, d2),
                  getW(wF, wR, wC, d1 + 1, d2),
                  getW(wF, wR, wC, d1 + 2, d2),
                  getW(wF, wR, wC, d1 + 3, d2)
                );

                dotProd += dot(xValues, wValues);
              }

              if (${m===1}) {
                dotProd +=
                  getX(batch, xF, xR, xC, ${p}) *
                  getW(wF, wR, wC, ${p}, d2);
              } else if (${m===2}) {
                vec2 xValues = vec2(
                  getX(batch, xF, xR, xC, ${p}),
                  getX(batch, xF, xR, xC, ${p} + 1)
                );
                vec2 wValues = vec2(
                  getW(wF, wR, wC, ${p}, d2),
                  getW(wF, wR, wC, ${p} + 1, d2)
                );
                dotProd += dot(xValues, wValues);
              } else if (${m===3}) {
                vec3 xValues = vec3(
                  getX(batch, xF, xR, xC, ${p}),
                  getX(batch, xF, xR, xC, ${p} + 1),
                  getX(batch, xF, xR, xC, ${p} + 2)
                );
                vec3 wValues = vec3(
                  getW(wF, wR, wC, ${p}, d2),
                  getW(wF, wR, wC, ${p} + 1, d2),
                  getW(wF, wR, wC, ${p} + 2, d2)
                );
                dotProd += dot(xValues, wValues);
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}},Ez=class{constructor(e,t=!1,n=null,r=!1,i=!1){this.variableNames=[`x`,`W`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`pads`,type:`ivec2`},{name:`strides`,type:`ivec2`},{name:`dilations`,type:`ivec2`},{name:`inDims`,type:`ivec2`}],this.outputShape=e.outShape,this.enableShapeUniforms=RP(this.outputShape.length);let a=e.padInfo.left,o=e.strideWidth,s=e.dilationWidth,c=e.filterHeight,l=e.filterWidth,u=l,d=`
       int xR; int xC; int xCOffset;
       vec4 wTexel; vec4 previous; vec4 final;`;for(let e=0;e<l;e++)d+=`
           vec4 xTexelC${e*2};
           int xTexelC${e*2}Ready;
           vec4 xTexelC${e*2+1};
           int xTexelC${e*2+1}Ready;
           vec4 xC${e};`;d+=`
     for (int r = 0; r < ${c}; r++) {
      for (int d1 = 0; d1 < ${e.inChannels}; d1 += 2) {
       `;for(let e=0;e<l;e++)d+=`
           xTexelC${e*2} = vec4(0.0);
           xTexelC${e*2}Ready = 0;
           xTexelC${e*2+1} = vec4(0.0);
           xTexelC${e*2+1}Ready = 0;
           xC${e} = vec4(0.0);`;d+=`
         xR = xRCorner + r * dilations[0];
         if (xR >=0 && xR < inDims[0]) {
       `;for(let t=0;t<(u+1)/2;t++){let n=t*2;if(d+=`
           xC = xCCorner + ${n*s};
           `,o===1){if(n<l&&(a%2==1?(d+=`
                 xCOffset = xC + 1;
                 if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${n}Ready == 0) {
                   xTexelC${n} = getX(batch, xR, xCOffset, d1);

                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${n}.zw = vec2(0.0);
                   }
                   xTexelC${n}Ready = 1;
                 }
               `,s===1&&n>0?d+=`
                 xC${n} = vec4(xTexelC${n-2}.zw, xTexelC${n}.xy);
                 `:d+=`
                   xCOffset = xC + 1 - 2;

                   if (xCOffset >= 0 && xCOffset < inDims[1]) {
                     previous = getX(batch, xR, xCOffset, d1);

                     // Need to manually clear unused channels in case
                     // we're reading from recycled texture.
                     if (xCOffset + 1 >= inDims[1]) {
                       previous.zw = vec2(0.0);
                     }

                     xC${n} = vec4(previous.zw, xTexelC${n}.xy);
                   } else {
                     xC${n} = vec4(0.0, 0.0, xTexelC${n}.xy);
                   }
                   `):d+=`
                 if (xC >= 0 && xC < inDims[1] && xTexelC${n}Ready == 0) {
                   xTexelC${n} = getX(batch, xR, xC, d1);
                   if (xC + 1 >= inDims[1]) {
                     xTexelC${n}.zw = vec2(0.0);
                   }
                   xTexelC${n}Ready = 1;
                 }

                 xC${n} = xTexelC${n};
                 `,n+1<l)){let e=a%2==0?ua(s):s;s%2==0&&a%2==1||s%2!=0&&a%2!=1?(d+=`
                   xCOffset = xC + imod(pads[1], 2) + ${e};

                   if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${n+1}Ready == 0) {
                     xTexelC${n+1} = getX(batch, xR, xCOffset, d1);

                     // Need to manually clear unused channels in case
                     // we're reading from recycled texture.
                     if (xCOffset + 1 >= inDims[1]) {
                       xTexelC${n+1}.zw = vec2(0.0);
                     }
                     xTexelC${n+1}Ready = 1;
                   }
                   `,s>1?d+=`
                     xCOffset -= 2;
                     if (xCOffset >= 0 && xCOffset < inDims[1]) {
                      previous = getX(batch, xR, xCOffset, d1);
                      xC${n+1} = vec4(previous.zw, xTexelC${n+1}.xy);
                     } else {
                      xC${n+1} = vec4(0.0, 0.0, xTexelC${n+1}.xy);
                     }
                     `:d+=`
                     xC${n+1} = vec4(xTexelC${n}.zw, xTexelC${n+1}.xy);
                     `):e===1?d+=`
                     xC${n+1} = xTexelC${n};
                     `:d+=`
                     xCOffset = xC + ${e};

                     if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${n+1}Ready == 0) {
                       xTexelC${n+1} = getX(batch, xR, xCOffset, d1);
                       if (xCOffset + 1 >= inDims[1]) {
                         xTexelC${n+1}.zw = vec2(0.0);
                       }
                       xTexelC${n+1}Ready = 1;
                     }

                     xC${n+1} = xTexelC${n+1};
                     `}}else n<l&&(a%2==1?(d+=`
                 xCOffset = xC + 1 - strides[1];
                 if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${n}Ready == 0) {
                   xTexelC${n} = getX(batch, xR, xCOffset, d1);
                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${n}.zw = vec2(0.0);
                   }
                   xTexelC${n}Ready = 1;
                 }

                 if(xC + 1 >= 0 && xC + 1 < inDims[1] && xTexelC${n+1}Ready == 0) {
                   xTexelC${n+1} = getX(batch, xR, xC + 1, d1);
                   // Need to manually clear unused channels in case
                   // we're reading from recycled texture.
                   if (xC + 2 >= inDims[1]) {
                     xTexelC${n+1}.zw = vec2(0.0);
                   }
                   xTexelC${n+1}Ready = 1;
                 }

                 xC${n} = vec4(xTexelC${n}.zw, xTexelC${n+1}.zw);
               `,n+1<l&&(d+=`
                   final = vec4(0.0);
                   xCOffset = xC + 1 + strides[1];
                   if(xCOffset >= 0 && xCOffset < inDims[1]) {
                     final = getX(batch, xR, xCOffset, d1);
                   }
                   xC${n+1} = vec4(xTexelC${n+1}.xy, final.xy);
                 `)):(d+=`
                 if(xC >= 0 && xC < inDims[1] && xTexelC${n}Ready == 0) {
                   xTexelC${n} = getX(batch, xR, xC, d1);
                   if (xC + 1 >= inDims[1]) {
                     xTexelC${n}.zw = vec2(0.0);
                   }
                   xTexelC${n}Ready = 1;
                 }

                 xCOffset = xC + strides[1];
                 if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${n+1}Ready == 0) {
                   xTexelC${n+1} = getX(batch, xR, xCOffset, d1);
                   if (xCOffset + 1 >= inDims[1]) {
                     xTexelC${n+1}.zw = vec2(0.);
                   }
                   xTexelC${n+1}Ready = 1;
                 }

                 xC${n} = vec4(
                   xTexelC${n}.xy, xTexelC${n+1}.xy);
               `,n+1<l&&(d+=`
                   xC${n+1} = vec4(xTexelC${n}.zw, xTexelC${n+1}.zw);
                 `)));n<l&&(d+=`
             wTexel = getW(r, ${n}, d1, d2);
             dotProd += xC${n}.xxzz * vec4(wTexel.xy, wTexel.xy);
             if(d1 + 1 < ${e.inChannels}) {
               dotProd += xC${n}.yyww * vec4(wTexel.zw, wTexel.zw);
             }
           `,n+1<l&&(d+=`
               wTexel = getW(r, ${n+1}, d1, d2);
               dotProd += xC${n+1}.xxzz * vec4(wTexel.xy, wTexel.xy);
               if(d1 + 1 < ${e.inChannels}) {
                 dotProd += xC${n+1}.yyww * vec4(wTexel.zw, wTexel.zw);
               }
             `))}d+=`
     }
   `,d+=`
     }
   `,d+=`
     }
   `;let f=``,p=``;n&&(f=r?`vec4 activation(vec4 a) {
           vec4 b = getPreluActivationWeightsAtOutCoords();
           ${n}
         }`:i?`vec4 activation(vec4 a) {
           vec4 b = getLeakyreluAlphaAtOutCoords();
           ${n}
         }`:`vec4 activation(vec4 x) {
           ${n}
         }`,p=`result = activation(result);`);let m=t?`result += getBiasAtOutCoords();`:``;t&&this.variableNames.push(`bias`),r&&this.variableNames.push(`preluActivationWeights`),i&&this.variableNames.push(`leakyreluAlpha`),this.userCode=`
       ${f}

       void main() {
         ivec4 coords = getOutputCoords();
         int batch = coords.x;
         ivec2 xRCCorner = coords.yz * strides - pads;
         int d2 = coords.w;
         int xRCorner = xRCCorner.x;
         int xCCorner = xRCCorner.y;

         //intialize dotProd with a small epsilon seems to reduce GPU accuracy loss.
         vec4 dotProd = vec4(0.000000000000001);

         ${d}

         vec4 result = dotProd - vec4(0.000000000000001);
         ${m}
         ${p}
         setOutput(result);
       }
     `}},Dz=class{constructor(e,t){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`inputShape`,type:`ivec4`},{name:`pad`,type:`ivec2`},{name:`stride`,type:`ivec2`},{name:`dilation`,type:`ivec2`},{name:`inChannels`,type:`int`},{name:`itemsPerBlockRow`,type:`int`},{name:`outWidth`,type:`int`}],this.outputShape=e,this.enableShapeUniforms=RP(this.outputShape.length);let{dataFormat:n}=t,r=NN(),i=n===`channelsLast`,a=i?1:2,o=i?2:3,s=this.enableShapeUniforms?`if(blockIndex < outShape[2] && pos < outShape[1]) {`:`if(blockIndex < ${e[2]} && pos < ${e[1]}) {`,c=``;for(let e=0;e<=1;e++)for(let t=0;t<=1;t++)c+=`
          blockIndex = rc.z + ${t};
          pos = rc.y + ${e};

          ${s}
            offsetY = int(blockIndex / outWidth) * stride[0] - pad[0];
            d0 = offsetY + dilation[0] * (pos / itemsPerBlockRow);

            if(d0 < inputShape[${a}] && d0 >= 0) {
              // Use custom imod instead mod. On Intel GPU, mod may generate
              // unexpected value.
              // https://github.com/tensorflow/tfjs/issues/5447
              offsetX = imod(blockIndex, outWidth) * stride[1] - pad[1];
              d1 = offsetX + dilation[1] * (imod(pos, itemsPerBlockRow) /
                  inChannels);

              if(d1 < inputShape[${o}] && d1 >= 0) {

                ch = imod(pos, inChannels);

                if (${i}) {
                  innerDims = vec2(d1, ch);
                  result[${e*2+t}] = getChannel(
                    getA(rc.x, d0, int(innerDims.x),
                    int(innerDims.y)), innerDims);
                } else {
                  innerDims = vec2(d0, d1);
                  result[${e*2+t}] = getChannel(
                    getA(rc.x, ch, int(innerDims.x),
                    int(innerDims.y)), innerDims);
                }
              }
            }
          }
        `;this.userCode=`
      void main() {
        ivec3 rc = getOutputCoords();

        vec4 result = vec4(0);

        int blockIndex, pos, offsetY, d0, offsetX, d1, ch;
        vec2 innerDims;

        ${c}

        ${r.output} = result;
      }
    `}};function Oz(e,t){let n=e.length;return n>=3?t?[...e.slice(0,-3),e[n-3]*e[n-2],e[n-1]]:[...e.slice(0,-3),e[n-3],e[n-2]*e[n-1]]:!t&&n===1&&e[0]>1?[e[0],1]:null}function kz({x:e,filter:t,convInfo:n,backend:r,bias:i=null,preluActivationWeights:a=null,leakyreluAlpha:s=0,activation:c=null}){let l=e.shape,u=r.texData.get(e.dataId),d=n.inChannels,f=l[0]*l[1]*l[2],p=n.outChannels,m=n.dataFormat===`channelsLast`,h,g=[];if(a!=null){let e=Oz(a.shape,m);e!=null&&(a=$({inputs:{x:a},backend:r,attrs:{shape:e}}),g.push(a))}if(i!=null){let e=Oz(i.shape,m);e!=null&&(i=$({inputs:{x:i},backend:r,attrs:{shape:e}}),g.push(i))}if(!((f===1||p===1)&&d>1e3)&&u.isPacked&&m&&u.texture!=null&&l[2]%2!=0&&qn(u.shape.slice(-3),l.slice(-3))){let d=l[0]*l[1]*(l[2]+1),f={dataId:e.dataId,shape:[1,d,n.inChannels],dtype:e.dtype},p=u.shape;u.shape=u.shape.slice(),u.shape[u.shape.length-2]++,o(_N(u.shape,f.shape),()=>`packed reshape ${u.shape} to ${f.shape} isn't free`);let m=$({inputs:{x:t},backend:r,attrs:{shape:[1,n.inChannels,n.outChannels]}});g.push(m);let _=BL({a:f,b:m,backend:r,transposeA:!1,transposeB:!1,bias:i,activation:c,preluActivationWeights:a,leakyreluAlpha:s}),v=r.texData.get(_.dataId);o(v.isPacked,()=>`batchMatMul result is expected to be packed`),u.shape=p,v.shape=n.outShape,h=iL({inputs:{x:_},backend:r}),h.shape=n.outShape,g.push(_)}else{let o=n.outHeight*n.outWidth,l=$({inputs:{x:e},backend:r,attrs:{shape:m?[n.batchSize,o,n.inChannels]:[n.batchSize,n.inChannels,o]}}),u=$({inputs:{x:t},backend:r,attrs:{shape:[1,n.inChannels,n.outChannels]}}),d=BL({a:m?l:u,b:m?u:l,transposeA:!m,transposeB:!1,backend:r,bias:i,activation:c,preluActivationWeights:a,leakyreluAlpha:s});h=$({inputs:{x:d},backend:r,attrs:{shape:n.outShape}}),g.push(l),g.push(u),g.push(d)}for(let e of g)r.disposeIntermediateTensorInfo(e);return h}function Az({x:e,filter:t,convInfo:n,backend:r,bias:i=null,preluActivationWeights:a=null,leakyreluAlpha:o=0,activation:s=null}){let{filterWidth:c,filterHeight:l,inChannels:u,outWidth:d,outHeight:f,dataFormat:p}=n,m=p===`channelsLast`,h=c*l*u,g=f*d,_=[n.batchSize,h,g],v=[];if(a!=null){let e=Oz(a.shape,m);e!=null&&(a=$({inputs:{x:a},backend:r,attrs:{shape:e}}),v.push(a))}if(i!=null){let e=Oz(i.shape,m);e!=null&&(i=$({inputs:{x:i},backend:r,attrs:{shape:e}}),v.push(i))}let y=$({inputs:{x:t},backend:r,attrs:{shape:[1,h,k(t.shape)/h]}});v.push(y);let b=new Dz(_,n),x=[e.shape,[n.padInfo.top,n.padInfo.left],[n.strideHeight,n.strideWidth],[n.dilationHeight,n.dilationWidth],[n.inChannels],[n.filterWidth*n.inChannels],[n.outWidth]],S=r.runWebGLProgram(b,[e],`float32`,x),C=$({inputs:{x:S},backend:r,attrs:{shape:_}});v.push(S),v.push(C);let w=i!=null,T=a!=null,E=s===`leakyrelu`,ee=s?vL(s,!0):null,te=new yL(m?C.shape:y.shape,m?y.shape:C.shape,m?[n.batchSize,g,n.outChannels]:[n.batchSize,n.outChannels,g],!0,!1,w,ee,T,E),ne=m?[C,y]:[y,C];if(i&&ne.push(i),T&&ne.push(a),E){let e=r.makeTensorInfo([],`float32`,Da(o,`float32`));ne.push(e),v.push(e)}let re=r.runWebGLProgram(te,ne,`float32`),ie=$({inputs:{x:re},backend:r,attrs:{shape:n.outShape}});v.push(re);for(let e of v)r.disposeIntermediateTensorInfo(e);return ie}function jz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:o,pad:s,dataFormat:c,dilations:l,dimRoundingMode:u}=r,d=nc(c),f=Vr(i.shape,a.shape,o,l,s,u,!1,d),p;if(f.filterHeight===1&&f.filterWidth===1&&f.dilationHeight===1&&f.dilationWidth===1&&f.strideHeight===1&&f.strideWidth===1&&(f.padInfo.type===`SAME`||f.padInfo.type===`VALID`))p=kz({x:i,filter:a,convInfo:f,backend:n});else if(f.strideWidth<=2&&d===`channelsLast`&&j().getBool(`WEBGL_EXP_CONV`)){let e=new Ez(f),t=[[f.padInfo.top,f.padInfo.left],[f.strideHeight,f.strideWidth],[f.dilationHeight,f.dilationWidth],[f.inHeight,f.inWidth]];p=n.runWebGLProgram(e,[i,a],`float32`,t)}else if(j().getBool(`WEBGL_CONV_IM2COL`))p=Az({x:i,filter:a,convInfo:f,backend:n});else{let e=new wz(f);p=n.runWebGLProgram(e,[i,a],`float32`)}let m=$({inputs:{x:p},backend:n,attrs:{shape:f.outShape}});return n.disposeIntermediateTensorInfo(p),m}var Mz={kernelName:Ec,backendName:`webgl`,kernelFunc:jz},Nz=class{constructor(e){this.variableNames=[`x`,`dy`],this.outputShape=e.filterShape;let t=e.strideHeight,n=e.strideWidth,r=e.padInfo.top,i=e.padInfo.left,a=e.dataFormat===`channelsLast`;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int wR = coords.x;
        int wC = coords.y;
        int d1 = coords.z;
        int d2 = coords.w;

        // Convolve x(?, ?, d1) with dy(:, :, d2) to get dw(wR, wC, d1, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int b = 0; b < ${e.batchSize}; b++) {
          for (int yR = 0; yR < ${e.outHeight}; yR++) {
            int xR = wR + yR * ${t} - ${r};

            if (xR < 0 || xR >= ${e.inHeight}) {
              continue;
            }

            for (int yC = 0; yC < ${e.outWidth}; yC++) {
              int xC = wC + yC * ${n} - ${i};

              if (xC < 0 || xC >= ${e.inWidth}) {
                continue;
              }

              ${a?`float dyValue = getDy(b, yR, yC, d2);
              float xValue = getX(b, xR, xC, d1);
              dotProd += (xValue * dyValue);`:`float dyValue = getDy(b, d2, yR, yC);
              float xValue = getX(b, d1, xR, xC);
              dotProd += (xValue * dyValue);`}
            }
          }
        }
        setOutput(dotProd);
      }
    `}},Pz=class{constructor(e){this.variableNames=[`dy`,`W`],this.outputShape=e.inShape;let t=e.filterHeight,n=e.filterWidth,r=e.strideHeight,i=e.strideWidth,a=e.dataFormat===`channelsLast`,o=t-1-e.padInfo.top,s=n-1-e.padInfo.left,c=a?1:2,l=a?2:3,u=a?3:1;this.userCode=`
      const ivec2 pads = ivec2(${o}, ${s});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[${u}];

        ivec2 dyCorner = ivec2(coords[${c}], coords[${l}]) - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${t}; wR++) {
          float dyR = float(dyRCorner + wR) / ${r}.0;

          if (dyR < 0.0 || dyR >= ${e.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          int wRPerm = ${t} - 1 - wR;

          for (int wC = 0; wC < ${n}; wC++) {
            float dyC = float(dyCCorner + wC) / ${i}.0;

            if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            int wCPerm = ${n} - 1 - wC;

            for (int d2 = 0; d2 < ${e.outChannels}; d2++) {

              if (${a}) {
                float xValue = getDy(batch, idyR, idyC, d2);
                float wValue = getW(wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              } else {
                float xValue = getDy(batch, d2, idyR, idyC);
                float wValue = getW(wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              }

            }
          }
        }
        setOutput(dotProd);
      }
    `}},Fz=class{constructor(e){this.variableNames=[`x`,`dy`],this.outputShape=e.filterShape;let t=e.strideDepth,n=e.strideHeight,r=e.strideWidth,i=e.padInfo.front,a=e.padInfo.top,o=e.padInfo.left;this.userCode=`
      void main() {
        ivec5 coords = getOutputCoords();
        int wF = coords.x;
        int wR = coords.y;
        int wC = coords.z;
        int d1 = coords.w;
        int d2 = coords.u;

        float dotProd = 0.0;

        for (int b = 0; b < ${e.batchSize}; b++) {
          for (int yF = 0; yF < ${e.outDepth}; yF++) {
            int xF = wF + yF * ${t} - ${i};

            if (xF < 0 || xF >= ${e.inDepth}) {
              continue;
            }

            for (int yR = 0; yR < ${e.outHeight}; yR++) {
              int xR = wR + yR * ${n} - ${a};

              if (xR < 0 || xR >= ${e.inHeight}) {
                continue;
              }

              for (int yC = 0; yC < ${e.outWidth}; yC++) {
                int xC = wC + yC * ${r} - ${o};

                if (xC < 0 || xC >= ${e.inWidth}) {
                  continue;
                }

                float dyValue = getDy(b, yF, yR, yC, d2);
                float xValue = getX(b, xF, xR, xC, d1);
                dotProd += (xValue * dyValue);
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}},Iz=class{constructor(e){this.variableNames=[`dy`,`W`],this.outputShape=e.inShape;let t=e.filterDepth,n=e.filterHeight,r=e.filterWidth,i=e.strideDepth,a=e.strideHeight,o=e.strideWidth,s=t-1-e.padInfo.front,c=n-1-e.padInfo.top,l=r-1-e.padInfo.left;this.userCode=`
      const ivec3 pads = ivec3(${s}, ${c}, ${l});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int d1 = coords.u;


        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyFCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        float dotProd = 0.0;
        for (int wF = 0; wF < ${t}; wF++) {
          float dyF = float(dyFCorner + wF) / ${i}.0;

          if (dyF < 0.0 || dyF >= ${e.outDepth}.0 || fract(dyF) > 0.0) {
            continue;
          }
          int idyF = int(dyF);

          int wFPerm = ${t} - 1 - wF;

          for (int wR = 0; wR < ${n}; wR++) {
            float dyR = float(dyRCorner + wR) / ${a}.0;

            if (dyR < 0.0 || dyR >= ${e.outHeight}.0 ||
              fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            int wRPerm = ${n} - 1 - wR;

            for (int wC = 0; wC < ${r}; wC++) {
              float dyC = float(dyCCorner + wC) / ${o}.0;

              if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              int wCPerm = ${r} - 1 - wC;

              for (int d2 = 0; d2 < ${e.outChannels}; d2++) {
                float xValue = getDy(batch, idyF, idyR, idyC, d2);
                float wValue = getW(wFPerm, wRPerm, wCPerm, d1, d2);
                dotProd += xValue * wValue;
              }
            }
          }
        }
        setOutput(dotProd);
      }
    `}};function Lz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,pad:s,dataFormat:c,dimRoundingMode:l,filterShape:u}=r,d=nc(c),f=new Nz(Vr(i.shape,u,o,1,s,l,!1,d));return n.runWebGLProgram(f,[i,a],`float32`)}var Rz={kernelName:ya,backendName:`webgl`,kernelFunc:Lz},zz=class{constructor(e){this.variableNames=[`dy`,`W`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`strides`,type:`vec2`}],this.outputShape=e.inShape,this.enableShapeUniforms=RP(this.outputShape.length);let t=e.filterHeight,n=e.filterWidth,r=t-1-e.padInfo.top,i=n-1-e.padInfo.left;this.userCode=`
      const ivec2 pads = ivec2(${r}, ${i});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[3];

        ivec2 dyCorner = ivec2(coords[1], coords[2]) - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        vec4 result = vec4(0.);
        for (int wR = 0; wR < ${t}; wR++) {
          float dyR = float(dyRCorner + wR) / strides[0];
          if (dyR < 0.0 || dyR >= ${e.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);
          int wRPerm = ${t} - 1 - wR;

          for (int wC = 0; wC < ${n}; wC++) {
            int wCPerm = ${n} - 1 - wC;

            float dyC = float(dyCCorner + wC) / strides[1];
            bool idyCVal = (dyC >= 0.0) && (dyC < ${e.outWidth}.0)
              && (fract(dyC) == 0.0);
            int idyC = int(dyC);

            float dyC2 = float(dyCCorner + wC + 1) / strides[1];
            bool idyCVal2 = (dyC2 >= 0.0) && (dyC2 < ${e.outWidth}.0)
              && (fract(dyC2) == 0.0);
            int idyC2 = int(dyC2);

            if (idyCVal && idyCVal2) {
              for (int d2 = 0; d2 < ${e.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC, d2);
                vec4 dySample2 = (idyC / 2 == idyC2 / 2) ?
                  dySample : getDy(batch, idyR, idyC2, d2);

                vec2 dyValue = mod(float(idyC), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.xy += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));

                dyValue = mod(float(idyC2), 2.) == 0. ?
                  dySample2.xy : dySample2.zw;
                result.zw += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            } else if (idyCVal) {
              for (int d2 = 0; d2 < ${e.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC, d2);
                vec2 dyValue = mod(float(idyC), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.xy += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            } else if (idyCVal2) {
              for (int d2 = 0; d2 < ${e.outChannels}; d2 += 2) {
                vec4 wValue = getW(wRPerm, wCPerm, d1, d2);
                vec4 dySample = getDy(batch, idyR, idyC2, d2);
                vec2 dyValue = mod(float(idyC2), 2.) == 0. ?
                  dySample.xy : dySample.zw;
                result.zw += vec2(dot(dyValue, wValue.xy),
                  dot(dyValue, wValue.zw));
              }
            }
          }
        }
        setOutput(result);
      }
    `}};function Bz(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{inputShape:o,strides:s,pad:c,dataFormat:l,dimRoundingMode:u}=r,d=nc(l),f=Vr(o,a.shape,s,1,c,u,!1,d);if(j().getBool(`WEBGL_PACK_CONV2DTRANSPOSE`)&&d===`channelsLast`){let e=[[f.strideHeight,f.strideWidth]],t=new zz(f);return n.runWebGLProgram(t,[i,a],`float32`,e)}else{let e=new Pz(f);return n.runWebGLProgram(e,[i,a],`float32`)}}var Vz={kernelName:ss,backendName:`webgl`,kernelFunc:Bz};function Hz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:o,pad:s,dilations:c}=r,l=new Tz(st(i.shape,a.shape,o,c,s));return n.runWebGLProgram(l,[i,a],`float32`)}var Uz={kernelName:Kc,backendName:`webgl`,kernelFunc:Hz};function Wz(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,pad:s,filterShape:c}=r,l=new Fz(st(i.shape,c,o,1,s));return n.runWebGLProgram(l,[i,a],`float32`)}var Gz={kernelName:ka,backendName:`webgl`,kernelFunc:Wz};function Kz(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{pad:o,strides:s,inputShape:c}=r,l=new Iz(st(c,a.shape,s,1,o));return n.runWebGLProgram(l,[i,a],`float32`)}var qz={kernelName:Ya,backendName:`webgl`,kernelFunc:Kz},Jz={kernelName:`Cos`,backendName:`webgl`,kernelFunc:Q({opSnippet:gL+`
  return cos(x);
`,packedOpSnippet:`
  vec4 result = cos(x);
  bvec4 isNaN = isnan(x);
  ${nL}
  return result;
`})},Yz={kernelName:vs,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  float e2x = exp(-x);
  return (e2x + 1.0 / e2x) / 2.0;
`})},Xz=class{constructor(e,t,n,r,i){this.variableNames=[`Image`,`Boxes`,`BoxInd`],this.outputShape=[];let[a,o,s,c]=e,[l]=t,[u,d]=n;this.outputShape=[l,u,d,c];let f=+(r===`bilinear`),[p,m]=[`${o-1}.0`,`${s-1}.0`],[h,g,_]=u>1?[`${(o-1)/(u-1)}`,`(y2-y1) * height_ratio`,`y1*${p} + float(y)*(height_scale)`]:[`0.0`,`0.0`,`0.5 * (y1+y2) * ${p}`],[v,y,b]=d>1?[`${(s-1)/(d-1)}`,`(x2-x1) * width_ratio`,`x1*${m} + float(x)*(width_scale)`]:[`0.0`,`0.0`,`0.5 * (x1+x2) * ${m}`];this.userCode=`
      const float height_ratio = float(${h});
      const float width_ratio = float(${v});
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int y = coords[1];
        int x = coords[2];
        int d = coords[3];

        // get box vals
        float y1 = getBoxes(b,0);
        float x1 = getBoxes(b,1);
        float y2 = getBoxes(b,2);
        float x2 = getBoxes(b,3);

        // get image in batch index
        int bInd = round(getBoxInd(b));
        if(bInd < 0 || bInd >= ${a}) {
          return;
        }

        float height_scale = ${g};
        float width_scale = ${y};

        float in_y = ${_};
        if( in_y < 0.0 || in_y > ${p} ) {
          setOutput(float(${i}));
          return;
        }
        float in_x = ${b};
        if( in_x < 0.0 || in_x > ${m} ) {
          setOutput(float(${i}));
          return;
        }

        vec2 sourceFracIndexCR = vec2(in_x,in_y);
        if(${f} == 1) {
          // Compute the four integer indices.
          ivec2 sourceFloorCR = ivec2(sourceFracIndexCR);
          ivec2 sourceCeilCR = ivec2(ceil(sourceFracIndexCR));

          float topLeft = getImage(b, sourceFloorCR.y, sourceFloorCR.x, d);
          float bottomLeft = getImage(b, sourceCeilCR.y, sourceFloorCR.x, d);
          float topRight = getImage(b, sourceFloorCR.y, sourceCeilCR.x, d);
          float bottomRight = getImage(b, sourceCeilCR.y, sourceCeilCR.x, d);

          vec2 fracCR = sourceFracIndexCR - vec2(sourceFloorCR);

          float top = topLeft + (topRight - topLeft) * fracCR.x;
          float bottom = bottomLeft + (bottomRight - bottomLeft) * fracCR.x;
          float newValue = top + (bottom - top) * fracCR.y;
          setOutput(newValue);
        } else {
          // Compute the coordinators of nearest neighbor point.
          ivec2 sourceNearestCR = ivec2(floor(
            sourceFracIndexCR + vec2(0.5,0.5)));
          float newValue = getImage(b, sourceNearestCR.y, sourceNearestCR.x, d);
          setOutput(newValue);
        }
      }
    `}},Zz={kernelName:_o,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{image:i,boxes:a,boxInd:o}=t,{cropSize:s,method:c,extrapolationValue:l}=r,u=new Xz(i.shape,a.shape,s,c,l);return n.runWebGLProgram(u,[i,a,o],`float32`)}},Qz;(function(e){e.Prod=`*`,e.Sum=`+`})(Qz||={});var $z=class{constructor(e,t,n,r){this.op=e,this.outputShape=t,this.variableNames=[`x`],this.customUniforms=[{name:`index`,type:`float`}];let i=this.outputShape.length,a=this.op===Qz.Prod?`1.0`:`0.0`,o=n?a:`getX(${eB(i,`coords`,this.op)})`,s=this.outputShape[this.outputShape.length-1],c=``,l=``;n?(c=r?`end != ${s-1}`:`end != 0`,l=r?`end + 1`:`end - 1`):(c=r?`end + pow2 < ${s}`:`end >= pow2`,l=r?`end + pow2`:`end - pow2`),this.userCode=`
      void main() {
        ${kP(i)} coords = getOutputCoords();
        int end = ${tB(i,`coords`,this.op)};
        float val = ${o};
        int pow2 = int(pow(2.0, index));
        if (${c}) {
          int idx = ${l};
          ${tB(i,`coords`,this.op)} = idx;
          val ${this.op}= getX(${eB(i,`coords`,this.op)});
        }
        setOutput(val);
      }
    `}};function eB(e,t,n){if(e===1)return`${t}`;if(e===2)return`${t}.x, ${t}.y`;if(e===3)return`${t}.x, ${t}.y, ${t}.z`;if(e===4)return`${t}.x, ${t}.y, ${t}.z, ${t}.w`;throw Error(`Cumulative ${n} for rank ${e} is not yet supported`)}function tB(e,t,n){if(e===1)return`${t}`;if(e===2)return`${t}.y`;if(e===3)return`${t}.z`;if(e===4)return`${t}.w`;throw Error(`Cumulative ${n} for rank ${e} is not yet supported`)}function nB(e,t,n,r,i,a){let o=t.shape.length,s=Zt([r],o),c=t;s!=null&&(c=RL({inputs:{x:t},backend:n,attrs:{perm:s}}));let l=or(1,o)[0];if(l!==o-1)throw Error(`WebGL cumprod shader expects an inner-most axis=${t.shape.length-1} but got axis=${r}`);let u=c.shape[l],d=iL({inputs:{x:c},backend:n});for(let t=0;t<=Math.ceil(Math.log2(u))-1;t++){let r=new $z(e,c.shape,!1,a),i=[[t]],o=d;d=n.runWebGLProgram(r,[d],d.dtype,i),n.disposeIntermediateTensorInfo(o)}if(i){let t=new $z(e,c.shape,i,a),r=d;d=n.runWebGLProgram(t,[d],d.dtype),n.disposeIntermediateTensorInfo(r)}if(s!=null){let e=Ul(s),t=RL({inputs:{x:d},backend:n,attrs:{perm:e}});return n.disposeIntermediateTensorInfo(d),n.disposeIntermediateTensorInfo(c),t}return d}function rB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,exclusive:o,reverse:s}=r;return nB(Qz.Prod,i,n,a,o,s)}var iB={kernelName:ao,backendName:`webgl`,kernelFunc:rB};function aB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,exclusive:o,reverse:s}=r;return nB(Qz.Sum,i,n,a,o,s)}var oB={kernelName:Bi,backendName:`webgl`,kernelFunc:aB};function sB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,weights:a}=t,{size:o,binaryOutput:s}=r;if(i.shape.length===1){let e=vF(n.readSync(i.dataId),n.readSync(a.dataId),a.dtype,a.shape,o);return n.makeTensorInfo([o],a.dtype,e)}else if(i.shape.length===2){let e=yF(n.bufferSync(i),n.bufferSync(a),o,s);return n.makeTensorInfo(e.shape,a.dtype,e.values)}throw Error(`Error in denseBincount: input must be at most rank 2, but got rank${i.shape.length}.`)}var cB={kernelName:rl,backendName:`webgl`,kernelFunc:sB},lB=class{constructor(e,t,n){this.variableNames=[`x`],this.outputShape=[],this.outputShape=e,this.blockSize=t,this.dataFormat=n,this.userCode=`
    void main() {
      ivec4 coords = getOutputCoords();
      int b = coords[0];
      int h = ${this.getHeightCoordString()};
      int w = ${this.getWidthCoordString()};
      int d = ${this.getDepthCoordString()};

      int in_h = h / ${t};
      int offset_h = imod(h, ${t});
      int in_w = w / ${t};
      int offset_w = imod(w, ${t});
      int offset_d = (offset_h * ${t} + offset_w) *
        ${this.getOutputDepthSize()};
      int in_d = d + offset_d;

      float result = ${this.getInputSamplingString()};
      setOutput(result);
    }
  `}getHeightCoordString(){return this.dataFormat===`NHWC`?`coords[1]`:`coords[2]`}getWidthCoordString(){return this.dataFormat===`NHWC`?`coords[2]`:`coords[3]`}getDepthCoordString(){return this.dataFormat===`NHWC`?`coords[3]`:`coords[1]`}getOutputDepthSize(){return this.dataFormat===`NHWC`?this.outputShape[3]:this.outputShape[1]}getInputSamplingString(){return this.dataFormat===`NHWC`?`getX(b, in_h, in_w, in_d)`:`getX(b, in_d, in_h, in_w)`}};function uB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockSize:a,dataFormat:o}=r,s=i.shape[0],c=o===`NHWC`?i.shape[1]:i.shape[2],l=o===`NHWC`?i.shape[2]:i.shape[3],u=o===`NHWC`?i.shape[3]:i.shape[1],d=c*a,f=l*a,p=u/(a*a),m=new lB(o===`NHWC`?[s,d,f,p]:[s,p,d,f],a,o);return n.runWebGLProgram(m,[i],i.dtype)}var dB={kernelName:Pl,backendName:`webgl`,kernelFunc:uB},fB=class{constructor(e,t=!1,n=null,r=!1,i=!1){this.variableNames=[`x`,`W`],this.customUniforms=[{name:`pads`,type:`ivec2`},{name:`strides`,type:`ivec2`},{name:`dilations`,type:`ivec2`},{name:`inDims`,type:`ivec2`}],this.outputShape=e.outShape,this.enableShapeUniforms=RP(this.outputShape.length);let a=e.filterHeight,o=e.filterWidth,s=e.outChannels/e.inChannels,c=``,l=``;n&&(c=r?`float activation(float a) {
          float b = getPreluActivationWeightsAtOutCoords();
          ${n}
        }`:i?`float activation(float a) {
          float b = getLeakyreluAlphaAtOutCoords();
          ${n}
        }`:`
          float activation(float x) {
            ${n}
          }
        `,l=`result = activation(result);`);let u=t?`result += getBiasAtOutCoords();`:``;t&&this.variableNames.push(`bias`),r&&this.variableNames.push(`preluActivationWeights`),i&&this.variableNames.push(`leakyreluAlpha`),this.userCode=`
      ${c}

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        ivec2 xRCCorner = coords.yz * strides - pads;
        int d2 = coords.w;
        int d1 = d2 / ${s};
        int q = d2 - d1 * ${s};

        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        // Convolve x(?, ?, d1) with w(:, :, d1, q) to get y(yR, yC, d2).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        // TO DO(dsmilkov): Flatten the two for loops and vec4 the operations.
        for (int wR = 0; wR < ${a}; wR++) {
          int xR = xRCorner + wR * dilations[0];

          if (xR < 0 || xR >= inDims[0]) {
            continue;
          }

          for (int wC = 0; wC < ${o}; wC++) {
            int xC = xCCorner + wC * dilations[1];

            if (xC < 0 || xC >= inDims[1]) {
              continue;
            }

            float xVal = getX(batch, xR, xC, d1);
            float wVal = getW(wR, wC, d1, q);
            dotProd += xVal * wVal;
          }
        }

        float result = dotProd;
        ${u}
        ${l}
        setOutput(result);
      }
    `}},pB=class{constructor(e,t=!1,n=null,r=!1,i=!1){this.variableNames=[`x`,`W`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`pads`,type:`ivec2`},{name:`strides`,type:`ivec2`},{name:`dilations`,type:`ivec2`},{name:`inDims`,type:`ivec2`}],this.outputShape=e.outShape,this.enableShapeUniforms=RP(this.outputShape.length);let a=e.outChannels/e.inChannels,o=e.padInfo.left,s=e.strideWidth,c=e.dilationWidth,l=e.filterHeight,u=e.filterWidth,d=u,f=`
      int xR; int xC; int xCOffset;
      vec4 wTexel; vec4 previous; vec4 final;`;for(let e=0;e<u;e++)f+=`
          vec4 xTexelC${e*2};
          int xTexelC${e*2}Ready;
          vec4 xTexelC${e*2+1};
          int xTexelC${e*2+1}Ready;
          vec4 xC${e};`;f+=`
    for (int r = 0; r < ${l}; r++) {
      `;for(let e=0;e<u;e++)f+=`
          xTexelC${e*2} = vec4(0.0);
          xTexelC${e*2}Ready = 0;
          xTexelC${e*2+1} = vec4(0.0);
          xTexelC${e*2+1}Ready = 0;
          xC${e} = vec4(0.0);`;f+=`
        xR = xRCorner + r * dilations[0];
        if (xR >=0 && xR < inDims[0]) {
      `;for(let e=0;e<(d+1)/2;e++){let t=e*2;if(f+=`
          xC = xCCorner + ${t*c};
          `,s===1){if(t<u&&(o%2==1?(f+=`
                xCOffset = xC + 1;
                if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${t}Ready == 0) {
                  xTexelC${t} = getX(batch, xR, xCOffset, d1);

                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${t}.zw = vec2(0.0);
                  }
                  xTexelC${t}Ready = 1;
                }
              `,c===1&&t>0?f+=`
                xC${t} = vec4(xTexelC${t-2}.zw, xTexelC${t}.xy);
                `:f+=`
                  xCOffset = xC + 1 - 2;

                  if (xCOffset >= 0 && xCOffset < inDims[1]) {
                    previous = getX(batch, xR, xCOffset, d1);

                    // Need to manually clear unused channels in case
                    // we're reading from recycled texture.
                    if (xCOffset + 1 >= inDims[1]) {
                      previous.zw = vec2(0.0);
                    }

                    xC${t} = vec4(previous.zw, xTexelC${t}.xy);
                  } else {
                    xC${t} = vec4(0.0, 0.0, xTexelC${t}.xy);
                  }
                  `):f+=`
                if (xC >= 0 && xC < inDims[1] && xTexelC${t}Ready == 0) {
                  xTexelC${t} = getX(batch, xR, xC, d1);
                  if (xC + 1 >= inDims[1]) {
                    xTexelC${t}.zw = vec2(0.0);
                  }
                  xTexelC${t}Ready = 1;
                }

                xC${t} = xTexelC${t};
                `,t+1<u)){let e=o%2==0?ua(c):c;c%2==0&&o%2==1||c%2!=0&&o%2!=1?(f+=`
                  xCOffset = xC + imod(pads[1], 2) + ${e};

                  if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${t+1}Ready == 0) {
                    xTexelC${t+1} = getX(batch, xR, xCOffset, d1);

                    // Need to manually clear unused channels in case
                    // we're reading from recycled texture.
                    if (xCOffset + 1 >= inDims[1]) {
                      xTexelC${t+1}.zw = vec2(0.0);
                    }
                    xTexelC${t+1}Ready = 1;
                  }
                  `,c>1?f+=`
                    xCOffset -= 2;
                    if (xCOffset >= 0 && xCOffset < inDims[1]) {
                     previous = getX(batch, xR, xCOffset, d1);
                     xC${t+1} = vec4(previous.zw, xTexelC${t+1}.xy);
                    } else {
                     xC${t+1} = vec4(0.0, 0.0, xTexelC${t+1}.xy);
                    }
                    `:f+=`
                    xC${t+1} = vec4(xTexelC${t}.zw, xTexelC${t+1}.xy);
                    `):e===1?f+=`
                    xC${t+1} = xTexelC${t};
                    `:f+=`
                    xCOffset = xC + ${e};

                    if (xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${t+1}Ready == 0) {
                      xTexelC${t+1} = getX(batch, xR, xCOffset, d1);
                      if (xCOffset + 1 >= inDims[1]) {
                        xTexelC${t+1}.zw = vec2(0.0);
                      }
                      xTexelC${t+1}Ready = 1;
                    }

                    xC${t+1} = xTexelC${t+1};
                    `}}else t<u&&(o%2==1?(f+=`
                xCOffset = xC + 1 - strides[1];
                if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${t}Ready == 0) {
                  xTexelC${t} = getX(batch, xR, xCOffset, d1);
                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${t}.zw = vec2(0.0);
                  }
                  xTexelC${t}Ready = 1;
                }

                if(xC + 1 >= 0 && xC + 1 < inDims[1] && xTexelC${t+1}Ready == 0) {
                  xTexelC${t+1} = getX(batch, xR, xC + 1, d1);
                  // Need to manually clear unused channels in case
                  // we're reading from recycled texture.
                  if (xC + 2 >= inDims[1]) {
                    xTexelC${t+1}.zw = vec2(0.0);
                  }
                  xTexelC${t+1}Ready = 1;
                }

                xC${t} = vec4(xTexelC${t}.zw, xTexelC${t+1}.zw);
              `,t+1<u&&(f+=`
                  final = vec4(0.0);
                  xCOffset = xC + 1 + strides[1];
                  if(xCOffset >= 0 && xCOffset < inDims[1]) {
                    final = getX(batch, xR, xCOffset, d1);
                  }
                  xC${t+1} = vec4(xTexelC${t+1}.xy, final.xy);
                `)):(f+=`
                if(xC >= 0 && xC < inDims[1] && xTexelC${t}Ready == 0) {
                  xTexelC${t} = getX(batch, xR, xC, d1);
                  if (xC + 1 >= inDims[1]) {
                    xTexelC${t}.zw = vec2(0.0);
                  }
                  xTexelC${t}Ready = 1;
                }

                xCOffset = xC + strides[1];
                if(xCOffset >= 0 && xCOffset < inDims[1] && xTexelC${t+1}Ready == 0) {
                  xTexelC${t+1} = getX(batch, xR, xCOffset, d1);
                  if (xCOffset + 1 >= inDims[1]) {
                    xTexelC${t+1}.zw = vec2(0.);
                  }
                  xTexelC${t+1}Ready = 1;
                }

                xC${t} = vec4(
                  xTexelC${t}.xy, xTexelC${t+1}.xy);
              `,t+1<u&&(f+=`
                  xC${t+1} = vec4(xTexelC${t}.zw, xTexelC${t+1}.zw);
                `)));t<u&&(f+=`
            wTexel = getW(r, ${t}, d1, q);
            dotProd += xC${t} * vec4(wTexel.xz, wTexel.xz);
          `,t+1<u&&(f+=`
              wTexel = getW(r, ${t+1}, d1, q);
              dotProd += xC${t+1} * vec4(wTexel.xz, wTexel.xz);
            `))}f+=`
    }
  `,f+=`
      }
    `;let p=``,m=``;n&&(p=r?`vec4 activation(vec4 a) {
          vec4 b = getPreluActivationWeightsAtOutCoords();
          ${n}
        }`:i?`vec4 activation(vec4 a) {
          vec4 b = getLeakyreluAlphaAtOutCoords();
          ${n}
        }`:`vec4 activation(vec4 x) {
          ${n}
        }`,m=`result = activation(result);`);let h=t?`result += getBiasAtOutCoords();`:``;t&&this.variableNames.push(`bias`),r&&this.variableNames.push(`preluActivationWeights`),i&&this.variableNames.push(`leakyreluAlpha`),this.userCode=`
      ${p}

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        ivec2 xRCCorner = coords.yz * strides - pads;
        int d2 = coords.w;
        int d1 = d2 / ${a};
        int q = d2 - d1 * ${a};
        int xRCorner = xRCCorner.x;
        int xCCorner = xRCCorner.y;

        //intialize dotProd with a small epsilon seems to reduce GPU accuracy loss.
        vec4 dotProd = vec4(0.000000000000001);

        ${f}

        vec4 result = dotProd - vec4(0.000000000000001);
        ${h}
        ${m}
        setOutput(result);
      }
    `}};function mB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:s,pad:c,dilations:l,dimRoundingMode:u}=r,d=l;d??=[1,1],o(Dt(s,d),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${s} and dilations '${d}'`);let f=Vr(i.shape,a.shape,s,d,c,u,!0),p;p=j().getBool(`WEBGL_PACK_DEPTHWISECONV`)&&f.strideWidth<=2&&f.outChannels/f.inChannels===1?new pB(f):new fB(f);let m=[[f.padInfo.top,f.padInfo.left],[f.strideHeight,f.strideWidth],[f.dilationHeight,f.dilationWidth],[f.inHeight,f.inWidth]];return n.runWebGLProgram(p,[i,a],`float32`,m)}var hB={kernelName:ca,backendName:`webgl`,kernelFunc:mB},gB=class{constructor(e){this.variableNames=[`x`,`dy`],this.outputShape=e.filterShape;let t=e.strideHeight,n=e.strideWidth,r=e.padInfo.top,i=e.padInfo.left,a=e.outChannels/e.inChannels;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int wR = coords.x;
        int wC = coords.y;
        int d1 = coords.z;
        int dm = coords.w;
        int d2 = d1 * ${a} + dm;

        float dotProd = 0.0;

        // TO DO: Vec4 over the batch size
        for (int b = 0; b < ${e.batchSize}; b++) {
          for (int yR = 0; yR < ${e.outHeight}; yR++) {
            int xR = wR + yR * ${t} - ${r};

            if (xR < 0 || xR >= ${e.inHeight}) {
              continue;
            }

            for (int yC = 0; yC < ${e.outWidth}; yC++) {
              int xC = wC + yC * ${n} - ${i};

              if (xC < 0 || xC >= ${e.inWidth}) {
                continue;
              }

              float dyValue = getDy(b, yR, yC, d2);
              float xValue = getX(b, xR, xC, d1);
              dotProd += (xValue * dyValue);
            }
          }
        }
        setOutput(dotProd);
      }
    `}},_B=class{constructor(e){this.variableNames=[`dy`,`W`],this.outputShape=e.inShape;let t=e.filterHeight,n=e.filterWidth,r=e.strideHeight,i=e.strideWidth,a=t-1-e.padInfo.top,o=n-1-e.padInfo.left,s=e.outChannels/e.inChannels;this.userCode=`
      const ivec2 pads = ivec2(${a}, ${o});

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords[0];
        int d1 = coords[3];
        ivec2 dyCorner = coords.yz - pads;
        int dyRCorner = dyCorner.x;
        int dyCCorner = dyCorner.y;

        float dotProd = 0.0;

        for (int wR = 0; wR < ${t}; wR++) {
          float dyR = float(dyRCorner + wR) / ${r}.0;

          if (dyR < 0.0 || dyR >= ${e.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          int wRPerm = ${t} - 1 - wR;

          for (int wC = 0; wC < ${n}; wC++) {
            float dyC = float(dyCCorner + wC) / ${i}.0;

            if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            int wCPerm = ${n} - 1 - wC;

            // TO DO: Vec4 over the channelMul
            for (int dm = 0; dm < ${s}; dm++) {
              int d2 = d1 * ${s} + dm;
              float xValue = getDy(batch, idyR, idyC, d2);
              float wValue = getW(wRPerm, wCPerm, d1, dm);
              dotProd += xValue * wValue;
            }
          }
        }
        setOutput(dotProd);
      }
    `}};function vB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,dy:a}=t,{strides:o,dilations:s,pad:c,dimRoundingMode:l,filterShape:u}=r,d=new gB(Vr(i.shape,u,o,s,c,l,!0));return n.runWebGLProgram(d,[i,a],`float32`)}var yB={kernelName:wl,backendName:`webgl`,kernelFunc:vB};function bB(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,filter:a}=t,{strides:o,dilations:s,pad:c,dimRoundingMode:l,inputShape:u}=r,d=new _B(Vr(u,a.shape,o,s,c,l,!0));return n.runWebGLProgram(d,[i,a],`float32`)}var xB={kernelName:_r,backendName:`webgl`,kernelFunc:bB},SB=class{constructor(e){this.variableNames=[`X`],this.outputShape=[e,e],this.userCode=`
      void main() {
          ivec2 coords = getOutputCoords();
          float val = coords[0] == coords[1] ? getX(coords[0]) : 0.0;
          setOutput(val);
      }
    `}};function CB(e){let{inputs:t,backend:n}=e,{x:r}=t,i=[...r.shape,...r.shape],a=k(r.shape),o=$({inputs:{x:r},backend:n,attrs:{shape:[a]}}),s=new SB(a),c=n.runWebGLProgram(s,[o],o.dtype),l=$({inputs:{x:c},backend:n,attrs:{shape:i}});return n.disposeIntermediateTensorInfo(o),n.disposeIntermediateTensorInfo(c),l}var wB={kernelName:me,backendName:`webgl`,kernelFunc:CB},TB=class{constructor(e){this.variableNames=[`x`,`W`],this.outputShape=e.outShape;let{inHeight:t,inWidth:n,padInfo:r,strideHeight:i,strideWidth:a,filterHeight:o,filterWidth:s,dilationHeight:c,dilationWidth:l}=e,{top:u,left:d}=r;this.userCode=`
      const ivec2 strides = ivec2(${i}, ${a});
      const ivec2 pads = ivec2(${u}, ${d});
      const float neg_infinity = -3.4e38;

      void main() {
        ivec4 coords = getOutputCoords();
        int batch = coords.x;
        int d1 = coords.w;
        ivec2 outTopLeftCorner =
            coords.yz * strides - pads;
        int hBeg = outTopLeftCorner.x;
        int wBeg = outTopLeftCorner.y;

        float curVal = neg_infinity;
        for (int h = 0; h < ${o}; h++) {
          int hIn = hBeg + h * ${c};

          if (hIn >= 0 && hIn < ${t}) {
            for (int w = 0; w < ${s}; w++) {
              int wIn = wBeg + w * ${l};

              if (wIn >= 0 && wIn < ${n}) {
                float xVal = getX(batch, hIn, wIn, d1);
                float wVal = getW(h, w, d1);

                float val = xVal + wVal;
                if (val > curVal) {
                  curVal = val;
                }
              }
            }
          }
        }

        float result = curVal;
        setOutput(result);
      }
    `}};function EB(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a}=t,{strides:o,pad:s,dilations:c}=r,l=Zr(i.shape,a.shape,o,s,`NHWC`,c),u,d=new TB(l);u=n.runWebGLProgram(d,[i,a],`float32`);let f=$({inputs:{x:u},backend:n,attrs:{shape:l.outShape}});return n.disposeIntermediateTensorInfo(u),f}var DB={kernelName:ml,backendName:`webgl`,kernelFunc:EB};function OB(e){let{inputs:t,backend:n,attrs:r}=e,{equation:i}=r,a=t,{allDims:o,summedDims:s,idDims:c}=vd(i,a.length);bd(o.length,c,a);let{path:l,steps:u}=xd(s,c),d=u.length,f=null,p=o.length,m=[];for(let e=0;e<d;++e){for(let t of u[e]){let{permutationIndices:e,expandDims:r}=yd(p,c[t]),i;Sd(e)?i=a[t]:(i=RL({inputs:{x:a[t]},backend:n,attrs:{perm:e}}),m.push(i));let o=i.shape.slice();for(let e=0;e<r.length;++e)o.splice(r[e],0,1);qn(i.shape,o)||(i=$({inputs:{x:i},backend:n,attrs:{shape:o}}),m.push(i)),f===null?f=i:(f=CL({inputs:{a:i,b:f},backend:n}),m.push(f))}e<d-1&&(l[e]>=0&&(f=IL({inputs:{x:f},backend:n,attrs:{axis:l[e]-(o.length-p),keepDims:!1}}),m.push(f)),p--)}for(let e of m)e!==f&&n.disposeIntermediateTensorInfo(e);return f}var kB={kernelName:An,backendName:`webgl`,kernelFunc:OB},AB={kernelName:`Elu`,backendName:`webgl`,kernelFunc:Q({opSnippet:`return (x >= 0.0) ? x : (exp(x) - 1.0);`,packedOpSnippet:`
  vec4 result;

  result.r = (x.r >= 0.0) ? x.r : (exp(x.r) - 1.0);
  result.g = (x.g >= 0.0) ? x.g : (exp(x.g) - 1.0);
  result.b = (x.b >= 0.0) ? x.b : (exp(x.b) - 1.0);
  result.a = (x.a >= 0.0) ? x.a : (exp(x.a) - 1.0);

  return result;
`})},jB=`return (b >= 0.0) ? a : a * (b + 1.0);`,MB=`
  vec4 bGTEZero = vec4(greaterThanEqual(b, vec4(0.)));
  return (bGTEZero * a) + ((vec4(1.0) - bGTEZero) * (a * (b + vec4(1.0))));
`,NB={kernelName:b,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n}=e,{dy:r,y:i}=t,a=j().getBool(`WEBGL_PACK_BINARY_OPERATIONS`)?new rL(MB,r.shape,i.shape):new tL(jB,r.shape,i.shape);return n.runWebGLProgram(a,[r,i],r.dtype)}},PB={kernelName:zo,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a == b);`,packedOpSnippet:`
  return vec4(equal(a, b));
`,dtype:`bool`,cpuKernelImpl:wF})},FB={kernelName:`Erf`,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  // Error function is calculated approximately with elementary function.
  // See "Handbook of Mathematical Functions with Formulas,
  // Graphs, and Mathematical Tables", Abramowitz and Stegun.
  float p = ${ed};
  float a1 = ${td};
  float a2 = ${nd};
  float a3 = ${rd};
  float a4 = ${id};
  float a5 = ${ad};

  float sign = sign(x);
  x = abs(x);
  float t = 1.0 / (1.0 + p * x);
  return sign * (1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1)*t*exp(-x*x));
`})},IB=Q({opSnippet:gL+`
  return exp(x);
`,packedOpSnippet:`
  vec4 result = exp(x);
  bvec4 isNaN = isnan(x);
  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,cpuKernelImpl:TF,dtype:`float32`}),LB={kernelName:`Exp`,backendName:`webgl`,kernelFunc:IB};function RB(e){let{inputs:t,attrs:n,backend:r}=e,{dim:i}=n,{input:a}=t,s=a.shape.length,c=a.shape.slice(),l=i;return i<0&&(o(-(s+1)<=i,()=>`Axis must be in the interval [${-(s+1)}, ${s}]`),l=s+i+1),c.splice(l,0,1),$({inputs:{x:a},backend:r,attrs:{shape:c}})}var zB={kernelName:Vn,backendName:`webgl`,kernelFunc:RB},BB=`return exp(x) - 1.0;`,VB={kernelName:Ke,backendName:`webgl`,kernelFunc:Q({opSnippet:BB,packedOpSnippet:BB,cpuKernelImpl:EF})},HB=class{constructor(e,t,n){this.variableNames=[`real`,`imag`];let r=t[1];this.outputShape=t;let i=n?`2.0 * ${Math.PI}`:`-2.0 * ${Math.PI}`,a=n?`${r}.0`:`1.0`,o;if(e===`real`)o=`return real * expR - imag * expI;`;else if(e===`imag`)o=`return real * expI + imag * expR;`;else throw Error(`FFT component must be either "real" or "imag", got ${e}.`);this.userCode=`
      const float exponentMultiplier = ${i};

      float unaryOpComplex(float real, float expR, float imag, float expI) {
        ${o}
      }

      float mulMatDFT(int batch, int index) {
        float indexRatio = float(index) / float(${r});
        float exponentMultiplierTimesIndexRatio =
            exponentMultiplier * indexRatio;

        float result = 0.0;

        for (int i = 0; i < ${r}; i++) {
          // x = (-2|2 * PI / N) * index * i;
          float x = exponentMultiplierTimesIndexRatio * float(i);
          float expR = cos(x);
          float expI = sin(x);
          float real = getReal(batch, i);
          float imag = getImag(batch, i);

          result +=
              unaryOpComplex(real, expR, imag, expI) / ${a};
        }

        return result;
      }

      void main() {
        ivec2 coords = getOutputCoords();
        setOutput(mulMatDFT(coords[0], coords[1]));
      }
    `}};function UB(e,t,n){let r=n.texData.get(e.dataId),i=k(e.shape),a=e.shape[e.shape.length-1],o=i/a,s=$({inputs:{x:e},backend:n,attrs:{shape:[o,a]}}),c=s.shape,l=new HB(`real`,c,t),u=new HB(`imag`,c,t),d=[{dataId:r.complexTensorInfos.real.dataId,dtype:r.complexTensorInfos.real.dtype,shape:c},{dataId:r.complexTensorInfos.imag.dataId,dtype:r.complexTensorInfos.imag.dtype,shape:c}],f=n.runWebGLProgram(l,d,`float32`),p=n.runWebGLProgram(u,d,`float32`),m=oL({inputs:{real:f,imag:p},backend:n});n.disposeIntermediateTensorInfo(f),n.disposeIntermediateTensorInfo(p);let h=$({inputs:{x:m},backend:n,attrs:{shape:e.shape}});return n.disposeIntermediateTensorInfo(s),n.disposeIntermediateTensorInfo(m),h}function WB(e){let{inputs:t,backend:n}=e,{input:r}=t;return UB(r,!1,n)}var GB={kernelName:`FFT`,backendName:`webgl`,kernelFunc:WB},KB=class{constructor(e,t){this.outputShape=[],this.customUniforms=[{name:`value`,type:`float`}],this.variableNames=[`x`],this.outputShape=e,this.userCode=`
      void main() {
        // Input can be obtained from uniform value.
        setOutput(value);
      }
    `}};function qB(e){let{backend:t,attrs:n}=e,{shape:r,value:i}=n,{dtype:a}=n;if(a||=ls(i),a===`string`){let e=$i(a,k(r));return e.fill(i),t.makeTensorInfo(r,a,e)}else{let e=new KB(r,i),n=[[i]];return t.runWebGLProgram(e,[],a,n)}}var JB={kernelName:Qt,backendName:`webgl`,kernelFunc:qB},YB=class{constructor(e){this.variableNames=[`Image`],this.outputShape=[];let t=e[2];this.outputShape=e,this.userCode=`
        void main() {
          ivec4 coords = getOutputCoords();
          int x = coords[2];

          int coordX = ${t} - x - 1;
          float outputValue;
          if(coordX >= 0 && coordX < ${t}) {
            outputValue = getImage(coords[0], coords[1], coordX, coords[3]);
          } else {
            outputValue = getImage(coords[0], coords[1], coords[2], coords[3]);
          }
          setOutput(outputValue);
        }
    `}},XB={kernelName:sr,backendName:`webgl`,kernelFunc:({inputs:e,backend:t})=>{let{image:n}=e,r=t,i=new YB(n.shape);return r.runWebGLProgram(i,[n],n.dtype)}},ZB=`return floor(x);`,QB={kernelName:Wl,backendName:`webgl`,kernelFunc:Q({opSnippet:ZB,packedOpSnippet:ZB,cpuKernelImpl:DF})},$B={kernelName:ie,backendName:`webgl`,kernelFunc:_L({opSnippet:`
  float s = sign(a) * sign(b);
  int ia = round(a);
  int ib = round(b);
  if (ib != 0) {
    // Windows (D3D) wants guaranteed non-zero int division at compile-time.
    return float(idiv(ia, ib, s));
  } else {
    return NAN;
  }
`,packedOpSnippet:`
  ivec4 ia = round(a);
  ivec4 ib = round(b);
  bvec4 cond = notEqual(ib, ivec4(0));
  ivec4 result = ivec4(0);
  vec4 s = sign(a) * sign(b);

  // Windows (D3D) wants guaranteed non-zero int division at compile-time.
  if (cond[0]) {
    result[0] = idiv(ia[0], ib[0], s[0]);
  }
  if (cond[1]) {
    result[1] = idiv(ia[1], ib[1], s[1]);
  }
  if (cond[2]) {
    result[2] = idiv(ia[2], ib[2], s[2]);
  }
  if (cond[3]) {
    result[3] = idiv(ia[3], ib[3], s[3]);
  }
  return vec4(result);
`,dtype:`int32`})},eV=class{constructor(e){this.variableNames=[`A`];let t=NN(),[n,r]=e;this.outputShape=e,this.userCode=`
      void main() {
        ivec3 coords = getOutputCoords();
        int texR = coords[0];
        int texC = coords[1];
        int depth = coords[2];
        vec2 uv = (vec2(texC, texR) + halfCR) / vec2(${r}.0, ${n}.0);

        vec4 values = ${t.texture2D}(A, uv);
        float value;
        if (depth == 0) {
          value = values.r;
        } else if (depth == 1) {
          value = values.g;
        } else if (depth == 2) {
          value = values.b;
        } else if (depth == 3) {
          value = values.a;
        }

        setOutput(floor(value * 255.0 + 0.5));
      }
    `}},tV=class{constructor(e){this.variableNames=[`A`],this.packedInputs=!1,this.packedOutput=!0;let t=NN(),[n,r]=e;this.outputShape=e,this.userCode=`
      void main() {
        ivec3 coords = getOutputCoords();
        int texR = coords[0];
        int texC = coords[1];
        int depth = coords[2];

        vec4 result = vec4(0.);

        for(int row=0; row<=1; row++) {
          for(int col=0; col<=1; col++) {
            texC = coords[1] + row;
            depth = coords[2] + col;

            vec2 uv = (vec2(texC, texR) + halfCR) /
                       vec2(${r}.0, ${n}.0);
            vec4 values = ${t.texture2D}(A, uv);
            float value;
            if (depth == 0) {
              value = values.r;
            } else if (depth == 1) {
              value = values.g;
            } else if (depth == 2) {
              value = values.b;
            } else if (depth == 3) {
              value = values.a;
            }

            result[row * 2 + col] = floor(value * 255.0 + 0.5);
          }
        }

        ${t.output} = result;
      }
    `}},nV={kernelName:Kr,backendName:`webgl`,kernelFunc:aV},rV,iV=j().getBool(`CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU`);function aV(e){let{inputs:t,backend:n,attrs:r}=e,{pixels:i}=t,{numChannels:a}=r,o=typeof HTMLVideoElement<`u`&&i instanceof HTMLVideoElement,s=typeof HTMLImageElement<`u`&&i instanceof HTMLImageElement,[c,l]=o?[i.videoWidth,i.videoHeight]:[i.width,i.height],u=[l,c],d=[l,c,a];if(s||o){let e=j().getBool(`CANVAS2D_WILL_READ_FREQUENTLY_FOR_GPU`);(rV==null||e!==iV)&&(iV=e,rV=document.createElement(`canvas`).getContext(`2d`,{willReadFrequently:iV})),rV.canvas.width=c,rV.canvas.height=l,rV.drawImage(i,0,0,c,l),i=rV.canvas}let f=n.makeTensorInfo(u,`int32`);n.texData.get(f.dataId).usage=TM.PIXELS,n.gpgpu.uploadPixelDataToTexture(n.getTexture(f.dataId),i);let p=j().getBool(`WEBGL_PACK`)?new tV(d):new eV(d),m=n.runWebGLProgram(p,[f],`int32`);return n.disposeData(f.dataId),m}function oV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a,bias:o,preluActivationWeights:s}=t,{strides:c,pad:l,dataFormat:u,dilations:d,dimRoundingMode:f,activation:p,leakyreluAlpha:m}=r,h=nc(u),g=Vr(i.shape,a.shape,c,d,l,f,!1,h),_,v=[],y=o!=null,b=s!=null,x=p===`leakyrelu`,S=()=>{let e=[i,a],t=(e,t)=>{if(t===`NCHW`&&e.shape.length===1&&e.shape[0]!==1){let t=$({inputs:{x:e},backend:n,attrs:{shape:[e.shape[0],1,1]}});return v.push(t),t}return e};if(y&&e.push(t(o,u)),b&&e.push(t(s,u)),x){let t=n.makeTensorInfo([],`float32`,Da(m,`float32`));e.push(t),v.push(t)}return e};if(g.filterHeight===1&&g.filterWidth===1&&g.dilationHeight===1&&g.dilationWidth===1&&g.strideHeight===1&&g.strideWidth===1&&(g.padInfo.type===`SAME`||g.padInfo.type===`VALID`))_=kz({x:i,filter:a,convInfo:g,backend:n,bias:o,activation:p,preluActivationWeights:s,leakyreluAlpha:m});else if(g.strideWidth<=2&&h===`channelsLast`&&j().getBool(`WEBGL_EXP_CONV`)){let e=new Ez(g,y,p?vL(p,!0):null,b,x),t=[[g.padInfo.top,g.padInfo.left],[g.strideHeight,g.strideWidth],[g.dilationHeight,g.dilationWidth],[g.inHeight,g.inWidth]],r=S();_=n.runWebGLProgram(e,r,`float32`,t)}else if(j().getBool(`WEBGL_CONV_IM2COL`))_=Az({x:i,filter:a,convInfo:g,backend:n,bias:o,activation:p,preluActivationWeights:s,leakyreluAlpha:m});else{let e=new wz(g,y,p?vL(p,!1):null,b,x),t=S();_=n.runWebGLProgram(e,t,`float32`)}let C=$({inputs:{x:_},backend:n,attrs:{shape:g.outShape}});return v.push(_),v.forEach(e=>n.disposeIntermediateTensorInfo(e)),C}var sV={kernelName:Ir,backendName:`webgl`,kernelFunc:oV};function cV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,filter:a,bias:s,preluActivationWeights:c}=t,{strides:l,pad:u,dilations:d,dimRoundingMode:f,activation:p,leakyreluAlpha:m}=r,h=[],g=d;g??=[1,1],o(Dt(l,g),()=>`Error in depthwiseConv2d: Either strides or dilations must be 1. Got strides ${l} and dilations '${g}'`);let _=Vr(i.shape,a.shape,l,g,u,f,!0),v=j().getBool(`WEBGL_PACK_DEPTHWISECONV`)&&_.strideWidth<=2&&_.outChannels/_.inChannels===1,y=p?vL(p,v):null,b=[i,a],x=s!=null,S=c!=null,C=p===`leakyrelu`;if(x&&b.push(s),S&&b.push(c),C){let e=n.makeTensorInfo([],`float32`,Da(m,`float32`));b.push(e),h.push(e)}let w;w=v?new pB(_,x,y,S,C):new fB(_,x,y,S,C);let T=[[_.padInfo.top,_.padInfo.left],[_.strideHeight,_.strideWidth],[_.dilationHeight,_.dilationWidth],[_.inHeight,_.inWidth]],E=n.runWebGLProgram(w,b,`float32`,T);return h.forEach(e=>n.disposeIntermediateTensorInfo(e)),E}var lV={kernelName:ni,backendName:`webgl`,kernelFunc:cV},uV=class{constructor(e,t,n,r){this.sliceDim=e,this.strides=t,this.paramsShape=r,this.variableNames=[`x`,`indices`],this.outputShape=n;let i=kP(n.length),a=`
    int index;`;for(let e=0;e<this.sliceDim;e++)a+=`
          index = round(getIndices(coords[0], ${e}));
          out_of_bounds = out_of_bounds || index < 0;
          out_of_bounds = out_of_bounds || index >= ${this.paramsShape[e]};
          flattenIndex += index * ${this.strides[e]};`;this.userCode=`
         void main() {
          ${i} coords = getOutputCoords();
          int flattenIndex = 0;
          bool out_of_bounds = false;

          ${a}

          setOutput(out_of_bounds ? 0.0 : getX(flattenIndex, coords[1]));
        }
      `}};function dV(e){let{inputs:t,backend:n}=e,{params:r,indices:i}=t,a=i.shape,o=a[a.length-1],s=k(r.shape),[c,l,u,d]=du(r,i),f=$({inputs:{x:i},backend:n,attrs:{shape:[l,o]}}),p=$({inputs:{x:r},backend:n,attrs:{shape:[k(r.shape)/u,u]}});if(n.shouldExecuteOnCPU([r,i])||r.dtype===`string`){let e=OF(n.readSync(i.dataId),n.bufferSync(r),r.dtype,l,o,u,d,r.shape,s);return n.makeTensorInfo(c,r.dtype,e.values)}let m=new uV(o,d,[l,u],r.shape),h=n.runWebGLProgram(m,[p,f],p.dtype),g=$({inputs:{x:h},backend:n,attrs:{shape:c}});return n.disposeIntermediateTensorInfo(f),n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(h),g}var fV={kernelName:nt,backendName:`webgl`,kernelFunc:dV},pV=class{constructor(e,t){this.variableNames=[`A`,`indices`],this.outputShape=t,this.rank=t.length;let n=kP(this.rank),r=mV(e,2);this.userCode=`
      void main() {
        ${n} resRC = getOutputCoords();
        int index = int(getIndices(resRC.x, resRC.z));
        float inBounds = (index >= 0) && (index < ${e[2]}) ? 1.0 : 0.0;
        setOutput(inBounds * getA(${r}));
      }
    `}};function mV(e,t){let n=[`resRC.x`,`resRC.y`,`resRC.z`,`resRC.w`],r=[];for(let t=0;t<e.length;t++)t===2?r.push(`index`):r.push(`${n[t]}`);return r.join()}function hV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,indices:a}=t,{axis:s,batchDims:c}=r,l=H(s,i.shape)[0];if(j().get(`DEBUG`)){let e=n.readSync(a.dataId),t=i.shape[l];for(let n=0;n<e.length;++n){let r=e[n];o(r<=t-1&&r>=0,()=>`GatherV2: the index value ${r} is not in [0, ${t-1}]`)}}let u=Bd(i,a,l,c),d=k(a.shape),f=[],p=$({inputs:{x:i},backend:n,attrs:{shape:[u.batchSize,u.outerSize,u.dimSize,u.sliceSize]}}),m=$({inputs:{x:a},backend:n,attrs:{shape:[u.batchSize,d/u.batchSize]}});f.push(p),f.push(m);let h=[u.batchSize,u.outerSize,d/u.batchSize,u.sliceSize];if(n.shouldExecuteOnCPU([i,a])||i.dtype===`string`){let e=n.bufferSync(m),t=kF(n.bufferSync(p),e,h);return f.forEach(e=>n.disposeIntermediateTensorInfo(e)),n.makeTensorInfo(u.outputShape,t.dtype,t.values)}let g=new pV(p.shape,h),_=n.runWebGLProgram(g,[p,m],p.dtype);f.push(_);let v=$({inputs:{x:_},backend:n,attrs:{shape:u.outputShape}});return f.forEach(e=>n.disposeIntermediateTensorInfo(e)),v}var gV={kernelName:Ht,backendName:`webgl`,kernelFunc:hV},_V={kernelName:oc,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a > b);`,packedOpSnippet:`
  return vec4(greaterThan(a, b));
`,cpuKernelImpl:AF,dtype:`bool`})},vV={kernelName:Mt,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a >= b);`,packedOpSnippet:`
  return vec4(greaterThanEqual(a, b));
`,dtype:`bool`,cpuKernelImpl:jF})};function yV(e){let{inputs:t,backend:n}=e,{input:r}=t;return UB(r,!0,n)}var bV={kernelName:Si,backendName:`webgl`,kernelFunc:yV},xV={kernelName:Zn,backendName:`webgl`,kernelFunc:Q({opSnippet:`return float(!isnan(x) && !isinf(x));`,dtype:`bool`})},SV={kernelName:u,backendName:`webgl`,kernelFunc:Q({opSnippet:`return float(isinf(x));`,dtype:`bool`})},CV={kernelName:Na,backendName:`webgl`,kernelFunc:Q({opSnippet:`return float(isnan(x));`,dtype:`bool`})},wV={kernelName:So,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a < b);`,packedOpSnippet:`
  return vec4(lessThan(a, b));
`,cpuKernelImpl:MF,dtype:`bool`})},TV={kernelName:Gi,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a <= b);`,packedOpSnippet:`
  return vec4(lessThanEqual(a, b));
`,cpuKernelImpl:NF,dtype:`bool`})};function EV(e){let{backend:t,attrs:n}=e,{start:r,stop:i,num:a}=n,o=PF(r,i,a);return t.makeTensorInfo([o.length],`float32`,o)}var DV={kernelName:Ps,backendName:`webgl`,kernelFunc:EV},OV={kernelName:`Log`,backendName:`webgl`,kernelFunc:Q({opSnippet:gL+`
  return x < 0.0 ? 0./0. : log(x);
`,packedOpSnippet:`
  vec4 result = log(x);
  bvec4 isNaN = isnan(x);
  result.r = isNaN.r ? x.r : (x.r < 0.0 ? 0./0. : result.r);
  result.g = isNaN.g ? x.g : (x.g < 0.0 ? 0./0. : result.g);
  result.b = isNaN.b ? x.b : (x.b < 0.0 ? 0./0. : result.b);
  result.a = isNaN.a ? x.a : (x.a < 0.0 ? 0./0. : result.a);
  return result;
`,cpuKernelImpl:FF})},kV={kernelName:pa,backendName:`webgl`,kernelFunc:Q({opSnippet:gL+`
  return log(1.0 + x);
`})},AV={kernelName:Vc,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a >= 1.0 && b >= 1.0);`,packedOpSnippet:`
  return vec4(
    vec4(greaterThanEqual(a, vec4(1.0))) *
    vec4(greaterThanEqual(b, vec4(1.0))));
`,dtype:`bool`})},jV={kernelName:Ca,backendName:`webgl`,kernelFunc:Q({opSnippet:`return float(!(x >= 1.0));`})},MV={kernelName:Ua,backendName:`webgl`,kernelFunc:_L({opSnippet:`return float(a >= 1.0 || b >= 1.0);`,packedOpSnippet:`
  return min(
    vec4(greaterThanEqual(a, vec4(1.0))) +
    vec4(greaterThanEqual(b, vec4(1.0))),
    vec4(1.0));
`,dtype:`bool`})},NV=class{constructor(e,t,n,r,i){this.variableNames=[`x`],this.outputShape=[];let a=t,o=e[3]-1;this.outputShape=e;let s,c=`float(${n}) + float(${r}) * sum`;s=i===.5?`inversesqrt(${c})`:i===1?`1.0/(${c})`:`exp(log(${c}) * float(-${i}));`,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int r = coords[1];
        int c = coords[2];
        int d = coords[3];
        float x = getX(b, r, c, d);
        float sum = 0.0;
        for (int j = -${a}; j <= ${a}; j++) {
          int idx = d + j;
          if (idx >= 0 && idx <=  ${o}) {
            float z = getX(b, r, c, idx);
            sum += z * z;
          }
        }
        float val = x * ${s};
        setOutput(val);
      }
    `}},PV=class{constructor(e,t,n,r,i){this.variableNames=[`x`],this.outputShape=[],this.packedInputs=!0,this.packedOutput=!0;let a=t,o=e[3]-1;this.outputShape=e;let s,c=`float(${n}) + float(${r}) * sum`;s=i===.5?`inversesqrt(${c})`:i===1?`1.0/(${c})`:`exp(log(${c}) * float(-${i}));`,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords.x;
        int r = coords.y;
        int c = coords.z;
        int d = coords.w;

        bool hasNextCol = d < ${this.outputShape[3]};
        bool hasNextRow = c < ${this.outputShape[2]};

        vec4 sum = vec4(0.);
        vec4 xFragAtOutputCoords = getX(b, r, c, d);

        vec4 xAtOutputCoords = vec4(
          getChannel(xFragAtOutputCoords, vec2(c, d)),
          hasNextCol ?
            getChannel(xFragAtOutputCoords, vec2(c, d + 1)) : 0.0,
          hasNextRow ?
            getChannel(xFragAtOutputCoords , vec2(c + 1, d)) : 0.0,
          (hasNextRow && hasNextCol) ?
            getChannel(xFragAtOutputCoords, vec2(c + 1, d + 1)) : 0.0
        );

        int firstChannel = d - ${a};
        vec2 cache = vec2(0.);
        if(firstChannel >= 0){
          vec4 firstChannelFrag = getX(b, r, c, firstChannel);
          cache.x = getChannel(firstChannelFrag, vec2(c, firstChannel));
            if(hasNextRow){
              cache.y = getChannel(firstChannelFrag, vec2(c + 1, firstChannel));
            }
        }

        ivec2 depth = ivec2(d, d + 1);
        for (int j = - ${a}; j <= ${a}; j++) {
          ivec2 idx = depth + j;
          bvec2 aboveLowerBound = greaterThanEqual(idx, ivec2(0));
          bvec2 belowUpperBound = lessThanEqual(idx, ivec2(${o}));

          bool depthInRange = aboveLowerBound.x && belowUpperBound.x;
          bool depthPlusOneInRange = aboveLowerBound.y && belowUpperBound.y;

          if(depthInRange || depthPlusOneInRange){
            vec4 z = vec4(0.);
            vec4 xFragAtCurrentDepth;
            z.xz = cache.xy;
            if(depthPlusOneInRange && hasNextCol){
              xFragAtCurrentDepth = idx.y != d ?
                getX(b, r, c, idx.y) : xFragAtOutputCoords;
              z.y = getChannel(xFragAtCurrentDepth, vec2(c, idx.y));
              if(hasNextRow){
                z.w = getChannel(xFragAtCurrentDepth, vec2(c + 1, idx.y));
              }
            }
            cache.xy = z.yw;
            sum += z * z;
          }
        }
        vec4 result = xAtOutputCoords * ${s};
        setOutput(result);
      }
    `}},FV={kernelName:`LRN`,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{depthRadius:a,bias:o,alpha:s,beta:c}=r,l=j().getBool(`WEBGL_PACK_NORMALIZATION`)?new PV(i.shape,a,o,s,c):new NV(i.shape,a,o,s,c);return n.runWebGLProgram(l,[i],i.dtype)}},IV=class{constructor(e,t,n,r,i){this.variableNames=[`inputImage`,`outputImage`,`dy`],this.outputShape=[],this.outputShape=e,this.depth=e[3],this.depthRadius=t,this.bias=n,this.alpha=r,this.beta=i,this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int r = coords[1];
        int c = coords[2];

        float result = 0.0;
        for (int d = 0; d < ${this.depth}; ++d) {
          int depthBegin = int(max(0.0, float(d - ${t})));
          int depthEnd = int(min(float(${this.depth}),
              float(d + ${t} + 1)));

          const int MIN_DEPTH_BEGIN = 0;
          const int MAX_DEPTH_END = ${this.depth};

          float norm = 0.0;
          for (int k = MIN_DEPTH_BEGIN; k < MAX_DEPTH_END; ++k) {
            if (k < depthBegin){
              continue;
            }
            else if (k >= depthBegin && k < depthEnd) {
              norm += getInputImage(b, r, c, k) * getInputImage(b, r, c, k);
            }
            else {
              break;
            }
          }

          norm = float(${r}) * norm + float(${n});

          for(int k = MIN_DEPTH_BEGIN; k < MAX_DEPTH_END; ++k){
            if (k < depthBegin){
              continue;
            }
            else if (k >= depthBegin && k < depthEnd){
              float dyi = -2.0 * float(${r})
                * float(${i})
                * getInputImage(b, r, c, k) * getOutputImage(b, r, c, d)
                / norm;
              if (k == d) {
                dyi += pow(norm, -1.0 * ${i});
              }
              if (k == coords[3]) {
                dyi *= getDy(b, r, c, d);
                result += dyi;
              }
            }
            else {
              break;
            }
          }
      }
      setOutput(result);
      }
    `}},LV={kernelName:Cs,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{x:i,y:a,dy:o}=t,{depthRadius:s,bias:c,alpha:l,beta:u}=r,d=new IV(i.shape,s,c,l,u);return n.runWebGLProgram(d,[i,a,o],i.dtype)}};function RV(e,t,n,r){let i=k(t),a=k(e.shape)/i,o=$({inputs:{x:e},attrs:{shape:[a,i]},backend:r}),s=AL(o,e.dtype,`max`,r),c=$({inputs:{x:s},attrs:{shape:n},backend:r});return r.disposeIntermediateTensorInfo(o),r.disposeIntermediateTensorInfo(s),c}function zV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{reductionIndices:a,keepDims:o}=r,s=i.shape.length,c=H(a,i.shape),l=c,u=Zt(l,s),d=u!=null,f=n.shouldExecuteOnCPU([i]),p=i;if(d){if(f){let e=n.texData.get(p.dataId).values,t=Array(s);for(let e=0;e<t.length;e++)t[e]=i.shape[u[e]];let r=uI(e,i.shape,i.dtype,u,t);p=n.makeTensorInfo(t,i.dtype);let a=n.texData.get(p.dataId);a.values=r}else p=PL(i,u,n);l=or(l.length,s)}cn(`max`,l,s);let[m,h]=Ge(p.shape,l),g=m;o&&(g=xt(m,c));let _;if(f){let e=n.texData.get(p.dataId).values,t=IF(e,k(h),g,i.dtype);_=n.makeTensorInfo(g,i.dtype);let r=n.texData.get(_.dataId);r.values=t}else _=RV(p,h,g,n);return d&&n.disposeIntermediateTensorInfo(p),_}var BV={kernelName:`Max`,backendName:`webgl`,kernelFunc:zV},VV={kernelName:dr,backendName:`webgl`,kernelFunc:_L({opSnippet:eL+`
  return max(a, b);
`,packedOpSnippet:`
  vec4 result = vec4(max(a, b));
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+nL+`
  return result;
`,cpuKernelImpl:LF})};function HV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t;MN(i,`maxPool`);let{filterSize:a,strides:s,pad:c,dimRoundingMode:l}=r;o(Dt(s,1),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${s} and dilations '1'`);let u=Ze(i.shape,a,s,1,c,l);if(u.filterWidth===1&&u.filterHeight===1&&qn(u.inShape,u.outShape))return iL({inputs:{x:i},backend:n});let d=new vR(u,`max`,!1);return n.runWebGLProgram(d,[i],i.dtype)}var UV={kernelName:Pi,backendName:`webgl`,kernelFunc:HV};function WV(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{filterSize:a,strides:o,pad:s,dataFormat:c,dimRoundingMode:l}=r,u=new yR(Lt(i.shape,a,o,[1,1,1],s,l,c),`max`,!1);return n.runWebGLProgram(u,[i],i.dtype)}var GV={kernelName:Zc,backendName:`webgl`,kernelFunc:WV},KV=class{constructor(e){this.variableNames=[`dy`,`maxPos`],this.outputShape=e.inShape;let t=e.strideHeight,n=e.strideWidth,r=e.dilationHeight,i=e.effectiveFilterHeight,a=e.effectiveFilterWidth,o=i-1-e.padInfo.top,s=a-1-e.padInfo.left,c=i*a-1;this.userCode=`
      const ivec2 pads = ivec2(${o}, ${s});

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];

        ivec2 dyRCCorner = coords.yz - pads;
        int dyRCorner = dyRCCorner.x;
        int dyCCorner = dyRCCorner.y;

        // Convolve dy(?, ?, d) with pos mask(:, :, d) to get dx(xR, xC, d).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;
        for (int wR = 0; wR < ${i};
          wR += ${r}) {
          float dyR = float(dyRCorner + wR) / ${t}.0;

          if (dyR < 0.0 || dyR >= ${e.outHeight}.0 || fract(dyR) > 0.0) {
            continue;
          }
          int idyR = int(dyR);

          for (int wC = 0; wC < ${a}; wC++) {
            float dyC = float(dyCCorner + wC) / ${n}.0;

            if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                fract(dyC) > 0.0) {
              continue;
            }
            int idyC = int(dyC);

            float dyValue = getDy(b, idyR, idyC, d);
            int maxPosValue = ${c} - int(getMaxPos(b, idyR, idyC, d));

            // Get the current value, check it against the value from the
            // position matrix.
            int curPosValue = wR * ${a} + wC;
            float mask = float(maxPosValue == curPosValue ? 1.0 : 0.0);

            dotProd += dyValue * mask;
          }
        }
        setOutput(dotProd);
      }
    `}},qV=class{constructor(e){this.variableNames=[`dy`,`maxPos`],this.outputShape=e.inShape;let t=e.strideDepth,n=e.strideHeight,r=e.strideWidth,i=e.dilationDepth,a=e.dilationHeight,o=e.dilationWidth,s=e.effectiveFilterDepth,c=e.effectiveFilterHeight,l=e.effectiveFilterWidth,u=s-1-e.padInfo.front,d=c-1-e.padInfo.top,f=l-1-e.padInfo.left,p=s*c*l-1;this.userCode=`
      const ivec3 pads = ivec3(${u}, ${d}, ${f});

      void main() {
        ivec5 coords = getOutputCoords();
        int batch = coords.x;
        int ch = coords.u;

        ivec3 dyCorner = ivec3(coords.y, coords.z, coords.w) - pads;
        int dyDCorner = dyCorner.x;
        int dyRCorner = dyCorner.y;
        int dyCCorner = dyCorner.z;

        // Convolve dy(?, ?, ?, ch) with pos mask(:, :, :, d) to get
        // dx(xD, xR, xC, ch).
        // ? = to be determined. : = across all values in that axis.
        float dotProd = 0.0;

        for (int wD = 0; wD < ${s};
           wD += ${i}) {
          float dyD = float(dyDCorner + wD) / ${t}.0;

          if (dyD < 0.0 || dyD >= ${e.outDepth}.0 || fract(dyD) > 0.0) {
            continue;
          }
          int idyD = int(dyD);

          for (int wR = 0; wR < ${c};
              wR += ${a}) {
            float dyR = float(dyRCorner + wR) / ${n}.0;

            if (dyR < 0.0 || dyR >= ${e.outHeight}.0 ||
                fract(dyR) > 0.0) {
              continue;
            }
            int idyR = int(dyR);

            for (int wC = 0; wC < ${l};
                wC += ${o}) {
              float dyC = float(dyCCorner + wC) / ${r}.0;

              if (dyC < 0.0 || dyC >= ${e.outWidth}.0 ||
                  fract(dyC) > 0.0) {
                continue;
              }
              int idyC = int(dyC);

              float dyValue = getDy(batch, idyD, idyR, idyC, ch);
              int maxPosValue = ${p} -
                  int(getMaxPos(batch, idyD, idyR, idyC, ch));

              // Get the current value, check it against the value from the
              // position matrix.
              int curPosValue =
                  wD * ${c} * ${l} +
                  wR * ${l} + wC;
              float mask = float(maxPosValue == curPosValue ? 1.0 : 0.0);

              dotProd += dyValue * mask;
            }
          }
        }
        setOutput(dotProd);
      }
    `}};function JV(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a}=t,o=a,{filterSize:s,strides:c,pad:l,dimRoundingMode:u}=r,d=Lt(o.shape,s,c,[1,1,1],l,u),f=new yR(d,`max`,!0),p=n.runWebGLProgram(f,[o],o.dtype),m=new qV(d),h=n.runWebGLProgram(m,[i,p],o.dtype);return n.disposeIntermediateTensorInfo(p),h}var YV={kernelName:Ol,backendName:`webgl`,kernelFunc:JV};function XV(e){let{inputs:t,backend:n,attrs:r}=e,{dy:i,input:a,output:o}=t,s=a;MN([a,o],`maxPoolGrad`);let{filterSize:c,strides:l,pad:u,dimRoundingMode:d}=r,f=Ze(s.shape,c,l,1,u,d),p=new vR(f,`max`,!0),m=n.runWebGLProgram(p,[s],s.dtype),h=new KV(f),g=n.runWebGLProgram(h,[i,m],s.dtype);return n.disposeIntermediateTensorInfo(m),g}var ZV={kernelName:na,backendName:`webgl`,kernelFunc:XV};function QV(e,t,n,r){let i=new vR(n,`max`,!1),a=r.runWebGLProgram(i,[e],`float32`);return i=new vR(n,`max`,!0,!0,t),[a,r.runWebGLProgram(i,[e],`float32`)]}var $V={kernelName:vl,backendName:`webgl`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{x:r}=e,{filterSize:i,strides:a,pad:s,includeBatchInIndex:c}=t,l=n;o(r.shape.length===4,()=>`Error in maxPool: input must be rank 4 but got rank ${r.shape.length}.`);let u=[1,1];o(Dt(a,u),()=>`Error in maxPool: Either strides or dilations must be 1. Got strides ${a} and dilations '${u}'`);let[d,f]=QV(r,c,Ze(r.shape,i,a,u,s),l);return[d,f]}};function eH(e,t,n,r){let i=k(t),a=k(e.shape)/i,o=$({inputs:{x:e},attrs:{shape:[a,i]},backend:r}),s=AL(o,`float32`,`mean`,r),c=$({inputs:{x:s},attrs:{shape:n},backend:r});return r.disposeIntermediateTensorInfo(o),r.disposeIntermediateTensorInfo(s),c}var tH={kernelName:ce,backendName:`webgl`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{x:r}=e,{keepDims:i,axis:a}=t,o=n,s=r.shape.length,c=H(a,r.shape),l=c,u=Zt(l,s),d=u!=null,f=o.shouldExecuteOnCPU([r]),p=[],m=r;if(d){if(f){let e=o.texData.get(m.dataId).values,t=Array(s);for(let e=0;e<t.length;e++)t[e]=r.shape[u[e]];let n=uI(e,r.shape,r.dtype,u,t);m=o.makeTensorInfo(t,r.dtype);let i=o.texData.get(m.dataId);i.values=n}else m=PL(r,u,o);p.push(m),l=or(l.length,s)}cn(`sum`,l,s);let[h,g]=Ge(m.shape,l),_=h;i&&(_=xt(h,c));let v=eH(m,g,_,o);for(let e of p)o.disposeIntermediateTensorInfo(e);return v}};function nH(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r,s=i.shape.length,c=H(a,i.shape),l=c,u=Zt(l,s),d=i;u!=null&&(d=RL({inputs:{x:i},backend:n,attrs:{perm:u}}),l=or(l.length,i.shape.length)),cn(`min`,l,s);let[f,p]=Ge(d.shape,l),m=k(p),h=$({inputs:{x:d},backend:n,attrs:{shape:[-1,m]}}),g=AL(h,h.dtype,`min`,n),_;if(o){let e=xt(f,c);_=$({inputs:{x:g},backend:n,attrs:{shape:e}})}else _=$({inputs:{x:g},backend:n,attrs:{shape:f}});return n.disposeIntermediateTensorInfo(h),n.disposeIntermediateTensorInfo(g),u!=null&&n.disposeIntermediateTensorInfo(d),_}var rH={kernelName:`Min`,backendName:`webgl`,kernelFunc:nH},iH={kernelName:Sr,backendName:`webgl`,kernelFunc:_L({opSnippet:eL+`
  return min(a, b);
`,packedOpSnippet:`
  vec4 result = vec4(min(a, b));
  bvec4 isNaNA = isnan(a);
  bvec4 isNaNB = isnan(b);
  bvec4 isNaN = bvec4(isNaNA.x || isNaNB.x, isNaNA.y || isNaNB.y, isNaNA.z || isNaNB.z, isNaNA.w || isNaNB.w);
  `+nL+`
  return result;
`,cpuKernelImpl:RF})},aH=class{constructor(e,t,n){this.variableNames=[`x`],this.outputShape=t.map((t,n)=>t[0]+e[n]+t[1]);let r=e.length,i=kP(r),a=t.map(e=>e[0]).join(`,`),o=t.map((t,n)=>t[0]+e[n]).join(`,`),s=[`coords[0]`,`coords[1]`,`coords[2]`,`coords[3]`].slice(0,r),c=n===`reflect`?0:1;if(r===1){this.userCode=`
        int start = ${a};
        int end = ${o};

        void main() {
          int outC = getOutputCoords();
          if (outC < start) {
            outC = start * 2 - outC - ${c};
          } else if(outC >= end) {
            outC = (end - 1) * 2 - outC + ${c};
          }
          setOutput(getX(outC - start));
        }
      `;return}this.userCode=`
      ${i} start = ${i}(${a});
      ${i} end = ${i}(${o});

      void main() {
        ${i} outC = getOutputCoords();
        for (int i = 0; i < ${r}; i++) {
          if (outC[i] < start[i]) {
            outC[i] = start[i] * 2 - outC[i] - ${c};
          } else if(outC[i] >= end[i]) {
            outC[i] = (end[i] - 1) * 2 - outC[i] + ${c};
          }
        }
        ${i} coords = outC - start;
        setOutput(getX(${s}));
      }
    `}},oH=class{constructor(e,t,n){this.variableNames=[`x`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=t.map((t,n)=>t[0]+e[n]+t[1]);let r=e.length,i=kP(r),a=t.map(e=>e[0]).join(`,`),o=t.map((t,n)=>t[0]+e[n]).join(`,`),s=pI(`rc`,r),c=pI(`source`,r),l=`${s[r-1]} < ${this.outputShape[r-1]}`,u=r===1?`source`:`vec2(${c.slice(-2).join()})`,d=n===`reflect`?0:1,f=``;if(r===1){let e=`
        ${i} source = rc;
        if (source < start) {
          source = start * 2 - source - ${d};
        } else if (source >= end) {
          source = (end - 1) * 2 - source + ${d};
        }
        source -= start;
      `;f=`
        ${i} rc = outputLoc;
        ${e}
        result[0] = getChannel(getX(${c.join()}), ${u});
        ${s[r-1]} += 1;
        if(${l}) {
          ${e}
          result[1] = getChannel(getX(${c.join()}), ${u});
        }
      `}else{let e=`
        ${i} source = rc;
        ${i} lt = ${i}(lessThan(source, start));
        ${i} gte = ${i}(greaterThanEqual(source, end));
        ${i} orig = 1 - (lt + gte);
        source = orig * source +
                lt * (start * 2 - source - ${d}) +
                gte * ((end - 1) * 2 - source + ${d});
        source -= start;
      `;f=`
        ${i} rc = outputLoc;
        ${e}
        result[0] = getChannel(getX(${c.join()}), ${u});
        ${s[r-1]} += 1;
        if(${l}) {
          ${e}
          result[1] = getChannel(getX(${c.join()}), ${u});
        }
        rc = outputLoc;
        ${s[r-2]} += 1;
        if(${s[r-2]} < ${this.outputShape[r-2]}) {
          ${e}
          result[2] = getChannel(getX(${c.join()}), ${u});
          ${s[r-1]} += 1;
          if(${l}) {
            ${e}
            result[3] = getChannel(getX(${c.join()}), ${u});
          }
        }
      `}this.userCode=`
      const ${i} start = ${i}(${a});
      const ${i} end = ${i}(${o});

      void main() {
        ${i} outputLoc = getOutputCoords();
        vec4 result = vec4(0.);
        ${f}
        setOutput(result);
      }
    `}},sH={kernelName:ke,backendName:`webgl`,kernelFunc:({inputs:e,backend:t,attrs:n})=>{let{x:r}=e,{paddings:i,mode:a}=n,o=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)?new oH(r.shape,i,a):new aH(r.shape,i,a);return t.runWebGLProgram(o,[r],r.dtype)}},cH={kernelName:`Mod`,backendName:`webgl`,kernelFunc:_L({opSnippet:`if (b == 0.0) return NAN;
  return mod(a, b);`,packedOpSnippet:`
  vec4 result = mod(a, b);
  bvec4 isNaN = equal(b, vec4(0.0));
  `+nL+`
  return result;
`})},lH=class{constructor(e,t,n){this.variableNames=[`probs`],this.customUniforms=[{name:`seed`,type:`float`}],this.outputShape=[e,n],this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];

        float r = random(seed);
        float cdf = 0.0;

        for (int i = 0; i < ${t-1}; i++) {
          cdf += getProbs(batch, i);

          if (r < cdf) {
            setOutput(float(i));
            return;
          }
        }

        // If no other event happened, last event happened.
        setOutput(float(${t-1}));
      }
    `}},uH=_L({opSnippet:`
if (a == b) {
  return 1.0;
};
return a / b;`,packedOpSnippet:`
  // vec4 one = vec4(equal(a, b));
  // return one + (vec4(1.0) - one) * a / b;
  vec4 result = a / b;
  if(a.x == b.x) {
    result.x = 1.;
  }
  if(a.y == b.y) {
    result.y = 1.;
  }
  if(a.z == b.z) {
    result.z = 1.;
  }
  if(a.w == b.w) {
    result.w = 1.;
  }

  return result;
`,checkOutOfBounds:!0}),dH={kernelName:Et,backendName:`webgl`,kernelFunc:uH},fH=`return a - b;`,pH=_L({opSnippet:fH,packedOpSnippet:fH,supportsComplex:!0,cpuKernelImpl:sI}),mH={kernelName:`Sub`,backendName:`webgl`,kernelFunc:pH};function hH(e){let{inputs:t,backend:n,attrs:r}=e,{logits:i}=t,{dim:a}=r,o=H([a],i.shape),s=zV({inputs:{x:i},backend:n,attrs:{reductionIndices:o,keepDims:!1}}),c=xt(s.shape,o),l=$({inputs:{x:s},backend:n,attrs:{shape:c}}),u=pH({inputs:{a:i,b:l},backend:n}),d=IB({inputs:{x:u},backend:n}),f=IL({inputs:{x:d},backend:n,attrs:{axis:o,keepDims:!1}}),p=$({inputs:{x:f},backend:n,attrs:{shape:c}}),m=uH({inputs:{a:d,b:p},backend:n});return n.disposeIntermediateTensorInfo(s),n.disposeIntermediateTensorInfo(l),n.disposeIntermediateTensorInfo(u),n.disposeIntermediateTensorInfo(d),n.disposeIntermediateTensorInfo(f),n.disposeIntermediateTensorInfo(p),m}var gH={kernelName:to,backendName:`webgl`,kernelFunc:hH};function _H(e){let{inputs:t,backend:n,attrs:r}=e,{logits:i}=t,{numSamples:a,seed:o,normalized:s}=r,c=s?i:hH({inputs:{logits:i},backend:n,attrs:{dim:i.shape.length-1}}),l=c.shape[0],u=c.shape[1],d=new lH(l,u,a),f=[[o]],p=n.runWebGLProgram(d,[c],`int32`,f);return s||n.disposeIntermediateTensorInfo(c),p}var vH={kernelName:wn,backendName:`webgl`,kernelFunc:_H},yH=EI+`
  return -x;
`,bH=`
  vec4 result = -x;
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`;function xH(e){let{inputs:t,backend:n}=e,{x:r}=t;if(n.shouldExecuteOnCPU([r])){let[e,t]=BF(n.texData.get(r.dataId).values,r.shape,r.dtype);return n.makeTensorInfo(t,r.dtype,e)}let i;return i=j().getBool(`WEBGL_PACK_UNARY_OPERATIONS`)?new zI(r.shape,bH):new TI(r.shape,yH),n.runWebGLProgram(i,[r],r.dtype)}var SH={kernelName:`Neg`,backendName:`webgl`,kernelFunc:xH},CH=fn;function wH(e){v(`tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead`);let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c}=r,{selectedIndices:l}=CH(n.readSync(i.dataId),n.readSync(a.dataId),o,s,c);return n.makeTensorInfo([l.length],`int32`,new Int32Array(l))}var TH={kernelName:No,backendName:`webgl`,kernelFunc:wH},EH=Nn;function DH(e){v(`tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead`);let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c,padToMaxOutputSize:l}=r,{selectedIndices:u,validOutputs:d}=EH(n.readSync(i.dataId),n.readSync(a.dataId),o,s,c,l);return[n.makeTensorInfo([u.length],`int32`,new Int32Array(u)),n.makeTensorInfo([],`int32`,new Int32Array([d]))]}var OH={kernelName:nn,backendName:`webgl`,kernelFunc:DH},kH=Re;function AH(e){v(`tf.nonMaxSuppression() in webgl locks the UI thread. Call tf.nonMaxSuppressionAsync() instead`);let{inputs:t,backend:n,attrs:r}=e,{boxes:i,scores:a}=t,{maxOutputSize:o,iouThreshold:s,scoreThreshold:c,softNmsSigma:l}=r,{selectedIndices:u,selectedScores:d}=kH(n.readSync(i.dataId),n.readSync(a.dataId),o,s,c,l);return[n.makeTensorInfo([u.length],`int32`,new Int32Array(u)),n.makeTensorInfo([d.length],`float32`,new Float32Array(d))]}var jH={kernelName:mn,backendName:`webgl`,kernelFunc:AH},MH=class{constructor(e,t,n,r){this.variableNames=[`indices`],this.outputShape=[e,t],this.userCode=`
      void main() {
        ivec2 coords = getOutputCoords();
        int index = round(getIndices(coords.x));
        setOutput(mix(float(${r}), float(${n}),
                      float(index == coords.y)));
      }
    `}},NH={kernelName:Be,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{indices:i}=t,{dtype:a,depth:o,onValue:s,offValue:c}=r,l=k(i.shape),u=new MH(l,o,s,c),d=$({inputs:{x:i},backend:n,attrs:{shape:[l]}}),f=n.runWebGLProgram(u,[d],a);n.disposeIntermediateTensorInfo(d);let p=[...i.shape,o],m=$({inputs:{x:f},backend:n,attrs:{shape:p}});return n.disposeIntermediateTensorInfo(f),m}};function PH(e){let{inputs:t,backend:n}=e,{x:r}=t;if(r.dtype===`complex64`){let e=$R({inputs:{input:r},backend:n}),t=PH({inputs:{x:e},backend:n}),i=vz({inputs:{input:r},backend:n}),a=PH({inputs:{x:i},backend:n}),o=oL({inputs:{real:t,imag:a},backend:n});return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),n.disposeIntermediateTensorInfo(i),n.disposeIntermediateTensorInfo(a),o}else return qB({attrs:{shape:r.shape,dtype:r.dtype,value:r.dtype===`string`?``:0},backend:n})}var FH={kernelName:rc,backendName:`webgl`,kernelFunc:PH};function IH(e){let{inputs:t,backend:n}=e,{x:r}=t;if(r.dtype===`string`)throw Error(`onesLike is not supported under string dtype`);if(r.dtype===`complex64`){let e=$R({inputs:{input:r},backend:n}),t=IH({inputs:{x:e},backend:n}),i=vz({inputs:{input:r},backend:n}),a=PH({inputs:{x:i},backend:n}),o=oL({inputs:{real:t,imag:a},backend:n});return n.disposeIntermediateTensorInfo(e),n.disposeIntermediateTensorInfo(t),n.disposeIntermediateTensorInfo(i),n.disposeIntermediateTensorInfo(a),o}else return qB({attrs:{shape:r.shape,dtype:r.dtype,value:1},backend:n})}var LH={kernelName:gt,backendName:`webgl`,kernelFunc:IH};function RH(e){let{inputs:t,backend:n,attrs:r}=e,{axis:i}=r;if(t.length===1)return RB({inputs:{input:t[0]},backend:n,attrs:{dim:i}});let a=t[0].shape,s=t[0].dtype;t.forEach(e=>{Ba(a,e.shape,`All tensors passed to stack must have matching shapes`),o(s===e.dtype,()=>`All tensors passed to stack must have matching dtypes`)});let c=[],l=Sz({inputs:t.map(e=>{let t=RB({inputs:{input:e},backend:n,attrs:{dim:i}});return c.push(t),t}),backend:n,attrs:{axis:i}});return c.forEach(e=>n.disposeIntermediateTensorInfo(e)),l}var zH={kernelName:Kt,backendName:`webgl`,kernelFunc:RH},BH=class{constructor(e,t,n){this.variableNames=[`x`],this.customUniforms=[{name:`value`,type:`float`}],this.outputShape=t.map((t,n)=>t[0]+e[n]+t[1]);let r=e.length,i=kP(r),a=t.map(e=>e[0]).join(`,`),o=t.map((t,n)=>t[0]+e[n]).join(`,`),s=[`coords[0]`,`coords[1]`,`coords[2]`,`coords[3]`].slice(0,r);if(r===1){this.userCode=`
        int start = ${a};
        int end = ${o};

        void main() {
          int outC = getOutputCoords();
          if (outC < start || outC >= end) {
            setOutput(value);
          } else {
            setOutput(getX(outC - start));
          }
        }
      `;return}this.userCode=`
      ${i} start = ${i}(${a});
      ${i} end = ${i}(${o});

      void main() {
        ${i} outC = getOutputCoords();
        if (any(lessThan(outC, start)) || any(greaterThanEqual(outC, end))) {
          setOutput(value);
        } else {
          ${i} coords = outC - start;
          setOutput(getX(${s}));
        }
      }
    `}},VH=class{constructor(e,t,n){this.variableNames=[`x`],this.packedInputs=!0,this.packedOutput=!0,this.customUniforms=[{name:`value`,type:`float`}],this.outputShape=t.map((t,n)=>t[0]+e[n]+t[1]);let r=e.length,i=kP(r),a=t.map(e=>e[0]).join(`,`),o=t.map((t,n)=>t[0]+e[n]).join(`,`),s=pI(`rc`,r),c=pI(`source`,r),l=`${s[r-1]} < ${this.outputShape[r-1]}`,u=r===1?`source`:`vec2(${c.slice(-2).join()})`,d=[`${i} rc = outputLoc;`,`${s[r-1]} += 1;
       if(${l}) {
      `,r===1?``:`}
       rc = outputLoc;
       ${s[r-2]} += 1;
       if(${s[r-2]} < ${this.outputShape[r-2]}) {`,r===1?``:`  ${s[r-1]} += 1;
         if(${l}) {`],f=r===1?`rc < start || rc >= end`:`any(lessThan(rc, start)) || any(greaterThanEqual(rc, end))`,p=``;for(let e=0,t=r===1?2:4;e<t;e++)p+=`
        ${d[e]}
        if (${f}) {
          result[${e}] = float(value);
        } else {
          ${i} source = rc - start;
          result[${e}] = getChannel(getX(${c.join()}), ${u});
        }
      `;p+=r===1?`} `:`}}`,this.userCode=`
      const ${i} start = ${i}(${a});
      const ${i} end = ${i}(${o});

      void main() {
        ${i} outputLoc = getOutputCoords();
        vec4 result = vec4(0.);
        ${p}
        setOutput(result);
      }
    `}},HH=e=>{let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{paddings:a,constantValue:o}=r;if(k(i.shape)===0)return qB({backend:n,attrs:{shape:a.map((e,t)=>e[0]+i.shape[t]+e[1]),value:o,dtype:i.dtype}});let s=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)?new VH(i.shape,a,o):new BH(i.shape,a,o),c=[[o]];return n.runWebGLProgram(s,[i],i.dtype,c)},UH={kernelName:tr,backendName:`webgl`,kernelFunc:HH},WH={kernelName:`Pow`,backendName:`webgl`,kernelFunc:_L({opSnippet:`
  if(a < 0.0 && floor(b) < b){
    return NAN;
  }
  if (b == 0.0) {
    return 1.0;
  }
  return (round(mod(b, 2.0)) != 1) ?
      pow(abs(a), b) : sign(a) * pow(abs(a), b);
`,packedOpSnippet:`
  // isModRound1 has 1 for components with round(mod(b, 2.0)) == 1, 0 otherwise.
  vec4 isModRound1 = vec4(equal(round(mod(b, 2.0)), ivec4(1)));
  vec4 multiplier = sign(a) * isModRound1 + (vec4(1.0) - isModRound1);
  vec4 result = multiplier * pow(abs(a), b);

  // Ensure that a^0 = 1, including 0^0 = 1 as this correspond to TF and JS
  bvec4 isExpZero = equal(b, vec4(0.0));
  result.r = isExpZero.r ? 1.0 : result.r;
  result.g = isExpZero.g ? 1.0 : result.g;
  result.b = isExpZero.b ? 1.0 : result.b;
  result.a = isExpZero.a ? 1.0 : result.a;

  bvec4 isNaN1 = lessThan(a, vec4(0.0));
  bvec4 isNaN2 = lessThan(floor(b), b);
  bvec4 isNaN = bvec4(isNaN1.x && isNaN2.x, isNaN1.y && isNaN2.y, isNaN1.z && isNaN2.z, isNaN1.w && isNaN2.w);
  `+nL+`
  return result;
`})};function GH(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{axis:a,keepDims:o}=r,s=i.shape.length,c=[],l=H(a,i.shape),u=l,d=Zt(u,s),f=i;d!=null&&(f=RL({inputs:{x:i},backend:n,attrs:{perm:d}}),u=or(u.length,s),c.push(f)),cn(`prod`,u,s);let p;if(n.shouldExecuteOnCPU([f])){let e=n.texData.get(f.dataId).values,{outVals:t,outShape:r,outDtype:i}=HF(f.shape,f.dtype,e,u);p=n.makeTensorInfo(r,i,t)}else{let[e,t]=Ge(f.shape,u),r=k(t),a=$({inputs:{x:f},backend:n,attrs:{shape:[-1,r]}}),o=AL(a,Yi(i.dtype),`prod`,n);p=$({inputs:{x:o},backend:n,attrs:{shape:e}}),c.push(a),c.push(o)}if(o){c.push(p);let e=xt(p.shape,l);p=$({inputs:{x:p},backend:n,attrs:{shape:e}})}return c.forEach(e=>n.disposeIntermediateTensorInfo(e)),p}var KH={kernelName:ot,backendName:`webgl`,kernelFunc:GH};function qH(e){let{inputs:t,backend:n,attrs:r}=e,{paramsNestedSplits:i,paramsDenseValues:a,indices:o}=t,{outputRaggedRank:s}=r,c=i.map(e=>n.readSync(e.dataId)),l=i.map(e=>e.shape),u=n.readSync(a.dataId),d=n.readSync(o.dataId),[f,p,m]=UF(c,l,u,a.shape,a.dtype,d,o.shape,s),h=f.map(e=>n.makeTensorInfo([e.length],`int32`,e)),g=n.makeTensorInfo(m,a.dtype,p);return h.concat([g])}var JH={kernelName:Ar,backendName:`webgl`,kernelFunc:qH};function YH(e){let{inputs:t,backend:n}=e,{starts:r,limits:i,deltas:a}=t,o=n.readSync(r.dataId),s=n.readSync(i.dataId),c=n.readSync(a.dataId),[l,u]=WF(o,r.shape,r.dtype,s,i.shape,c,a.shape);return[n.makeTensorInfo([l.length],`int32`,l),n.makeTensorInfo([u.length],r.dtype,u)]}var XH={kernelName:Xr,backendName:`webgl`,kernelFunc:YH};function ZH(e){let{inputs:t,backend:n,attrs:r}=e,{shape:i,values:a,defaultValue:o,rowPartitionTensors:s}=t,{rowPartitionTypes:c}=r,l=n.readSync(i.dataId),u=n.readSync(a.dataId),d=n.readSync(o.dataId),f=s.map(e=>n.readSync(e.dataId)),p=s.map(e=>e.shape),[m,h]=GF(l,i.shape,u,a.shape,a.dtype,d,o.shape,f,p,c);return n.makeTensorInfo(m,a.dtype,h)}var QH={kernelName:Xe,backendName:`webgl`,kernelFunc:ZH},$H=e=>{let{backend:t,attrs:n}=e,{start:r,stop:i,step:a,dtype:o}=n,s=KF(r,i,a,o);return t.makeTensorInfo([s.length],o,s)},eU={kernelName:It,backendName:`webgl`,kernelFunc:$H},tU={kernelName:gi,backendName:`webgl`,kernelFunc:Q({opSnippet:`return 1.0 / x;`})},nU={kernelName:oi,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  return (x < 0.0) ? 0.0 : x;
`,packedOpSnippet:`
  vec4 result = x * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`})},rU={kernelName:Ei,backendName:`webgl`,kernelFunc:Q({opSnippet:EI+`
  return (x < 0.0) ? 0.0 : min(6.0, x);
`,packedOpSnippet:`
  vec4 result = min(x, vec4(6.)) * vec4(greaterThanEqual(x, vec4(0.0)));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`})},iU=class{constructor(e,t,n,r,i){this.variableNames=[`A`],this.outputShape=[];let[a,o,s,c]=e;this.outputShape=[a,t,n,c];let l=[r&&t>1?o-1:o,r&&n>1?s-1:s],u=[r&&t>1?t-1:t,r&&n>1?n-1:n],d;d=i?`(vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC - vec2(0.5)`:`vec2(yRC) * effectiveInputOverOutputRatioRC`,this.userCode=`
      const vec2 effectiveInputOverOutputRatioRC = vec2(
          ${l[0]/u[0]},
          ${l[1]/u[1]});
      const vec2 inputShapeRC = vec2(${o}.0, ${s}.0);

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        ivec2 yRC = coords.yz;

        // Fractional source index.
        vec2 sourceFracIndexRC = ${d};

        // Compute the four integer indices.
        ivec2 sourceFloorRC = ivec2(max(sourceFracIndexRC, vec2(0.0)));
        ivec2 sourceCeilRC = ivec2(
          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));

        float topLeft = getA(b, sourceFloorRC.x, sourceFloorRC.y, d);
        float bottomLeft = getA(b, sourceCeilRC.x, sourceFloorRC.y, d);
        float topRight = getA(b, sourceFloorRC.x, sourceCeilRC.y, d);
        float bottomRight = getA(b, sourceCeilRC.x, sourceCeilRC.y, d);

        vec2 fracRC = sourceFracIndexRC - vec2(sourceFloorRC);

        float top = topLeft + (topRight - topLeft) * fracRC.y;
        float bottom = bottomLeft + (bottomRight - bottomLeft) * fracRC.y;
        float newValue = top + (bottom - top) * fracRC.x;

        setOutput(newValue);
      }
    `}},aU=class{constructor(e,t,n,r,i){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];let[a,o,s,c]=e;this.outputShape=[a,t,n,c];let l=[r&&t>1?o-1:o,r&&n>1?s-1:s],u=[r&&t>1?t-1:t,r&&n>1?n-1:n],d;d=i?`(vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC - vec3(0.5)`:`vec3(yRC) * effectiveInputOverOutputRatioRC`,this.userCode=`
      const vec3 effectiveInputOverOutputRatioRC = vec3(
          ${l[0]/u[0]},
          ${l[1]/u[1]},
          ${l[1]/u[1]});
      const vec3 inputShapeRC = vec3(${o}.0, ${s}.0,
                                     ${s}.0);

      float getAValue(int b, int r, int c, int d) {
        return getChannel(getA(b, r, c, d), vec2(c, d));
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        // Calculate values for next column in yRC.z.
        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);

        // Fractional source index.
        vec3 sourceFracIndexRC = ${d};

        // Compute the four integer indices.
        ivec3 sourceFloorRC = ivec3(max(sourceFracIndexRC, vec3(0.0)));
        ivec3 sourceCeilRC = ivec3(
          min(inputShapeRC - 1.0, ceil(sourceFracIndexRC)));

        // Should we calculate next column and row elements in 2x2 packed cell.
        bool hasNextCol = d < ${c-1};
        bool hasNextRow = coords.z < ${n-1};

        // In parallel, construct four corners for all four components in
        // packed 2x2 cell.
        vec4 topLeft = vec4(
          getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d),
          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceFloorRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceFloorRC.x, sourceFloorRC.z, d + 1) : 0.0);

        vec4 bottomLeft = vec4(
          getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d),
          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceFloorRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceCeilRC.x, sourceFloorRC.z, d + 1) : 0.0);

        vec4 topRight = vec4(
          getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d),
          hasNextCol ? getAValue(b, sourceFloorRC.x, sourceCeilRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceFloorRC.x, sourceCeilRC.z, d + 1) : 0.0);

        vec4 bottomRight = vec4(
          getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d),
          hasNextCol ? getAValue(b, sourceCeilRC.x, sourceCeilRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceCeilRC.x, sourceCeilRC.z, d + 1) : 0.0);

        vec3 fracRC = sourceFracIndexRC - vec3(sourceFloorRC);

        vec4 top = mix(topLeft, topRight, fracRC.yyzz);
        vec4 bottom = mix(bottomLeft, bottomRight, fracRC.yyzz);
        vec4 newValue = mix(top, bottom, fracRC.x);

        setOutput(newValue);
      }
    `}};function oU(e){let{inputs:t,backend:n,attrs:r}=e,{images:i}=t,{alignCorners:a,halfPixelCenters:o,size:s}=r,[c,l]=s,u=j().getBool(`WEBGL_PACK_IMAGE_OPERATIONS`)?new aU(i.shape,c,l,a,o):new iU(i.shape,c,l,a,o);return n.runWebGLProgram(u,[i],`float32`)}var sU={kernelName:i,backendName:`webgl`,kernelFunc:oU},cU=class{constructor(e,t,n){this.variableNames=[`dy`],this.outputShape=[],this.outputShape=t;let[,r,i]=t,[,a,o]=e,s=[n&&a>1?r-1:r,n&&o>1?i-1:i],c=[n&&a>1?a-1:a,n&&o>1?o-1:o],l=s[0]/c[0],u=s[1]/c[1],d=1/l,f=1/u,p=Math.ceil(d)*2+2,m=Math.ceil(f)*2+2;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        int r = coords[1];
        int c = coords[2];

        float accumulator = 0.0;

        const float heightScale = float(${l});
        const float widthScale = float(${u});

        const float invHeightScale = float(${d});
        const float invWidthScale = float(${f});

        const int winHeight = int(${p});
        const int winWidth = int(${m});

        // Compute bounds for where in dy we will look
        float startRLerp = floor(float(r) * invHeightScale);
        int startDyR = int(startRLerp - float(winHeight / 2));

        float startCLerp = floor(float(c) * invWidthScale);
        int startDyC = int(startCLerp - float(winWidth / 2));

        // Loop over dy
        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {
          int dyR = dyROffset + startDyR;

          // Guard against the window exceeding the bounds of dy
          if (dyR < 0 || dyR >= ${a}) {
            continue;
          }

          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {
            int dyC = dyCOffset + startDyC;

            // Guard against the window exceeding the bounds of dy
            if (dyC < 0 || dyC >= ${o}) {
              continue;
            }

            float dxR = float(dyR) * heightScale;
            int topDxRIndex = int(floor(dxR));
            int bottomDxRIndex = int(min(ceil(dxR), ${r-1}.0));
            float dxRLerp = dxR - float(topDxRIndex);
            float inverseDxRLerp = 1.0 - dxRLerp;

            float dxC = float(dyC) * widthScale;
            int leftDxCIndex = int(floor(dxC));
            int rightDxCIndex = int(min(ceil(dxC), ${i-1}.0));
            float dxCLerp = dxC - float(leftDxCIndex);
            float inverseDxCLerp = 1.0 - dxCLerp;

            if (r == topDxRIndex && c == leftDxCIndex) {
              // topLeft
              accumulator +=
                getDy(b, dyR, dyC, d) * inverseDxRLerp * inverseDxCLerp;
            }

            if (r == topDxRIndex && c == rightDxCIndex) {
              // topRight
              accumulator += getDy(b, dyR, dyC, d) * inverseDxRLerp * dxCLerp;
            }

            if (r == bottomDxRIndex && c == leftDxCIndex) {
              // bottomLeft
              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * inverseDxCLerp;
            }

            if (r == bottomDxRIndex && c == rightDxCIndex) {
              // bottomRight
              accumulator += getDy(b, dyR, dyC, d) * dxRLerp * dxCLerp;
            }
          }
        }
        // End loop over dy

        setOutput(accumulator);
      }
    `}};function lU(e){let{inputs:t,backend:n,attrs:r}=e,{images:i,dy:a}=t,{alignCorners:o}=r,s=new cU(a.shape,i.shape,o);return n.runWebGLProgram(s,[a],a.dtype)}var uU={kernelName:Fa,backendName:`webgl`,kernelFunc:lU},dU=class{constructor(e,t,n,r,i){this.variableNames=[`A`],this.outputShape=[];let[a,o,s,c]=e;this.outputShape=[a,t,n,c];let l=[r&&t>1?o-1:o,r&&n>1?s-1:s],u=[r&&t>1?t-1:t,r&&n>1?n-1:n],d=r?`0.5`:`0.0`,f;f=i?`max((vec2(yRC) + vec2(0.5)) * effectiveInputOverOutputRatioRC, vec2(0.0))`:`vec2(yRC) * effectiveInputOverOutputRatioRC`,this.userCode=`
      const vec2 effectiveInputOverOutputRatioRC = vec2(
          ${l[0]/u[0]},
          ${l[1]/u[1]});
      const vec2 inputShapeRC = vec2(${o}.0, ${s}.0);

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        ivec2 yRC = coords.yz;

        // Fractional source index.
        vec2 sourceFracIndexRC = ${f};

        // Compute the coordinators of nearest neighbor point.
        ivec2 sourceNearestRC = ivec2(
          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));
        float newValue = getA(b, sourceNearestRC.x, sourceNearestRC.y, d);

        setOutput(newValue);
      }
    `}},fU=class{constructor(e,t,n,r,i){this.variableNames=[`A`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=[];let[a,o,s,c]=e;this.outputShape=[a,t,n,c];let l=[r&&t>1?o-1:o,r&&n>1?s-1:s],u=[r&&t>1?t-1:t,r&&n>1?n-1:n],d=r?`0.5`:`0.0`,f;f=i?`max((vec3(yRC) + vec3(0.5)) * effectiveInputOverOutputRatioRC, vec3(0.0))`:`vec3(yRC) * effectiveInputOverOutputRatioRC`,this.userCode=`
      const vec3 effectiveInputOverOutputRatioRC = vec3(
          ${l[0]/u[0]},
          ${l[1]/u[1]},
          ${l[1]/u[1]});
      const vec3 inputShapeRC = vec3(${o}.0, ${s}.0,
                                     ${s}.0);

      float getAValue(int b, int r, int c, int d) {
        return getChannel(getA(b, r, c, d), vec2(c, d));
      }

      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        // Calculate values for next column in yRC.z.
        ivec3 yRC = coords.yzz + ivec3(0, 0, 1);

        // Fractional source index.
        vec3 sourceFracIndexRC = ${f};

        // Compute the coordinators of nearest neighbor point.
        ivec3 sourceNearestRC = ivec3(
          min(inputShapeRC - 1.0, floor(sourceFracIndexRC + ${d})));

        // Should we calculate next column and row elements in 2x2 packed cell.
        bool hasNextCol = d < ${c-1};
        bool hasNextRow = coords.z < ${n-1};

        vec4 newValue = vec4(
          getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d),
          hasNextCol ? getAValue(b, sourceNearestRC.x, sourceNearestRC.y, d + 1)
                     : 0.0,
          hasNextRow ? getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d)
                     : 0.0,
          (hasNextRow && hasNextCol) ?
            getAValue(b, sourceNearestRC.x, sourceNearestRC.z, d + 1) : 0.0);

        setOutput(newValue);
      }
    `}};function pU(e){let{inputs:t,backend:n,attrs:r}=e,{images:i}=t,{alignCorners:a,halfPixelCenters:o,size:s}=r,[c,l]=s,u=j().getBool(`WEBGL_PACK_IMAGE_OPERATIONS`)?new fU(i.shape,c,l,a,o):new dU(i.shape,c,l,a,o);return n.runWebGLProgram(u,[i],i.dtype)}var mU={kernelName:Nc,backendName:`webgl`,kernelFunc:pU},hU=class{constructor(e,t,n){this.variableNames=[`dy`],this.outputShape=[],this.outputShape=t;let[,r,i]=t,[,a,o]=e,s=[n&&a>1?r-1:r,n&&o>1?i-1:i],c=[n&&a>1?a-1:a,n&&o>1?o-1:o],l=s[0]/c[0],u=s[1]/c[1],d=1/l,f=1/u,p=Math.ceil(d)*2+2,m=Math.ceil(f)*2+2;this.userCode=`
      void main() {
        ivec4 coords = getOutputCoords();
        int b = coords[0];
        int d = coords[3];
        int r = coords[1];
        int c = coords[2];

        float accumulator = 0.0;

        const float heightScale = float(${l});
        const float widthScale = float(${u});

        const float invHeightScale = float(${d});
        const float invWidthScale = float(${f});

        const int winHeight = int(${p});
        const int winWidth = int(${m});

        // Compute bounds for where in dy we will look
        float startRLerp = floor(float(r) * invHeightScale);
        int startDyR = int(floor(startRLerp - float(winHeight / 2)));

        float startCLerp = floor(float(c) * invWidthScale);
        int startDyC = int(floor(startCLerp - float(winWidth / 2)));

        // Loop over dy
        for (int dyROffset = 0; dyROffset < winHeight; dyROffset++) {
          int dyR = dyROffset + startDyR;

          // Guard against the window exceeding the bounds of dy
          if (dyR < 0 || dyR >= ${a}) {
            continue;
          }

          for (int dyCOffset = 0; dyCOffset < winWidth; dyCOffset++) {
            int dyC = dyCOffset + startDyC;

            // Guard against the window exceeding the bounds of dy
            if (dyC < 0 || dyC >= ${o}) {
              continue;
            }

            float sourceFracRow =
              float(${s[0]}) *
                (float(dyR) / float(${c[0]}));

            float sourceFracCol =
                float(${s[1]}) *
                  (float(dyC) / float(${c[1]}));

            int sourceNearestRow = int(min(
                float(int(${r}) - 1),
                ${n} ? float(round(sourceFracRow)) :
                                  float(floor(sourceFracRow))));

            int sourceNearestCol = int(min(
                float(int(${i}) - 1),
                ${n} ? float(round(sourceFracCol)) :
                                  float(floor(sourceFracCol))));

            if (r == sourceNearestRow && c == sourceNearestCol) {
              accumulator += getDy(b, dyR, dyC, d);
            }
          }
        }
        // End loop over dy

        setOutput(accumulator);
      }
    `}};function gU(e){let{inputs:t,backend:n,attrs:r}=e,{images:i,dy:a}=t,{alignCorners:o}=r,s=new hU(a.shape,i.shape,o);return n.runWebGLProgram(s,[a],a.dtype)}var _U={kernelName:Ts,backendName:`webgl`,kernelFunc:gU},vU=class{constructor(e,t){this.variableNames=[`x`];let n=e.length;if(n>4)throw Error(`WebGL backend: Reverse of rank-${n} tensor is not yet supported`);if(this.outputShape=e,n===1){this.userCode=`
        void main() {
          int coord = getOutputCoords();
          setOutput(getX(${e[0]} - coord - 1));
        }
      `;return}let r=n=>t.indexOf(n)!==-1&&e[n]!==1?`${e[n]} - coords[${n}] - 1`:`coords[${n}]`,i=e.map((e,t)=>r(t)).join(`,`),a=kP(n);this.userCode=`
      void main() {
        ${a} coords = getOutputCoords();
        setOutput(getX(${i}));
      }
    `}},yU=class{constructor(e,t){this.variableNames=[`x`],this.packedInputs=!0,this.packedOutput=!0;let n=e.length;if(n>4)throw Error(`WebGL backend: Reverse of rank-${n} tensor is not yet supported`);this.outputShape=e;let r=pI(`rc`,n),i=`${r[n-1]} + 1 < ${this.outputShape[n-1]}`,a=`${r[n-2]} + 1 < ${this.outputShape[n-2]}`,o=kP(n);n===1?this.userCode=`
        void main(){
          int rc = getOutputCoords();
          vec4 result = vec4(0.);
          result.r = getChannel(getX(${e[0]} - rc - 1),
            ${e[0]} - rc - 1);
          if(${i}){
              result.g = getChannel(getX(${e[0]} - (rc  + 1) - 1),
                ${e[0]} - (rc  + 1) - 1);
          }
          setOutput(result);
        }
      `:this.userCode=`
        void main() {
          ${o} rc = getOutputCoords();
          vec4 result = vec4(0.);
          result.r = ${s(r.slice())};
          if(${i}){
            result.g = ${c(r.slice())};
          }
          if(${a}) {
            result.b = ${l(r.slice())};
            if(${i}) {
              result.a = ${u(r.slice())};
            }
          }
          setOutput(result);
        }
    `;function s(e){return d(e)}function c(e){return e[n-1]=`(`+e[n-1]+` + 1)`,d(e)}function l(e){return e[n-2]=`(`+e[n-2]+` + 1)`,d(e)}function u(e){return e[n-1]=`(`+e[n-1]+` + 1)`,e[n-2]=`(`+e[n-2]+` + 1)`,d(e)}function d(t){let n=e.map((e,n)=>f(n,t));return`getChannel(getX(${n.join(`,`)}), vec2(${n.slice(-2).join(`,`)}))`}function f(n,r){return t.indexOf(n)!==-1&&e[n]!==1?`${e[n]} - ${r[n]} - 1`:`${r[n]}`}}};function bU(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{dims:a}=r,o=i.shape.length,s=H(a,i.shape);if(o===0)return iL({inputs:{x:i},backend:n});let c=j().getBool(`WEBGL_PACK_ARRAY_OPERATIONS`)?new yU(i.shape,s):new vU(i.shape,s);return n.runWebGLProgram(c,[i],i.dtype)}var xU={kernelName:fc,backendName:`webgl`,kernelFunc:bU},SU=class{constructor(e,t){this.variableNames=[`Image`],this.outputShape=[],this.customUniforms=[{name:`params`,type:`vec4`}];let n=e[1],r=e[2];this.outputShape=e;let i=``;i=typeof t==`number`?`float outputValue = ${t.toFixed(2)};`:`
        vec3 fill = vec3(${t.join(`,`)});
        float outputValue = fill[coords[3]];`,this.userCode=`
        void main() {
          ivec4 coords = getOutputCoords();
          int x = coords[2];
          int y = coords[1];
          float coordXFloat = (float(x) - params[0]) * params[3] -
            (float(y) - params[1]) * params[2];
          float coordYFloat = (float(x) - params[0]) * params[2] +
            (float(y) - params[1]) * params[3];
          int coordX = int(round(coordXFloat + params[0]));
          int coordY = int(round(coordYFloat + params[1]));
          ${i}
          if(coordX >= 0 && coordX < ${r} && coordY >= 0 && coordY < ${n}) {
            outputValue = getImage(coords[0], coordY, coordX, coords[3]);
          }
          setOutput(outputValue);
        }
    `}},CU={kernelName:wo,backendName:`webgl`,kernelFunc:({inputs:e,attrs:t,backend:n})=>{let{image:r}=e,{radians:i,fillValue:a,center:o}=t,s=n,c=new SU(r.shape,a),[l,u]=Ku(o,r.shape[1],r.shape[2]),d=[[l,u,Math.sin(i),Math.cos(i)]];return s.runWebGLProgram(c,[r],r.dtype,d)}},wU={kernelName:qi,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  // OpenGL ES does not support round function.
  // The algorithm is based on banker's rounding.
  float base = floor(x);
  if ((x - base) < 0.5) {
    return floor(x);
  } else if ((x - base) > 0.5) {
    return ceil(x);
  } else {
    if (mod(base, 2.0) == 0.0) {
      return base;
    } else {
      return base + 1.0;
    }
  }
`})},TU={kernelName:Is,backendName:`webgl`,kernelFunc:Q({opSnippet:`return inversesqrt(x);`,cpuKernelImpl:qF})},EU=class{constructor(e,t,n,r,i,a,o=!0,s=!1){this.variableNames=[`updates`,`indices`,`defaultValue`],this.outputShape=a;let c=kP(i.length),l=kP(a.length),u=``;n===1?u=`i`:n===2&&(u=`i, j`);let d=`getIndices(${u})`,f=``;r===1?f=`i`:r===2&&(f=`i, coords[1]`);let p=`getUpdates(${f})`,m=``;s&&(m=`coords[0], coords[1]`);let h=`getDefaultValue(${m})`,g=t>1?`strides[j]`:`strides`;this.userCode=`
        ${c} strides = ${c}(${i});

        void main() {
          ${l} coords = getOutputCoords();
          float sum = 0.0;
          bool found = false;
          for (int i = 0; i < ${e}; i++) {
            int flattenedIndex = 0;
            for (int j = 0; j < ${t}; j++) {
              int index = round(${d});
              flattenedIndex += index * ${g};
            }
            if (flattenedIndex == coords[0]) {
              sum += ${p};
              found = true;
            }
          }
          setOutput(mix(${h}, sum, float(found)));
        }
      `}},DU=class{constructor(e,t,n,r,i,a,o=!0,s=!1){this.variableNames=[`updates`,`indices`,`defaultValue`],this.packedInputs=!0,this.packedOutput=!0,this.outputShape=a;let c=kP(i.length),l=kP(a.length),u=``;n===1?u=`i`:n===2&&(u=`i, j`);let d=`getIndices(${u})`,f=``;r===1?f=`i`:r===2&&(f=`i, coords[1]`);let p=`getUpdates(${f})`,m=``;s&&(m=`coords[0], coords[1]`);let h=`getDefaultValue(${m})`,g=t>1?`strides[j]`:`strides`,_=t>1?`strides[j + 1]`:`strides`;this.userCode=`
        ${c} strides = ${c}(${i});

        void main() {
          ${l} coords = getOutputCoords();
          vec4 sum = vec4(0.);
          vec4 found = vec4(0.);
          for (int i = 0; i < ${e}; i+=2) {
            ivec2 flattenedIndex = ivec2(0);
            for (int j = 0; j < ${t}; j+=2) {
              ivec4 index = round(${d});
              flattenedIndex += index.xz * ${g};
              if (j + 1 < ${t}) {
                flattenedIndex += index.yw * ${_};
              }
            }
            if (flattenedIndex[0] == coords[0] || flattenedIndex[1] == coords[0] ||
                flattenedIndex[0] == coords[0] + 1 || flattenedIndex[1] == coords[0] + 1) {
              vec4 updVals = ${p};
              if (flattenedIndex[0] == coords[0]) {
                sum.xy += updVals.xy;
                found.xy = vec2(1.);
              } else if (flattenedIndex[0] == coords[0] + 1) {
                sum.zw += updVals.xy;
                found.zw = vec2(1.);
              }
              if (flattenedIndex[1] == coords[0]) {
                sum.xy += updVals.zw;
                found.xy = vec2(1.);
              } else if (flattenedIndex[1] == coords[0] + 1) {
                sum.zw += updVals.zw;
                found.zw = vec2(1.);
              }
            }
          }
          setOutput(mix(${h}, sum, found));
        }
      `}};function OU(e){let{inputs:t,backend:n,attrs:r}=e,{indices:i,updates:a}=t,{shape:o}=r,{sliceRank:s,numUpdates:c,sliceSize:l,strides:u,outputSize:d}=Xa(a,i,o),f=[d/l,l];if(d===0)return n.makeTensorInfo(o,i.dtype);let p=$({inputs:{x:i},backend:n,attrs:{shape:[c,s]}}),m=$({inputs:{x:a},backend:n,attrs:{shape:[c,l]}}),h=n.makeTensorInfo([],`float32`,new Float32Array([0])),g;g=j().getBool(`WEBGL_PACK`)?new DU(c,s,p.shape.length,m.shape.length,u,f):new EU(c,s,p.shape.length,m.shape.length,u,f);let _=n.runWebGLProgram(g,[m,p,h],m.dtype),v=$({inputs:{x:_},backend:n,attrs:{shape:o}});return n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),n.disposeIntermediateTensorInfo(_),n.disposeIntermediateTensorInfo(h),v}var kU={kernelName:Sc,backendName:`webgl`,kernelFunc:OU},AU=class{constructor(e,t,n,r){this.variableNames=[`sortedSequence`,`values`],this.customUniforms=[{name:`numInputs`,type:`int`}],this.outputShape=[e,n];let i=`for (int i = 0; i < ${Math.ceil(Math.log2(t+1))}; ++i) { if (left >= right) break;`,a=j().getNumber(`WEBGL_VERSION`)===2?`while (left < right) {`:i,o=r===`left`?`<`:`<=`;this.userCode=`
       int findBound(int batch, float value) {
         int left = 0;
         int right = numInputs;
         int mid;
         ${a}
           mid = (left + right) / 2;
           if (getSortedSequence(batch, mid) ${o} value) {
             left = mid + 1;
           } else {
             right = mid;
           }
         }
         return right;
       }

       void main() {
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int valueIndex = coords[1];

         float value = getValues(batch, valueIndex);

         setOutput(float(findBound(batch, value)));
       }
     `}};function jU(e){let{inputs:t,backend:n,attrs:r}=e,{sortedSequence:i,values:a}=t,{side:o}=r,s=new AU(i.shape[0],i.shape[1],a.shape[1],o),c=[[i.shape[1]]];return n.runWebGLProgram(s,[i,a],`int32`,c)}var MU={kernelName:ha,backendName:`webgl`,kernelFunc:jU},NU=class{constructor(e,t,n){this.variableNames=[`c`,`a`,`b`],this.outputShape=t;let r,i;if(n>4)throw Error(`Where for rank ${n} is not yet supported`);if(n===1)i=`resRC`,r=`resRC`;else{let n=[`resRC.x`,`resRC.y`,`resRC.z`,`resRC.w`],a=[],o=[];for(let r=0;r<t.length;r++)o.push(`${n[r]}`),r<e&&a.push(`${n[r]}`);r=a.join(),i=o.join()}let a=kP(n);this.userCode=`
      void main() {
        ${a} resRC = getOutputCoords();
        float cVal = getC(${r});
        if (cVal >= 1.0) {
          setOutput(getA(${i}));
        } else {
          setOutput(getB(${i}));
        }
      }
    `}};function PU(e){let{inputs:t,backend:n}=e,{condition:r,t:i,e:a}=t,o=new NU(r.shape.length,i.shape,i.shape.length);return n.runWebGLProgram(o,[r,i,a],Rs(i.dtype,a.dtype))}var FU={kernelName:rs,backendName:`webgl`,kernelFunc:PU},IU={kernelName:Uc,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  // Stable and Attracting Fixed Point (0, 1) for Normalized Weights.
  // see: https://arxiv.org/abs/1706.02515
  float scaleAlpha = ${Qu};
  float scale = ${$u};
  return (x >= 0.0) ? scale * x : scaleAlpha * (exp(x) - 1.0);
`})},LU={kernelName:Ta,backendName:`webgl`,kernelFunc:Q({opSnippet:gL+`
  return 1.0 / (1.0 + exp(-1.0 * x));
`,packedOpSnippet:`
  vec4 result = 1.0 / (1.0 + exp(-1.0 * x));
  bvec4 isNaN = isnan(x);

  result.r = isNaN.r ? x.r : result.r;
  result.g = isNaN.g ? x.g : result.g;
  result.b = isNaN.b ? x.b : result.b;
  result.a = isNaN.a ? x.a : result.a;

  return result;
`,cpuKernelImpl:YF})},RU={kernelName:Ga,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  if (isnan(x)) { return 0.0; }
  return sign(x);
`})},zU={kernelName:`Sin`,backendName:`webgl`,kernelFunc:Q({opSnippet:gL+`
  return sin(x);
`,packedOpSnippet:`
  vec4 result = sin(x);
  bvec4 isNaN = isnan(x);
  ${nL}
  return result;
`})},BU={kernelName:ms,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  float e2x = exp(x);
  return (e2x - 1.0 / e2x) / 2.0;
`})},VU={kernelName:Ii,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  float epsilon = 1.1920928955078125e-7;
  float threshold = log(epsilon) + 2.0;

  bool too_large = x > -threshold;
  bool too_small = x < threshold;

  float result;
  float exp_x = exp(x);

  if (too_large){
    result = x;
  }
  else if (too_small){
    result = exp_x;
  }
  else{
    result = log(exp_x + 1.0);
  }
  return result;
`})},HU={kernelName:$c,backendName:`webgl`,kernelFunc:e=>{let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{blockShape:a,paddings:s}=r;o(i.shape.length<=4,()=>`spaceToBatchND for rank > 4 with a WebGL backend not implemented yet`);let c=a.reduce((e,t)=>e*t),l=[[0,0]];l.push(...s);for(let e=1+a.length;e<i.shape.length;++e)l.push([0,0]);let u=[],d=HH({inputs:{x:i},backend:n,attrs:{paddings:l,constantValue:0}}),f=qu(d.shape,a,c,!1),p=Ju(f.length,a.length,!1),m=Yu(d.shape,a,c,!1),h=$({inputs:{x:d},backend:n,attrs:{shape:f}}),g=RL({inputs:{x:h},backend:n,attrs:{perm:p}}),_=$({inputs:{x:g},backend:n,attrs:{shape:m}});return u.push(d),u.push(h),u.push(g),u.forEach(e=>n.disposeIntermediateTensorInfo(e)),_}};function UU(e){let{inputs:t,backend:n}=e,{indices:r,values:i,denseShape:a,defaultValue:o}=t;if(a.shape.length!==1)throw Error(`Dense shape must be a vector, saw:
         ${a.shape}`);if(r.shape.length!==2)throw Error(`Indices must be a matrix, saw:
         ${r.shape}`);if(i.shape.length!==1)throw Error(`Values must be a vector, saw:
         ${i.shape}`);if(o.shape.length!==0)throw Error(`Default value must be a scalar, saw:
        ${o.shape}`);let s=n.readSync(r.dataId),c=n.readSync(i.dataId),l=n.readSync(a.dataId),u=n.readSync(o.dataId)[0],[d,f,p,m,h]=QF(s,r.shape,r.dtype,c,i.dtype,l,u);return[n.makeTensorInfo(f,r.dtype,d),n.makeTensorInfo([f[0]],i.dtype,p),n.makeTensorInfo([m.length],`bool`,new Uint8Array(m.map(e=>Number(e)))),n.makeTensorInfo([h.length],r.dtype,new Int32Array(h))]}var WU={kernelName:Al,backendName:`webgl`,kernelFunc:UU};function GU(e){let{inputs:t,backend:n}=e,{inputIndices:r,inputShape:i,newShape:a}=t;if(r.shape.length!==2)throw Error(`Input indices should be a matrix but received shape ${r.shape}`);if(i.shape.length!==1)throw Error(`Input shape should be a vector but received shape ${i.shape}`);if(a.shape.length!==1)throw Error(`Target shape should be a vector but received shape ${a.shape}`);let o=Array.from(n.readSync(i.dataId)),s=n.readSync(r.dataId),c=Array.from(n.readSync(a.dataId)),[l,u,d]=$F(s,r.shape,r.dtype,o,c);return[n.makeTensorInfo(u,r.dtype,l),n.makeTensorInfo([d.length],a.dtype,new Int32Array(d))]}var KU={kernelName:ia,backendName:`webgl`,kernelFunc:GU};function qU(e){let{inputs:t,backend:n}=e,{data:r,indices:i,segmentIds:a}=t;if(r.shape.length<1)throw Error(`Data should be at least 1 dimensional but received scalar`);if(i.shape.length!==1)throw Error(`Indices should be a vector but received shape
              ${i.shape}`);if(a.shape.length!==1)throw Error(`Segment ids should be a vector but received shape
              ${a.shape}`);let o=n.readSync(r.dataId),s=n.readSync(i.dataId),c=n.readSync(a.dataId),[l,u]=eI(o,r.shape,r.dtype,s,c,!0);return n.makeTensorInfo(u,r.dtype,l)}var JU={kernelName:bl,backendName:`webgl`,kernelFunc:qU};function YU(e){let{inputs:t,backend:n}=e,{data:r,indices:i,segmentIds:a}=t;if(r.shape.length<1)throw Error(`Data should be at least 1 dimensional but received scalar`);if(i.shape.length!==1)throw Error(`Indices should be a vector but received shape
             ${i.shape}`);if(a.shape.length!==1)throw Error(`Segment ids should be a vector but received shape
             ${a.shape}`);let o=n.readSync(r.dataId),s=n.readSync(i.dataId),c=n.readSync(a.dataId),[l,u]=eI(o,r.shape,r.dtype,s,c);return n.makeTensorInfo(u,r.dtype,l)}var XU={kernelName:pr,backendName:`webgl`,kernelFunc:YU};function ZU(e){let{inputs:t,backend:n,attrs:r}=e,{sparseIndices:i,sparseValues:a,defaultValue:o}=t,{outputShape:s}=r,{sliceRank:c,numUpdates:l,sliceSize:u,strides:d,outputSize:f}=Xa(a,i,s);if(a.dtype===`string`){let e=JF(n.bufferSync(i),n.bufferSync(a),s,f,u,l,c,d,qa(n.readSync(o.dataId)[0]),!1);return n.makeTensorInfo(s,e.dtype,e.values)}let p=new EU(l,c,i.shape.length,a.shape.length,d,[f,1],!1),m=n.runWebGLProgram(p,[a,i,o],a.dtype),h=$({inputs:{x:m},backend:n,attrs:{shape:s}});return n.disposeIntermediateTensorInfo(m),h}var QU={kernelName:ue,backendName:`webgl`,kernelFunc:ZU};function $U(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{numOrSizeSplits:a,axis:o}=r,s=H(o,i.shape)[0],c=wd(i,a,s),l=i.shape.length,u=Array(l).fill(0),d=i.shape.slice();return c.map(e=>{let t=[...d];t[s]=e;let r=BR({inputs:{x:i},backend:n,attrs:{begin:u,size:t}});return u[s]+=e,r})}var eW={kernelName:ul,backendName:`webgl`,kernelFunc:$U},tW=`return sqrt(x);`,nW={kernelName:wr,backendName:`webgl`,kernelFunc:Q({opSnippet:tW,packedOpSnippet:tW,cpuKernelImpl:tI})},rW={kernelName:je,backendName:`webgl`,kernelFunc:Q({opSnippet:`return x * x;`})},iW=`return (a - b) * (a - b);`,aW={kernelName:be,backendName:`webgl`,kernelFunc:_L({opSnippet:iW,packedOpSnippet:iW})};function oW(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t;if(i.dtype!==`string`)throw Error(`Input must be of datatype string`);let a=nI(Hd(n.readSync(i.dataId)),`string`,r);return n.makeTensorInfo(i.shape,`string`,a)}var sW={kernelName:En,backendName:`webgl`,kernelFunc:oW};function cW({inputs:e,attrs:t,backend:n}){let{x:r}=e,i=EI+`
    return x > 0.0 ? 1.0 : float(${t.alpha});
  `,a=new TI(r.shape,i);return n.runWebGLProgram(a,[r],r.dtype)}var lW={kernelName:Ko,backendName:`webgl`,kernelFunc:cW},uW=class{constructor(e,t,n){this.variableNames=[`x`],this.outputShape=n;let r=n.length,i=kP(n.length),a=kP(n.length),o=``;if(r===1)o=`coords * strides + begin`;else{let e=0;o=n.map((t,r)=>(e++,n.length===1?`coords * strides[${r}] + begin[${r}]`:`coords[${e-1}] * strides[${r}] + begin[${r}]`)).join(`,`)}this.userCode=`
      ${i} begin = ${i}(${e});
      ${i} strides = ${i}(${t});

      void main() {
        ${a} coords = getOutputCoords();
        setOutput(getX(${o}));
      }
    `}};function dW(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{begin:a,end:s,strides:c,beginMask:l,endMask:u,ellipsisMask:d,newAxisMask:f,shrinkAxisMask:p}=r,{finalShapeSparse:m,finalShape:h,isIdentity:g,sliceDim0:_,isSimpleSlice:v,begin:y,end:b,strides:x}=Au(i.shape,a,s,c,l,u,d,f,p),S;if(g)S=$({inputs:{x:i},backend:n,attrs:{shape:h}});else if(_||v){o(i.shape.length>=1,()=>`Input must have rank at least 1, got: ${i.shape.length}`);let e=_u(y,b,x),t=BR({inputs:{x:i},backend:n,attrs:{begin:y,size:e}});S=$({inputs:{x:t},backend:n,attrs:{shape:h}}),n.disposeIntermediateTensorInfo(t)}else if(n.shouldExecuteOnCPU([i])){let e=n.readSync(i.dataId),t=rI(m,M(i.shape,i.dtype,e),x,y);S=n.makeTensorInfo(h,i.dtype,t.values)}else{let e=new uW(y,x,m);S=n.runWebGLProgram(e,[i],i.dtype)}let C=$({inputs:{x:S},backend:n,attrs:{shape:h}});return n.disposeIntermediateTensorInfo(S),C}var fW={kernelName:g,backendName:`webgl`,kernelFunc:dW};function pW(e){let{inputs:t,backend:n,attrs:r}=e,{separator:i,nGramWidths:a,leftPad:o,rightPad:s,padWidth:c,preserveShortSequences:l}=r,{data:u,dataSplits:d}=t,[f,p]=iI(n.readSync(u.dataId),n.readSync(d.dataId),i,a,o,s,c,l);return[n.makeTensorInfo([f.length],`string`,f),n.makeTensorInfo(d.shape,`int32`,p)]}var mW={kernelName:Fo,backendName:`webgl`,kernelFunc:pW};function hW(e){let{inputs:t,backend:n,attrs:r}=e,{skipEmpty:i}=r,{input:a,delimiter:o}=t;if(a.dtype!==`string`)throw Error(`Input must be of datatype string`);if(a.shape.length!==1)throw Error(`Input must be a vector, got shape: ${a.shape}`);if(o.shape.length!==0)throw Error(`Delimiter must be a scalar, got shape: ${o.shape}`);let s=n.readSync(a.dataId),c=n.readSync(o.dataId)[0],[l,u,d]=aI(s,c,i),f=u.length;return[n.makeTensorInfo([f,2],`int32`,l),n.makeTensorInfo([f],`string`,u),n.makeTensorInfo([2],`int32`,new Int32Array(d))]}var gW={kernelName:an,backendName:`webgl`,kernelFunc:hW};function _W(e){let{inputs:t,backend:n,attrs:r}=e,{numBuckets:i}=r,{input:a}=t;if(a.dtype!==`string`)throw Error(`Input must be of datatype string`);if(i<=0)throw Error(`Number of buckets must be at least 1`);let o=oI(n.readSync(a.dataId),i);return n.makeTensorInfo(a.shape,`int32`,o)}var vW={kernelName:gn,backendName:`webgl`,kernelFunc:_W},yW={kernelName:`Tan`,backendName:`webgl`,kernelFunc:Q({opSnippet:`return tan(x);`})},bW={kernelName:Jt,backendName:`webgl`,kernelFunc:Q({opSnippet:`
  float e2x = exp(-2.0 * abs(x));
  return sign(x) * (1.0 - e2x) / (1.0 + e2x);
`})};function xW(e){let{inputs:t,backend:n,attrs:r}=e,{tensor:i,indices:a,updates:o}=t,{}=r,{sliceRank:s,numUpdates:c,sliceSize:l,strides:u,outputSize:d}=Xa(o,a,i.shape),f=[d/l,l];if(d===0)return n.makeTensorInfo(i.shape,a.dtype);let p=$({inputs:{x:a},backend:n,attrs:{shape:[c,s]}}),m=$({inputs:{x:o},backend:n,attrs:{shape:[c,l]}}),h=$({inputs:{x:i},backend:n,attrs:{shape:f}}),g=new EU(c,s,p.shape.length,m.shape.length,u,f,!1,!0),_=n.runWebGLProgram(g,[m,p,h],h.dtype),v=$({inputs:{x:_},backend:n,attrs:{shape:i.shape}});return n.disposeIntermediateTensorInfo(p),n.disposeIntermediateTensorInfo(m),n.disposeIntermediateTensorInfo(h),n.disposeIntermediateTensorInfo(_),v}var SW={kernelName:rr,backendName:`webgl`,kernelFunc:xW},CW=class{constructor(e,t){this.variableNames=[`A`];let n=Array(e.length);for(let r=0;r<n.length;r++)n[r]=e[r]*t[r];this.outputShape=n,this.rank=n.length;let r=kP(this.rank),i=wW(e);this.userCode=`
      void main() {
        ${r} resRC = getOutputCoords();
        setOutput(getA(${i}));
      }
    `}};function wW(e){let t=e.length;if(t>5)throw Error(`Tile for rank ${t} is not yet supported`);if(t===1)return`imod(resRC, ${e[0]})`;let n=[`resRC.x`,`resRC.y`,`resRC.z`,`resRC.w`,`resRC.u`],r=[];for(let t=0;t<e.length;t++)r.push(`imod(${n[t]}, ${e[t]})`);return r.join()}function TW(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{reps:a}=r;if(i.dtype===`string`||i.shape.length>5){let e=n.readSync(i.dataId),t=i.dtype===`string`?e.map(e=>qa(e)):e,r=cI(M(i.shape,i.dtype,t),a);return n.makeTensorInfo(r.shape,r.dtype,r.values)}let o=new CW(i.shape,a);return n.runWebGLProgram(o,[i],i.dtype)}var EW={kernelName:Bl,backendName:`webgl`,kernelFunc:TW},DW=class{constructor(e){this.variableNames=[`x`,`indices`],this.customUniforms=[{name:`n`,type:`int`},{name:`firstPass`,type:`int`},{name:`negativeInf`,type:`float`},{name:`dir`,type:`int`},{name:`inc`,type:`int`}],this.outputShape=e,this.userCode=`
       void main() {
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int elemIdx = coords[1];

         // We compare elements pair-wise within a group of size 2 * inc.
         // The comparing rule for each group alternates between ascending
         // and descending. Within each group, we compare each pair at
         // positions i and i+inc. To decide whether an element at position i
         // is x0 or x1, we mod it by 2 * inc, if the result is smaller than
         // inc, it is in the first half of the group, we denote it as x0,
         // otherwise we denote it as x1.
         // For example, as shown in the Bitonic top K paper referenced above,
         // Figure5(a) shows that element[1] is in the
         // second half of the group when group size is 2, but it is in the
         // first half of the group when group size is 4.

         bool isFirstInPair = imod(elemIdx, 2 * inc) < inc;
         int i = isFirstInPair ? elemIdx : elemIdx - inc;

         int i0 = firstPass == 1 ? i : int(getIndices(batch, i));
         int i1 = firstPass == 1 ? i + inc : int(getIndices(batch, i + inc));
         float x0 = i0 < n ? getX(batch, i0) : negativeInf;
         float x1 = i1 < n ? getX(batch, i1) : negativeInf;

         // Denotes which direction indices are in (ascending or descending).
         bool reverse = imod(elemIdx, 2 * dir) >= dir;
         bool isGreater = x0 > x1 || (x0 == x1 && i1 > i0);
         if (reverse == isGreater) { // Elements in opposite order of direction
           int iTemp = i0;
           i0 = i1;
           i1 = iTemp;
         }
         if (isFirstInPair) {
            setOutput(float(i0));
         } else {
            setOutput(float(i1));
         }
       }
     `}},OW=class{constructor(e){this.variableNames=[`x`,`indices`],this.customUniforms=[{name:`n`,type:`int`},{name:`firstPass`,type:`int`},{name:`k`,type:`int`}],this.outputShape=e,this.userCode=`
    void main() {
         // Takes max of indices (0, k), (1, k + 1), (2, k + 2) ...
         ivec2 coords = getOutputCoords();
         int batch = coords[0];
         int elemIdx = coords[1];

         // The output size is half of the previous size.
         // If the previous sequence is | | | | _ _ _ _  | | | |  _ _ _ _ (k=4),
         // we only need to output the indices at positions |, the indices at
         // positions _ can be thrown away, see Figure5(b) After Phase 2
         // (Merge phase) in the Bitonic Top K paper referenced above.
         // For example, the paper shows we only need to output the orange bars.
         // The output sequence should look like this | | | | | | | |.
         // Because the sequence is halved, to map the output index back
         // to the previous sequence to find the corresponding value,
         // we need to double the index. When we double the index,
         // we basically interpolate a position, so 2i looks like
         // | _ | _ | _ | _ | _ | _ | _. We move the | to the first k position
         // of each 2k positions by - elemIdx % k. E.g. for output at
         // index 4,5,6,7, we want to get the corresponding element at
         // original index 8,9,10,11, for output at index 8,9,10,11,
         // we want to get the corresponding element at original index
         // 16,17,18,19, so on and so forth.

         int i = elemIdx < k ? elemIdx : (elemIdx * 2 - imod(elemIdx, k));
         int i0 = firstPass == 1 ? i : int(getIndices(batch, i));
         int i1 = firstPass == 1 ? i + k : int(getIndices(batch, i + k));

         float x0 = getX(batch, i0);
         float x1 = i1 < n ? getX(batch, i1) : x0;

         setOutput(x0 >= x1 ? float(i0) : float(i1));
       }
     `}};function kW(e,t){t!==null&&e.disposeIntermediateTensorInfo(t)}function AW(e){let t=1;for(;t<e;)t*=2;return t}function jW(e){let{inputs:t,backend:n,attrs:r}=e,{x:i}=t,{k:a,sorted:o}=r,s=j().getNumber(`TOPK_LAST_DIM_CPU_HANDOFF_SIZE_THRESHOLD`),c=j().getNumber(`TOPK_K_CPU_HANDOFF_THRESHOLD`),l=i.shape,u=l[l.length-1];if(n.shouldExecuteOnCPU([i])||u<s||a>c){let[e,t]=lI(n.readSync(i.dataId),l,i.dtype,a,o);return[n.makeTensorInfo(e.shape,e.dtype,e.values),n.makeTensorInfo(t.shape,t.dtype,t.values)]}if(a===0)return l[l.length-1]=0,[n.makeTensorInfo(l,i.dtype,[]),n.makeTensorInfo(l,`int32`,[])];if(u===1)return[i,qB({attrs:{shape:l,dtype:`int32`,value:0},backend:n})];let d=n.texData.get(i.dataId),f=d!==null&&d.isPacked,p=f?n.unpackTensor(i):i,m=k(l)/u,h=$({inputs:{x:p},attrs:{shape:[m,u]},backend:n});f&&kW(n,p);let g=AW(a),_=AW(u),v=null,y=()=>v===null?[h,h]:[h,v],b=(e,t,r)=>{let i=y(),a=new DW(r),o=[[u],[+(v===null)],[-1/0],[e],[t]],s=v;v=n.runWebGLProgram(a,i,`int32`,o),kW(n,s)};for(let e=1;e<g;e*=2){let t=e*2;for(let n=e;n>=1;n/=2)b(t,n,[m,_])}for(let e=_;e>g;e/=2){let t=y(),r=new OW([m,e/2]),i=[[u],[+(v===null)],[g]],a=v;v=n.runWebGLProgram(r,t,`int32`,i),kW(n,a);let o=g/2,s=o*2;for(let e=o;e>=1;e/=2)b(s,e,v.shape)}let x=v;v=BR({inputs:{x:v},backend:n,attrs:{begin:0,size:[m,a]}}),kW(n,x);let S=hV({inputs:{x:h,indices:v},backend:n,attrs:{axis:1,batchDims:1}});kW(n,h);let C=l.slice(0,-1);C.push(a),x=v,v=$({inputs:{x:v},attrs:{shape:C},backend:n}),kW(n,x);let w=S;return S=$({inputs:{x:S},attrs:{shape:C},backend:n}),kW(n,w),[S,v]}var MW={kernelName:ee,backendName:`webgl`,kernelFunc:jW},NW=class{constructor(e,t,n,r,i,a){this.variableNames=[`Image`,`Transforms`],this.outputShape=a;let o=n===`nearest`?1:2,s;switch(r){case`constant`:s=1;break;case`reflect`:s=2;break;case`wrap`:s=3;break;case`nearest`:s=4;break;default:s=1;break}this.userCode=`
            float mapCoord(float outCoord, float len) {
              float inCoord = outCoord;
              if(${s} == 2) {
                if (inCoord < 0.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz2 = 2.0 * len;
                    if (inCoord < sz2) {
                      inCoord = sz2 * float(int(float(-inCoord / sz2))) +
                      inCoord;
                    }
                    inCoord = inCoord < -len ? inCoord + sz2 : -inCoord - 1.0;
                  }
                } else if (inCoord > len - 1.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz2 = 2.0 * len;
                    inCoord -= sz2 * float(int(float(inCoord / sz2)));
                    if (inCoord >= len) {
                      inCoord = sz2 - inCoord - 1.0;
                    }
                  }
                }
                return clamp(inCoord, 0.0, len - 1.0);
              } else if (${s} == 3) {
                if (inCoord < 0.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz = len - 1.0;
                    inCoord += len * (float(int(float(-inCoord / sz))) + 1.0);
                  }
                } else if (inCoord > len - 1.0) {
                  if (len <= 1.0) {
                    inCoord = 0.0;
                  } else {
                    float sz = len - 1.0;
                    inCoord -= len * float(int(float(inCoord / sz)));
                  }
                }
                return clamp(inCoord, 0.0, len - 1.0);
              } else if (${s} == 4) {
                return clamp(outCoord, 0.0, len - 1.0);
              } else {
                return outCoord;
              }
            }

            float readWithFillValue(int batch, int coordY, int coordX,
              int channel) {
              float outputValue;
              if (0 <= coordY && coordY < ${e} && 0 <= coordX && coordX < ${t}) {
                  outputValue = getImage(batch, coordY, coordX, channel);
              } else {
                outputValue = float(${i});
              }
              return outputValue;
            }

            void main() {
              ivec4 coords = getOutputCoords();
              float outputValue;
              int batch = coords[0];
              int x = coords[2];
              int y = coords[1];
              int channel = coords[3];
              float xf = float(x);
              float yf = float(y);
              float a1 = getTransforms(batch, 0);
              float a2 = getTransforms(batch, 1);
              float a3 = getTransforms(batch, 2);
              float b1 = getTransforms(batch, 3);
              float b2 = getTransforms(batch, 4);
              float b3 = getTransforms(batch, 5);
              float c1 = getTransforms(batch, 6);
              float c2 = getTransforms(batch, 7);
              float projection = c1 * xf + c2 * yf + 1.0;
              if (projection == 0.0) {
                outputValue = float(${i});
              } else {
                float inX = (a1 * xf + a2 * yf + a3) / projection;
                float inY = (b1 * xf + b2 * yf + b3) / projection;
                float mapX = mapCoord(inX, float(${t}));
                float mapY = mapCoord(inY, float(${e}));

                if (${o} == 1) {
                  int coordY = int(round(mapY));
                  int coordX = int(round(mapX));
                  outputValue = readWithFillValue(batch, coordY, coordX,
                    channel);
                } else {
                  float yFloor = floor(mapY);
                  float xFloor = floor(mapX);
                  float yCeil = yFloor + 1.0;
                  float xCeil = xFloor + 1.0;
                  float valueYFloor = (xCeil - mapX) *
                  readWithFillValue(batch, int(yFloor), int(xFloor), channel) +
                  (mapX - xFloor) *
                  readWithFillValue(batch, int(yFloor), int(xCeil), channel);
                  float valueYCeil = (xCeil - mapX) *
                  readWithFillValue(batch, int(yCeil), int(xFloor), channel) +
                  (mapX - xFloor) *
                  readWithFillValue(batch, int(yCeil), int(xCeil), channel);
                  outputValue = (yCeil - mapY) * valueYFloor +
                  (mapY - yFloor) * valueYCeil;
                }
              }
              setOutput(outputValue);
            }
        `}};function PW(e){let{inputs:t,backend:n,attrs:r}=e,{image:i,transforms:a}=t,{interpolation:o,fillMode:s,fillValue:c,outputShape:l}=r,[u,d,f,p]=i.shape,[m,h]=l??[d,f],g=new NW(d,f,o,s,c,[u,m,h,p]);return n.runWebGLProgram(g,[i,a],`float32`)}var FW={kernelName:Hr,backendName:`webgl`,kernelFunc:PW};function IW(e){let{inputs:t,attrs:n,backend:r}=e,{axis:i}=n,{x:a}=t;MN(a,`unique`),console.warn(`WARNING: `,`UI might be locked temporarily as data is being downloaded`);let{outputValues:o,outputShape:s,indices:c}=dI(r.readSync(a.dataId),i,a.shape,a.dtype);return[r.makeTensorInfo(s,a.dtype,o),r.makeTensorInfo([c.length],`int32`,c)]}var LW={kernelName:Mr,backendName:`webgl`,kernelFunc:IW};function RW(e){let{inputs:t,backend:n,attrs:r}=e,{value:i}=t,{axis:a}=r;a<0&&(a+=i.shape.length);let o=i,s=o.shape.length,c=i.shape[a],l=Array(s-1),u=0;for(let e=0;e<s;e++)e!==a&&(l[u++]=o.shape[e]);let d=[],f=Array(s).fill(0),p=o.shape.slice();p[a]=1;let m=Array(c);for(let e=0;e<m.length;e++){f[a]=e;let t=BR({inputs:{x:o},backend:n,attrs:{begin:f,size:p}});m[e]=$({inputs:{x:t},backend:n,attrs:{shape:l}}),d.push(t)}return d.forEach(e=>n.disposeIntermediateTensorInfo(e)),m}var zW={kernelName:Qr,backendName:`webgl`,kernelFunc:RW},BW=class{constructor(e,t){this.variableNames=[`x`,`segmentIds`];let n=e.windowSize,r=e.batchSize,i=e.inSize,a=e.numSegments,o=a*Math.ceil(i/n);this.outputShape=[r,o];let s=Math.floor(n/4)*4,c=n%4,l=`
        sumValue += dot(values, segFilter);
    `,u=``;i%n>0&&(u=`
        if (inIdx < 0 || inIdx >= ${i}) {
          return initializationValue;
        }
      `);let d=``;i%n>0&&(d=`
        if (inIdx < 0 || inIdx >= ${i}) {
          return -1.0;
        }
      `),this.userCode=`
      const float initializationValue = 0.0;

      float getValue(int batch, int inIdx) {
        ${u}
        return getX(batch, inIdx);
      }

      float getSegmentIdAtIndex(int inIdx) {
        ${d}
        return getSegmentIds(inIdx);
      }

      void main() {
        ivec2 coords = getOutputCoords();
        int batch = coords[0];
        int outIdx = coords[1];
        int inOffset = int(floor(float(outIdx) / float(
          ${a})) * float(${n}));
        int currentSeg = int(mod(float(outIdx), float(${a})));

        float sumValue = 0.0;

        for (int i = 0; i < ${s}; i += 4) {
          int inIdx = inOffset + i;
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            getValue(batch, inIdx + 3)
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 2)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 3)) == currentSeg ? 1 : 0
          );

          ${l}
        }

        int inIdx = inOffset + ${s};
        if (${c===1}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            initializationValue,
            initializationValue,
            initializationValue
          );

          int inIdxSeg = int(getSegmentIdAtIndex(inIdx));

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            0,
            0,
            0
          );

          ${l}
        } else if (${c===2}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            initializationValue,
            initializationValue
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
              0,
              0
          );

          ${l}
        } else if (${c===3}) {
          vec4 values = vec4(
            getValue(batch, inIdx),
            getValue(batch, inIdx + 1),
            getValue(batch, inIdx + 2),
            initializationValue
          );

          vec4 segFilter = vec4(
            int(getSegmentIdAtIndex(inIdx)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 1)) == currentSeg ? 1 : 0,
            int(getSegmentIdAtIndex(inIdx + 2)) == currentSeg ? 1 : 0,
            0
          );

          ${l}
        }
        setOutput(sumValue);
      }
    `}};function VW(e){let{inputs:t,backend:n,attrs:r}=e,{x:i,segmentIds:a}=t,{numSegments:o}=r,s=i.shape.length,c=[],l=0,u=Zt([l],s),d=i;u!=null&&(d=RL({inputs:{x:i},backend:n,attrs:{perm:u}}),c.push(d),l=or(1,s)[0]);let f=zd(d.shape,l,o),p=k([d.shape[l]]),m=$({inputs:{x:d},backend:n,attrs:{shape:[-1,p]}});c.push(m);let h=Yi(i.dtype),g=(e,t,r,i,a)=>{let o=e.shape[0],s=e.shape[1],l=Rd(s,a),u=new BW({windowSize:l,inSize:s,batchSize:o,numSegments:a},t),d=n.compileAndRun(u,[e,r],i);if(c.push(d),d.shape[1]===a)return d;let f=$H({backend:n,attrs:{start:0,stop:a,step:1,dtype:`float32`}}),p=TW({inputs:{x:f},backend:n,attrs:{reps:[s/l]}});return c.push(f),c.push(p),g(d,t,p,i,a)},_=$({inputs:{x:g(m,`unsortedSegmentSum`,a,h,o)},backend:n,attrs:{shape:f}}),v=_;if(u!=null){c.push(_);let e=Ul(u);v=RL({inputs:{x:v},backend:n,attrs:{perm:e}})}return c.forEach(e=>n.disposeIntermediateTensorInfo(e)),v}var HW=[HL,GL,KL,qL,YL,$L,tR,rR,uR,fR,pR,mR,hR,gR,_R,xR,CR,DR,kR,jR,PR,HR,WR,JR,XR,iz,oz,uz,sL,mz,Cz,Mz,Rz,Vz,Uz,Gz,qz,Jz,Yz,Zz,iB,oB,cB,dB,hB,yB,xB,wB,DB,kB,AB,NB,PB,FB,LB,zB,VB,GB,JB,XB,QB,$B,nV,sV,lV,fV,gV,_V,vV,aL,bV,yz,xV,SV,CV,dL,wV,TV,DV,OV,kV,AV,jV,MV,FV,LV,BV,VV,UV,GV,YV,ZV,$V,tH,rH,iH,sH,cH,vH,wL,SH,TH,OH,jH,QR,NH,LH,zH,UH,WH,hL,KH,JH,XH,QH,eU,ez,dH,tU,nU,rU,EL,sU,uU,mU,_U,xU,CU,wU,TU,kU,MU,FU,IU,LU,RU,zU,BU,VR,gH,VU,HU,WU,KU,JU,XU,QU,eW,nW,rW,aW,sW,lW,fW,mW,gW,vW,mH,LL,yW,bW,SW,EW,MW,FW,zL,LW,zW,{kernelName:Qe,backendName:`webgl`,kernelFunc:VW},FH];for(let e of HW)Ne(e);var UW={"tfjs-core":Nu,"tfjs-backend-cpu":lD,"tfjs-backend-webgl":ZI,"tfjs-data":Kw,"tfjs-layers":gv,"tfjs-converter":Gd,tfjs:`4.22.0`};export{Lo as Abs,sn as Acos,vn as Acosh,Ni as AdadeltaOptimizer,Qa as AdagradOptimizer,co as AdamOptimizer,us as AdamaxOptimizer,zn as Add,We as AddN,bt as All,Xt as Any,ar as ArgMax,Hl as ArgMin,ne as Asin,Wr as Asinh,ut as Atan,Pr as Atan2,ei as Atanh,et as AvgPool,Bt as AvgPool3D,ic as AvgPool3DGrad,At as AvgPoolGrad,bi as BatchMatMul,ui as BatchToSpaceND,ki as Bincount,Yn as BitwiseAnd,c as BroadcastArgs,za as BroadcastTo,wC as Callback,l_ as CallbackList,Lc as Cast,ks as Ceil,gc as ClipByValue,Oo as Complex,Zi as ComplexAbs,Bs as Concat,Ec as Conv2D,ya as Conv2DBackpropFilter,ss as Conv2DBackpropInput,Kc as Conv3D,ka as Conv3DBackpropFilterV2,Ya as Conv3DBackpropInputV2,Xs as Cos,vs as Cosh,_o as CropAndResize,ao as Cumprod,Bi as Cumsum,f_ as CustomCallback,Vo as DataStorage,rl as DenseBincount,Pl as DepthToSpace,ca as DepthwiseConv2dNative,wl as DepthwiseConv2dNativeBackpropFilter,_r as DepthwiseConv2dNativeBackpropInput,me as Diag,ml as Dilation2D,Dr as Dilation2DBackpropFilter,Fe as Dilation2DBackpropInput,we as Draw,vi as ENV,DC as EarlyStopping,An as Einsum,Xo as Elu,b as EluGrad,ci as Environment,zo as Equal,ln as Erf,bn as Exp,Vn as ExpandDims,Ke as Expm1,St as FFT,Qt as Fill,sr as FlipLeftRight,Wl as Floor,ie as FloorDiv,Kr as FromPixels,ft as FusedBatchNorm,Ir as FusedConv2D,ni as FusedDepthwiseConv2D,hF as GPGPUContext,nt as GatherNd,Ht as GatherV2,kc as GraphModel,oc as Greater,Mt as GreaterEqual,d_ as History,Si as IFFT,fi as Identity,ji as Imag,og as InputSpec,Zn as IsFinite,u as IsInf,Na as IsNan,dn as KernelBackend,jc as LRN,Cs as LRNGrad,ng as LayerVariable,qv as LayersModel,uc as LeakyRelu,So as Less,Gi as LessEqual,Ps as LinSpace,bc as Log,pa as Log1p,ts as LogSoftmax,Vc as LogicalAnd,Ca as LogicalNot,Ua as LogicalOr,Ws as LogicalXor,fs as LowerBound,Yw as MathBackendCPU,YI as MathBackendWebGL,uo as MatrixBandPart,$a as Max,Pi as MaxPool,Zc as MaxPool3D,Ol as MaxPool3DGrad,na as MaxPoolGrad,vl as MaxPoolWithArgmax,dr as Maximum,ce as Mean,cl as Min,Sr as Minimum,ke as MirrorPad,ve as Mod,Va as MomentumOptimizer,wn as Multinomial,Wo as Multiply,m as Neg,No as NonMaxSuppressionV3,nn as NonMaxSuppressionV4,mn as NonMaxSuppressionV5,Fn as NotEqual,ec as OP_SCOPE_SUFFIX,Be as OneHot,gt as OnesLike,Yc as Optimizer,Pu as OptimizerConstructors,Kt as Pack,tr as PadV2,zl as Pool,T as Pow,Br as Prelu,ot as Prod,Sa as RMSPropOptimizer,cb as RNN,Ar as RaggedGather,Xr as RaggedRange,Xe as RaggedTensorToTensor,It as Range,Eo as Rank,tc as Real,Et as RealDiv,gi as Reciprocal,f as Reduction,oi as Relu,Ei as Relu6,Gn as Reshape,i as ResizeBilinear,Fa as ResizeBilinearGrad,Nc as ResizeNearestNeighbor,Ts as ResizeNearestNeighborGrad,fc as Reverse,wo as RotateWithOffset,qi as Round,Is as Rsqrt,Us as SGDOptimizer,Sc as ScatterNd,ha as SearchSorted,rs as Select,Uc as Selu,$v as Sequential,Ta as Sigmoid,Ga as Sign,Ks as Sin,ms as Sinh,po as Slice,to as Softmax,Ii as Softplus,$c as SpaceToBatchND,Al as SparseFillEmptyRows,ia as SparseReshape,bl as SparseSegmentMean,pr as SparseSegmentSum,ue as SparseToDense,ul as SplitV,wr as Sqrt,je as Square,be as SquaredDifference,En as StaticRegexReplace,Ko as Step,g as StridedSlice,Fo as StringNGrams,an as StringSplit,gn as StringToHashBucketFast,Ln as Sub,He as Sum,sg as SymbolicTensor,vt as Tan,Jt as Tanh,wc as Tensor,_a as TensorBuffer,rr as TensorScatterUpdate,Bl as Tile,ee as TopK,Hr as Transform,ct as Transpose,Mr as Unique,Qr as Unpack,Qe as UnsortedSegmentSum,Rt as UpperBound,as as Variable,rc as ZerosLike,Ot as _FusedMatMul,es as abs,fa as acos,yc as acosh,I as add,Ns as addN,Wi as all,xo as any,lc as argMax,Ss as argMin,Ac as asin,Ma as asinh,a as atan,Kn as atan2,Di as atanh,nr as avgPool,qt as avgPool3d,sl as backend,Vd as backend_util,Po as basicLSTMCell,Go as batchNorm,Tn as batchNorm2d,ye as batchNorm3d,Ae as batchNorm4d,h as batchToSpaceND,Cr as bincount,ll as bitwiseAnd,Rc as booleanMaskAsync,le as broadcastArgs,fr as broadcastTo,di as broadcast_util,Ms as browser,M as buffer,kC as callbacks,F as cast,yl as ceil,kl as clipByValue,lo as clone,Ft as complex,_t as concat,Qc as concat1d,Fi as concat2d,eo as concat3d,fo as concat4d,Rg as constraints,Gs as conv1d,ps as conv2d,wa as conv2dTranspose,Hc as conv3d,ma as conv3dTranspose,Sl as copyRegisteredKernels,xc as cos,Fs as cosh,$s as cosineWindow,Ki as cumprod,Co as cumsum,Oi as customGrad,qw as data,dc as denseBincount,xr as deprecationWarn,ws as depthToSpace,Mc as depthwiseConv2d,bo as deregisterOp,Ti as device_util,Pa as diag,l as dilation2d,Oe as disableDeprecationWarnings,D as dispose,Cn as disposeVariables,N as div,tt as divNoNan,ti as dot,mi as dropout,Fr as einsum,dt as elu,Uo as enableDebugMode,p as enableProdMode,wt as enclosingPowerOfTwo,Mo as engine,Gr as ensureShape,j as env,jt as equal,re as erf,pe as euclideanNorm,gr as exp,Cl as expandDims,sa as expm1,nl as eye,un as fft,ra as fill,tn as findBackend,pn as findBackendFactory,zi as floor,Ha as floorDiv,QI as forceHalfFloat,mt as fused,io as gather,ii as gatherND,uu as gather_util,Pn as getBackend,hr as getGradient,fe as getKernel,fl as getKernelsForBackend,KP as gpgpu_util,Jn as grad,s as grads,go as greater,_s as greaterEqual,Bo as ifft,Ys as imag,oe as image,Pt as inTopKAsync,Ug as initializers,ny as input,da as io,x as irfft,Ja as isFinite,Oa as isInf,Gc as isNaN,ze as keep,Wd as kernel_impls,Nx as layers,os as leakyRelu,va as less,Tc as lessEqual,ol as linalg,zs as linspace,xs as loadGraphModel,cc as loadGraphModelSync,Xv as loadLayersModel,Xi as localResponseNormalization,Do as log,hc as log1p,kt as logSigmoid,zt as logSoftmax,$e as logSumExp,$r as logicalAnd,Nr as logicalNot,lt as logicalOr,Ur as logicalXor,br as losses,Vl as lowerBound,Ve as matMul,lu as math,Ro as max,ir as maxPool,Yt as maxPool3d,yt as maxPoolWithArgmax,Ue as maximum,Rn as mean,ht as memory,Io as meshgrid,nC as metrics,y as min,_ as minimum,qo as mirrorPad,Dn as mod,ey as model,yC as models,xe as moments,n as movingAverage,z as mul,Me as multiRNNCell,Tr as multinomial,li as neg,Lu as nextFrame,pl as norm,dl as notEqual,de as oneHot,on as ones,mr as onesLike,Tt as op,xl as outerProduct,aa as pad,jl as pad1d,el as pad2d,Li as pad3d,no as pad4d,hs as pool,Yo as pow,qs as prelu,ds as print,Ka as prod,Gt as profile,Ea as raggedGather,Wc as raggedRange,is as raggedTensorToTensor,ga as rand,Ls as randomGamma,Ji as randomNormal,To as randomStandardNormal,pc as randomUniform,Es as randomUniformInt,Pc as range,er as ready,Ia as real,d as reciprocal,Rl as registerBackend,ry as registerCallbackConstructor,Er as registerGradient,Ne as registerKernel,Ui as registerOp,bC as regularizers,Qn as relu,Mi as relu6,w as removeBackend,U as reshape,pi as reverse,Ci as reverse1d,Nt as reverse2d,sc as reverse3d,Ut as reverse4d,jn as rfft,rt as round,ri as rsqrt,kn as scalar,Un as scatterND,Zs as scatter_util,te as searchSorted,Lr as selu,pt as separableConv2d,ty as sequential,lr as serialization,zr as setBackend,at as setPlatform,bM as setWebGLContext,qr as setdiff1dAsync,cD as shared,In as sigmoid,ae as sign,De as signal,Gl as sin,cr as sinh,hn as slice,$t as slice1d,Ct as slice2d,qe as slice3d,Hn as slice4d,fu as slice_util,xn as softmax,yi as softplus,mo as spaceToBatchND,_e as sparse,wi as sparseToDense,Sn as spectral,Zo as split,Ce as sqrt,Pe as square,Te as squaredDifference,Ie as squeeze,Or as stack,hl as step,he as stridedSlice,Ho as string,L as sub,O as sum,Yi as sumOutType,vr as tan,rn as tanh,Ye as tensor,Tl as tensor1d,la as tensor2d,Fl as tensor3d,il as tensor4d,Vi as tensor5d,oo as tensor6d,Aa as tensorScatterUpdate,mc as tensor_util,Kl as test_util,A as tidy,Nl as tile,Yr as time,qc as topk,Fu as train,P as transpose,cs as truncatedNormal,ba as unique,Se as unregisterGradient,On as unregisterKernel,Dc as unsortedSegmentSum,Vs as unstack,Rs as upcastType,Qi as upperBound,Ml as util,Ra as valueAndGrad,Ic as valueAndGrads,ko as variable,Os as variableGrads,UW as version,Gd as version_converter,Nu as version_core,lD as version_cpu,gv as version_layers,ZI as version_webgl,$I as webgl,NM as webgl_util,ac as where,As as whereAsync,_n as zeros,Vt as zerosLike};